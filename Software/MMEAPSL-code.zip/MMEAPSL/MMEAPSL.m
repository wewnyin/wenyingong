classdef MMEAPSL < ALGORITHM
% <multi> <real/binary/permutation> <multimodal>
% Growing Neural Gas Network-based Surrogate-assisted Pareto Set Learning for Multimodal Multi-objective Optimization

    methods
        function main(Algorithm,Problem)
            %% Parameters for GNG network
            params.N = Problem.N;
            params.MaxIt = 50;
            params.L = 30;
            params.epsilon_b = 0.2;
            params.epsilon_n = 0.006;
            params.alpha = 0.5;
            params.delta = 0.995;
            params.T = 30;
            genFlag = [];
            MaxGen = ceil(Problem.maxFE/Problem.N);
            netInitialized = 0;
            Pop1get = 0;
            gen = 0;
            
            %% Generate random population
            Population = Problem.Initialization();
            
            %% calculate fitness of populations
            [Fitness,D_Dec,~] = CalFitness(Population.objs,Population.decs);
            
            %% Optimization
            while Algorithm.NotTerminated(Population)
                gen = gen + 1;
                %% Initial the GNG network when can
                if ~netInitialized
                    NDNum = sum(Fitness<1);
                    if NDNum >= 2
                        net = InitilizeGrowingGasNet(Population,params,Fitness);
                        netInitialized = 1;
                        if Problem.D == 2
                            PlotResults(net.w, net.C)
                        elseif Problem.D == 3
                            PlotResults1(net.w, net.C)
                        end
                    end
                end
                
                if ~netInitialized || gen < 0.2 * MaxGen
                    MatingPool = TournamentSelection(2,Problem.N,D_Dec,Fitness);
                    Offspring  = OperatorGA(Population(MatingPool));
                    [Population,Fitness,D_Dec,~,net,genFlag] = EnvironmentalSelectionOrig([Population,Offspring],Problem.N,Problem,params,net,genFlag);
                else
                    if Pop1get == 0
                        Population1 = Population;
                        Fitness1 = CalFitnessSup(Population1.decs,net.w);
                        Pop1get = 1;
                    end
                     % use the network in generating offspring
                    MatingPool1 = TournamentSelection(2,Problem.N,D_Dec,Fitness);
                    Offspring1  = OperatorGAhalf(Population(MatingPool1));
                    V = net.w;
                    MatingPool2 = randi(length(V),1,Problem.N);
                    Offspring2 = SOLUTION(OperatorGAhalf(V(MatingPool2,:)));
                    
                    MatingPool1 = TournamentSelection(2,Problem.N,-Fitness1);
                    Offspring3  = OperatorGAhalf(Population1(MatingPool1));
                    
                    Offspring = [Offspring1,Offspring2,Offspring3];
                    
                    [Population,Fitness,D_Dec,~,net,genFlag] = EnvironmentalSelectionOrig([Population,Offspring],Problem.N,Problem,params,net,genFlag);
                    [Population1,Fitness1] = EnvironmentalSelectionSup([Population1,Offspring],Problem.N,net);
                end
            end
        end
    end
end