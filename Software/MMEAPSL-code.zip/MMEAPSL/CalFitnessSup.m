function D_Dec = CalFitnessSup(PopDec,V)
% Calculate the fitness of each solution of the sup population
    
    %% Calculate D(i)    
    Distance = pdist2(PopDec,V);
    Distance = sort(Distance,2);
    D_Dec = Distance(:,1);
end