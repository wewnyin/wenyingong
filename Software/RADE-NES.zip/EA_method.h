// EA_method.h: interface for the CEA_method class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EA_METHOD_H__E143D832_5285_42F4_AF7D_B4A0D80E75DB__INCLUDED_)
#define AFX_EA_METHOD_H__E143D832_5285_42F4_AF7D_B4A0D80E75DB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "global.h"

#include "./EACommonClass/Individual.h"
#include "./EACommonClass/ProblemDef.h"
#include "./EACommonClass/Rand.h"
#include "./EACommonClass/GenerateMatlab.h"
#include "./EACommonClass/ErrorFunc.h"


#include <direct.h>						// include the mkdir() for folder creation
#define SIZEOFBUFFER	256*1024L 

#define out_internal	30


typedef struct 
{
	CIndividual *ind;
}population;

// Structure of velocity of PSO
struct velocity
{
	int    size;
	double v[MAX_N_of_x];
};

class CEA_method  
{
public:
	CEA_method();
	virtual ~CEA_method();

public:
	void init_variables();
	
	void allocate_memory_pop (population *pop, int size);
	void deallocate_memory_pop (population *pop);
	
	void initialize_ind (CIndividual *ind);
	void initialize_pop (population *pop);

	void evaluate_problem (CIndividual *ind);
	void evaluate_ind (CIndividual *ind);
	void evaluate_pop (population *pop, int size);
	
	double	cal_ecu_dist(double *x, double *y, int n);
	double	cal_ecu_dist_normalized(double *x, double *y, int n);

	void report_pop (population *pop, FILE *fpt);
	void report_final_pop (population *pop, FILE *fpt);
	void report_ind (CIndividual *ind, FILE *fpt);

	void random_index(int *array_index, int all_size, int size);

	void shell_sort_pop(population *pop, int *list, int size);
	void shell_sort_array(double *array, int *list, int size);

	void Run_optimizer(int run_no, double seed, int method, int func_flag, int flag_of_read_data);

	/************************************************************************/
	/* Methods for statistics                                               */
	/************************************************************************/
public:
	int			num_of_seeds;			// number of different optima
	int			seeds_indices[population_size];
	void		get_seeds_indices(population *pop, int size, int *seeds_indices);

	int			num_of_optimal_POF;		// number of the optimal solutions in true POF
	double		POS_data[200][MAX_N_of_x];
	double		POF_data[200][2];
	int			flag_of_true_POF;		// the true POF exists or not
	void		read_POS_data(FILE *fpt);
	void		calculate_POS_data();

	void		get_the_archive();
	int			how_many_optima(CIndividual *pop, int size);
	double		IGD_performance(CIndividual *pop, int size);
	double		IGD_performance_objective(CIndividual *pop, int size);

	void		report_NOF_performance(long int gen, int NOF_rst, double peak_ratio, FILE *fpt);
	void		report_IGD_performance(long int gen, double IGD_rst, FILE *fpt);
	void		report_final_archive(FILE *fpt);

	/************************************************************************/
	/* Methods and attributes for batch execution                           */
	/************************************************************************/
public:
	void	create_folders(int method_ii);					// create the folders
	void	copy_files(char *source, char *target);			// copy files from the source directory to the target directory
	long	filesize(FILE *stream);
	int		copyfile(const char* src,const char* dest);

public:
	int	   opt_method;
	int    popsize;						// size of the population
	int	   gen;							// current generation
	int    ngen;						// maximum generation of the algorithm
	int    max_evaluation;				// maximum fitness function evaluation
	int    neval;						// number of fitness function evaluation
	double min_realvar[MAX_N_of_x];		// lower bounds of the real variables
	double max_realvar[MAX_N_of_x];		// upper bounds of the real variables

	double max_abs_var;

	int	   nreal;						// number of the real variables
	int	   nobj;						// number of the objective functions

	population *parent_pop;				// pointer of the parent population
	population *child_pop;				// pointer of the child population
	population *mixed_pop;				// pointer of the mixed population
	int        child_size;				// size of the child population (max = popsize)
	
	int		   num_of_optima;
	population *optima_pop;				// pointer of the population saving the optimal solution
	
	CIndividual new_child;
	int			sorted_index[5*population_size];

	CIndividual best_indv, worst_indv;
	int         best_index, worst_index;

	double		repulsion_alpha;		// only for the second repulsion technique
	double		repulsion_epsilon;		// only for the second repulsion technique


	// some class objects may be needed in the algorithm
	double			seed;				// seed of the random number generator
	CRand			m_rnd;
	int				m_func;
	CProblemDef		m_ofunc;
	CGenerateMatlab m_mtb; 
	CErrorFunc		m_erf;

	/* for archive population */
	void	QuickSort(CIndividual* ,int ,int);					// sort the archive
	void	report_archive();									// report the archive in the file

	CIndividual m_ArchivePop[MAX_ARCHIVE_SIZE];					// Archive population = MAX_ARCHIVE_SIZE
	int			m_ArchiveSize;									// size of the current archive
	int			m_MaxOrMin[MAX_N_of_obj];						// type of objectives

	/*************************************************************************/
	/* Check the solution whether optimal or not                            */
	/************************************************************************/
	double		weights_x[200];
	int			weights_min_index;
	void		generate_weights(double *a, int n);


	/************************************************************************/
	/* Methods and attributes for SHADE method                              */
	/************************************************************************/
	// Ref: R. Tanabe and A. Fukunaga, Success-History Based Parameter Adaptation for Differential Evolution, CEC-2013, 71-78.
public:
	double	JADE_mu_CR;
	double	JADE_mu_FF;

	int		SHADE_memory_size;
	double	SHADE_M_CR_FF[1000][2];							// The historical memory of CR and F
	
	double	m_CR;
	double	m_FF;

	/************************************************************************/
	/* For NCDE with neighborhood-based mutation                            */
	/************************************************************************/
public:
	int		neighborhood_size;
	int		neighborhood_index[population_size];
	double	dist_t[population_size][population_size];
	
	void	calculate_proximity_prob(population *pop, int size);				// get the neighborhood indices
	void	get_neighborhood_index(int base_index);


	void	run_NCDE_SHADE();

};

#endif // !defined(AFX_EA_METHOD_H__E143D832_5285_42F4_AF7D_B4A0D80E75DB__INCLUDED_)
