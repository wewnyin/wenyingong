// GenerateMatlab.cpp: implementation of the CGenerateMatlab class.
//
//////////////////////////////////////////////////////////////////////


#include "GenerateMatlab.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGenerateMatlab::CGenerateMatlab()
{
}

CGenerateMatlab::~CGenerateMatlab()
{
}

void CGenerateMatlab::GenerateMatlabFile2(char *f_matlab)
{
	int N = 0;
	int i =0, j = 0;
	char temp[100];

	// equals to the number of the objective functions
	double value  = 0.0;
	double value1 = 0.0;

	// ��ȡ�ļ��м�¼�еĸ���
	ifstream indata1("./output/sorted_archive.out");
	while (!indata1.eof())
	{
		indata1.getline(temp,1000);
		N++;
	}
	indata1.close();
	N = N - 1;
	
// 	cout<<N<<endl;

	// Convert result data to matlab file's format
	ofstream outdata(f_matlab);//".\\results\\matlab.m");

	// x
	ifstream indata ("./output/sorted_archive.out");
	outdata<<"clear;clc;"<<endl;

//	outdata<<"x1 = -2:0.1:2;"<<endl;
//	outdata<<"y1 = 1 - x1;"<<endl;
//	outdata<<"plot(x1, y1);"<<endl;
//	outdata<<"hold on"<<endl;

	outdata<<"x = [";
	
	j = 0;
	for (i=0;i<N;i++)
	{
		indata>>value>>value1;
		
		j++;
		outdata<<value<<" ";
		if (j%9 == 0)
		{
			outdata<<"..."<<endl;
		}
		
	}
	outdata<<"]';"<<endl;
	indata.close();

	// y
	ifstream indata2 ("./output/sorted_archive.out");
	outdata<<"y = [";

	j = 0;
	for (i=0;i<N;i++)
	{
		indata2>>value>>value1;
		
		j++;
		outdata<<value1<<" ";
		if (j%9 == 0)
		{
			outdata<<"..."<<endl;
		}
		
	}
	outdata<<"]';"<<endl;
	indata2.close();

	outdata<<"hndl=plot(x,y,'r.');"<<endl;
	outdata<<"set(hndl,'LineWidth',2)"<<endl;
	outdata<<"set(gcf,'Units','centimeters','Position',[10 10 12 9]);"<<endl;	// ����ͼƬ��СΪ11cm*cm, ���(10, 10)
	outdata<<"xlabel('f1','FontSize',10)"<<endl;
	outdata<<"ylabel('f2','FontSize',10)"<<endl;

	printf("The MATLAB file is generated. See file matlab.txt\n");
 	
	outdata.close();
}

void CGenerateMatlab::GenerateMatlabFile3(char *f_matlab)
{
	int N = 0;
	int i =0, j = 0;
	char temp[100];

	// equals to the number of the objective functions
	double value  = 0.0;
	double value1 = 0.0;
	double value2 = 0.0;
	double value3 = 0.0;

	// ��ȡ�ļ��м�¼�еĸ���
	ifstream indata("./output/sorted_archive.out");
	while (!indata.eof())
	{
		indata.getline(temp,1000);
		N++;
	}
	indata.close();
	N = N - 1;
	
	// test: the number of the data items
// 	cout<<N<<endl;

	// Convert result data to matlab file's format
	ofstream outdata(f_matlab);//".\\results\\matlab.m");

	// x = f1
	ifstream indata1 ("./output/sorted_archive.out");
	outdata<<"clear;clc;"<<endl;
	outdata<<"x = [";
	
	j = 0;
	for (i=0;i<N;i++)
	{
		indata1>>value>>value1>>value2;
		
		j++;
		outdata<<value<<" ";
		if (j%9 == 0)
		{
			outdata<<"..."<<endl;
		}
		
	}
	outdata<<"]';"<<endl;
	indata1.close();

	// y = f2
	ifstream indata2 ("./output/sorted_archive.out");
	outdata<<"y = [";

	j = 0;
	for (i=0;i<N;i++)
	{
		indata2>>value>>value1>>value2;
		
		j++;
		outdata<<value1<<" ";
		if (j%9 == 0)
		{
			outdata<<"..."<<endl;
		}
		
	}
	outdata<<"]';"<<endl;
	indata2.close();

	// z = f3
	ifstream indata3 ("./output/sorted_archive.out");
	outdata<<"z = [";

	j = 0;
	for (i=0;i<N;i++)
	{
		indata3>>value>>value1>>value2;
		
		j++;
		outdata.precision(10);
		outdata<<value2<<" ";
		if (j%9 == 0)
		{
			outdata<<"..."<<endl;
		}
		
	}
	outdata<<"]';"<<endl;
	indata3.close();

	outdata<<"hndl=plot3(x,y,z,'r.');"<<endl;
	outdata<<"set(hndl,'LineWidth',2)"<<endl;

	outdata<<"xlabel('f1')"<<endl;
	outdata<<"ylabel('f2')"<<endl;
	outdata<<"zlabel('f3')"<<endl;
	outdata<<"grid on"<<endl;
	
	printf("The MATLAB file is generated. See file matlab.txt\n");
 	
	outdata.close();
}
