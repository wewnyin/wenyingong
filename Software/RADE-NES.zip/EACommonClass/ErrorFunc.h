// ErrorFunc.h: interface for the CErrorFunc class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ERRORFUNC_H__76E78026_87FE_44DE_A419_EAAA0D8ADB87__INCLUDED_)
#define AFX_ERRORFUNC_H__76E78026_87FE_44DE_A419_EAAA0D8ADB87__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../global.h"

class CErrorFunc  
{
public:
	CErrorFunc();
	virtual ~CErrorFunc();

	double q_gamma(double, double, double);
	double p_gamma(double, double, double);

	double erf(double x);		// Error Function 
	double erfc(double x);		// Complementary Error Function
	double erfinv(double x);	// Inverse Error Function


};

#endif // !defined(AFX_ERRORFUNC_H__76E78026_87FE_44DE_A419_EAAA0D8ADB87__INCLUDED_)
