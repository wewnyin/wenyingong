// ErrorFunc.cpp: implementation of the CErrorFunc class.
//
//////////////////////////////////////////////////////////////////////

#include "ErrorFunc.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CErrorFunc::CErrorFunc()
{
}

CErrorFunc::~CErrorFunc()
{
}

/* Incomplete gamma function
   1 / Gamma(a) * Int_0^x exp(-t) t^(a-1) dt  */
double CErrorFunc::p_gamma(double a, double x, double loggamma_a)
{
	int k;
    double result, term, previous;

    if (x >= 1 + a) return 1 - q_gamma(a, x, loggamma_a);
    if (x == 0)     return 0;
    result = term = exp(a * log(x) - x - loggamma_a) / a;
    for (k = 1; k < 1000; k++) {
        term *= x / (a + k);
        previous = result;  result += term;
        if (result == previous) return result;
    }
    fprintf(stderr, "erf.c:%d:p_gamma() could not converge.", __LINE__);
    return result;
}

/* Incomplete gamma function
   1 / Gamma(a) * Int_x^inf exp(-t) t^(a-1) dt  */
double  CErrorFunc::q_gamma(double a, double x, double loggamma_a)
{
	int k;
    double result, w, temp, previous;
    double la = 1, lb = 1 + x - a;  /* Laguerre polynomial */

    if (x < 1 + a) return 1 - p_gamma(a, x, loggamma_a);
    w = exp(a * log(x) - x - loggamma_a);
    result = w / lb;
    for (k = 2; k < 1000; k++) {
        temp = ((k - 1 - a) * (lb - la) + (k + x) * lb) / k;
        la = lb;  lb = temp;
        w *= (k - 1 - a) / k;
        temp = w / (la * lb);
        previous = result;  result += temp;
        if (result == previous) return result;
    }
    fprintf(stderr, "erf.c:%d:q_gamma() could not converge.", __LINE__);
    return result;
}

/************************************************************************/
/* Error Function                                                       */
/************************************************************************/
double CErrorFunc::erf(double x)
{
	if (!finite(x)) 
	{
        if (isnan(x)) return x;      /* erf(NaN)   = NaN   */
        return (x>0 ? 1.0 : -1.0);   /* erf(+-inf) = +-1.0 */
    }
    if (x >= 0) return   p_gamma(0.5, x * x, LOG_PI_OVER_2);
    else        return - p_gamma(0.5, x * x, LOG_PI_OVER_2);
}

/************************************************************************/
/* Complementary Error Function                                         */
/************************************************************************/
double CErrorFunc::erfc(double x)
{
    if (!finite(x)) 
	{
        if (isnan(x)) return x;      /* erfc(NaN)   = NaN      */
        return (x>0 ? 0.0 : 2.0);    /* erfc(+-inf) = 0.0, 2.0 */
    }
    if (x >= 0) return  q_gamma(0.5, x * x, LOG_PI_OVER_2);
    else        return  1 + p_gamma(0.5, x * x, LOG_PI_OVER_2);
}

/************************************************************************/
/* Inverse Error Function                                               */
/************************************************************************/
double CErrorFunc::erfinv(double p)
{
    /* 
       Source: This routine was derived (using f2c) from the 
       FORTRAN subroutine MERFI found in 
       ACM Algorithm 602 obtained from netlib.

       MDNRIS code contains the 1978 Copyright 
       by IMSL, INC. .  Since MERFI has been 
       submitted to netlib, it may be used with 
       the restriction that it may only be 
       used for noncommercial purposes and that
       IMSL be acknowledged as the copyright-holder
       of the code.
     */

    /* Initialized data */
	static double a1 = -.5751703;
    static double a2 = -1.896513;
    static double a3 = -.05496261;
    static double b0 = -.113773;
    static double b1 = -3.293474;
    static double b2 = -2.374996;
    static double b3 = -1.187515;
    static double c0 = -.1146666;
    static double c1 = -.1314774;
    static double c2 = -.2368201;
    static double c3 = .05073975;
    static double d0 = -44.27977;
    static double d1 = 21.98546;
    static double d2 = -7.586103;
    static double e0 = -.05668422;
    static double e1 = .3937021;
    static double e2 = -.3166501;
    static double e3 = .06208963;
    static double f0 = -6.266786;
    static double f1 = 4.666263;
    static double f2 = -2.962883;
    static double g0 = 1.851159e-4;
    static double g1 = -.002028152;
    static double g2 = -.1498384;
    static double g3 = .01078639;
    static double h0 = .09952975;
    static double h1 = .5211733;
    static double h2 = -.06888301;

    /* Local variables */
    static double a, b, f, w, x, y, z, sigma, z2, sd, wi, sn;

    x = p;

    /* determine sign of x */
    if (x > 0)
		sigma = 1.0;
    else
		sigma = -1.0;

    /* Note: -1.0 < x < 1.0 */
    z = fabs(x);

    /* z between 0.0 and 0.85, approx. f by a 
       rational function in z  */

    if (z <= 0.85) 
	{
		z2 = z * z;
		f = z + z * (b0 + a1 * z2 / (b1 + z2 + a2 / (b2 + z2 + a3 / (b3 + z2))));

	/* z greater than 0.85 */
    } 
	else 
	{
		a = 1.0 - z;
		b = z;

		/* reduced argument is in (0.85,1.0), 
		   obtain the transformed variable */

		w = sqrt(-(double) log(a + a * b));

		/* w greater than 4.0, approx. f by a 
		   rational function in 1.0 / w */

		if (w >= 4.0) 
		{
			wi = 1.0 / w;
			sn = ((g3 * wi + g2) * wi + g1) * wi;
			sd = ((wi + h2) * wi + h1) * wi + h0;
			f = w + w * (g0 + sn / sd);

			/* w between 2.5 and 4.0, approx. 
			   f by a rational function in w */

		} 
		else if (w < 4.0 && w > 2.5) 
		{
			sn = ((e3 * w + e2) * w + e1) * w;
			sd = ((w + f2) * w + f1) * w + f0;
			f = w + w * (e0 + sn / sd);

			/* w between 1.13222 and 2.5, approx. f by 
			   a rational function in w */
		} 
		else if (w <= 2.5 && w > 1.13222) 
		{
			sn = ((c3 * w + c2) * w + c1) * w;
			sd = ((w + d2) * w + d1) * w + d0;
			f = w + w * (c0 + sn / sd);
		}
    }

    y = sigma * f;

    return (y);
}