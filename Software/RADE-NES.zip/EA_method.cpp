// EA_method.cpp: implementation of the CEA_method class.
//
//////////////////////////////////////////////////////////////////////

#include "EA_method.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEA_method::CEA_method()
{
	parent_pop		= new population;
	child_pop		= new population;
	mixed_pop		= new population;

	optima_pop      = new population;

	repulsion_alpha = 10.0;
}

CEA_method::~CEA_method()
{
	delete parent_pop;
	delete child_pop;
	delete mixed_pop;

	delete optima_pop;
}

void CEA_method::allocate_memory_pop(population *pop, int size)
{
	pop->ind = new CIndividual[size];
}

void CEA_method::deallocate_memory_pop(population *pop)
{
	delete []pop->ind;
}

void CEA_method::init_variables()
{
	int i;

	CIndividual::N_of_obj	= 1;
	CIndividual::MAX_NFEs	= 50000;
	
	switch(m_func) {
	case 1:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -1.0;
			max_realvar[i] = 1.0;
		}
		break;	
	case 2:		
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 20;
		//CIndividual::MAX_NFEs		  = 200000;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -1.0;
			max_realvar[i] = 1.0;
		}
		break;	
	case 3:		
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -1.0;
			max_realvar[i] = 1.0;
		}
		break;	
	case 4:	
		CIndividual::num_of_equations = 2;	
		CIndividual::N_of_x           = 2;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -1.0;
			max_realvar[i] = 1.0;
		}
		break;	
	case 5:		
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 3;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -1.0;
			max_realvar[i] = 1.0;
		}
		break;	
	case 6:	
		CIndividual::num_of_equations = 6;
		CIndividual::N_of_x           = 6;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -1.0;
			max_realvar[i] = 1.0;
		}
		break;
	case 7:	
		CIndividual::num_of_equations = 20;	
		CIndividual::N_of_x           = 20;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -1.0;
			max_realvar[i] = 1.0;
		}
		break;
	case 8:	
		CIndividual::MAX_NFEs		  = 500000;
		CIndividual::num_of_equations = 4;
		CIndividual::N_of_x           = 4;
		for(i = 0; i < CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -2.0;
			max_realvar[i] = 2.0;
		}
		break;
	case 9:	
		CIndividual::MAX_NFEs		  = 50000;	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;	
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -10.0;
			max_realvar[i] = 10.0;
		}
		break;
	case 10:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -10.0;
			max_realvar[i] = 10.0;
		}
		break;
	case 11:	
		CIndividual::num_of_equations = 10;
		CIndividual::N_of_x           = 10;
		for(i = 0; i < CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -2.0;
			max_realvar[i] = 2.0;
		}
		break;
	case 12:
		CIndividual::MAX_NFEs		  = 200000;	
		CIndividual::num_of_equations = 5;
		CIndividual::N_of_x           = 5;
//		for (i=0; i<CIndividual::N_of_x; i++)
//		{
//			min_realvar[i] = 0.001;
//			max_realvar[i] = 100.0;
//		}
		min_realvar[0] = 0.001;
		max_realvar[0] = 0.1;
		min_realvar[1] = 0;
		max_realvar[1] = 40;
		min_realvar[2] = 0.001;
		max_realvar[2] = 0.1;
		min_realvar[3] = 0.001;
		max_realvar[3] = 1;
		min_realvar[4] = 0.001;
		max_realvar[4] = 1;
		break;	
	case 13:	
		CIndividual::num_of_equations = 10;
		CIndividual::N_of_x           = 10;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -10.0;
			max_realvar[i] = 10.0;
		}
		break;	
	case 14:
		CIndividual::MAX_NFEs		  = 500000;		
		CIndividual::num_of_equations = 8;
		CIndividual::N_of_x           = 8;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -10.0;
			max_realvar[i] = 10.0;
		}
		break;
	case 15:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -1.0;
			max_realvar[i] = 1.0;
		}
		break;
	case 16:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		min_realvar[0] = 0;
		max_realvar[0] = 1;
		min_realvar[1] = -10;
		max_realvar[1] = 0;
		break;
	case 17:	
		CIndividual::num_of_equations = 4;
		CIndividual::N_of_x           = 4;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = 0.0;
			max_realvar[i] = 5.0;
		}
		break;
	case 18:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = 0.0;
			max_realvar[i] = 1.0;
		}
		break;
	case 19:	
		CIndividual::num_of_equations = 3;
		CIndividual::N_of_x           = 3;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = 0.0;
			max_realvar[i] = 100.0;
		}
		break;
	case 20:
		CIndividual::MAX_NFEs		  = 100000;
		CIndividual::num_of_equations = 5;
		CIndividual::N_of_x           = 5;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -10.0;
			max_realvar[i] = 10.0;
		}
		break;
	case 21:	
		CIndividual::num_of_equations = 6;
		CIndividual::N_of_x           = 6;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -1.0;
			max_realvar[i] = 1.0;
		}
		break;
	case 22:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		min_realvar[0] = 0;
		max_realvar[0] = 2.5;
		min_realvar[1] = -4;
		max_realvar[1] = 6;
		break;
	case 23:	
		CIndividual::num_of_equations = 3;
		CIndividual::N_of_x           = 3;
		min_realvar[0] = -5;
		max_realvar[0] = 5;
		min_realvar[1] = -1;
		max_realvar[1] = 3;
		min_realvar[2] = -5;
		max_realvar[2] = 5;
		break;
	case 24:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		min_realvar[0] = -1;
		max_realvar[0] = 1;
		min_realvar[1] = -10;
		max_realvar[1] = 10;
		break;
	case 25:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -2;
			max_realvar[i] = 2;
		}
		break;
	case 26:	
		CIndividual::num_of_equations = 3;
		CIndividual::N_of_x           = 3;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = 0;
			max_realvar[i] = 1;
		}
		break;
	case 27:	
		CIndividual::num_of_equations = 3;
		CIndividual::N_of_x           = 3;
		min_realvar[0] = -0.6;
		max_realvar[0] = 6;
		min_realvar[1] = -0.6;
		max_realvar[1] = 0.6;
		min_realvar[2] = -5;
		max_realvar[2] = 5;
		break;
	case 28:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -5;
			max_realvar[i] = 5;
		}
		break;
	case 29:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		min_realvar[0] = 0.25;
		max_realvar[0] = 1.0;
		min_realvar[1] = 1.5;
		max_realvar[1] = 2*PI;
		break;
	case 30:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = 0;
			max_realvar[i] = 2*PI;
		}
		break;
	case 31:
		CIndividual::MAX_NFEs		  = 100000;
		CIndividual::num_of_equations = 8;
		CIndividual::N_of_x           = 8;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -1.0;
			max_realvar[i] = 1.0;
		}
		break;
	case 32:	
		CIndividual::num_of_equations = 3;
		CIndividual::N_of_x           = 3;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = 0.06;
			max_realvar[i] = 1.0;
		}
		break;
	case 33:	
		CIndividual::num_of_equations = 3;
		CIndividual::N_of_x           = 3;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -10.0;
			max_realvar[i] = 10.0;
		}
		break;
	case 34:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -2.0;
			max_realvar[i] = 2.0;
		}
		break;
	case 35:
		CIndividual::MAX_NFEs		  = 200000;
		CIndividual::num_of_equations = 20;
		CIndividual::N_of_x           = 20;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -2.0;
			max_realvar[i] = 2.0;
		}
		break;
	case 36:	
		CIndividual::num_of_equations = 4;
		CIndividual::N_of_x           = 4;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = 0.0;
			max_realvar[i] = 1.0;
		}
		break;
	case 37:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -4.0;
			max_realvar[i] = 4.0;
		}
		break;

	case 38:	
		CIndividual::num_of_equations = 3;
		CIndividual::N_of_x           = CIndividual::num_of_equations;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -1.0;
			max_realvar[i] = 1.0;
		}
		break;
		
	case 39:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		min_realvar[0] = -2.0;
		max_realvar[0] = 2.0;
		min_realvar[1] = -2.0;
		max_realvar[1] = 2.0;
		break;
	case 40:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -2.0;
			max_realvar[i] = 2.0;
		}
		break;
		
	case 41:
		CIndividual::num_of_equations = 10;
		CIndividual::N_of_x           = 10;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -1.0;
			max_realvar[i] = 0.0;
		}
		break;
		
	case 42:
		CIndividual::MAX_NFEs		  = 500000;	
		CIndividual::num_of_equations = 3;
		CIndividual::N_of_x           = 3;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -20.0;
			max_realvar[i] = 20.0;
		}
		break;
		
	case 43:
		CIndividual::MAX_NFEs		  = 100000;
		CIndividual::num_of_equations = 3;
		CIndividual::N_of_x           = 3;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = 0.0;
			max_realvar[i] = 1.0;
		}
		break;
		
	case 44:
	case 45:
		CIndividual::MAX_NFEs		  = 100000;
		CIndividual::num_of_equations = 3;
		CIndividual::N_of_x           = 3;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -3.0;
			max_realvar[i] = 3.0;
		}
		break;
		
	case 46:
		CIndividual::num_of_equations = 1;
		CIndividual::N_of_x           = CIndividual::num_of_equations;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -1;
			max_realvar[i] = 1;
		}
		break;
	
	case 50:	
		CIndividual::num_of_equations = 3;
		CIndividual::N_of_x           = 3;
		min_realvar[0] = 3;
		max_realvar[0] = 5;
		min_realvar[1] = 2;
		max_realvar[1] = 4;
		min_realvar[2] = 0.5;
		max_realvar[2] = 2.0;
		break;
	case 51:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		min_realvar[0] = -1;
		max_realvar[0] = -0.1;
		min_realvar[1] = -2;
		max_realvar[1] = 2;
		break;
	case 52:	
		CIndividual::num_of_equations = 3;
		CIndividual::N_of_x           = 3;
		//CIndividual::MAX_NFEs		  = 200000;
		min_realvar[0] = 1;
		max_realvar[0] = 2.5;
		min_realvar[1] = 0.2;
		max_realvar[1] = 2;
		min_realvar[2] = 0.1;
		max_realvar[2] = 3;
		break;
	case 53:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		min_realvar[0] = -5;
		max_realvar[0] = 1.5;
		min_realvar[1] = -0.5;
		max_realvar[1] = 5;
		break;
	case 54:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		//CIndividual::MAX_NFEs		  = 200000;
		min_realvar[0] = 0;
		max_realvar[0] = 2;
		min_realvar[1] = 10;
		max_realvar[1] = 30;
		break;
	case 55:	
		CIndividual::num_of_equations = 3;
		CIndividual::N_of_x           = 3;
		//CIndividual::MAX_NFEs		  = 200000;
		min_realvar[0] = 0;
		max_realvar[0] = 2;
		min_realvar[1] = -10;
		max_realvar[1] = 10;
		min_realvar[2] = -1;
		max_realvar[2] = 1;
		break;
	case 56:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		//CIndividual::MAX_NFEs		  = 200000;
		min_realvar[0] = -2;
		max_realvar[0] = 2;
		min_realvar[1] = 0;
		max_realvar[1] = 1.1;
		break;
	case 57:
		CIndividual::num_of_equations = 3;
		CIndividual::N_of_x           = CIndividual::num_of_equations;
		//CIndividual::MAX_NFEs		  = 200000;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -1;
			max_realvar[i] = 1;
		}
		break;
		
	case 61:
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = CIndividual::num_of_equations;
		CIndividual::MAX_NFEs		  = 30000;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -3;
			max_realvar[i] = 3;
		}
		break;
	case 62:
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = CIndividual::num_of_equations;
		CIndividual::MAX_NFEs		  = 150000;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -3;
			max_realvar[i] = 3;
		}
		break;
	case 63:
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = CIndividual::num_of_equations;
		CIndividual::MAX_NFEs		  = 300000;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -5;
			max_realvar[i] = 5;
		}
		break;
	case 64:
		CIndividual::num_of_equations = 3;
		CIndividual::N_of_x           = CIndividual::num_of_equations;
		CIndividual::MAX_NFEs		  = 300000;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = 0;
			max_realvar[i] = 50;
		}
		break;
	case 65:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		CIndividual::MAX_NFEs		  = 150000;
		min_realvar[0] = 0.25;
		max_realvar[0] = 1.0;
		min_realvar[1] = 1.5;
		max_realvar[1] = 2*PI;
		break;
	case 66:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		CIndividual::MAX_NFEs		  = 60000;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = 0;
			max_realvar[i] = 2*PI;
		}
		break;
	case 67:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		CIndividual::MAX_NFEs		  = 300000;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = 0.0;
			max_realvar[i] = 1.0;
		}
		break;
	case 68:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		CIndividual::MAX_NFEs		  = 60000;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -3.0;
			max_realvar[i] = 3.0;
		}
		break;
	case 69:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		CIndividual::MAX_NFEs		  = 300000;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -3.0;
			max_realvar[i] = 3.0;
		}
		break;
	case 70:	
		CIndividual::num_of_equations = 3;
		CIndividual::N_of_x           = 3;
		CIndividual::MAX_NFEs		  = 150000;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = 0.0;
			max_realvar[i] = 1.0;
		}
		break;
	case 71:	
		CIndividual::num_of_equations = 2;
		CIndividual::N_of_x           = 2;
		CIndividual::MAX_NFEs		  = 150000;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -1.0;
			max_realvar[i] = 2.0;
		}
		break;
	case 72:	
		CIndividual::num_of_equations = 1;
		CIndividual::N_of_x           = 1;
		CIndividual::MAX_NFEs		  = 150000;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -1.0;
			max_realvar[i] = 1.0;
		}
		break;
	case 73:	
		CIndividual::num_of_equations = 1;
		CIndividual::N_of_x           = 1;
		CIndividual::MAX_NFEs		  = 150000;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -50.0;
			max_realvar[i] = 50.0;
		}
		break;

	case 81:	
		CIndividual::num_of_equations = 9;
		CIndividual::N_of_x           = 9;
		CIndividual::MAX_NFEs		  = 5000000;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -PI;
			max_realvar[i] = PI;
		}
		break;

	case 91:	
		CIndividual::num_of_equations = 8;
		CIndividual::N_of_x           = 8;
		CIndividual::MAX_NFEs		  = 100000;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -3;
			max_realvar[i] = 3;
		}
// 		min_realvar[0] = -3;
// 		max_realvar[0] = -2.5;
		break;
	case 92:	
		CIndividual::num_of_equations = 9;
		CIndividual::N_of_x           = 9;
		CIndividual::MAX_NFEs		  = 500000;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -2;
			max_realvar[i] = 2;
		}
		break;
		
	case 96:	
		CIndividual::num_of_equations = 4;
		CIndividual::N_of_x           = 4;
		CIndividual::MAX_NFEs		  = 100000;
		for (i=0; i<CIndividual::N_of_x; i++)
		{
			min_realvar[i] = -1;
			max_realvar[i] = 40;
		}
		min_realvar[3] = 0;
		max_realvar[3] = 40;
		break;
	default:
		printf("The function does not exist in init_variables()!\n");
		exit(0);
	}

	/* initialize some global parameters */
	popsize			= population_size;
	max_evaluation	= CIndividual::MAX_NFEs;
	ngen			= (max_evaluation)/popsize;
	
	nreal			= CIndividual::N_of_x;
	nobj			= CIndividual::N_of_obj;

	child_size		= 0;

	repulsion_alpha		= 10.0;
	repulsion_epsilon	= 1e-10;

	for (i=0;i<CIndividual::N_of_obj;i++)
	{
		m_MaxOrMin[i] = 1;					// 1:min; -1:max
	}

	double temp1, temp2;
	temp1 = temp2 = -INF;
	for (i=0; i<nreal; i++)
	{
		if (temp1 < fabs(min_realvar[i]))
		{
			temp1 = fabs(min_realvar[i]);
		}
		if (temp2 < fabs(max_realvar[i]))
		{
			temp2 = fabs(max_realvar[i]);
		}
	}
	max_abs_var = (temp1 > temp2) ? temp1 : temp2;
}

void CEA_method::initialize_ind(CIndividual *ind)
{
	int j;
	for (j=0; j<nreal; j++)
	{
		ind->xreal[j] = m_rnd.rndreal (min_realvar[j], max_realvar[j]);
	}
	return;
}

void CEA_method::initialize_pop(population *pop)
{
	int i;
	for (i=0; i<popsize; i++)
	{
		initialize_ind (&(pop->ind[i]));
	}

// 	double x[MAX_N_of_x] = {-0.10002985383902,	-0.42781123484657,
// 		0.09764987505113,	0.51484610962593,	1.28815389037407,	-0.18681610962593,	0.81995791876134,	0.00057551532619,	-0.09282189473363};
// 	for (i=0; i<nreal; i++)
// 	{
// 		pop->ind[0].xreal[i] = x[i];
// 	}

	return;
}

void CEA_method::evaluate_pop(population *pop, int size)
{
	int i;
	for (i=0;i<size;i++)
	{
		evaluate_problem(&pop->ind[i]);
		evaluate_ind(&pop->ind[i]);
	}
	return;
}

void CEA_method::evaluate_problem(CIndividual *indv)
{
	m_ofunc.evaluate_problem(indv->xreal, indv->f_e_f, indv->sum_f_e_f, m_func);
	
	neval++;
}

void CEA_method::evaluate_ind(CIndividual *indv)
{
	//evaluate_problem(indv);
	
	/************************************************************************/
	/* Transformed function                                                 */
	/************************************************************************/
	int		i = 0;

	if ( m_ArchiveSize==0 || (opt_method>2 && opt_method<7) || (opt_method==28) )		// for method that does not use the repulsion technique
	{// the archive size is empty
		indv->obj[0] = indv->sum_f_e_f;
	}
	else
	{// repulsion is used
		double tmp_dist;
		double penalty = 0.0;
		double xi = 0.0;

		/************************************************************************/
		/* For the first repulsion technique                                    */
		/************************************************************************/
		/*double beta = 1000.0;
		double rho  = 0.01;
		if (nreal>5)
		{
			rho = 0.1;
		}

		for (i=0; i<m_ArchiveSize; i++)
		{
			tmp_dist = cal_ecu_dist(indv->xreal, m_ArchivePop[i].xreal, nreal);
			xi		 = (tmp_dist <= rho) ? 1.0 : 0.0;
			penalty += exp(-tmp_dist)*xi;
		}
		penalty     *= beta;
		indv->obj[0] = indv->sum_f_e_f + penalty;*/

		/************************************************************************/
		/* For the second repulsion technique                                   */
		/************************************************************************/
		double alpha	= repulsion_alpha;			//alpha = 1.0 + 19.0*((double)gen/ngen);
		double epsilon	= repulsion_epsilon;		// 1e-10, default value
		penalty = 1.0;
		for (i=0; i<m_ArchiveSize; i++)
		{
			tmp_dist = cal_ecu_dist(indv->xreal, m_ArchivePop[i].xreal, nreal);
			//tmp_dist = cal_ecu_dist_normalized(indv->xreal, m_ArchivePop[i].xreal, nreal);
			penalty *= fabs(1.0/tanh(alpha*tmp_dist));
		}
		indv->obj[0] = (indv->sum_f_e_f+epsilon) * penalty;

		/************************************************************************/
		/* For the third repulsion technique                                    */
		/***********************************************************************
		double delta = 0.1;
		double rho1  = max_realvar[0] - min_realvar[0];
		double temp_rho;
		for (i=0;i<nreal; i++)
		{
			temp_rho = max_realvar[i] - min_realvar[i];
			if (temp_rho < rho1)
			{
				rho1 = temp_rho;
			}
		}
		rho1 = 0.1*rho1;

		penalty = 1.0;
		for (i=0; i<m_ArchiveSize; i++)
		{
			tmp_dist = cal_ecu_dist(indv->xreal, m_ArchivePop[i].xreal, nreal);
			//tmp_dist = cal_ecu_dist_normalized(indv->xreal, m_ArchivePop[i].xreal, nreal);
			xi		 = (tmp_dist <= rho1) ? ( fabs(1.0/m_erf.erf(delta*tmp_dist)) ) : 1.0;
			//xi		 = fabs( 1.0/m_erf.erf(delta*tmp_dist) );
			penalty *= xi;
		}
		indv->obj[0] = (indv->sum_f_e_f) * penalty;*/
	}
}

double CEA_method::cal_ecu_dist(double *x, double *y, int n)
{
	double rst = 0.0;
	int    i;
	double a, b;
	for (i=0; i<n; i++)
	{
		a   = x[i];
		b   = y[i];
		rst += (a-b)*(a-b);
	}
	rst = sqrt(rst);

	return rst;
}

double CEA_method::cal_ecu_dist_normalized(double *x, double *y, int n)
{
	double rst = 0.0;
	int    i;
	double a, b;
	double low, upp;
	for (i=0; i<n; i++)
	{
		low = min_realvar[i];
		upp = max_realvar[i];
		a   = (x[i]-low)/(upp-low);
		b   = (y[i]-low)/(upp-low);
		rst += (a-b)*(a-b);
	}
	rst = sqrt(rst);

	return rst;
}

void CEA_method::random_index(int *array_index, int all_size, int size)
{
	int i,j,krand;
	int *a;
	a = new int[all_size];

	for(i = 0;i<all_size;i++)
	{
		a[i] = i;
	}
	for(i=0;i<size;i++)
	{
		j     = m_rnd.rndint(i,(all_size-1));
		krand = a[i];
		a[i]  = a[j];
		a[j]  = krand;
	}	
	for(i=0;i<size;i++)
	{
		array_index[i] = a[i];
	}

	//a = NULL;
	delete []a;
}

/* Function to print the information of a population in a file */
void CEA_method::report_pop (population *pop, FILE *fpt)
{
    int i, j;
    for (i=0; i<popsize; i++)
    {
        for (j=0; j<nreal; j++)
		{
			fprintf(fpt,"%e\t", pop->ind[i].xreal[j]);
		}		
	   fprintf(fpt,"%e\n", pop->ind[i].sum_f_e_f);

        /*for (j=0; j<CIndividual::N_of_obj; j++)
        {
            fprintf(fpt,"%e\t", m_MaxOrMin[j] * pop->ind[i].obj[j]);
        }*/
		//fprintf(fpt,"%e\n", pop->ind[i].sum_f_e_f);
        //fprintf(fpt,"%d\t", pop->ind[i].rank);
        //fprintf(fpt,"%e\n", pop->ind[i].crowd_dist);
    }
    return;
}

void CEA_method::report_final_pop (population *pop, FILE *fpt)
{
    int i, j;
    for (i=0; i<popsize; i++)
    {
       for (j=0; j<CIndividual::N_of_obj; j++)
	   {
		   fprintf(fpt,"%e\t", m_MaxOrMin[j] * pop->ind[i].obj[j]);
	   }
	   fprintf(fpt,"\n");
    }
    return;
}

void CEA_method::QuickSort(CIndividual* Individual,int left,int right)
{
	int i,j;
	double pivot;					
	CIndividual temp;				

	i=left;
	j=right+1;						
	pivot=Individual[left].obj[0];	
	
	if(i<j)
	{
		do 
		{
			do 
			{
				i++;
			} while(Individual[i].obj[0]<=pivot && i<= right);
			do 
			{
				j--;
			} while(Individual[j].obj[0]>=pivot && j>left);
			if(i<j)
			{
				temp=Individual[i];
				Individual[i]=Individual[j];
				Individual[j]=temp;
			}
		} while(i<j);
		
		temp = Individual[left];
		Individual[left] = Individual[j];
		Individual[j] = temp;
		
		QuickSort(Individual,left,j-1);
		QuickSort(Individual,j+1,right);
	}
}

void CEA_method::shell_sort_pop(population *pop, int *list, int size)
{
	int done;
	int step, bound, i, j;
	int temp;

	for (i=0;i<size;i++)
	{
		list[i] = i;
	}

	step = size;  // array length
	while (step > 1) 
	{
		step /= 2;	//halve the step size
		do 
		{
			done   = 1;
			bound  = size - step;
			for (j = 0; j < bound; j++) 
			{
				i = j + step + 1;
				if (pop->ind[list[j]].obj[0] > pop->ind[list[i-1]].obj[0]) 	
				//if (pop->ind[list[j]].sum_f_e_f > pop->ind[list[i-1]].sum_f_e_f) 
				{
					temp      = list[i-1];
					list[i-1] = list[j];
					list[j]   = temp;
					done      = 0; // if a swap has been made we are not finished yet
				}  // if
			}  // for
		} while (done == 0);   // while
	} //while (step > 1)
}

void CEA_method::shell_sort_array(double *array, int *list, int size)
{
	int done;
	int step, bound, i, j;
	int temp;

	for (i=0;i<size;i++)
	{
		list[i] = i;
	}

	step = size;  // array length
	while (step > 1) 
	{
		step /= 2;	//halve the step size
		do 
		{
			done   = 1;
			bound  = size - step;
			for (j = 0; j < bound; j++) 
			{
				i = j + step + 1;
				if (array[list[j]] > array[list[i-1]]) 	
				{
					temp      = list[i-1];
					list[i-1] = list[j];
					list[j]   = temp;
					done      = 0; // if a swap has been made we are not finished yet
				}  // if
			}  // for
		} while (done == 0);   // while
	} //while (step > 1)
}

void CEA_method::generate_weights(double *a, int n)
{	
	int    i;	

	/*double mm   = 0.05;
	
	double MaxA = 1.0-mm;
	double MinA = mm;
	double sumA;
	double tmpMin, tmpMax, mt1;
	
	sumA = 0.0;
	for(i=0; i<n-1; i++)
	{
		mt1;
		mt1=n-i;
		tmpMin=1-sumA-MaxA*mt1;
		tmpMax=1-sumA-MinA*mt1;
		if(tmpMin<MinA)
			tmpMin=MinA;
		if(tmpMax>MaxA)
			tmpMax=MaxA;
		a[i]=m_rnd.rndreal(tmpMin, tmpMax);
		sumA=sumA+a[i];
	}
	a[n-1] = 1.0-sumA;*/

//	double mm   = 1.0/n;
//	for(i=0; i<n; i++)
//	{
//		/*a[i] = m_rnd.rndreal(1.0, 2.0);*/
//		do {
//			a[i] = m_rnd.gaussian(mm, 1);
//		} while(a[i]<mm);
//	}

	int  rnd_index[MAX_N_of_x];
	random_index(rnd_index, n, n);
	double mm = 0.99/n;
	for(i=0; i<n; i++)
	{
		a[rnd_index[i]] = m_rnd.rndreal(1.001+i*mm, 1.001+(i+1)*mm);
	}


//	for(i=0; i<n; i++)
//	{
//		a[i] = m_rnd.rndreal(0.1, 1.0);
//	}

	
	/////////////////////////////////////////////////////////////////////////////
	weights_min_index = 0;
	double tmp        = a[0];
	for (i=1; i<n; i++)
	{
		if (tmp > a[i])
		{
			weights_min_index = i;
			tmp               = a[i];
		}
	}

//	printf("\n**********************************************************************\n");
//	printf("The weights are: \n");
//	for (i=0; i<n; i++)
//	{
//		printf("%f\t", a[i]);
//		if ((i+1)%5==0)
//		{
//			printf("\n");
//		}
//	}
//	printf("%f\n", a[weights_min_index]);
//	printf("\n**********************************************************************\n\n");
}

void CEA_method::get_seeds_indices(population *pop, int size, int *seeds_indices)
{	
	double radius = 0.01;

	shell_sort_pop(pop, sorted_index, size);

	/* remove any forgotten items in the seed list */
	num_of_seeds = 0;	

	/* Determine the species seeds: iterate through sorted population */
	int i, j;
	for (i=0; i<size; i++) {
		//if (pop->ind[sorted_index[i]].sum_f_e_f>0.2) continue;
		int found = 0;
		/* Iterate seeds */
		for (j=0; j<num_of_seeds; j++) {
			/* Calculate distance from seeds */
			double dist = cal_ecu_dist(pop->ind[sorted_index[i]].xreal, pop->ind[seeds_indices[j]].xreal, nreal);
			
			/* If the Euclidean distance is less than the radius */
			if (dist <= radius) {
				found = 1;
				break;
			}
		} //seeds

		/* If it is not similar to any other seed, then it is a new seed */
		if (!found) {
			seeds_indices[num_of_seeds] = sorted_index[i];
			num_of_seeds++;
		}
	} //pop
}

void CEA_method::read_POS_data(FILE *fpt)
{
	int i, j;

	fscanf(fpt, "%d", &num_of_optimal_POF);

	for (i=0; i<num_of_optimal_POF; i++)
	{
		for (j=0; j<nreal; j++)
		{
			fscanf(fpt, "%Lf", &POS_data[i][j]);
		}
	}
}

void CEA_method::calculate_POS_data()
{	
	return;
}

/*void CEA_method::get_the_archive()
{
	int		i, j;
	double	dist1, dist2, dist_threhold;

	dist_threhold = (nreal>5)?0.01:0.001;

	//m_ArchiveSize = 0;

	double			delta_e = 1.0e-6;
	if (nreal>5)	delta_e = 1.0e-4;				/// important to the quality of final solutions

	for (i = 0; i < num_of_seeds; i++)
	{
		int k = seeds_indices[i];
		
		if (parent_pop->ind[k].obj[0] < delta_e)
		{
			if (m_ArchiveSize==0)
			{			
				m_ArchivePop[m_ArchiveSize] = parent_pop->ind[k];
				m_ArchiveSize++;
			}
			else
			{
				if (m_ArchiveSize < popsize)
				{			
					m_ArchivePop[m_ArchiveSize] = parent_pop->ind[k];
					m_ArchiveSize++;
				}
				else
				{
					int j_index = 0;
					dist1 = cal_ecu_dist(m_ArchivePop[0].xreal, parent_pop->ind[k].xreal, nreal);
					for (j=1; j<m_ArchiveSize; j++)
					{
						dist2 = cal_ecu_dist(m_ArchivePop[j].xreal, parent_pop->ind[k].xreal, nreal);
						if (dist2 < dist1)
						{// find the minimal distance in the decision space
							dist1	= dist2;
							j_index	= j;
						}
					}
					if (parent_pop->ind[k].sum_f_e_f < m_ArchivePop[j_index].sum_f_e_f)
					{
						m_ArchivePop[j_index] = parent_pop->ind[k];
					}
				}
			}
		}
	}
}*/


void CEA_method::get_the_archive()
{
	int		i, j;
	double	dist1, dist2, dist_threhold;

	dist_threhold = (nreal>5)?0.01:0.001;

	//m_ArchiveSize = 0;

	double			delta_e = 1.0e-6;
	if (nreal>5)	delta_e = 1.0e-4;				/// important to the quality of final solutions

	for (i = 0; i < num_of_seeds; i++)
	{
		int k = seeds_indices[i];
		
		if (parent_pop->ind[k].sum_f_e_f < delta_e)
		{
			if (m_ArchiveSize==0)
			{			
				m_ArchivePop[m_ArchiveSize] = parent_pop->ind[k];
				m_ArchiveSize++;
			}
			else
			{
				int j_index = 0;
				dist1 = cal_ecu_dist(m_ArchivePop[0].xreal, parent_pop->ind[k].xreal, nreal);
				for (j=1; j<m_ArchiveSize; j++)
				{
					dist2 = cal_ecu_dist(m_ArchivePop[j].xreal, parent_pop->ind[k].xreal, nreal);
					if (dist2 < dist1)
					{// find the minimal distance in the decision space
						dist1	= dist2;
						j_index	= j;
					}
				}

				if (dist1 < dist_threhold)
				{// the two solution is too close, replace the worse one
					if (parent_pop->ind[k].sum_f_e_f < m_ArchivePop[j_index].sum_f_e_f)
					{
						m_ArchivePop[j_index] = parent_pop->ind[k];
					}
				}
				else
				{
					if (m_ArchiveSize < 100)		// popsize, MAX_ARCHIVE_SIZE
					{			
						m_ArchivePop[m_ArchiveSize] = parent_pop->ind[k];
						m_ArchiveSize++;
					}
					else
					{
						int j_index = 0;
						dist1 = cal_ecu_dist(m_ArchivePop[0].xreal, parent_pop->ind[k].xreal, nreal);
						for (j=1; j<m_ArchiveSize; j++)
						{
							dist2 = cal_ecu_dist(m_ArchivePop[j].xreal, parent_pop->ind[k].xreal, nreal);
							if (dist2 < dist1)
							{// find the minimal distance in the decision space
								dist1	= dist2;
								j_index	= j;
							}
						}
						if (parent_pop->ind[k].sum_f_e_f < m_ArchivePop[j_index].sum_f_e_f)
						{
							m_ArchivePop[j_index] = parent_pop->ind[k];
						}
					}
				}
			}

			// re-initialize the individual
// 			for (j=0; j<nreal; j++)
// 			{
// 				parent_pop->ind[k].xreal[j] = m_rnd.rndreal(min_realvar[j], max_realvar[j]);
// 			}
// 			evaluate_ind(&parent_pop->ind[k]);
// 			evaluate_problem(&parent_pop->ind[k]);
		}
	}
}

// get the number of optima in the decision space
int CEA_method::how_many_optima(CIndividual *pop, int size)
{
	int		rst = 0;
	int		i, j;
	double	dist1, dist2;
	double	dist_threshold = 0.1;//0.01

	if (nreal>5)	dist_threshold = 0.1;

	if (1)//num_of_optimal_POF <= size)
	{
		for (i=0; i<num_of_optimal_POF; i++)
		{
			dist1 = cal_ecu_dist(POS_data[i], pop[0].xreal, nreal);
			for (j=1; j<size; j++)
			{
				dist2 = cal_ecu_dist(POS_data[i], pop[j].xreal, nreal);
				if (dist2 < dist1)
				{// find the minimal distance in the objective space
					dist1 = dist2;
				}
			}
			if (dist1 < dist_threshold)
			{
				rst++;
			}
		}
	}
	else
	{
		for (i=0; i<size; i++)
		{
			dist1 = cal_ecu_dist(POS_data[0], pop[i].xreal, nreal);
			for (j=1; j<num_of_optimal_POF; j++)
			{
				dist2 = cal_ecu_dist(POS_data[j], pop[i].xreal, nreal);
				if (dist2 < dist1)
				{// find the minimal distance in the objective space
					dist1 = dist2;
				}
			}
			if (dist1 < dist_threshold)
			{
				rst++;
			}
		}
	}

	return rst;
}

// calculate the IGD performance in the decision space
double CEA_method::IGD_performance(CIndividual *pop, int size)
{
	if (size==0)	return -1;
	
	double rst = 0.0;

	int		i, j;
	double	dist1, dist2;

	for (i=0; i<num_of_optimal_POF; i++)
	{
		dist1 = cal_ecu_dist(POS_data[i], pop[0].xreal, nreal);
		for (j=1; j<size; j++)
		{
			dist2 = cal_ecu_dist(POS_data[i], pop[j].xreal, nreal);
			if (dist2 < dist1)
			{// find the minimal distance in the objective space
				dist1 = dist2;
			}
		}
			
		rst += dist1;
	}

	rst /= (double)num_of_optimal_POF;

	return rst;
}

// calculate the IGD performance in the objective space
double CEA_method::IGD_performance_objective(CIndividual *pop, int size)
{
	double rst = 0.0;

	int		i, j;
	double	dist1, dist2;

	for (i=0; i<num_of_optimal_POF; i++)
	{
		dist1 = cal_ecu_dist(POF_data[i], pop[0].obj, 2);
		for (j=1; j<size; j++)
		{
			dist2 = cal_ecu_dist(POF_data[i], pop[j].obj, 2);
			if (dist2 < dist1)
			{// find the minimal distance in the objective space
				dist1 = dist2;
			}
		}
			
		rst += dist1;
	}
	
	rst /= (double)num_of_optimal_POF;

	return rst;
}

// report the NOF performance in the file
void CEA_method::report_NOF_performance(long int gen, int NOF_rst, double peak_ratio, FILE *fpt)
{
	if (gen <= 10)
	{
		fprintf(fpt, "%d\t%ld\t%d\t%f\n", gen, neval, NOF_rst, peak_ratio);
	}
	else
	{
		if ((gen % (ngen/out_internal) == 0 ||
			gen >= ngen ||
			nreal >= max_evaluation) )
		{
			fprintf(fpt, "%d\t%ld\t%d\t%f\n", gen, neval, NOF_rst, peak_ratio);
		}
	}
}

// report the IGD performance in the file
void CEA_method::report_IGD_performance(long int gen, double IGD_rst, FILE *fpt)
{
	if (gen <= 10)
	{
		fprintf(fpt, "%d\t%ld\t%f\n", gen, neval, IGD_rst);
	}
	else
	{
		if ((gen % (ngen/out_internal) == 0 ||
			gen >= ngen ||
			nreal >= max_evaluation) )
		{
			fprintf(fpt, "%d\t%ld\t%f\n", gen, neval, IGD_rst);
		}
	}
}

void CEA_method::report_final_archive(FILE *fpt)
{
	int i, j;
	for (i = 0; i < m_ArchiveSize; i++)
	{
		for (j = 0; j < CIndividual::N_of_x; j++)
		{
			fprintf(fpt, "%15f", m_ArchivePop[i].xreal[j]);
		}

		/*for (j = 0; j < CIndividual::N_of_obj; j++)
		{
			fprintf(fpt, "%15f", m_MaxOrMin[j] * m_ArchivePop[i].obj[j]);
		}*/

		fprintf(fpt, "  |  %15e", m_ArchivePop[i].sum_f_e_f);
			
		double obj = 0.0;
		for (j=0; j<CIndividual::num_of_equations; j++)
		{
			obj += m_ArchivePop[i].f_e_f[j];
		}
		fprintf(fpt, "   |  %15e\n", obj);
	}
}

/************************************************************************/
/* Methods and attributes for batch execution                           */
/************************************************************************/
void CEA_method::copy_files(char *source, char *target)
{
	FILE *fs,*ft;
	char ma[204];
	unsigned int rd=0;

	fs=fopen(source, "rb");
	ft=fopen(target, "wb"); 
	if (fs&&ft) 
	{
		while (!feof(fs))
		{
			rd=fread(ma,sizeof(char),204,fs);
			fwrite(ma,sizeof(char),rd,ft);
		}
		fclose(fs);
		fclose(ft);
	}
}

long CEA_method::filesize(FILE *stream)
{
	long curpos, length;
	curpos = ftell(stream);
	fseek(stream, 0L, SEEK_END);
	length = ftell(stream);
	fseek(stream, curpos, SEEK_SET);
	return length;
}

int CEA_method::copyfile(const char* src,const char* dest)
{
	FILE *fp1,*fp2;
	int fsize,factread;
	static unsigned char buffer[SIZEOFBUFFER];

	fp1=fopen(src,  "rb");
	fp2=fopen(dest, "wb+");
	if (!fp1 || !fp2) 
	{
		return 0;
	}

    for (fsize=filesize(fp1);fsize>0;fsize-=SIZEOFBUFFER)
    {
		factread=fread(buffer,1,SIZEOFBUFFER,fp1);
		fwrite(buffer,factread,1,fp2);
    }
	fclose(fp1);
	fclose(fp2);
	return 1;
}

// create folders, only for batch execution
void CEA_method::create_folders(int method_ii)
{
	int status;
	int func_index;
	func_index = m_func;

	/************************************************************************/
	/* Create the zero-order folders: function level                         */
	/************************************************************************/
	char f_name_0[150];
	// set the folder name
	sprintf(f_name_0,"%s%s%d", ".\\results", (func_index<10 ? "\\f0" : "\\f"), func_index);

	// create the folders
	status = mkdir(f_name_0);
	//if (!status==0)	printf("Unable to create directory 1\n");

	/* to save the summary file for different methods */
	char f_name00[150];
	// set the folder name
	sprintf(f_name00,"%s%s%d%s", ".\\results", (func_index<10 ? "\\f0" : "\\f"), func_index, "\\summary");

	// create the folders
	status = mkdir(f_name00);
	//if (!status==0)	printf("Unable to create directory 1\n");
	/************************************************************************/

	/************************************************************************/
	/* Create the first-order folders: method level                         */
	/************************************************************************/
	char f_name0[150];
	// set the folder name
	sprintf(f_name0,"%s%s%d%s%d", ".\\results", (func_index<10 ? "\\f0" : "\\f"), func_index, "\\algorithm_", method_ii);

	// create the folders
	status = mkdir(f_name0);
	//if (!status==0)	printf("Unable to create directory 1\n");
	/************************************************************************/

	/************************************************************************/
	/* Create the second-order folders: results level                        */
	/************************************************************************/
	char f_name1[150];
	char f_name2[150];
	char f_name3[150];

	// set the folder name
	sprintf(f_name1, "%s%s%d%s%d%s", ".\\results", (func_index<10 ? "\\f0" : "\\f"), func_index, "\\algorithm_", method_ii, "\\final_archive");
	sprintf(f_name2, "%s%s%d%s%d%s", ".\\results", (func_index<10 ? "\\f0" : "\\f"), func_index, "\\algorithm_", method_ii, "\\IGD");
	sprintf(f_name3, "%s%s%d%s%d%s", ".\\results", (func_index<10 ? "\\f0" : "\\f"), func_index, "\\algorithm_", method_ii, "\\NOF");

	// create the folders
	status = mkdir(f_name1);
	//if (!status==0)	printf("Unable to create directory 2\n");
	status = mkdir(f_name2);
	//if (!status==0)	printf("Unable to create directory 3\n");
	status = mkdir(f_name3);
	//if (!status==0)	printf("Unable to create directory 4\n");
// 	status = mkdir(f_name4);
	//if (!status==0)	printf("Unable to create directory 4\n");
	/************************************************************************/
}

/************************************************************************/
/* Run the optimizers                                                   */
/************************************************************************/
void CEA_method::Run_optimizer(int run_no, double seed, int method, int func_flag, int flag_of_read_data)
{
	m_func			= func_flag;
	opt_method		= method;

	m_ArchiveSize	= 0;			// !! clear the archive before the run !!

	repulsion_alpha		= 10.0;
	repulsion_epsilon	= 1e-10;
	
	m_rnd.randomize(seed);
	init_variables();
	
	switch(method) {
	case 1:
		printf("You have selected the RADE/C optimizer.\n");
		break;
	default:
		printf("The optimizer your selected does not exist in Run_optimizer().\n");
		exit(0);
	}

	if (batch_execution==1)
	{
		create_folders(method);
	}

	int i;

	FILE *fpt1;
	FILE *fpt2;
	FILE *fpt3;
	FILE *fpt4;
	FILE *fpt5;

	clock_t start, finish;
	double time_consume = 0.0;

	fpt1 = fopen("./output/initial_pop.out","w");
	fpt2 = fopen("./output/final_pop.out","w");
	fpt3 = fopen("./output/best_pop.out","w");
	fpt4 = fopen("./output/all_pop.out","w");
	fpt5 = fopen("./output/params.out","w");


	FILE *fpt_IGD;
	FILE *fpt_NOF;
	FILE *fpt_summary_file;

	if (0==batch_execution)
	{		
		fpt_IGD				= fopen("./results/IGD/IGD.txt", "w");
		fpt_NOF				= fopen("./results/NOF/NOF.txt", "w");
		fpt_summary_file	= fopen("./results/summary.txt", "a");
	}
	else if (1==batch_execution)
	{
		char f_name0[150];
		sprintf(f_name0, "%s%s%d%s%d%s%d%s", ".\\results", (m_func<10 ? ".\\f0" : ".\\f"), m_func, ".\\algorithm_", method, ".\\IGD/IGD_", run_no+1,".txt");
		fpt_IGD = fopen(f_name0, "w");

		char f_name1[150];
		sprintf(f_name1, "%s%s%d%s%d%s%d%s", ".\\results", (m_func<10 ? ".\\f0" : ".\\f"), m_func, ".\\algorithm_", method, ".\\NOF/NOF_", run_no+1,".txt");
		fpt_NOF = fopen(f_name1, "w");

		char f_name2[150];
		sprintf(f_name2, "%s%s%d%s%s%d%s", ".\\results", (m_func<10 ? ".\\f0" : ".\\f"), m_func, ".\\summary", ".\\summary_", method, ".txt");
		fpt_summary_file = fopen(f_name2, "a");
	}

	start			= clock();		// online time calculation for orthogonal initialization

	neval			= 0;
	gen				= 1;

	generate_weights(weights_x, nreal);

	allocate_memory_pop (parent_pop, popsize);
	allocate_memory_pop (child_pop, popsize);
	allocate_memory_pop (mixed_pop, 2*popsize);
	
	allocate_memory_pop (optima_pop, 5*popsize);

	printf("The algorithm generates the initial population randomly.\n");
	initialize_pop (parent_pop);
	evaluate_pop (parent_pop, popsize);

// 	printf("%f\n", parent_pop->ind[0].sum_f_e_f); getchar();

	report_pop (parent_pop, fpt1);
//	fprintf(fpt4,"# gen = 1\n");
//	report_pop(parent_pop,fpt4);

	/************************************************************************/
	/* read the true POS                                                    */
	/************************************************************************/
	char f_POF_name[150];
	sprintf(f_POF_name,"%s%d%s","optimal_POF/_F",func_flag,".txt");
	FILE *fpt_POF;
	fpt_POF = fopen(f_POF_name, "r");
	if (fpt_POF == NULL)
	{
		printf("The optimal POF for f(%d) does not exist!\n", func_flag);
		flag_of_true_POF = 0;
	}
	else
	{
		flag_of_true_POF = 1;
	}
	if (flag_of_true_POF==1)
	{
		printf("!!!!!!!!!!! The POS data only reads once. !!!!!!!!!!!\n");
		read_POS_data(fpt_POF);
		flag_of_read_data = 0;
		fclose(fpt_POF);
	}
	//calculate_POS_data();
	/************************************************************************/

	FILE *fpt000;
	fpt000 = fopen("./output/final_variable.txt","w");
		
	int		num_of_POF_obtained = -1;
	double	peak_ratio			= -1;
	double	igd					= -1;
	while (neval<=max_evaluation)//gen<=ngen && 
	{
/*		repulsion_alpha = 1.0 + 29.0*(1-(double)gen/ngen);*/
		child_size = 0;		// reset the size of the child population 

		get_seeds_indices(parent_pop, popsize, seeds_indices);
		get_the_archive();
		if (flag_of_true_POF==1)
		{
			igd = IGD_performance(m_ArchivePop, m_ArchiveSize);
			//igd = IGD_performance_objective(m_ArchivePop, m_ArchiveSize);
			report_IGD_performance(gen, igd, fpt_IGD);

			num_of_POF_obtained = how_many_optima(m_ArchivePop, m_ArchiveSize);
			peak_ratio			= (double)num_of_POF_obtained/num_of_optimal_POF;
			report_NOF_performance(gen, num_of_POF_obtained, peak_ratio, fpt_NOF);
		}

		if (gen==1 || gen%100==0)
		{
			fprintf(fpt4,"# gen = %d\n", gen);
			report_pop(parent_pop,fpt4);
			fprintf(fpt4,"\n");			
			
			fprintf(fpt000, "# gen = %d\n", gen);
			for (i=0;i<m_ArchiveSize;i++)
			{
				int j;
				for (j=0; j<nreal; j++)
				{
					fprintf(fpt000, "%15f", m_ArchivePop[i].xreal[j]);
				}			
				fprintf(fpt000, "\n");
			}
			fprintf(fpt000, "\n");
		}

		/* add different optimizers in the following space */
		switch(method) {
		case 1:
			run_NCDE_SHADE();
			break;
		default:
			printf("The optimizer your selected does not exist in Run_optimizer().\n");
			exit(0);
		}
		
		// increase the generation number
		gen++;	

		// statistic the running time each generation
		finish = clock();
		time_consume = (double)(finish - start)/CLOCKS_PER_SEC;
	}

	report_pop(parent_pop, fpt2);

	if (1)
	{
		//report_archive();

		/************************************************************************/
		/* The sorted archive will be used to generate the matlab file          */
		// sort the final archive population with f[0]
		QuickSort(m_ArchivePop,0,m_ArchiveSize-1);

		// output the sorted archive population to file
		ofstream sortedArchive("./output/sorted_archive.out");
		sortedArchive.precision(8);
		
		char f_allbest[150];
		if (0==batch_execution)
		{
			sprintf(f_allbest,"%s",".\\results\\allbest.txt");	
		}
		else if (1==batch_execution)
		{
			sprintf(f_allbest, "%s%s%d%s%d%s", ".\\results", (m_func<10 ? ".\\f0" : ".\\f"), m_func, ".\\algorithm_", method, ".\\allbest.txt");
		}
		FILE *allbest = fopen(f_allbest, "a");

		char f_fitness[150];
		if (0==batch_execution)
		{
			sprintf(f_fitness,"%s%d%s",".\\results\\fitness_", run_no+1, ".txt");	
		}
		else if (1==batch_execution)
		{
			sprintf(f_fitness, "%s%s%d%s%d%s%d%s", ".\\results", (m_func<10 ? ".\\f0" : ".\\f"), m_func, ".\\algorithm_", method, ".\\fitness_", run_no+1, ".txt");
		}
		FILE *fitness = fopen(f_fitness, "w");

		/************************************************************************/
		double	aa5[3] = {1.868484, 1.445985, 1.230368};
		double	aa6[6] = {1.817181, 1.252479, 1.605436, 1.950331, 1.362872, 1.161547};
		double	aa7[20] = {1.524090, 1.064611, 1.232732, 1.659674, 1.773058, 1.486098, 1.848031, 1.616587, 1.181112,  1.360487, 
			1.724548, 1.829136, 1.904545, 1.312096, 1.136315, 1.444147, 1.947805, 1.010554, 1.562374, 1.280985};
		double	aa13[10] = {1.644408, 1.174599, 1.432387, 1.799492, 1.765321, 1.392430, 1.990823, 1.284636, 1.094708, 1.551805};
		double	weights_x0[MAX_N_of_x];
		for (i = 0; i < m_ArchiveSize; i++)
		{
			int j;
			if (m_func==5)
			{
				for (j=0; j<CIndividual::N_of_x; j++)
				{	
					weights_x0[j] = aa5[j];		
				}
			}
			else if (m_func==6)
			{
				for (j=0; j<CIndividual::N_of_x; j++)
				{	
					weights_x0[j] = aa6[j];		
				}
			}
			else if (m_func==7)
			{
				for (j=0; j<CIndividual::N_of_x; j++)
				{	
					weights_x0[j] = aa7[j];		
				}
			}
			else if (m_func==13)
			{
				for (j=0; j<CIndividual::N_of_x; j++)
				{	
					weights_x0[j] = aa13[j];		
				}
			}
			else
			{
				for (j=0; j<CIndividual::N_of_x; j++)
				{	
					weights_x0[j] = weights_x[j];		
				}
			}
			
			double	sum_w, tmp_x=0;
			double  base_x;
			sum_w  = 0.0;
			base_x = 0.0;
			for (j=0; j<CIndividual::N_of_x; j++)
			{
				sum_w   += weights_x0[j];
				base_x  += weights_x0[j] * m_ArchivePop[i].xreal[j];
			}
			base_x /= sum_w;

			double obj = 0.0;
			for (j=0; j<CIndividual::num_of_equations; j++)
			{
				obj += m_ArchivePop[i].f_e_f[j];
			}
			
			sortedArchive<<setw(20)<<base_x + obj<<setw(20)<<1.0-base_x + obj;
			sortedArchive<<endl;
			
			fprintf(allbest, "%20f%20f%20f\n", base_x + obj, 1.0-base_x + obj, obj);
			if (obj<=1e-2)	obj = 0.0;		///////// 2016-09-18
			fprintf(fitness, "%20f%20f\n", base_x + obj, 1.0-base_x + obj);
		}
		fprintf(allbest, "\n");
		fprintf(fitness, "\n");
		
		sortedArchive.close();
		fclose(allbest);
		fclose(fitness);
		
		fclose(fpt000);
		/************************************************************************/

		char f_name[150];
		if (0==batch_execution)
		{
			sprintf(f_name,"%s%d%s",".\\results\\final_archive\\final_archive_",run_no+1,".txt");	
		}
		else if (1==batch_execution)
		{
			sprintf(f_name, "%s%s%d%s%d%s%d%s", ".\\results", (m_func<10 ? ".\\f0" : ".\\f"), m_func, ".\\algorithm_", method, ".\\final_archive/final_archive_", run_no+1,".txt");
		}	
		FILE *sortedArchive1 = fopen(f_name, "w");
		report_final_archive(sortedArchive1);
		fclose(sortedArchive1);
		
		/************************************************************************/
		/* Output the variables of the archive members                          */
		/************************************************************************/
// 		FILE *fpt10;
// 		fpt10 = fopen("./output/final_variable.txt","w");
// 		for (i=0;i<m_ArchiveSize;i++)
// 		{
// 			int j;
// 			for (j=0; j<nreal; j++)
// 			{
// 				fprintf(fpt10, "%15f", m_ArchivePop[i].xreal[j]);
// 			}
// 			
// 			fprintf(fpt10, "%15.4e\n", m_ArchivePop[i].sum_f_e_f);
// 		}
// 		fclose(fpt10);
	}

	/************************************************************************/
	/* report the summary file                                              */
	/************************************************************************/
	fprintf(fpt_summary_file, "%15f%5d%15f%15.3f\n", igd, num_of_POF_obtained, peak_ratio, time_consume);
	/************************************************************************/

	fclose(fpt1);
	fclose(fpt2);
	fclose(fpt3);
	fclose(fpt4);
	fclose(fpt5);

	fclose(fpt_IGD);
	fclose(fpt_NOF);
	fclose(fpt_summary_file);

	deallocate_memory_pop (parent_pop);
	deallocate_memory_pop (child_pop);
	deallocate_memory_pop (mixed_pop);

	deallocate_memory_pop(optima_pop);

	/************************************************************************/
	/* generate the matlab file                                             */
	char f_matlab[150];
	if (0==batch_execution)
	{
		sprintf(f_matlab,"%s%d%s%d%s",".\\results\\matlab_r", run_no+1, "_m", method,".m");	
	}
	else if (1==batch_execution)
	{
		sprintf(f_matlab, "%s%s%d%s%d%s%d%s", ".\\results", (m_func<10 ? ".\\f0" : ".\\f"), m_func, ".\\matlab_r", run_no+1, "_m" , method, ".m");
	}

	m_mtb.GenerateMatlabFile2(f_matlab);
	/************************************************************************/


	printf("\n----------------------------------------------------\n");
	printf("The function evaluations is %d and gen=%d\n", neval, gen);
	printf("The final time consume is %f s\n", time_consume);
	printf ("The obtained archive size is: %d\n", m_ArchiveSize);
	printf ("And the number of the obtained optimal solutions is: %d\n", num_of_POF_obtained);
	printf("------------------------------------------------------\n");
	printf("==========================f(%d) is optimized.==========================\n\n\n\n", func_flag);
}

/************************************************************************/
/* For NCDE with proximity-based mutation                               */
/************************************************************************/
void CEA_method::calculate_proximity_prob(population *pop, int size)
{
	int		i, j;

	for (i=0; i<size; i++)
	{
		for (j=0; j<=i; j++)
		{
			if (i==j)
			{
				dist_t[i][j] = 0;
			}
			else
			{
				dist_t[i][j] = cal_ecu_dist(pop->ind[i].xreal, pop->ind[j].xreal, nreal);
			}
		}
	}
	
	for (i=0; i<size; i++)
	{
		for (j=i+1; j<size; j++)
		{
			dist_t[i][j] = dist_t[j][i];
		}
	}
}

void CEA_method::get_neighborhood_index(int base_index)
{
	int dd_index[population_size], i;
	shell_sort_array(dist_t[base_index], dd_index, popsize);

	assert(neighborhood_size+1 < popsize);
	for (i=0; i<neighborhood_size; i++)
	{
		neighborhood_index[i] = dd_index[i+1];		// exclude the base_index itself
	}
}

void CEA_method::run_NCDE_SHADE()
{
	int		i, j, j_rand;
	int		r1, r2, r3=-1;
	double	low, up;
	double	tmp_xreal;

	/************************************************************************/
	/* parameter adaptation                                                 */
	double FF[population_size];
	double CR[population_size];
	double SS_FF[population_size], SS_CR[population_size];
	int    SS_size = 0;
	if (1==gen)
	{		
		SHADE_memory_size = 2*popsize/1;

		/* Initialize the historical memory of CR and F */
		for (i=0; i<SHADE_memory_size; i++)
		{
			SHADE_M_CR_FF[i][0] = 0.5;
			SHADE_M_CR_FF[i][1] = 0.5;
		}

		neighborhood_size = 10;
	}
	int		binary_x[MAX_N_of_x];
	/************************************************************************/
	
	for (i=0; i<popsize; i++)
	{
		// select mu_CR and mu_F from the memory
		int kk     = m_rnd.rndint(0, SHADE_memory_size-1);
		JADE_mu_CR = SHADE_M_CR_FF[kk][0];
		JADE_mu_FF = SHADE_M_CR_FF[kk][1];

		// generate F value for each individual (individual level)
		do {
			FF[i] = m_rnd.cauchy(JADE_mu_FF, 0.1);		// cauchy
		} while (FF[i] <= 0.);
		if (FF[i] > 1.0)	FF[i] = 1.0;

		// generate CR value for each dimension of each individual (component level)
		if (JADE_mu_CR < 0.)
		{
			CR[i] = 0.0;
		}
		else
		{
			CR[i] = m_rnd.gaussian(JADE_mu_CR, 0.1);
			if (CR[i] < 0.0)	CR[i] = 0.0;
			if (CR[i] > 1.0)	CR[i] = 1.0;
		}
	}
		
	// dynamic neighborhood size is used
	if(popsize <= 200)	neighborhood_size =  5  + (int)floor( 5.0*(ngen - gen)/ngen );
	else				neighborhood_size =  20 + (int)floor( 30.0*(ngen - gen)/ngen );
	calculate_proximity_prob(parent_pop, popsize);

	// re-calculate the fitness of the parent population
	for (i=0; i<popsize; i++)
	{
		evaluate_ind(&parent_pop->ind[i]);
	}
	
	for (i=0; i<popsize; i++)
	{
		m_CR = CR[i];
		m_FF = FF[i];
// 		m_CR = 0.1;
// 		m_FF = 0.9;
	
		get_neighborhood_index(i);
		do {
			r1 = m_rnd.rndint(0, neighborhood_size-1);
			r1 = neighborhood_index[r1];
		} while(r1==i);
		do {
			r2 = m_rnd.rndint(0, neighborhood_size-1);
			r2 = neighborhood_index[r2];
		} while(r2==i || r2==r1);//
		do {
			r3 = m_rnd.rndint(0, neighborhood_size-1);
			r3 = neighborhood_index[r3];
		} while(r3==i || r3==r2 || r3==r1);//

		/************************************************************************/
		/* Repairing the crossover rate                                         */
		/************************************************************************/
		int tmp = 0;
		j_rand = m_rnd.rndint(0, nreal-1);
		for (j=0; j<nreal; j++)
		{
			if (m_rnd.rndreal(0, 1)<m_CR || j==j_rand)
			{
				binary_x[j] = 1;
				tmp += 1;
			}
			else
			{
				binary_x[j] = 0;
			}
		}
		if (nreal>5) CR[i] = (double)tmp/nreal;
		/************************************************************************/

		//r1 = (m_rnd.flip(0.5)) ? r1 : i;
		r1 = (nreal>10) ? r1 : i;

		// mutation
		for (j=0; j<nreal; j++)
		{
			low = min_realvar[j];
			up  = max_realvar[j];

			tmp_xreal = parent_pop->ind[r1].xreal[j]		// r1 (F02, F17, F20, F35); i (F03, F18, F27, F28, F30, F31)
				+ m_FF * (parent_pop->ind[r2].xreal[j] - parent_pop->ind[r3].xreal[j]);	
			if (tmp_xreal<low || tmp_xreal>up)
			{
				tmp_xreal = m_rnd.rndreal(low, up);
			}

			child_pop->ind[i].xreal[j] = tmp_xreal;
		}

		// crossover
		for (j=0; j<nreal; j++)
		{
			
			if (binary_x[j]==0)
			{		
				child_pop->ind[i].xreal[j] = parent_pop->ind[i].xreal[j];
			}
		}

		evaluate_problem(&child_pop->ind[i]);
		evaluate_ind(&child_pop->ind[i]);
	}

	for (i=0; i<popsize; i++)
	{
		double dd_dist  = INF, temp=0.0;
		int	   dd_index = -1;
		for (j=0; j<popsize; j++)
		{
			temp = cal_ecu_dist_normalized(child_pop->ind[i].xreal, parent_pop->ind[j].xreal, nreal);
			if (temp < dd_dist)
			{
				dd_dist  = temp;
				dd_index = j;			// get the most similar solution
			}
		}

		//dd_index = i;

		if ( child_pop->ind[i].obj[0] <= parent_pop->ind[dd_index].obj[0] )
		{// new child dominates its parent, replace the parent
			parent_pop->ind[dd_index] = child_pop->ind[i];

			// save the successful parameters
			SS_FF[SS_size] = FF[i];
			SS_CR[SS_size] = CR[i];
			SS_size++;
		}
	}

	if (SS_size != 0) 
	{
		int kk = (gen-1)%SHADE_memory_size;

		// calculate the weighted mean of CR
		double mean_cr  = 0.0, tmp_cr = 0.0;	
		for (i=0;i<SS_size;i++)
		{
			tmp_cr += SS_CR[i];
		}
		if (SHADE_M_CR_FF[kk][0]==-1 || tmp_cr==0.0)
		{
			mean_cr = -1;
		}
		else
		{
			for (i=0;i<SS_size;i++)
			{
				mean_cr += SS_CR[i];
			}
			mean_cr /= (double)SS_size;
		}

		// calculate the weighted mean of FF
		double mean_ff = 0.0;
		double t1      = 0.0;
		double t2      = 0.0;
		for (i=0;i<SS_size;i++)
		{
			t1 += SS_FF[i]*SS_FF[i];
			t2 += SS_FF[i];
		}					
		mean_ff = t1/t2;					// Lehmer mean
		//mean_ff = t2/SS_size;				// arithmetic mean

		// update the historical memory
		SHADE_M_CR_FF[kk][0] = mean_cr;
		SHADE_M_CR_FF[kk][1] = mean_ff;
	}
}




