
/* Program:   RADE-NES
   Author:    Wenyin Gong
   E-mail:    wenyingong@yahoo.com; wygong@cug.edu.cn
   Date:      08/Apr./2018
   License:   free
   Platform:  Microsoft Visual C++ 6.0
   Reference: W. Gong, Y. Wang, Z. Cai and L. Wang, "Finding multiple roots of nonlinear equation systems via a repulsion-based adaptive differential evolution,"
              IEEE Transactions on Systems, Man, and Cybernetics: Systems. In press.
*/



