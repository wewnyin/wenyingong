// --------------------include files--------------------
#include <iostream.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <float.h>
#include <fstream.h>
#include <iomanip.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>

#ifdef _WIN32
# include <float.h>
# if !defined __MINGW32__ || defined __NO_ISOCEXT
#  ifndef isnan
#   define isnan(x) _isnan(x)
#  endif
#  ifndef isinf
#   define isinf(x) (!_finite(x) && !_isnan(x))
#  endif
#  ifndef finite
#   define finite(x) _finite(x)
#  endif
# endif
#endif

#define LOG_PI_OVER_2	0.572364942924700087071713675675 /* log_e(PI)/2 */

// --------------------Global variables--------------------
#define E		exp(1)
#define PI		acos(-1)
#define INF		DBL_MAX
#define EPS		DBL_EPSILON		// the precision of the constraints
#define DELTA	DBL_EPSILON

#define max(a,b) (((a) > (b)) ? (a) : (b))
