function ParentC = MatingSelection(CA,DA,N,z,znad)
% The mating selection of Two_Arch2

% Copyright (c) 2016-2017 BIMK Group

    EA=[CA,DA];
    CAObj=EA.objs;
    [N1,~]=size(CAObj);
    CAObj2 = (CAObj-repmat(z,N1,1))./(repmat(znad,N1,1)-repmat(z,N1,1));
    D = pdist2(CAObj2,CAObj2,'cosine');
    D=D+eye(N1);
    [cos,mincos]=min(D);
    CAO=sum(CAObj2.^2,2);
    minCAO=CAO(mincos);
    ch=(minCAO-CAO)>0;
    ch3=(1-ch).*mincos'+(ch).*(1:N1)';
    cos=1-cos;
    cos=(cos-min(cos))./repmat((max(cos)-min(cos)),1,N1);
    ParentC=[];
    for i=1:1:2*N
        
        % 这里用CV构建轮盘赌选择
        k=randi(N1);
        
        if rand<cos(k)
            ParentC=[ParentC,EA(ch3(k))];
        else
            ParentC=[ParentC,EA(k)];
        end
    end

end