function [f,error,obj_var,VI_data] = pflow(x)

global VD PGS emission ploss VI scale shape fuelvlvcost Qgen mcarlo SP1 wgencost sgencost nbins cumcost
%x = [27.0699	 42.9420	 10.0000	 36.2679	 38.0055	 1.0720	 1.0570	 1.0348	 1.0396	 1.0982	 1.0556];
%x = [20.58 60 35 60 60 1.0543 1.04764 1.03343 1.04372 1.0802 1.07762];
%x = [62.84 50 24.64 40 40 1.0591 1.05273 1.03364 1.0355 1.071 1.08075];
% 29.0242	 44.0263	 10.0000	 37.1634	 34.0473	 1.0718	 1.0568
% 1.0349	 1.0665	 1.0998	 1.0489  add!!!!

Ctax = 20; % Carbon tax $/ton

data = loadcase(case30);
data.gen(2:6,2) = x(1:5);
data.gen(1:6,6) = x(6:11);

%%%%%%%%%%%%%%%% XB���ٽ����㷨
mpopt = mpoption('pf.enforce_q_lims',2,'verbose',0,'out.all',0);
result = runpf(data,mpopt);


thpowgen = [result.gen(1,2),x(1),x(3)];  %%%%% bus1�Ĺ��ʣ��Լ�Ptg2��Ptg3�Ķ����
%thpowgen = [94.7753,x(1),x(3)];

thgencoeff = vertcat(data.gencost(1:2,5:7),data.gencost(4,5:7));  %%%% �õ��ȷ�����ĳɱ�ϵ��ai,bi,ci(i=1,2,3)
%  thgencoeff=[0  2   0.00375;
%              0 1.75 0.0175;              
%              0 3.25 0.00834]

% �����ȷ���ɱ�
thgencost = sum(thgencoeff(:,1)+thgencoeff(:,2).*thpowgen'+thgencoeff(:,3).*(thpowgen.^2)'); % thermal generator cost

%Find wind generator related parameters
%windgen parameter sl no. bus costcoeff(gi)
wgenpar = [1   5   1.60;  % g1 = 1.6 (bus5)
           2   11  1.75]; % g2 = 1.75 (bus11)
       
Crwj = 3; Cpwj = 1.5; % wind power penalty and reserve cost coefficients

schwpow = [x(2),x(4)]'; %% ��������Ķ����

%stochastic wind power cost
%meanwpow = [26;30]; wp = 35;

% scale = [9 10 11]; % Enter shape parameters of 3 windfarms for Weibull dist
% shape = [2 2 2]; % Enter shape parameters of 3 windfarms for Weibull dist

NT = [25 20]; % No. of turbines in the 2 farms
Vin = 3; Vout = 25; Vr = 16; % Cut-in, cut-out, rated speed
Pr = 3;  % rated power of turbine

Prw0 = 1-exp(-(Vin./scale).^shape)+exp(-(Vout./scale).^shape);  %%%% fw(Pw){Pw = 0} ʱ�������
Prwwr = exp(-(Vr./scale).^shape)-exp(-(Vout./scale).^shape);    %%%% fw(Pw){Pw = Pwr} ʱ�������\

count1 = 1;
wovest = zeros();  %%% �����ɱ�(overestimation case)
wundest = zeros(); %%% ΥԼ�ɱ�(underestimated case)

for ii = 1:2
    %%% k(Vr-Vin)/c^k*Pr
    Prww1 = (shape(ii)*(Vr-Vin))/((scale(ii)^shape(ii))*(NT(ii)*Pr));
    
    %%% Prww = Krw,j*integral(����)��Pws,j - Pw,j��
    Prww = @(wp)((schwpow(ii)-wp)*Prww1*((Vin + (wp/(NT(ii)*Pr))*(Vr-Vin))^(shape(ii)-1))*(exp(-((Vin + (wp/(NT(ii)*Pr))*(Vr-Vin))/scale(ii))^shape(ii))));
    
    %%% �����
    wovest2 = integral(Prww,0,schwpow(ii),'ArrayValued',true);
    
    %%% Pw = 0 ʱ�ĸ��ʳɱ�+overestimation�ɱ�
    wovest(count1) = schwpow(ii)*Prw0(ii)*Crwj+Crwj*wovest2;

    Prww = @(wp)((wp-schwpow(ii))*Prww1*((Vin + (wp/(NT(ii)*Pr))*(Vr-Vin))^(shape(ii)-1))*(exp(-((Vin + (wp/(NT(ii)*Pr))*(Vr-Vin))/scale(ii))^shape(ii))));
    wundest2 = integral(Prww,schwpow(ii),NT(ii)*Pr,'ArrayValued',true);
    
    %%% Pw = Pwr ʱ�ĸ��ʳɱ�+underestimated�ɱ�
    wundest(count1) = (NT(ii)*Pr-schwpow(ii))*Prwwr(ii)*Cpwj+Cpwj*wundest2;
    count1 = count1+1;
end

wgencost = sum(wgenpar(:,3).*schwpow)+sum(wovest)+sum(wundest); % wind generator cost = ֱ�ӳɱ�+overestimation�ɱ�+underestimated�ɱ�

%solargen parameter sl no. bus costcoeff
sgenpar = [1   13  1.60];   %%%% KRs = 1.6

Crsj = 3; % Reserve cost for solar power overestimation ($/MW)
Cpsj = 1.5; % Penalty cost for solar power underestimation ($/MW)

schspow = x(5); % solar generator schedule power

% Segregate over and underestimated power on the power histogram

[histy1,histx1] = hist(SP1,nbins);

Lowind1 = histx1<schspow;
Highind1 = histx1>schspow;
allP1und = schspow-histx1(histx1<schspow);
allP1over = histx1(histx1>schspow)-schspow;
ProbP1und = histy1(Lowind1)./mcarlo;
ProbP1over = histy1(Highind1)./mcarlo;

% Finding under and over estimation cost
C1und = sum(Crsj*(ProbP1und.*allP1und)); 
C1over = sum(Cpsj*(ProbP1over.*allP1over));
sovundcost = [C1und,C1over];

sgencost = sum(sgenpar(:,3).*schspow)+sum(sovundcost); % solar generator cost


%Constraint finding 
Vmax = data.bus(:,12);
Vmin = data.bus(:,13);
genbus = data.gen(:,1); %%% genbus = [1,2,5,8,11,13]

Qmax = data.gen(:,4)/data.baseMVA; %%% Qmax = [150.0, 60.0, 35.0, 40.0, 30.0, 25.0 ]
Qmin = data.gen(:,5)/data.baseMVA; %%% Qmin = [-20    -20   -30   -15   -25   -20  ]
Qgen = result.gen(:,3);            %%% Qgen = [-3.99 50.0 37.0 37.3 37.3 37.3 ]
QG = result.gen(:,3)/data.baseMVA; %%% QG = [-0.0399    0.5000    0.3700    0.3730    0.3730    0.3730]

PGSmax = data.gen(1,9);  %%%  PGSmax = 140
PGSmin = data.gen(1,10); %%%  PGSmin = 50

PGS = result.gen(1,2);   %%%  PGS = ��õĽ��

%%%%% PG constraints
PGSerr = (PGS<PGSmin)*(abs(PGSmin-PGS)/(PGSmax-PGSmin))+(PGS>PGSmax)*(abs(PGSmax-PGS)/(PGSmax-PGSmin));

%%%%%   squared branch flow constraints ��ƽ����֧����Լ����
blimit = data.branch(:,6);
Slimit = sqrt(result.branch(:,14).^2+result.branch(:,15).^2);

%%%% Security constraints
Serr = sum((Slimit>blimit).*abs(blimit-Slimit))/data.baseMVA;

% TO find the error in Qg of gen buses- inequality constraint
Qerr = sum((QG<Qmin).*(abs(Qmin-QG)./(Qmax-Qmin))+(QG>Qmax).*(abs(Qmax-QG)./(Qmax-Qmin)));


% TO find the error in V of load buses-inequality constraint
VI = result.bus(:,8);  % V of load buses-inequality constraint

VI(genbus)=[];  %%%%��genbus = [1,2,5,8,11,13]���ڵ�����ȥ������Ϊ��Щ��Ϊ�������Ѿ��ڷ�Χ����

%%%% ͬVI
Vmax(genbus)=[];
Vmin(genbus)=[];

%%%%% load buses-inequality constraint
VIerr = sum((VI<Vmin).*(abs(Vmin-VI)./(Vmax-Vmin))+(VI>Vmax).*(abs(Vmax-VI)./(Vmax-Vmin)));

%%%  Voltage deviation
VD = sum(abs(VI-1));

% Emission : Of thermal generating unit
% bus_no. alpha   beta      gama    omega  miu   d   e  Pmin
 emcoeff = [
 	1	0.04091 -0.05554 0.06490 0.000200 6.667 18 0.037 50;
 	2	0.02543 -0.06047 0.05638 0.000500 3.333 16 0.038 20;
 	8	0.05326 -0.03550 0.03380 0.002000 2.000 12 0.045 10];

% VALVE EFFECT  ���Ƿ�ֵ��
valveff = sum(abs(emcoeff(:,7).*sin(emcoeff(:,8).*(emcoeff(:,9)-thpowgen')))); % if all have valve effects

% OBJECTIVE FUNCTIONS
emission = sum(emcoeff(:,2)+emcoeff(:,3).*thpowgen'/100+emcoeff(:,4).*(thpowgen.^2/100^2)'...
     +emcoeff(:,5).*exp(emcoeff(:,6).*thpowgen'/100));

ploss = sum(result.branch(:,14)+result.branch(:,16));

fuelvlvcost = thgencost+valveff;
cumcost = fuelvlvcost+wgencost+sgencost;

%%%%% �洢����
obj_var = [PGS,cumcost,ploss,VD,emission,Qgen'];
VI_data = VI';

%%%% Լ��Υ����
error = [Qerr,VIerr,Serr,PGSerr];

f1 = cumcost; 
f2 = ploss;
f3 = VD;
f4 = emission;

%%%%%%%%%%%%%% Two objectives %%%%%%%%%%%%
% CASE 1: cumcost and ploss
%f = [f1,f2];
% % CASE 2: cumcost and VD
% f = [f1,f3];
% % CASE 3: cumcost and emission
% f = [f1,f4];
% % CASE 4: ploss and VD
% f = [f2,f3];
% % CASE 5: ploss and emission
% f = [f2,f4];
% % CASE 6: VD and emission
% f = [f3,f4];
% %%%%%%%%%%%%%% Two objectives %%%%%%%%%%%%
% 
% 
% %%%%%%%%%%%%%% Three objectives %%%%%%%%%%%%
% % CASE  7: cumcost, ploss and VD
% f = [f1,f2,f3];
% % CASE  8: cumcost, ploss and emission
f = [f1,f2,f4];
% % CASE 9: cumcost, VD and emission
% f = [f1,f3,f4];
% % CASE 10: ploss, VD and emission
% f = [f2,f3,f4];
% %%%%%%%%%%%%%% Three objectives %%%%%%%%%%%%
% 
% %%%%%%%%%%%%%% four objectives %%%%%%%%%%%%
% % CASE 11: cumcost, ploss, VD and emission
% f = [f1,f2,f3,f4];
% %%%%%%%%%%%%%% four objectives %%%%%%%%%%%%
