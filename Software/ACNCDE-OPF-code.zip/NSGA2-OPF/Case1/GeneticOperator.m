function [ OffspringPop,newg,new_obj_var,new_VI_data ] = GeneticOperator(ParentPop,M,N,D,LB,UB )
%GENETICOPERATOR �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    % GA parameter
    CR = 0.9; % ������
    mu = 20; % �����㷨�ķֲ�ָ��
    mum = 20; % �����㷨�ķֲ�ָ��
    
    flag = 0; % ������־�ǽ��滹��ͻ����:0Ϊ���棬1Ϊͻ��
    count = 1; % ���������Ӵ�����
    
    [NP,~] = size(ParentPop);
    
    % Start loop
    for i=1:NP
        if rand<CR % crossover
           Child1 = [];
           Child2 = [];
           index = randperm(NP); 
           Child1 = ParentPop(index(1),:);
           Child2 = ParentPop(index(2),:);
           for j=1:D
               rand1 = rand;
               if rand1<=0.5
                   temp = (2*rand1)^(1/(mu+1));
               else
                   temp = (1/(2*(1-rand1)))^(1/(mu+1));
               end
               Child1(j) = 0.5*(((1+temp)*Child1(j))+(1-temp)*Child2(j));
               Child2(j) = 0.5*(((1-temp)*Child1(j))+(1+temp)*Child2(j));
               
               % deal with boundary
%                if Child1(j)<LB(j)
%                   Child1(j) = LB(j);
%                end
%                if Child1(j)>UB(j)
%                   Child1(j) = UB(j);
%                end
%                
%                if Child2(j)<LB(j)
%                   Child2(j) = LB(j);
%                end
%                if Child2(j)>UB(j)
%                   Child2(j) = UB(j);
%                end
               if Child1(j)<LB(j) || Child1(j)>UB(j)
                  Child1(j) = LB(j)+rand*(UB(j)-LB(j));
               end
               
               if Child2(j)<LB(j) || Child2(j)>UB(j)
                  Child2(j) = LB(j)+rand*(UB(j)-LB(j));
               end
                
           end
           
           % calculate the objective function
           [Child1(D+1:D+M),g1,obj_var1,VI_data1] = pflow(Child1(1:D));
           [Child2(D+1:D+M),g2,obj_var2,VI_data2] = pflow(Child2(1:D));
           flag = 0; % Crossover
           
        else % mutation
            index = randperm(NP);
            Child3 = ParentPop(index(1),:);
            for j=1:D
                rand2 = rand;
                if rand2<0.5
                    delta = (2*rand2)^(1/(mum+1))-1;
                else
                    delta = 1-(2*(1-rand2))^(1/(mum+1));
                end
                Child3(j) = Child3(j)+delta;
                
                if Child3(j)<LB(j) || Child3(j)>UB(j)
                    Child3(j) = LB(j)+rand*(UB(j)-LB(j));
                end
%                 if Child3(j)<LB(j)
%                    Child3(j) = LB(j);
%                 end
%                 if Child3(j)>UB(j)
%                    Child3(j) = UB(j);
%                 end
            end
            
            [Child3(D+1:D+M),g3,obj_var3,VI_data3] = pflow(Child3(1:D));
            flag = 1; % Mutation   
            
        end
        
        if flag==0
           OffspringPop(count,:) = Child1;
           newg(count,:) = g1;
           new_obj_var(count,:) = obj_var1;
           new_VI_data(count,:) = VI_data1;
           OffspringPop(count+1,:) = Child2;
           newg(count+1,:) = g2;
           new_obj_var(count+1,:) = obj_var2;
           new_VI_data(count+1,:) = VI_data2;
           count = count+2;
        else
           OffspringPop(count,:) = Child3;
           newg(count,:) = g3;
           new_obj_var(count,:) = obj_var3;
           new_VI_data(count,:) = VI_data3;
           count = count+1;
        end
    end

end

