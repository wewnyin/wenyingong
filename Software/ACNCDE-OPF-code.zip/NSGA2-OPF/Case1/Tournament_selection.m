function [ PoolPop ] = Tournament_selection( POP,pool_size,tour_size)
%TOURNAMENT_SELECTION �˴���ʾ�йش˺�����ժҪ
%   POP: Population
%   pool_size: pool size
%   tour_size: tournament size
    [NP,D] = size(POP);
    rank = D-1; % Front�ȼ����ڵ�����
    distance = D; % �����ӵ���������ڵ�����
    for i=1:pool_size
        index = randperm(NP);
        for j=1:tour_size
            Candidate(j,:)  = POP(index(j),:);
        end
        if Candidate(1,rank)<Candidate(2,rank)
            PoolPop(i,:) = Candidate(1,:);
        elseif Candidate(1,rank)==Candidate(2,rank)
            if Candidate(1,distance)>Candidate(2,distance)
               PoolPop(i,:) = Candidate(1,:); 
            else
               PoolPop(i,:) = Candidate(2,:);
            end
        else
            PoolPop(i,:) = Candidate(2,:);
        end
    end
    
end

