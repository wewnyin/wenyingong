clear all
close all

rehash

format long g

warning ('off'); 

global  nfeval VD PGS emission ploss VI fuelvlvcost Qgen wgencost sgencost cumcost
run_times = 20;
D = 11;
Max_NFE = 60000;
M = 3; % The number of objectives
Result = [];
VI_data = [];
QG_data = [];
other_data = []; 

result_HV = [];

tic() % ��ʼ��ʱ

for i=1:run_times
    [Final_Pop,obj_var,VI_data] = NSGA2(@pflow,Max_NFE,M);

    Result{i} = Final_Pop;
    Result_var{i} = obj_var;
    Result_data{i} = VI_data;
    %%% ����HVָ��
    result_HV(i) = HV(Final_Pop(:,D+1:D+M));   
    dlmwrite(strcat('ResultPF',char(num2str(i)),'.txt'),Final_Pop,'newline','pc');  
    dlmwrite(strcat('obj_var',char(num2str(i)),'.txt'),obj_var,'newline','pc');
    dlmwrite(strcat('VI_data',char(num2str(i)),'.txt'),VI_data,'newline','pc');
    fprintf('the number of %d function has been finished\n',i);
end

dlmwrite(strcat('result_HV','.txt'),result_HV','newline','pc');

% Best compromise solution
[~,index] = max(result_HV);
bestPF = Result{index};
bestvar = Result_var{index};
[~,worst_index] = min(result_HV);
worstPF = Result{worst_index};
bestdata = Result_data{index};
dlmwrite(strcat('bestPF','.txt'),bestPF,'newline','pc');
dlmwrite(strcat('worstPF','.txt'),worstPF,'newline','pc');
objPF = bestPF(:,D+1:D+M);
objPF = flip(sortrows(objPF,1));
[no_par,no_pf] = size(objPF);
miu_pf = zeros(no_par,no_pf);
 for jj = 1:no_pf
    max_pareto = max(objPF(:,jj));
    min_pareto = min(objPF(:,jj));
    miu_pf(:,jj) = (repmat(max_pareto,no_par,1)-objPF(:,jj))./(max_pareto-min_pareto);
 end
 miu_sum = sum(miu_pf,2);
 miu_wt = miu_sum./sum(miu_sum);
 [miu_max,bestindex] = max(miu_wt);
 
 bestsolution = bestPF(bestindex,:);
 best_obj_var = bestvar(bestindex,:);
 best_VI_data = bestdata(bestindex,:);
 dlmwrite(strcat('bestsolution','.txt'),bestsolution,'newline','pc');  
 dlmwrite(strcat('best_obj_var','.txt'),best_obj_var,'newline','pc');
 dlmwrite(strcat('best_VI_data','.txt'),best_VI_data,'newline','pc');

toc()

% plot(Final_Pop(:,11 + 1),Final_Pop(:,11 + 2),'r.');
% 
% xlabel('f_1'); ylabel('f_2');
% title('Pareto Optimal Front');

