function net = TrainDQN(XTrain,YTrain)

layers = [
    featureInputLayer(101, 'Name', 'input')
    fullyConnectedLayer(30, 'Name', 'fc1')
    reluLayer('Name', 'relu1')
    fullyConnectedLayer(30, 'Name', 'fc2')
    reluLayer('Name', 'relu2')
    fullyConnectedLayer(1, 'Name', 'fc3')
    tanhLayer('Name', 'tanh1')
    ];

net = dlnetwork(layers);

% 设定训练参数
numEpochs = 100;
miniBatchSize = 60;
learnRate = 0.001;

% 创建 Adam 优化器
averageGrad = [];
averageSqGrad = [];

XTrain = XTrain';
YTrain = YTrain';

for epoch = 1:numEpochs
    % 遍历每个 mini-batch
    for i = 1:miniBatchSize:size(XTrain, 2)
        idx = i:min(i+miniBatchSize-1, size(XTrain, 2));
        X = XTrain(:,idx);
        Y = YTrain(:,idx);
        dlX = dlarray(X, 'CB');
        dlY = dlarray(Y, 'CB');
        dlYPred = forward(net, dlX);
        loss = mse(dlYPred, dlY);

        % 求前向传播和损失
        [~, gradients] = dlfeval(@modelGradients, net, loss);

        % % 更新网络参数
        [net, averageGrad, averageSqGrad] = adamupdate(net, gradients, ...
            averageGrad, averageSqGrad, epoch, learnRate);
    end

end
end

function [loss, gradients] = modelGradients(net, loss)
    gradients = dlgradient(loss, net.Learnables);
end

function loss = customLoss(Y, T)
    % Y 是网络的输出，T 是目标值
    loss = sum((Y - T).^2, 'all');
end