function net = UpdateActor(net,critic_net,XTrain)

% 设定训练参数
numEpochs = 100;
miniBatchSize = 60;
learnRate = 0.001;

% 创建 Adam 优化器
averageGrad = [];
averageSqGrad = [];

XTrain = XTrain';

for epoch = 1:numEpochs
    % 遍历每个 mini-batch
    for i = 1:miniBatchSize:size(XTrain, 2)
        idx = i:min(i+miniBatchSize-1, size(XTrain, 2));
        X = XTrain(:,idx);
        dlX = dlarray(X, 'CB');
        action = forward(net,dlX);
        reward = forward(critic_net,dlarray([X;double(extractdata(action))],'CB'));
        loss = sum(-reward(:,1));

        % 求前向传播和损失
        % [~, gradients] = dlfeval(@modelGradients, net, X, dlX, critic_net);
        [~, gradients] = dlfeval(@modelGradients1, net, loss);
        % [loss, gradients] = dlfeval(@(x) dlgradient(scalarFunction(x), x), x);

        % % 更新网络参数
        [net, averageGrad, averageSqGrad] = adamupdate(net, gradients, ...
            averageGrad, averageSqGrad, epoch, learnRate);
    end

end
end

function [loss, gradients] = modelGradients(net, X, dlX, critic_net)
    action = forward(net, dlX);
    dlYPred = critic_net([X,double(extractdata(action))]);
    loss = customLoss(dlYPred(:,end));
    gradients = dlgradient(single(loss), net.Learnables);
end

function [loss, gradients] = modelGradients1(net, loss)
    gradients = dlgradient(loss, net.Learnables);
end

function loss = customLoss(Y)
    % Y 是网络的输出，T 是目标值
    loss = sum(dlarray(-Y,'CB'));
end