function DeleteRpeat()
global AP AF AV AFit;
[m,~]=size(AFit);
for i=1:m
    if i>m
        break;
    end
    F=AFit(i,:);
    j=i+1;
    while j<m
        if AFit(j,1)==F(1,1)&&AFit(j,2)==F(1,2)
            AP(j,:)=[];  
            AV(j,:,:)=[];  
            AF(j,:)=[];  
            AFit(j,:)=[];
            j=j-1;
            m=m-1;
        end
        j=j+1;
    end
end
end