function [N,NS,F,NM,stime,ptime]=DATAREAD_DHWSP(filepath)
% filepath='DATASET//20J4S2F.txt';
fin=fopen(filepath,'r');
A=fscanf(fin,'%d');
A=A';

N=A(1);
F=A(2);
NS=A(3);

NM=zeros(F,NS);
p=4;

f_index=A(p);
p=p+1;
ptime=zeros(F,NS,N);
stime=zeros(F,NS,N);
for f=1:F
    for s=1:NS
        NM(f,s)=A(p);
        p=p+1;
        for i=1:N   
            stime(f,s,i)=A(p);
            p=p+1;
            ptime(f,s,i)=A(p);
            p=p+1;
        end
    end
    p=p+1;
end

fclose(fin);

end
