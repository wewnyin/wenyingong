clear all
close all

rehash

format long g

warning ('off'); 

run_times = 30;
Max_NFE = 50000;
tic()
    for type=1:5
        for i=1:run_times
            [solution ,value ,nfes] = itlbo(@ModelFunction,type,Max_NFE);
%             ppsolution(i,:) = solution;
            meanss(type,i) = value;
        end
%         [bestvalue,bestindex]=min(meanss(type,:));
%         bestSolution = ppsolution(bestindex,:);
        pp(type,:) = [min(meanss(type,:)),max(meanss(type,:)),mean(meanss(type,:)),std(meanss(type,:))];
        fprintf('the number of %d function has been finished\n',type);
    end
toc()
