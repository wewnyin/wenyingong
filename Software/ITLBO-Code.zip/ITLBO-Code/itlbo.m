function [ solution , value ,NFE] = itlbo( ObjectFunction, type, Max_NFE)

    stderr=1;
    more off
    
    %% Parameter settings
    NP=50;
    NFE = 0;
    [LB,UB,Nvars] = Parameter(type);
    
     %% Initialize the population randomly 
     X=zeros(NP,Nvars);
     for i=1:Nvars
         X(:,i) = randraw('unif',[LB(i),UB(i)],NP,1);
     end
     
     % calculate the objective function value for each individual
     CurrentOFV = zeros(1,NP);
     for i=1:NP
         CurrentOFV(i) = ObjectFunction(type,X(i,:));
         NFE = NFE+1;
     end

     
     %% loop
      while NFE<Max_NFE 
          
          [sorted,indices] = sort(CurrentOFV);
          Xteacher = X(indices(1),:);% Xteacher
          
          finalX = Xteacher;
          finalY = sorted(1);
          
          Xmean = mean(X); % mean of the class
          f_mean = ObjectFunction(type,Xmean);
          NFE = NFE+1;
          CurrentOFV = sorted;
          X = X(indices,:);

         %% teacher phase
          for i=1:NP
              if CurrentOFV(i)<=f_mean
                  r1 = randi(NP);
                  while r1==i
                      r1 = randi(NP);
                  end
                  
                  r2 = randi(NP);
                  while r2==r1 || r2==i
                      r2 = randi(NP); 
                  end
                  New_X(i,:) = X(i,:)+rand.*(Xteacher-X(i,:))+rand.*(X(r1,:)-X(r2,:));
              else
                  New_X(i,:) = X(i,:)+rand.*(Xteacher-round(rand+1).*Xmean);
              end
              
              % Boundary handling
              for j=1:Nvars
                  if New_X(i,j)<LB(j)
                      New_X(i,j) = LB(j)+rand()*(UB(j)-LB(j));
                  end
                  
                  if New_X(i,j)>UB(j)
                      New_X(i,j) = LB(j)+rand()*(UB(j)-LB(j));
                  end
              end
              
              New_CurrentOFV(i) = ObjectFunction(type,New_X(i,:));
              NFE = NFE+1;
              if New_CurrentOFV(i)<CurrentOFV(i)
                  X(i,:) = New_X(i,:);
                  CurrentOFV(i) = New_CurrentOFV(i);
              end
              
          end
          
          [sorted,indices] = sort(CurrentOFV);
          CurrentOFV = sorted;
          Xmean = mean(X); 
          f_mean = ObjectFunction(type,Xmean);
          NFE = NFE+1;
          X = X(indices,:);                 
          
          %% learner phase
          for i=1:NP
              if CurrentOFV(i)<=f_mean % better learners
                  if i==1
                     j = i;
                  else
                     j = randi(i-1); 
                  end

                  k = randi(NP);
                  while i==k || j==k
                      k = randi(NP);
                  end
                  
                  New_X(i,:) = X(i,:)+rand.*(X(j,:)-X(k,:));
              else
                  
                  r1 = randi(NP);
                  while i==r1
                      r1 = randi(NP);
                  end
                  r2 = randi(NP);
                  while i==r2 || r1==r2
                      r2 = randi(NP);
                  end
                  
                  r3 = randi(NP);
                  while i==r3 || r1==r3 || r2==r3
                      r3 = randi(NP);
                  end
                  r4 = randi(NP);
                  while i==r4 || r1==r4 || r2==r4 || r3==r4
                      r4 = randi(NP);
                  end
                  New_X(i,:) = X(i,:)+rand.*(X(r1,:)-X(r2,:))+rand().*(X(r3,:)-X(r4,:));
              end
              
               % Boundary handling
              for j=1:Nvars
                  if New_X(i,j)<LB(j)
                      New_X(i,j) = LB(j)+rand()*(UB(j)-LB(j));
                  end
                  
                  if New_X(i,j)>UB(j)
                      New_X(i,j) = LB(j)+rand()*(UB(j)-LB(j));
                  end
              end
              
              New_CurrentOFV(i) = ObjectFunction(type,New_X(i,:));
              NFE = NFE+1;
              
              if New_CurrentOFV(i)<CurrentOFV(i)
                  X(i,:) = New_X(i,:);
                  CurrentOFV(i) = New_CurrentOFV(i);
              end
              
          end
          
          
      end
      
      solution = finalX;
      value = finalY;
      


end

