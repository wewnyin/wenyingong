// ProblemDef.h: interface for the CProblemDef class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_)
#define AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../global.h"
#include "Individual.h"
#include "Rand.h"


// only for unconstrained optimization problems
class CProblemDef  
{
public:
	CProblemDef();
	virtual ~CProblemDef();

	// for unconstrained optimization problems
public:
	int		flag_once;
	CRand	m_rnd;

	void	evaluate_normal_fitness(double *xreal,tFitness &obj, 
				double *constr, int func_flag, long int &evaluations);

public:
	tFitness	actual_V_data[1000], actual_I_data[1000], model_I_data[1000];
	int			data_len;
	/************************************************************************/
	/* only for the photovoltaic problem                                    */
	/************************************************************************/
	// Ref: K.M. El-Naggar, et al, Simulated Annealing algorithm for photovoltaic parameters identification, Solar Energy 86 (2012) 266-274
	tFitness	calculate_objective_single(double *x, double V_L, double I_L);
	void		PV_model_single (double *x, tFitness &obj, double *constr);					// 1

	tFitness	calculate_objective_double(double *x, double V_L, double I_L);
	void		PV_model_double (double *x, tFitness &obj, double *constr);					// 2

	tFitness	calculate_objective_module(double *x, double V_L, double I_L);
	void		PV_model_module (double *x, tFitness &obj, double *constr);					// 3

	tFitness	calculate_objective_module_double(double *x, double V_L, double I_L);
	void		PV_model_module_double (double *x, tFitness &obj, double *constr);			// 4


};

#endif // !defined(AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_)
