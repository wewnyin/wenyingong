
/* Program:   Parameter extraction of solar cell models using repaired adaptive differential evolution
   Author:    Wenyin Gong
   E-mail:    wenyingong@yahoo.com; wygong@cug.edu.cn
   Date:      18/7/2013
   License:   free
   Platform:  Microsoft Visual C++ 6.0
   Reference: 
              1. W. Gong and Z. Cai, "Differential Evolution with Ranking-based Mutation Operators,"
                 IEEE Transactions on Cybernetics. Jan. 2013. Accepted.
              2. W. Gong and Z. Cai, "Parameter extraction of solar cell models using repaired adaptive differential evolution,"
                 Solor Energy. 2013, 94: 209 - 220.
*/



