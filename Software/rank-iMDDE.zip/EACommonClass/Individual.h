// Individual.h: interface for the CIndividual class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INDIVIDUAL_H__A05E59DB_40D8_4282_9D3C_A0201898ACA8__INCLUDED_)
#define AFX_INDIVIDUAL_H__A05E59DB_40D8_4282_9D3C_A0201898ACA8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../global.h"

/* global parameters (changed with different problems sloved) */
#define batch_execution			0			// 1: for batch execution; 0: original execution (mannual)

/* the following parameters are problem dependent */
#define Max_of_NFEs				20000		// the maximal number of function evaluations

#define PRECISION				1e-6		// value to reach (VTR)
/* ---------------------------------------------- */

#define population_size			30			// size of the population
/* -------------------------------------------------------------- */

class CIndividual
{
public:
	CIndividual();
	virtual ~CIndividual();

public:
	CIndividual(const CIndividual &);							// �������캯��
	CIndividual &operator=(const CIndividual &);				// ����"="�����

	static int	N_of_x;
	static int	N_of_constr;
	static int	index_of_constrain;

public:
	double		*xreal;				// Real Coded Decision Variable
	tFitness	obj;				// value of the objective function
	tFitness	fitness;			// fitness of the objective function
	double		constr_violation;	// parameter for constraint violation
    double		*constr;			// defining the constraint values
	int			feasible;			// check the individual is feasible or not (1: feasible; 0: infeasible)
	int			no_of_violation;	// number of the violated constraint functions
};

#endif // !defined(AFX_INDIVIDUAL_H__A05E59DB_40D8_4282_9D3C_A0201898ACA8__INCLUDED_)
