// ConstrainedProblemDef.cpp: implementation of the CConstrainedProblemDef class.
//
//////////////////////////////////////////////////////////////////////

#include "ConstrainedProblemDef.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CConstrainedProblemDef::CConstrainedProblemDef()
{
	epsilon = 1e-8;		// tolerance of the equality conversion
}

CConstrainedProblemDef::~CConstrainedProblemDef()
{
}

void CConstrainedProblemDef::evaluate_constraint_fitness(double *x, tFitness &obj, double *constr,
													int &no_of_violation, int &feasible, double &cv,
													int func_flag, long int &evaluations)
{
	switch(func_flag) {
	case 1:
		EOPs_01_welded_beam_design1(x,obj,constr,no_of_violation,feasible,cv);
		break;
	case 2:
		EOPs_02_welded_beam_design2(x,obj,constr,no_of_violation,feasible,cv);
		break;
	case 3:
		EOPs_03_spring_design(x,obj,constr,no_of_violation,feasible,cv);
		break;
	case 4:
		EOPs_04_speed_reducer_design(x,obj,constr,no_of_violation,feasible,cv);
		break;
	case 5:
		EOPs_05_three_bar_truss_design(x,obj,constr,no_of_violation,feasible,cv);
		break;
	default:
		printf("The function you selected does not exist.\n");
		exit(0);
		break;
	}
	evaluations++;		// increase the number of fitness function evaluations
}

/*
   !!!!!!!!!!!!!!!!! NOTE !!!!!!!!!!!!!!!!!!!!
   1. Convert all of the constrained function into g(x) <= 0.0
   2. The objective problem does not convert into the minimal objective problem
*/

/*  Test problem g01
    # of real variables = 4
    # of constraints    = 5
    */
void CConstrainedProblemDef::EOPs_01_welded_beam_design1(double *x,tFitness &obj, double *constr, int &no_of_violation, int &feasible, double &cv)
{
	double P,L,M_delta,EE,G,M_tau,M_sigma,M,R,J;
	double tau, tau_1, tau_2, sigma, delta, pc;
	double c[20], ps = 0.0;
	int    i;

	P       = 6000.0;
	L       = 14.0;
	M_delta = 0.25;
	EE      = 3.0E+7;
	G       = 1.2E+7;
	M_tau   = 13600.0;
	M_sigma = 30000.0;

	/************************************************************************/
	/* For objective function's value                                       */
	/************************************************************************/
	obj = 1.10471*pow(x[0],2)*x[1] + 0.04811*x[2]*x[3]*(14.0+x[1]);

	/************************************************************************/
	/* For constrained functions' values                                    */
	/************************************************************************/
	tau_1 = P/(sqrt(2.0)*x[0]*x[1]);
	M     = P * (L+x[1]/2.0);
	R     = sqrt(pow(x[1],2)/4.0+pow((x[0]+x[2])/2.0,2));
	J     = 2*(x[0]*x[1]/sqrt(2)*(pow(x[1],2)/12.0+pow((x[0]+x[2])/2.0,2)));
	tau_2 = M*R/J;
	tau   = sqrt(pow(tau_1,2)+2*tau_1*tau_2*x[1]/(2*R)+pow(tau_2,2));
	sigma = 6.0*P*L/(x[3]*pow(x[2],2));
	delta = 4.0*P*pow(L,3)/(EE*x[3]*pow(x[2],3));
	pc    = 4.013*sqrt(EE*G*pow(x[2],2)*pow(x[3],6)/36.0)*(1-x[2]*sqrt(EE/(4.0*G))/(2.0*L))/pow(L,2);

	c[0]  = tau - M_tau;
	c[1]  = sigma - M_sigma;
	c[2]  = x[0] - x[3];
	c[3]  = delta - M_delta;
	c[4]  = P - pc;

	/************************************************************************/
	/* For constraints                                                      */
	/************************************************************************/
	feasible        = TRUE;
	no_of_violation = 0;
	cv              = 0.0;
	for(i=0;i<CIndividual::N_of_constr;i++)
	{
		if(c[i]>0)
		{
			cv += c[i];
			feasible=FALSE;
			no_of_violation++;
		}
	}

	for (i=0;i<CIndividual::N_of_constr;i++)
	{
		if (c[i] <= ps)
		{
			c[i] = 0.0;
		}
		constr[i] = c[i];
	}

	return;
}

/*  Test problem g02
    # of real variables = 4
    # of constraints    = 7
    */
void CConstrainedProblemDef::EOPs_02_welded_beam_design2(double *x,tFitness &obj, double *constr, int &no_of_violation, int &feasible, double &cv)
{
	double P,L,M_delta,EE,G,M_tau,M_sigma,M,R,J;
	double tau, tau_1, tau_2, sigma, delta, pc;
	double c[20], ps = 0.0;
	int    i;

	P       = 6000.0;
	L       = 14.0;
	M_delta = 0.25;
	EE      = 3.0E+7;
	G       = 1.2E+7;
	M_tau   = 13600.0;
	M_sigma = 30000.0;

	/************************************************************************/
	/* For objective function's value                                       */
	/************************************************************************/
	obj = 1.10471*pow(x[0],2)*x[1] + 0.04811*x[2]*x[3]*(14.0+x[1]);

	/************************************************************************/
	/* For constrained functions' values                                    */
	/************************************************************************/
	tau_1 = P/(sqrt(2.0)*x[0]*x[1]);
	M     = P * (L+x[1]/2.0);
	R     = sqrt(pow(x[1],2)/4.0+pow((x[0]+x[2])/2.0,2));
	J     = 2.0*(sqrt(2)*x[0]*x[1]*(pow(x[1],2)/12.0+pow((x[0]+x[2])/2.0,2)));
	tau_2 = M*R/J;
	tau   = sqrt(pow(tau_1,2)+2*tau_1*tau_2*x[1]/(2*R)+pow(tau_2,2));
	sigma = 6.0*P*L/(x[3]*pow(x[2],2));
	delta = 4.0*P*pow(L,3)/(EE*x[3]*pow(x[2],3));
	pc    = 4.013*EE*sqrt(pow(x[2],2)*pow(x[3],6)/36.0)*(1-x[2]*sqrt(EE/(4.0*G))/(2.0*L))/pow(L,2);

	c[0]  = tau - M_tau;
	c[1]  = sigma - M_sigma;
	c[2]  = x[0] - x[3];
	c[3]  = delta - M_delta;
	c[4]  = P - pc;
	c[5]  = 0.10471*x[0]*x[0]+0.04811*x[2]*x[3]*(14.0+x[1])-5.0;
	c[6]  = 0.125-x[0];

	/************************************************************************/
	/* For constraints                                                      */
	/************************************************************************/
	feasible        = TRUE;
	no_of_violation = 0;
	cv              = 0.0;
	for(i=0;i<CIndividual::N_of_constr;i++)
	{
		if(c[i]>0)
		{
			cv += c[i];
			feasible=FALSE;
			no_of_violation++;
		}
	}

	for (i=0;i<CIndividual::N_of_constr;i++)
	{
		if (c[i] <= ps)
		{
			c[i] = 0.0;
		}
		constr[i] = c[i];
	}

	return;
}



/*  Test problem g03
    # of real variables = 3
    # of constraints    = 4
    */
void CConstrainedProblemDef::EOPs_03_spring_design(double *x,tFitness &obj, double *constr, int &no_of_violation, int &feasible, double &cv)
{
	/************************************************************************/
	/* For objective function's value                                       */
	/************************************************************************/
	obj = (x[2]+2.0)*x[0]*pow(x[1],2);

	/************************************************************************/
	/* For constrained functions' values                                    */
	/************************************************************************/
	double c[20];
	c[0] = 1.0 - pow(x[0],3)*x[2]/(71785.0*pow(x[1],4));
	c[1] = (4.0*pow(x[0],2)-x[0]*x[1])/(12566.0*(x[0]*pow(x[1],3)-pow(x[1],4)))+1.0/(5108.0*pow(x[1],2))-1.0;
	c[2] = 1.0 - 140.45*x[1]/(pow(x[0],2)*x[2]);
	c[3] = (x[0]+x[1])/1.5 - 1.0;

	/************************************************************************/
	/* For constraints                                                      */
	/************************************************************************/
	int    i;
	double ps = 0.0;
	feasible        = TRUE;
	no_of_violation = 0;
	cv              = 0.0;
	for(i=0;i<CIndividual::N_of_constr;i++)
	{
		if(c[i]>0)
		{
			cv += c[i];
			feasible=FALSE;
			no_of_violation++;
		}
	}

	for (i=0;i<CIndividual::N_of_constr;i++)
	{
		if (c[i] <= ps)
		{
			c[i] = 0.0;
		}
		constr[i] = c[i];
	}

	return;
}

/*  Test problem g04
    # of real variables = 7
    # of constraints    = 11
    */
void CConstrainedProblemDef::EOPs_04_speed_reducer_design(double *x,tFitness &obj, double *constr, int &no_of_violation, int &feasible, double &cv)
{
	/************************************************************************/
	/* For objective function's value                                       */
	/************************************************************************/
	double x3;
	x3  = floor(x[2]+0.5);
	obj = 0.7854*x[0]*pow(x[1],2)*(3.3333*pow(x3,2)+14.9334*x3-43.0934) - 1.508*x[0]*(pow(x[5],2)+pow(x[6],2))
		+ 7.4777*(pow(x[5],3)+pow(x[6],3)) + 0.7854*(x[3]*pow(x[5],2)+x[4]*pow(x[6],2));

	/************************************************************************/
	/* For constrained functions' values                                    */
	/************************************************************************/
	double c[20];
	c[0]  = 27.0/(x[0]*pow(x[1],2)*x3) - 1.0;
	c[1]  = 397.5/(x[0]*pow(x[1],2)*pow(x3,2)) - 1.0;
	c[2]  = 1.93*pow(x[3],3)/(x[1]*x3*pow(x[5],4)) - 1.0;
	c[3]  = 1.93*pow(x[4],3)/(x[1]*x3*pow(x[6],4)) - 1.0;
	c[4]  = sqrt(pow(745.0*x[3]/(x[1]*x3),2)+(1.69E+7))/(110.0*pow(x[5],3)) - 1.0;
	c[5]  = sqrt(pow(745.0*x[4]/(x[1]*x3),2)+(1.575E+8))/(85.0*pow(x[6],3)) - 1.0;
	c[6]  = x[1]*x3/40.0 - 1.0;
	c[7]  = 5.0*x[1]/x[0] - 1.0;
	c[8]  = x[0]/(12.0*x[1]) - 1.0;
	c[9]  = (1.5*x[5]+1.9)/x[3] - 1.0;
	c[10] = (1.1*x[6]+1.9)/x[4] - 1.0;

	/************************************************************************/
	/* For constraints                                                      */
	/************************************************************************/
	int    i;
	double ps = 0.0;
	feasible        = TRUE;
	no_of_violation = 0;
	cv              = 0.0;
	for(i=0;i<CIndividual::N_of_constr;i++)
	{
		if(c[i]>0)
		{
			cv += c[i];
			feasible=FALSE;
			no_of_violation++;
		}
	}

	for (i=0;i<CIndividual::N_of_constr;i++)
	{
		if (c[i] <= ps)
		{
			c[i] = 0.0;
		}
		constr[i] = c[i];
	}

	return;
}

/*  Test problem g05
    # of real variables = 2
    # of constraints    = 3
    */
void CConstrainedProblemDef::EOPs_05_three_bar_truss_design(double *x,tFitness &obj, double *constr, int &no_of_violation, int &feasible, double &cv)
{
	double L,P,sigma;
	/************************************************************************/
	/* For objective function's value                                       */
	/************************************************************************/
	L   = 100.0; P = 2.0; sigma = 2.0;
	obj = (2.0*sqrt(2.0)*x[0]+x[1]) * L;

	/************************************************************************/
	/* For constrained functions' values                                    */
	/************************************************************************/
	double c[20];
	c[0] = (sqrt(2.0)*x[0]+x[1])*P/(sqrt(2.0)*pow(x[0],2)+2*x[0]*x[1])-sigma;
	c[1] = x[1]*P/(sqrt(2.0)*pow(x[0],2)+2*x[0]*x[1])-sigma;
	c[2] = P/(x[0]+sqrt(2.0)*x[1])-sigma;

	/************************************************************************/
	/* For constraints                                                      */
	/************************************************************************/
	int    i;
	double ps = 0.0;
	feasible        = TRUE;
	no_of_violation = 0;
	cv              = 0.0;
	for(i=0;i<CIndividual::N_of_constr;i++)
	{
		if(c[i]>0)
		{
			cv += c[i];
			feasible=FALSE;
			no_of_violation++;
		}
	}

	for (i=0;i<CIndividual::N_of_constr;i++)
	{
		if (c[i] <= ps)
		{
			c[i] = 0.0;
		}
		constr[i] = c[i];
	}

	return;
}
