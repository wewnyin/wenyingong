// ConstrainedProblemDef.h: interface for the CConstrainedProblemDef class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CONSTRAINEDPROBLEMDEF_H__7E5BBA9D_B8CA_4DD1_B4BD_DBED7B755F3B__INCLUDED_)
#define AFX_CONSTRAINEDPROBLEMDEF_H__7E5BBA9D_B8CA_4DD1_B4BD_DBED7B755F3B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../global.h"
#include "Individual.h"

class CConstrainedProblemDef
{
public:
	CConstrainedProblemDef();
	virtual ~CConstrainedProblemDef();

	double epsilon;		// tolerance of the equality constraint

	void	evaluate_constraint_fitness(double *xreal,tFitness &obj, double *constr,
		 int &no_of_violation, int &feasible, double &cv,
		 int func_flag, long int &evaluations);

public:
	// constrained functions	
	/* Problems 1, 3 - 5:
	   Ref: INS2008 Differential evolution with dynamic stochastic selection for constrained optimization
	*/
	void EOPs_01_welded_beam_design1 (double *x,tFitness &obj, double *constr, int &no_of_violation, int &feasible, double &cv);
	void EOPs_02_welded_beam_design2 (double *x,tFitness &obj, double *constr, int &no_of_violation, int &feasible, double &cv);
	void EOPs_03_spring_design (double *x,tFitness &obj, double *constr, int &no_of_violation, int &feasible, double &cv);
	void EOPs_04_speed_reducer_design (double *x,tFitness &obj, double *constr, int &no_of_violation, int &feasible, double &cv);
	void EOPs_05_three_bar_truss_design (double *x,tFitness &obj, double *constr, int &no_of_violation, int &feasible, double &cv);

};

#endif // !defined(AFX_CONSTRAINEDPROBLEMDEF_H__7E5BBA9D_B8CA_4DD1_B4BD_DBED7B755F3B__INCLUDED_)
