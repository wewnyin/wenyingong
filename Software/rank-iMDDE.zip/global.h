#ifndef GLOBAL_H_INCLUDED
#define GLOBAL_H_INCLUDED

// --------------------include files--------------------
#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <fstream>
#include <iomanip>
#include <stdio.h>
#include <assert.h>

using namespace std;


// --------------------Global variables--------------------
#define E	exp(1.0)
#define PI	acos(-1.0)
#define INF	1.0e99
#define EPS 1.0e-14		// the precision of the constraints

#define max(a,b) (((a) > (b)) ? (a) : (b))
#define min(a,b) (((a) < (b)) ? (a) : (b))

#define DBL_MAX 1.7976931348623158e+308

#define TRUE	1
#define FALSE	0

typedef long double tFitness;


#endif // GLOBAL_H_INCLUDED
