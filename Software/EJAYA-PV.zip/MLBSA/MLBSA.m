function [ optValue,bestP,endNFEs] = MLBSA(fType,pType,Max_NFE,NP)
%SATLBO �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    addpath('../');
    stderr=1;
    more off
    
    NFE = 0;
    z=rand;
    rate=1;
    type=fType;
    
    [UB,LB,Nvars] = Parameter(pType);
    
     X=(UB-LB).*rand(NP,Nvars)+LB;
     for num=1:NP
         for i=1:Nvars
             history_X(num,i)=LB(i)+rand*(UB(i)-LB(i));
         end
     end
     
     for i=1:NP
         CurrentOFV(i) = TestFunction(type,X(i,:));
         NFE = NFE+1;
     end
     OFV=CurrentOFV;
     
    while NFE<Max_NFE
         
        if rand<rand
            history_X=X;
        end
        history_X=history_X(randperm(NP),:);
        F=3*randn; 
     
         map=ones(NP,Nvars);     %����map    
         if rand<rand
            for i=1:NP 
                u=randperm(Nvars); 
                map(i,u(1:ceil(rate*rand*Nvars)))=0;  
            end
         else
            for i=1:NP
                map(i,randi(Nvars))=0; 
            end
         end
     
         % Mutation 
        for i=1:NP
                r1= randi(NP);
                while r1==i 
                    r1= randi(NP);
                end
                if rand<rand
                   X_newi=X(i,:)+ F.*((history_X(i,:)-X(i,:))+(X(r1,:)-X(i,:))); %%%
                else 
                   [~,index1]=min(CurrentOFV);    %%%
                   X_newi=X(i,:)+rand(1,Nvars).*(X(index1,:)-X(i,:));
                end

                %% �߽紦��
                 for j=1:Nvars
                     if X_newi(j)<LB(j)
                         X_newi(j) = LB(j)+rand()*(UB(j)-LB(j));
                     end

                     if X_newi(j)>UB(j)
                         X_newi(j) = LB(j)+rand()*(UB(j)-LB(j));
                     end
                 end

                 newX_OFVi =  TestFunction(type,X_newi);
                 NFE = NFE+1;
                 OFV(NFE)=newX_OFVi;

                 if newX_OFVi<CurrentOFV(i)
                     X(i,:) = X_newi;
                     CurrentOFV(i) = newX_OFVi;
                 end

        end
        [sorted,indices] = sort(CurrentOFV);
     
          FE_best=  sorted(1);
          Xbest=X(indices(1),:); 

          z=4*z*(1-z);  
     
         for k=1:Nvars
                if rand<1-NFE/Max_NFE
                    newX(k)=Xbest(k)+rand*(2*z-1);
                else
                    newX(k)=Xbest(k);                        
                end       

                %�߽紦��
                 if newX(k)<LB(k)
                     newX(k) = LB(k)+rand()*(UB(k)-LB(k));
                 end
                 if newX(k)>UB(k)
                     newX(k) = LB(k)+rand()*(UB(k)-LB(k));
                 end
         end   
            
        newX_OFV =  TestFunction(type,newX);
        NFE = NFE+1;
        OFV(NFE)=newX_OFV;
             
             if newX_OFV<CurrentOFV(indices(end))
                 X(indices(end),:) = newX;
                 CurrentOFV(indices(end)) = newX_OFV;
             end
             
             [sorted,indices] = sort(CurrentOFV);
     
          FE_best=  sorted(1);
          Xbest=X(indices(1),:); 
    end

    %% ���ս�����
    endNFEs=NFE;
    optValue=FE_best;
    bestP=Xbest;

  

end

