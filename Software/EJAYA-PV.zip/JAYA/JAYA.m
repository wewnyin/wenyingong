function [optValue,bestP,endNFEs]=JAYA(fType,pType,Max_NFEs,NP)

    addpath('../');
    [ UB,LB,Dim ] = Parameter(pType);

    index=fType;%���Ժ�������

    MaMi=(repmat((UB-LB),NP,1));
    MiLB=repmat((LB),NP,1);
    X=MaMi.*rand(NP,Dim)+MiLB;%���������ʼ��Ⱥ����
    
    for i=1:NP
        fitnessX(i)=TestFunction(index,X(i,:));
    end
    NFEs=NP;
    [fitnessBestX,~]=min(fitnessX);%��¼��õĸ�����Ӧֵ

    while NFEs<Max_NFEs

        [sortFitnessX,sortIndexX]=sort(fitnessX);
        Xbest=X(sortIndexX(1),:);
        Xworst=X(sortIndexX(end),:);
        
        for i=1:NP               

            rand1=rand;
            rand2=rand;
            for j=1:Dim %ԭ�ķ�ʽ
                V(i,j) = X(i,j)+rand1*(Xbest(j)-abs(X(i,j)))-rand2*(Xworst(j)-abs(X(i,j)));
            end

            for j=1:Dim
                if V(i,j)>UB(j) || V(i,j)<LB(j)
                    V(i,j)=LB(j)+rand*(UB(j)-LB(j));
                end
            end

            fitnessV(i)=TestFunction(index,V(i,:));
            NFEs=NFEs+1;

            if fitnessV(i)<fitnessX(i)
                X(i,:)=V(i,:);
                fitnessX(i)=fitnessV(i);
            end
        end
        
        [fitnessBestX,recordIndex]=min(fitnessX);%��¼��õĸ�����Ӧֵ
        
    end
    
        %% ���ս�����
    endNFEs=NFEs;
    optValue=fitnessBestX;
    bestP=X(recordIndex,:);

end
