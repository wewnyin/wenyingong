function [optValue,bestP,endNFEs] = GOTLBO( ~,pType,Max_NFE,NP)
%TLBO �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    addpath('../');
    stderr=1;
    more off
    
    Jr = 0.3;
    NFE = 0;
    iter = 0;
    type=pType;
    [UB,LB,Nvars] = Parameter(pType);
     %% ��ʼ����ȺP
     X=(UB-LB).*rand(NP,Nvars)+LB;
      
     CurrentOFV = zeros(1,NP);
     
     for i=1:NP
         CurrentOFV(i) = TestFunction(type,X(i,:));
         NFE = NFE+1;
     end
     OFV=CurrentOFV;
     
     %% ����һ��GO��ȺGOP
     GOX=zeros(NP,Nvars);
     for i=1:NP
         for d=1:Nvars
             GOX(i,d) = rand*(LB(d)+UB(d))-X(i,d);
             if GOX(i,d)< LB(d) || GOX(i,d)>UB(d)
                GOX(i,d) = LB(d)+ rand*(UB(d)-LB(d)) ;
             end
         end
     end
     GOXCurrentOFV = zeros(1,NP);
     
     for i=1:NP
         GOXCurrentOFV(i) = TestFunction(type,GOX(i,:));
         NFE = NFE+1;
         OFV(NFE)=GOXCurrentOFV(i);
     end
     
    
     %% ����ȺX��GOX��ѡ��NP��������Ϊ��ʼ��Ⱥ
     UnionXGOX_X = [X;GOX];
     UnionXGOX_F = [CurrentOFV, GOXCurrentOFV];
     
     [sortedF,index] = sort(UnionXGOX_F);
     
     X(1:NP,:) = UnionXGOX_X(index(1:NP),:);
     CurrentOFV(1:NP) = sortedF(1:NP);
     
%      for i=1:NP
%          if GOXCurrentOFV(i)<CurrentOFV(i)
%              X(i,:) = GOX(i,:);
%              CurrentOFV(i) = GOXCurrentOFV(i);
%          end
%      end
         
     [sorted,indices] = sort(CurrentOFV);
     Xteacher = X(indices(1),:);%�õ���õ�Xteacher
     Xmean = mean(X); % �õ���ֵXmean
     
     finalX = Xteacher;
     finalY = sorted(1);
     
     %% loop
      while NFE<Max_NFE 
          

          %% teacher phase 
          for i=1:NP
              New_X(i,:) = X(i,:)+rand.*(Xteacher-round(rand()+1).*Xmean);
              
              for j=1:Nvars
                  if New_X(i,j)<LB(j)
                      New_X(i,j) = LB(j)+rand()*(UB(j)-LB(j));
                  end
                  
                  if New_X(i,j)>UB(j)
                      New_X(i,j) = LB(j)+rand()*(UB(j)-LB(j));
                  end
              end
              
              New_CurrentOFV(i) = TestFunction(type,New_X(i,:));
              NFE = NFE+1;
              OFV(NFE)=New_CurrentOFV(i) ;
              
              if New_CurrentOFV(i)<CurrentOFV(i)
                  X(i,:) = New_X(i,:);
                  CurrentOFV(i) = New_CurrentOFV(i);
              end
              
          end
          
          %% learner phase
          for i=1:NP
              j = randi(NP);
              while i==j
                  j = randi(NP);
              end
              if CurrentOFV(i)<CurrentOFV(j)
                  New_X(i,:) = X(i,:)+rand.*(X(i,:)-X(j,:));
              else
                  New_X(i,:) = X(i,:)+rand.*(X(j,:)-X(i,:));
              end
              
              for j=1:Nvars
                  if New_X(i,j)<LB(j)
                      New_X(i,j) = LB(j)+rand()*(UB(j)-LB(j));
                  end
                  
                  if New_X(i,j)>UB(j)
                      New_X(i,j) = LB(j)+rand()*(UB(j)-LB(j));
                  end
              end
              
              New_CurrentOFV(i) = TestFunction(type,New_X(i,:));
              NFE = NFE+1;
              OFV(NFE)=New_CurrentOFV(i) ;
              
              if New_CurrentOFV(i)<CurrentOFV(i)
                  X(i,:) = New_X(i,:);
                  CurrentOFV(i) = New_CurrentOFV(i);
              end
          end
          
          %% ����Jr�����Ƿ�����µ���Ⱥ
          if rand<Jr
              for i=1:NP
                  for d=1:Nvars
                      GOX(i,d) = rand*(LB(d)+UB(d))-X(i,d);
                      if GOX(i,d)< LB(d) || GOX(i,d)>UB(d)
                          GOX(i,d) = LB(d)+ rand*(UB(d)-LB(d)) ;
                      end
                  end
              end
              
              for i=1:NP
                  GOXCurrentOFV(i) = TestFunction(type,GOX(i,:));
                  NFE = NFE+1;
                  OFV(NFE)=GOXCurrentOFV(i);
              end
              
              UnionXGOX_X = [X;GOX];
              UnionXGOX_F = [CurrentOFV, GOXCurrentOFV];
     
              [sortedF,index] = sort(UnionXGOX_F);
     
              X(1:NP,:) = UnionXGOX_X(index(1:NP),:);
              CurrentOFV(1:NP) = sortedF(1:NP);
              
%               for i=1:NP
%                   if GOXCurrentOFV(i)<CurrentOFV(i)
%                       X(i,:) = GOX(i,:);
%                       CurrentOFV(i) = GOXCurrentOFV(i);
%                   end
%               end
          end
  
          
          [sorted,indices] = sort(CurrentOFV);
          Xteacher = X(indices(1),:);%�õ���õ�Xteacher
          Xmean = mean(X); % �õ���ֵXmean
          
          finalX = Xteacher;
          finalY = sorted(1);
          iter = iter+1;
          
      end
      
      %% ���ս�����
    endNFEs=NFE;
    optValue=finalY;
    bestP=finalX;
      


end

