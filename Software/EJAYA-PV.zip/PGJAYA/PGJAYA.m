function [optValue,bestP,endNFEs]=PGJAYA(fType,pType,Max_NFEs,NP)
    addpath('../');
    [ UB,LB,Dim ] = Parameter(pType);
    
    z=rand;
    index=fType;%���Ժ�������

    MaMi=(repmat((UB-LB),NP,1));
    MiLB=repmat((LB),NP,1);
    X=MaMi.*rand(NP,Dim)+MiLB;%���������ʼ��Ⱥ����

    
    for i=1:NP
        fitnessX(i)=TestFunction(index,X(i,:));
    end
    NFEs=NP;
    [fitnessBestX,~]=min(fitnessX);%��¼��õĸ�����Ӧֵ

    while NFEs<Max_NFEs

        [sortFitnessX,sortIndexX]=sort(fitnessX);
        Xbest=X(sortIndexX(1),:);
        Xworst=X(sortIndexX(end),:);
        for i=1:NP
            R(sortIndexX(i))=NP-i;
            PV(sortIndexX(i))=(R(sortIndexX(i))/NP)^2;
        end

        for i=1:NP
            if rand>PV(i)
                % Strategy 1
                w=1;
                if sortFitnessX(end)~=0
                    w=(sortFitnessX(1)/sortFitnessX(end))^2;
                end
                

                for j=1:Dim %ԭ�ķ�ʽ
                    V(i,j) = X(i,j)+rand*(Xbest(j)-abs(X(i,j)))-w*rand*(Xworst(j)-abs(X(i,j)));
                end
                
            else
                % Strategy 2
                l=randi([1,NP]);
                while (rand>PV(l) || l==i)
                    l=randi([1,NP]);
                end
                m=randi([1,NP]);
                while (m==l || m==i)
                    m=randi([1,NP]);
                end
                
                for j=1:Dim %ԭ�ķ�ʽ
                    V(i,j) = X(i,j)+rand*(X(l,j)-X(m,j));
                end

            end

            for j=1:Dim
                if V(i,j)>UB(j) || V(i,j)<LB(j)
                    V(i,j)=LB(j)+rand*(UB(j)-LB(j));
                end
            end

            fitnessV(i)=TestFunction(index,V(i,:));
            NFEs=NFEs+1;

            if fitnessV(i)<fitnessX(i)
                X(i,:)=V(i,:);
                fitnessX(i)=fitnessV(i);
            end
        end

        [sortFitnessX,sortIndexX]=sort(fitnessX);
        Xbest=X(sortIndexX(1),:);
        Xworst=X(sortIndexX(end),:);

        for j=1:Dim
            Xbetter(j)=Xbest(j);
            if rand < 1-(NFEs/Max_NFEs)
                Xbetter(j)=Xbest(j)+rand*(2*z-1);
            end

            if Xbetter(j)>UB(j) || Xbetter(j)<LB(j)
                Xbetter(j)=LB(j)+rand*(UB(j)-LB(j));
            end
        end

        z=4*z*(1-z);
        
        if TestFunction(index,Xbetter)<=sortFitnessX(end)
            X(sortIndexX(end),:)=Xbetter;
            fitnessX(sortIndexX(end))=TestFunction(index,Xbetter);
        end
        NFEs=NFEs+1;
        
        [fitnessBestX,recordIndex]=min(fitnessX);%��¼��õĸ�����Ӧֵ
        
    end
    
        %% ���ս�����
    endNFEs=NFEs;
    bestP=X(recordIndex,:);
    optValue=fitnessBestX;

end
