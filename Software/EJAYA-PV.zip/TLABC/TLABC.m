function [ optValue,bestP,endNFEs] = TLABC( ~,pType,Max_NFE,NP)
%TLBO �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    addpath('../');
    stderr=1;
    more off

    limit = 200;
    NFE = 0;
    iter = 0;
     type=pType;
    [UB,LB,Nvars] = Parameter(pType);
     %% ��ʼ��
     X=(UB-LB).*rand(NP,Nvars)+LB;
     trial = zeros(1,NP);
     
     CurrentOFV = zeros(1,NP);
     Fitness = zeros(1,NP);
     
     for i=1:NP
         CurrentOFV(i) = TestFunction(type,X(i,:));
         % ����Ŀ�꺯��ֵ����Ӧֵ
         if CurrentOFV(i)>=0
             Fitness(i) = 1/(1+CurrentOFV(i));
         else
             Fitness(i) = 1+abs(CurrentOFV(i));
         end
         NFE = NFE+1;
         OFV=CurrentOFV(i);
     end
     
     [sorted,indices] = sort(CurrentOFV);
     Xteacher = X(indices(1),:);%�õ���õ�Xteacher
     Xmean = mean(X); % �õ���ֵXmean
     
     finalX = Xteacher;
     finalY = sorted(1);
     
     %% loop
      while NFE<Max_NFE 
          
          %% Teaching-based employed bee phase
          for i=1:NP
              if rand<0.5
                  New_X(i,:) = X(i,:)+rand.*(Xteacher-(rand()+1).*Xmean);
              else
                  r1 = randi(NP);
                  while r1==i
                    r1 = randi(NP);
                  end
                  r2 = randi(NP);
                  while r2==r1 || r2==i
                    r2 = randi(NP);
                  end
                  r3 = randi(NP);
                  while r3==r2 || r3==r1 || r3==i
                      r3 = randi(NP);
                  end
%                   F = unifrnd(0,1,1,1);
                  New_X(i,:) = X(r1,:)+rand*(X(r2,:)-X(r3,:));
              end
              % �߽紦��
              for j=1:Nvars
                  if New_X(i,j)<LB(j)
                      New_X(i,j) = LB(j)+rand()*(UB(j)-LB(j));
                  end
                  
                  if New_X(i,j)>UB(j)
                      New_X(i,j) = LB(j)+rand()*(UB(j)-LB(j));
                  end
              end
              
              New_CurrentOFV(i) = TestFunction(type,New_X(i,:));
              NFE = NFE+1;
              OFV(NFE)=New_CurrentOFV(i);
              ;
              if New_CurrentOFV(i)>=0
                  New_Fitness(i) = 1/(1+New_CurrentOFV(i));
              else
                  New_Fitness(i) = 1+abs(New_CurrentOFV(i));
              end
              
              if New_CurrentOFV(i)<CurrentOFV(i)
                  X(i,:) = New_X(i,:);
                  CurrentOFV(i) = New_CurrentOFV(i);
                  Fitness(i) = New_Fitness(i);
                  trial(i) = 0;
              else
                  trial(i) = trial(i)+1;
              end

          end
          
          % ����ѡ�����
          for i=1:NP
              pv(i) = CurrentOFV(i)/sum(CurrentOFV);
          end
          
          %% learning-based on looker bee phase
          for i=1:NP
              % ѡ��Xs
%               total = 0;
%               for m=1:NP
%                   total = total+pv(m);
%                   if total>rand
%                       s = m;
%                       break;
%                   end
%               end
%               if m==NP
%                   s = i;
%               end
               s = randi(NP);
               while pv(s)<rand
                  s = randi(NP);
               end
              
              j = randi(NP);
              while j==s
                 j = randi(NP);
              end
              if CurrentOFV(s)<CurrentOFV(j)
                  New_X(s,:) = X(s,:)+rand.*(X(s,:)-X(j,:));
              else
                  New_X(s,:) = X(s,:)+rand.*(X(j,:)-X(s,:));
              end
              
              % �߽紦��
              for j=1:Nvars
                  if New_X(s,j)<LB(j)
                      New_X(s,j) = LB(j)+rand()*(UB(j)-LB(j));
                  end
                  
                  if New_X(s,j)>UB(j)
                      New_X(s,j) = LB(j)+rand()*(UB(j)-LB(j));
                  end
              end
              
              New_CurrentOFV(s) = TestFunction(type,New_X(s,:));
              NFE = NFE+1;
              OFV(NFE)=New_CurrentOFV(s);
              
              if New_CurrentOFV(s)>=0
                  New_Fitness(s) = 1/(1+New_CurrentOFV(s));
              else
                  New_Fitness(s) = 1+abs(New_CurrentOFV(s));
              end
              
              if New_CurrentOFV(s)<CurrentOFV(s)
                  X(s,:) = New_X(s,:);
                  CurrentOFV(s) = New_CurrentOFV(s);
                  Fitness(s) = New_Fitness(s);
                  trial(s) = 0;
              else
                  trial(s) = trial(s)+1;
              end
          end
          
          %% Generalized oppositional scout bee phase
          for i=1:NP
              if trial(i)>=limit
                  for j=1:Nvars
                      XX(i,j) = LB(j)+rand*(UB(j)-LB(j));
                      GOX(i,j) = rand*(UB(j)+LB(j))-XX(i,j);
                      if GOX(i,j)>UB(j) || GOX(i,j)<LB(j)
                         GOX(i,j) = LB(j)+rand*(UB(j)-LB(j));
                      end
                  end
                  
                  f(i) = TestFunction(type,XX(i,:));
                  NFE = NFE+1;
                  OFV(NFE)=f(i);
                  
                  fgox(i) = TestFunction(type,GOX(i,:));
                  OFV(NFE)=fgox(i);
                  
                  NFE = NFE+1;
                  if f(i)>=0
                      Xfitness(i) = 1/(1+f(i));
                  else
                      Xfitness(i) = 1+abs(f(i));
                  end
                  
                  if fgox(i)>=0
                      XGOfitness(i) = 1/(1+fgox(i));
                  else
                      XGOfitness(i) = 1+abs(fgox(i));
                  end
                  
                  if f(i)<=fgox(i)
                      X(i,:) = XX(i,:);
                      CurrentOFV(i) = f(i);
                      Fitness(i) = Xfitness(i);
                  else
                      X(i,:) = GOX(i,:);
                      CurrentOFV(i) = fgox(i);
                      Fitness(i) = XGOfitness(i);
                  end
              end
          end

          [sorted,indices] = sort(CurrentOFV);
          Xteacher = X(indices(1),:);%�õ���õ�Xteacher
          Xmean = mean(X); % �õ���ֵXmean
          
          finalX = Xteacher;
          finalY = sorted(1);
          iter = iter+1;
          
      end
     endNFEs=NFE;
    optValue=finalY;
    bestP=finalX;
      


end

