function [optValue,bestP,endNFEs]=IJAYA(fType,pType,Max_NFEs,NP)
    addpath('../');
    [ UB,LB,Dim ] = Parameter(pType);
    
    z=rand;
    index=fType;%���Ժ�������

    MaMi=(repmat((UB-LB),NP,1));
    MiLB=repmat((LB),NP,1);
    X=MaMi.*rand(NP,Dim)+MiLB;%���������ʼ��Ⱥ����

    
    for i=1:NP
        fitnessX(i)=TestFunction(index,X(i,:));
    end
    NFEs=NP;
    [fitnessBestX,~]=min(fitnessX);%��¼��õĸ�����Ӧֵ

    while NFEs<Max_NFEs

        [sortFitnessX,sortIndexX]=sort(fitnessX);
        Xbest=X(sortIndexX(1),:);
        Xworst=X(sortIndexX(end),:);
        
         w=1;
         if sortFitnessX(end)~=0
            w=(sortFitnessX(1)/sortFitnessX(end))^2;
         end

        for i=1:NP
            
            if (X(i,:)~=Xbest)
                if (rand<rand)
                    for j=1:Dim %ԭ�ķ�ʽ
                        V(i,j) = X(i,j)+rand*(Xbest(j)-abs(X(i,j)))-w*rand*(Xworst(j)-abs(X(i,j)));
                    end
                else
                    other=randperm(NP,2);
                    while (other(1)==i || other(2)==i)
                        other=randperm(NP,2);
                    end
                    for j=1:Dim %ԭ�ķ�ʽ
                        if (TestFunction(index,X(other(1),:))<TestFunction(index,X(other(2),:)))
                            V(i,j) = X(i,j)+rand*(X(other(1),j)-X(other(2),j));
                        else
                            V(i,j) = X(i,j)+rand*(X(other(2),j)-X(other(1),j));
                        end
                    end
                end
            elseif (X(i,:)==Xbest)             
                for j=1:Dim
                        V(i,j)=Xbest(j)+rand*(2*z-1);
                end
                z=4*z*(1-z);
            end
            
            
            for j=1:Dim
                if V(i,j)>UB(j) || V(i,j)<LB(j)
                    V(i,j)=LB(j)+rand*(UB(j)-LB(j));
                end
            end

            fitnessV(i)=TestFunction(index,V(i,:));
            NFEs=NFEs+1;

            if fitnessV(i)<fitnessX(i)
                X(i,:)=V(i,:);
                fitnessX(i)=fitnessV(i);
            end
        end

        [sortFitnessX,sortIndexX]=sort(fitnessX);
        Xbest=X(sortIndexX(1),:);
        Xworst=X(sortIndexX(end),:);
        
        [fitnessBestX,recordIndex]=min(fitnessX);%��¼��õĸ�����Ӧֵ
        
    end
    
        %% ���ս�����
    endNFEs=NFEs;
    bestP=X(recordIndex,:);
    optValue=fitnessBestX;

end
