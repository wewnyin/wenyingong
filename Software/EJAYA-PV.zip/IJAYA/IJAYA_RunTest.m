clear all
clc

format long;
format compact;
warning('off');

runtime=30;

tic()
    indexFun=input('Input the type of TestFuntion:');
    indexPara=indexFun;
    NP = 20;
    
    if indexFun==1
        maxNFEs=50000;
    elseif indexFun==2
        maxNFEs=50000;
    elseif indexFun==3
        maxNFEs=50000;
     elseif indexFun==4
        maxNFEs=50000;
    elseif indexFun==5 
        maxNFEs=50000;
    end
    
    disp(strcat('��',num2str(indexFun),'��ģ�ͽ��Ϊ��'));
   
    for j=1:runtime
        [bestValue(j),bestP(j,:),bestNFEs(j)]=IJAYA(indexFun,indexPara,maxNFEs,NP);
    end

    rmse_static=[min(bestValue),mean(bestValue),max(bestValue),std(bestValue)];
    [minRMSE,index]=min(bestValue);
    result=bestP(index,:);

    disp(strcat('NP=',num2str(NP),'ʱΪ��'));

    if indexFun==1||indexFun==3||indexFun==4||indexFun==5
        disp(strcat('I_pv=',num2str(bestP(index,1)),',I_sd=',num2str(bestP(index,2)),',R_s=',num2str(bestP(index,3)),...
        ',R_p=',num2str(bestP(index,4)),',a=',num2str(bestP(index,5)),',RMSE=',num2str(minRMSE),',NFEs=',num2str(bestNFEs(1))));
    elseif indexFun==2
        disp(strcat('I_pv=',num2str(bestP(index,1)),',I_sd1=',num2str(bestP(index,2)),',R_s=',num2str(bestP(index,3)),...
            ',R_p=',num2str(bestP(index,4)),',a1=',num2str(bestP(index,5)),',I_sd2=',num2str(bestP(index,6)),...
            ',a2=',num2str(bestP(index,7)),',RMSE=',num2str(minRMSE),',NFEs=',num2str(bestNFEs(1))));
    end

    disp(strcat('Min=',num2str(rmse_static(1)),',Mean=',num2str(rmse_static(2)),',Max=',num2str(rmse_static(3)),',Std=',num2str(rmse_static(4))));
        
    
toc()

