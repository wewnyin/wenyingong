function [optValue,bestP,endNFEs]=EJAYA2(fType,pType,Max_NFEs,NP,P)

    addpath('../CauchyFunction');
    addpath('../');

    [ UB,LB,Dim ] = Parameter(pType);

    index=fType;%���Ժ�������

    X=(UB-LB).*rand(NP,Dim)+LB;%���������ʼ��Ⱥ����
    
    uF1=0.5;%��ʼ����������
    uF2=0.5;
    c=0.1;
    NPg_current=NP;
    NPmin=3;%��С��Ⱥ��ģ
    Ra=0.3;
    
    for i=1:NP
        fitnessX(i)=TestFunction(index,X(i,:));
    end
    NFEs=NP;
    OFV=fitnessX;
    [fitnessBestX,~]=min(fitnessX);%��¼��õĸ�����Ӧֵ

    while NFEs<Max_NFEs

        Sf1=[];%��ʼ�ɹ��μӱ���ĸ������������Ϊ�ռ�
        Sf2=[];
        n0=1;%��¼Scr��Sf�е�Ԫ�ظ���
        
        [sortFitnessX,sortIndexX]=sort(fitnessX);
        Xbest=X(sortIndexX(1),:);
        Xworst=X(sortIndexX(end),:);
        
        for i=1:NPg_current
            F1(i)=cauchyrnd(uF1,0.1);%���ӿ����ֲ�
            F2(i)=cauchyrnd(uF2,0.1);
            while (F1(i)<=0||F2(i)<=0)
                F1(i)=cauchyrnd(uF1,0.1);
                F2(i)=cauchyrnd(uF2,0.1);
            end
            if (F1(i)>1||F2(i)>1)
                F1(i)=1;
                F2(i)=1;
            end
        end
        

        for i=1:NPg_current               
                
%             for j=1:Dim %ԭ�ķ�ʽ
%                 V(i,j) = X(i,j)+rand*(Xbest(j)-abs(X(i,j)))-rand*(Xworst(j)-abs(X(i,j)));
%             end
                
                V(i,:)=X(i,:)+F1(i).*(Xbest-abs(X(i,:)))-F2(i).*(Xworst-abs(X(i,:)));

            for j=1:Dim
                if V(i,j)>UB(j) || V(i,j)<LB(j)
                    V(i,j)=LB(j)+rand*(UB(j)-LB(j));
                end
            end
           
            fitnessV(i)=TestFunction(index,V(i,:));
            NFEs=NFEs+1;
            OFV(NFEs)=fitnessV(i);

            if fitnessV(i)<fitnessX(i)
                Sf1(n0)=F1(i);
                Sf2(n0)=F2(i);
                n0=n0+1;
                X(i,:)=V(i,:);
                fitnessX(i)=fitnessV(i);
            end
        end
        
        [~,ab]=size(Sf1);
        if ab~=0
            newSf1=(sum(Sf1.^2))/(sum(Sf1));
            uF1=(1-c)*uF1+c.*newSf1;
            newSf2=(sum(Sf2.^2))/(sum(Sf2));
            uF2=(1-c)*uF2+c.*newSf2;
        end
        
        NPg_current=round((NPmin-NP)/Max_NFEs*NFEs+NP);
        numP=size(X,1);
        
        if NPg_current<numP
            [~,indexSortP2]=sort(fitnessX);
            %LPSR���ơ���ɾ����Ⱥ����õ� (NPg_current-NPg_next)������ 
            X(indexSortP2(NPg_current+1:numP),:)=[]; 
            fitnessX(indexSortP2(NPg_current+1:numP))=[]; 

        end
        
%         if rand<Ra
%             maxBoun=max(X);
%             minBoun=min(X);
%             for i=1:NPg_current
%                 GOP(i,:)=rand.*(maxBoun+minBoun)-X(i,:);
%                 for j=1:Dim
%                     if GOP(i,j)>maxBoun(j) || GOP(i,j)<minBoun(j)
%                         GOP(i,j)=minBoun(j)+rand*(maxBoun(j)-minBoun(j));
%                     end
%                 end
%                 fitnessGOP(i)=TestFunction(index,GOP(i,:));
%                 NFEs=NFEs+1;
%                 OFV(NFEs)=fitnessV(i);
%             end
%             fitnessNew=[fitnessX,fitnessGOP];
%             NewP=[X;GOP];
%             [sortFitnessNew,sortIndex]=sort(fitnessNew);
%             X=NewP(sortIndex(1:NPg_current),:);
%             fitnessX=sortFitnessNew(1:NPg_current);
%         end
%         
        [fitnessBestX,recordIndex]=min(fitnessX);%��¼��õĸ�����Ӧֵ
        
    end
    
        %% ���ս�����
    endNFEs=NFEs;
    optValue=fitnessBestX;
    bestP=X(recordIndex,:);

end
