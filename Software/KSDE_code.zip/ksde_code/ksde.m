

function [peakslocation]=ksde(funcNum,bounds,optima,tolerance,popSize,maxGen)
warning off;
global xl xu
F=0.5;
CR=0.9;
minSize=5;
theta=0.5;
st=2;
NP=popSize;
XRmin=bounds(:,1)';
XRmax=bounds(:,2)';
D=size(bounds,1);
if D>5
    t_dis=0.01;
    tolerance=0.0001;
else
    t_dis=0.01;
    tolerance=0.000001;
end
Lbound=bounds(:,1)';
Ubound=bounds(:,2)';
Max_FES=NP*maxGen;
xl=bounds(:,1)';
xu=bounds(:,2)';
numOpt=size(optima,1);

for i=1:popSize
    pop(i,:)=XRmin+(XRmax-XRmin).*rand(1,D);
end

val=zeros(1,popSize);          % create and reset the "cost array"
DE_gbest=zeros(1,D);           % best population member ever
nfeval=0;                    % number of function evaluations

%------Evaluate the best member after initialization----------------------
ibest   = 1;                      % start with first population member

val(1)=myeobj(pop(ibest,:),funcNum);%

DE_gbestval = val(1);                 % best objective function value so far
nfeval  = nfeval + 1;
for i=2:popSize                        % check the remaining members
    val(i)=myeobj(pop(i,:),funcNum);    
    nfeval  = nfeval + 1;
    if (val(i) < DE_gbestval)           % if member is better
        ibest   = i;                 % save its location
        DE_gbestval = val(i);          
    end   
end
DE_gbest = pop(ibest,:);         % best member of current iteration
bestvalit = DE_gbestval;              % best value of current iteration


%------popold is the population which has to compete.  pop is the population.----------------------------------------


iter = 0;
while nfeval < Max_FES 
%------one-step k-means cluster--------
    k=unidrnd(5)+7;
    random_no=randperm(NP);
    cluster_center=pop(random_no(1:k),:);  
    record=zeros(1,k);
    distancemin=ones(NP,1);
    for i=1:NP
        for cluster_index=2:k
            a=sum((pop(i,:)-cluster_center(distancemin(i),:)).^2,2); 
            b=sum((pop(i,:)-cluster_center(cluster_index,:)).^2,2);
            if b<a
                distancemin(i)=cluster_index;
            end
        end
        record(distancemin(i))=record(distancemin(i))+1;
    end
       
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    for i=1:k
        spop(i).pop=pop(distancemin==i,:);%Individuals in i-th cluster as a species  
        spop(i).val=val(distancemin==i);
        for m=1:NP %Mark individuals that have been assigned to species
            if distancemin(m)==i;
                pop(m,:)=1000*ones(1,D);
            end
        end
        for j=1:size(spop(i).pop,1);
            popold=spop(i).pop(j,:);
            newpop1=spop(i).pop;
            if size(spop(i).pop,1)<minSize
                if iter>=theta*maxGen   %ksde/n 
                    ss=pop(distancemin~=i,:);
                    [tempss s]=sort(sqrt(sum((ones(size(ss,1),1)*cluster_center(i,:)-ss).^2,2)));
                    newpop1(size(spop(i).pop,1)+1:minSize,:)=ss(s(1:minSize-size(spop(i).pop,1)),:);
                else  %ksde/r
                    for kk=size(spop(i).pop,1)+1:minSize
                        newpop1(kk,:)=XRmin+(XRmax-XRmin).*rand(1,D);
                    end
                end
            end
            [min_spop_val min_spop_val_index]=min(spop(i).val);
            bm=spop(i).pop(min_spop_val_index,:);
            ui(j,1:D)=DE(popold,newpop1,bm,st,F,CR,D,size(newpop1,1));%Execute DE to produce offspring
            tempval(j,1)=myeobj(ui(j,:),funcNum);%���㺯��ֵ
            nfeval  = nfeval + 1;
            if tempval(j,1)>tolerance %Different crowding factors
                checkdis=sum((ones(size(spop(i).pop,1),1)*ui(j,:)-spop(i).pop).^2,2);
                [minval,minindex]=min(checkdis);
                if tempval(j,1)<spop(i).val(minindex)
                    spop(i).val(minindex)=tempval(j,1);
                    spop(i).pop(minindex,:)=ui(j,:);
                end
            else
                checkdis=sum((ones(NP,1)*ui(j,:)-pop).^2,2);
                [minval,minindex]=min(checkdis);%Calculate the closest individual in the remaining population
                checkdis2=sum((ones(size(spop(i).pop,1),1)*ui(j,:)-spop(i).pop).^2,2);%Calculate the closest individual in the species
                [minval2,minindex2]=min(checkdis2);
                if minval<minval2 %Selection with individuals in the population
                    if tempval(j,1)<pop(minindex)
                        pop(minindex)=tempval(j,1);
                        pop(minindex,:)=ui(j,:);
                    end
                else %Selection with individuals in the species
                    if tempval(j,1)<spop(i).val(minindex2)
                        spop(i).val(minindex2)=tempval(j,1);
                        spop(i).pop(minindex2,:)=ui(j,:);
                    end
                end
            end
            
        end
        cur=1;
        for index=1:NP %Restore marked individuals
            if pop(index,:)==1000*ones(1,D)
                pop(index,:)=spop(i).pop(cur,:);
                val(index)=spop(i).val(cur);
                cur=cur+1;
            end
        end        
    end
         
  
    
   
    for i=1:k
        spop(i).pop=[];
        spop(i).val=[];
    end



    iter = iter + 1;

end %---end while 

    peaks=10000*ones(numOpt,1);
    distance=10000*ones(numOpt,1);
    peakslocation=10000*ones(numOpt,D);  
    for u=1:numOpt
        checkdis=sum((ones(size(pop,1),1)*optima(u,:)-pop).^2,2);
        [minval,minindex]=min(checkdis);
        if abs(val(minindex))<=tolerance && minval<=t_dis
            if val(minindex)<peaks(u)
                peaks(u)=val(minindex);
                peakslocation(u,:)=pop(minindex,:);
            end
        end
    end

best=100;
for i=1:NP
    if val(i)<100
        best=val(i);
        popbest=pop(i,:);
    end
end
finalpeak=[peakslocation,peaks];
endPop=[pop val'];




