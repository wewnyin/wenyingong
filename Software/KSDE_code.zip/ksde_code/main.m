clear all

runTime=30;
testSet=[2,7,9,10,11,12,13,14,16,17,19,20,21,22,23,24,25,26,27,28,29,30,33,34,38,39,40,41,43,44];

result=[];
for index=1:30
    funcNum=testSet(index);
    sr=0;
    rr=0;
    [bounds,optima,tolerance,popSize,maxGen] =parameter( funcNum );
    solutionNum=size(optima,1);
    for i=1:runTime
        flag=1; 
        [solution]=ksde(funcNum,bounds,optima,tolerance,popSize,maxGen);
        current=[index,i]
        for j=1:solutionNum           
            if solution(j,1)~=10000
                rr=rr+1;
            else
                flag=0;
            end
        end
        if flag~=0
            sr=sr+1;
        end   
    end       
    srMean(index)=sr/runTime;
    rrMean(index)=rr/(runTime*solutionNum);
    result=[srMean', rrMean']
end
resultMean=mean(result,1)     

       
        
        
                  
                               
         
        
        

        
       