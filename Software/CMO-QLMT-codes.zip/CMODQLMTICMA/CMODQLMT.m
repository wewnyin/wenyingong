classdef CMODQLMT < ALGORITHM
% <multi> <real> <constrained>
% EMT and DQL based CMOEA

    methods
        function main(Algorithm,Problem)
            %% Generate random population
            Population{1} = Problem.Initialization();
            Population{2} = Problem.Initialization();
            Population{3} = Problem.Initialization();
            alpha1 = 2./(1+exp(1).^(-Problem.FE*10/Problem.maxFE))-1;
            para = ceil(Problem.maxFE/Problem.N)/2 - ceil(Problem.FE/Problem.N);
            Population{4} = Problem.Initialization();
            Zmin       = min(Population{4}.objs,[],1);
            Fmin       = min(Population{4}(all(Population{4}.cons<=0,2)).objs,[],1);
            Fitness{1} = CalFitness(Population{1}.objs,Population{1}.cons);
            Fitness{3} = CalFitness(Population{3}.objs);
            LengthO{1} = Problem.N/2; LengthO{2} = Problem.N/2; LengthO{3} = Problem.N/2; LengthO{4} = Problem.N/2;
            W          = UniformPoint(Problem.N,Problem.M);
            Ra         = 1;
            
            %% For DQL
            Data = [];
            num_task = 3;
            learning = 0.5;
            model_built = 0;
            count = 0;
            greedy = 0.9;
            gama = 0.9;
            train = 0;

            %% Optimization
            while Algorithm.NotTerminated(Population{1})
                gen        = ceil(Problem.FE/Problem.N);
                if Problem.FE < learning * Problem.maxFE
                    % generate offspring
                    % Re-rank
                    Population{1} = Population{1}(randperm(Problem.N));
                    Population{2} = Population{2}(randperm(Problem.N));
                    Lia   = ismember(Population{2}.objs,Population{1}.objs, 'rows');
                    gamma = 1-sum(Lia)/Problem.N;
                    [Population{2},Fitness{2},~] = EnvironmentalSelectionT2(Population{2},Problem.N,alpha1,gamma,para);
                    MatingPool{1} = TournamentSelection(2,2*LengthO{1},Fitness{1});
                    Offspring{1}  = OperatorGAhalf(Population{1}(MatingPool{1}));
                    MatingPool{2} = TournamentSelection(2,2*LengthO{2},Fitness{2});
                    Offspring{2}  = OperatorGAhalf(Population{2}(MatingPool{2}));
                    MatingPool{3} = TournamentSelection(2,2*LengthO{3},Fitness{3});
                    Offspring{3}  = OperatorGAhalf(Population{3}(MatingPool{3}));
                    Nt     = floor(Ra*Problem.N);
                    if length(Population{1}) > Problem.N-Nt
                        MatingPool{4} = [Population{4}(randsample(Problem.N,Nt)),Population{1}(randsample(Problem.N,Problem.N-Nt))];
                    else
                        MatingPool{4} = Population{4}(randsample(Problem.N,Problem.N));
                    end
                    [Mate1,Mate2,Mate3]        = Neighbor_Pairing_Strategy(MatingPool{4},Zmin);
                    if rand > 0.5
                        Offspring{4}  = OperatorDE(Mate1,Mate2,Mate3);
                    else
                        Offspring{4}  = OperatorDE(Mate1,Mate2,Mate3,{0.5,0.5,0.5,0.75});
                    end
                    
                    % select action
                    if gen <= 200
                        % random select at the first 100 generations
                        action = randi(num_task);
                    else
                        % choose an action based on the trained net
                        if ~model_built
                            % build model here
                            tr_x = Data(:,1:4);
                            [tr_xx,ps] = mapminmax(tr_x');tr_xx=tr_xx';
                            tr_y = Data(:,5:8);
                            [tr_yy,qs] = mapminmax(tr_y');tr_yy=tr_yy';
                            Params.ps  = ps;Params.qs=qs;
                            [net,Params] = trainmodel(tr_xx,tr_yy,Params);
                            model_built = 1;
                            % use the model to choose action
                            %                         if rand > greedy
                            action = randi(num_task);
                            %                         else
                            %                             succ1 = testNet([s,1],net,Params);
                            %                             succ2 = testNet([s,2],net,Params);
                            %                             succ3 = testNet([s,3],net,Params);
                            %                             succ = [succ1,succ2,succ3];
                            %                             [~,action] = max(succ);
                            %                         end
                        else
                            % use the model to choose action
                            if rand > greedy
                                action = randi(num_task);
                            else
                                test_x1 = [s,average_f,average_cv,1];
                                test_x2 = [s,average_f,average_cv,2];
                                test_x3 = [s,average_f,average_cv,3];
                                ps=Params.ps;qs=Params.qs;
                                x1=mapminmax('apply',test_x1',ps);x1=x1';
                                x2=mapminmax('apply',test_x2',ps);x2=x2';
                                x3=mapminmax('apply',test_x3',ps);x3=x3';
                                succ1 = testNet(x1,net,Params);
                                succ1=mapminmax('reverse',succ1',qs);succ1=succ1';
                                succ2 = testNet(x2,net,Params);
                                succ2=mapminmax('reverse',succ2',qs);succ2=succ2';
                                succ3 = testNet(x3,net,Params);
                                succ3=mapminmax('reverse',succ3',qs);succ3=succ3';
                                succ = [succ1;succ2;succ3];
                                [~,action] = max(succ(:,1));
                                
                            end
                        end
                    end
                    
                    % old state
                    s = sum(Fitness{1})/length(Population{1});
                    average_f = sum(sum(Population{1}.objs,2))/length(Population{1});
                    cv = overall_cv(Population{1}.cons);
                    average_cv = sum(cv)/length(Population{1});
                    
                    % determine the transfer rate
                    [~,~,Next1] = EnvironmentalSelectionT1([Population{1},Offspring{1},Population{action+1},Offspring{action+1}],Problem.N);
                    succ_rate =  (sum(Next1(length(Population{1})+length(Offspring{1})+1:end))) / (length(Population{action+1})+length(Offspring{action+1}));
                    
                    current_at = action;
                    
                    % Environmental Selection
                    alpha1 = 2./(1+exp(1).^(-Problem.FE*10/Problem.maxFE)) - 1;
                    para  = ceil(Problem.maxFE/Problem.N)/2 - ceil(Problem.FE/Problem.N);
                    Fmin       = min([Fmin;Offspring{4}(all(Offspring{4}.cons<=0,2)).objs],[],1);
                    Zmin       = min([Zmin;Offspring{4}.objs],[],1);
                    [Population{1},Fitness{1},~] = EnvironmentalSelectionT1([Population{1},Offspring{1},Population{current_at+1},Offspring{current_at+1}],Problem.N);
                    [Population{2},~,~] = EnvironmentalSelectionT2([Population{2},Offspring{2}],Problem.N,alpha1,gamma,para);
                    [Population{3},Fitness{3},~] = EnvironmentalSelectionT3([Population{3},Offspring{3}],Problem.N);
                    [Population{4},~] = ICMA_Update([Population{4},Offspring{4}],Problem.N,W,Zmin,Fmin);
                    
                    % manage data in queue Data as the experience replay, delete the oldest if exceed
                    s1 = sum(Fitness{1})/length(Population{1});
                    average_f1 = sum(sum(Population{1}.objs,2))/length(Population{1});
                    cv1 = overall_cv(Population{1}.cons);
                    average_cv1 = sum(cv1)/length(Population{1});
                    
                    current_record = [s average_f average_cv current_at succ_rate,s1 average_f1 average_cv1];
                    %                 current_record = [s,current_at,s1-s,s1];
                    Data = [Data;current_record];
                    if size(Data,1) > 500
                        Data(end,:) = [];
                    end
                
                else
                    % use the model to choose action
                    if rand > greedy
                        action = randi(num_task);
                    else
                        test_x1 = [s,average_f,average_cv,1];
                        test_x2 = [s,average_f,average_cv,2];
                        test_x3 = [s,average_f,average_cv,3];
                        ps=Params.ps;qs=Params.qs;
                        x1=mapminmax('apply',test_x1',ps);x1=x1';
                        x2=mapminmax('apply',test_x2',ps);x2=x2';
                        x3=mapminmax('apply',test_x3',ps);x3=x3';
                        succ1 = testNet(x1,net,Params);
                        succ1=mapminmax('reverse',succ1',qs);succ1=succ1';
                        succ2 = testNet(x2,net,Params);
                        succ2=mapminmax('reverse',succ2',qs);succ2=succ2';
                        succ3 = testNet(x3,net,Params);
                        succ3=mapminmax('reverse',succ3',qs);succ3=succ3';
                        succ = [succ1;succ2;succ3];
                        [~,action] = max(succ(:,1));
                    end
                    
                    % Offspring Reproduction
                    MatingPool{1} = TournamentSelection(2,2*LengthO{1},Fitness{1});
                    Offspring{1}  = OperatorGAhalf(Population{1}(MatingPool{1}));
                    
                    if action == 1
                        % Re-rank
                        Population{1} = Population{1}(randperm(Problem.N));
                        Population{2} = Population{2}(randperm(Problem.N));
                        Lia   = ismember(Population{2}.objs,Population{1}.objs, 'rows');
                        gamma = 1-sum(Lia)/Problem.N;
                        [Population{2},Fitness{2},~] = EnvironmentalSelectionT2(Population{2},Problem.N,alpha1,gamma,para);
                        MatingPool{2} = TournamentSelection(2,2*LengthO{2},Fitness{2});
                        Offspring{2}  = OperatorGAhalf(Population{2}(MatingPool{2}));
                        
                        % old state
                        s = sum(Fitness{1})/length(Population{1});
                        average_f = sum(sum(Population{1}.objs,2))/length(Population{1});
                        cv = overall_cv(Population{1}.cons);
                        average_cv = sum(cv)/length(Population{1});
                        
                        % determine the transfer rate
                        [~,~,Next1] = EnvironmentalSelectionT1([Population{1},Offspring{1},Population{action+1},Offspring{action+1}],Problem.N);
                        succ_rate =  (sum(Next1(length(Population{1})+length(Offspring{1})+1:end))) / (length(Population{action+1})+length(Offspring{action+1}));
                        
                        current_at = action;
                        
                        % Environmental Selection
                        alpha1 = 2./(1+exp(1).^(-Problem.FE*10/Problem.maxFE)) - 1;
                        para  = ceil(Problem.maxFE/Problem.N)/2 - ceil(Problem.FE/Problem.N);
                        [Population{1},Fitness{1},~] = EnvironmentalSelectionT1([Population{1},Offspring{1},Population{current_at+1},Offspring{current_at+1}],Problem.N);
                        [Population{2},~,~] = EnvironmentalSelectionT2([Population{2},Offspring{2}],Problem.N,alpha1,gamma,para);
                        [Population{3},Fitness{3},~] = EnvironmentalSelectionT3([Population{3},Offspring{3}],Problem.N);
                        
                        % manage data in queue Data as the experience replay, delete the oldest if exceed
                        s1 = sum(Fitness{1})/length(Population{1});
                        average_f1 = sum(sum(Population{1}.objs,2))/length(Population{1});
                        cv1 = overall_cv(Population{1}.cons);
                        average_cv1 = sum(cv1)/length(Population{1});
                        
                        current_record = [s average_f average_cv current_at succ_rate,s1 average_f1 average_cv1];
                        %                 current_record = [s,current_at,s1-s,s1];
                        Data = [Data;current_record];
                        if size(Data,1) > 300
                            Data(end,:) = [];
                        end
                        
                    elseif action == 2
                        MatingPool{3} = TournamentSelection(2,2*LengthO{3},Fitness{3});
                        Offspring{3}  = OperatorGAhalf(Population{3}(MatingPool{3}));
                        
                        % old state
                        s = sum(Fitness{1})/length(Population{1});
                        average_f = sum(sum(Population{1}.objs,2))/length(Population{1});
                        cv = overall_cv(Population{1}.cons);
                        average_cv = sum(cv)/length(Population{1});
                        
                        % determine the transfer rate
                        [~,~,Next1] = EnvironmentalSelectionT1([Population{1},Offspring{1},Population{action+1},Offspring{action+1}],Problem.N);
                        succ_rate =  (sum(Next1(length(Population{1})+length(Offspring{1})+1:end))) / (length(Population{action+1})+length(Offspring{action+1}));
                        
                        current_at = action;
                        
                        % Environmental Selection
                        alpha1 = 2./(1+exp(1).^(-Problem.FE*10/Problem.maxFE)) - 1;
                        para  = ceil(Problem.maxFE/Problem.N)/2 - ceil(Problem.FE/Problem.N);
                        [Population{1},Fitness{1},~] = EnvironmentalSelectionT1([Population{1},Offspring{1},Population{current_at+1},Offspring{current_at+1}],Problem.N);
                        [Population{2},~,~] = EnvironmentalSelectionT2([Population{2},Offspring{2}],Problem.N,alpha1,gamma,para);
                        [Population{3},Fitness{3},~] = EnvironmentalSelectionT3([Population{3},Offspring{3}],Problem.N);
                        
                        % manage data in queue Data as the experience replay, delete the oldest if exceed
                        s1 = sum(Fitness{1})/length(Population{1});
                        average_f1 = sum(sum(Population{1}.objs,2))/length(Population{1});
                        cv1 = overall_cv(Population{1}.cons);
                        average_cv1 = sum(cv1)/length(Population{1});
                        
                        current_record = [s average_f average_cv current_at succ_rate,s1 average_f1 average_cv1];
                        %                 current_record = [s,current_at,s1-s,s1];
                        Data = [Data;current_record];
                        if size(Data,1) > 300
                            Data(end,:) = [];
                        end
                        
                    else
                        Nt     = floor(Ra*Problem.N);
                        if length(Population{1}) > Problem.N-Nt
                            MatingPool{4} = [Population{4}(randsample(Problem.N,Nt)),Population{1}(randsample(Problem.N,Problem.N-Nt))];
                        else
                            MatingPool{4} = Population{4}(randsample(Problem.N,Problem.N));
                        end
          
                        [Mate1,Mate2,Mate3]        = Neighbor_Pairing_Strategy(MatingPool{4},Zmin);
                        if rand > 0.5
                            Offspring{4}  = OperatorDE(Mate1,Mate2,Mate3);
                        else
                            Offspring{4}  = OperatorDE(Mate1,Mate2,Mate3,{0.5,0.5,0.5,0.75});
                        end
                        
                        % old state
                        s = sum(Fitness{1})/length(Population{1});
                        average_f = sum(sum(Population{1}.objs,2))/length(Population{1});
                        cv = overall_cv(Population{1}.cons);
                        average_cv = sum(cv)/length(Population{1});
                        
                        % determine the transfer rate
                        [~,~,Next1] = EnvironmentalSelectionT1([Population{1},Offspring{1},Population{action+1},Offspring{action+1}],Problem.N);
                        succ_rate =  (sum(Next1(length(Population{1})+length(Offspring{1})+1:end))) / (length(Population{action+1})+length(Offspring{action+1}));
                        
                        current_at = action;
                        
                        % Environmental Selection
                        Fmin       = min([Fmin;Offspring{4}(all(Offspring{4}.cons<=0,2)).objs],[],1);
                        Zmin       = min([Zmin;Offspring{4}.objs],[],1);
                        [Population{1},Fitness{1},~] = EnvironmentalSelectionT1([Population{1},Offspring{1},Population{current_at+1},Offspring{current_at+1}],Problem.N);
                        [Population{4},~] = ICMA_Update([Population{4},Offspring{4}],Problem.N,W,Zmin,Fmin);
                        
                        % manage data in queue Data as the experience replay, delete the oldest if exceed
                        s1 = sum(Fitness{1})/length(Population{1});
                        average_f1 = sum(sum(Population{1}.objs,2))/length(Population{1});
                        cv1 = overall_cv(Population{1}.cons);
                        average_cv1 = sum(cv1)/length(Population{1});
                        
                        current_record = [s average_f average_cv current_at succ_rate,s1 average_f1 average_cv1];
                        %                 current_record = [s,current_at,s1-s,s1];
                        Data = [Data;current_record];
                        if size(Data,1) > 300
                            Data(end,:) = [];
                        end
                        
                    end
                    
                end
                
                % update net model every 10 generations
                if model_built
                    count = count + 1;
                    if count > 50
                        % update model here
                        qs=Params.qs;
                        tr_x = Data(:,1:4);
                        [tr_xx,ps] = mapminmax(tr_x');tr_xx=tr_xx';
                        succ1 = testNet(tr_xx,net,Params);
                        succ1=mapminmax('reverse',succ1',qs);succ1=succ1';
                        succ = succ1(:,1);
                        tr_yy = Data(:,5)+gama*max(succ);
                        [tr_yy,qs] = mapminmax(tr_yy');tr_yy=tr_yy';
                        Params.ps  = ps;Params.qs=qs;  
                        net = updatemodel(tr_xx,tr_yy,Params,net);
                        count = 0;
%                         train = train + 1
                    end
                end
            end
        end
    end
end

% The Overall Constraint Violation
function result = overall_cv(cv)
    cv(cv <= 0) = 0;cv = abs(cv);
    result = sum(cv,2);
end