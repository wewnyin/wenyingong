function result=FNODE(func_no,pop,NP,Max_EFs,D,root)
warning off;


F=0.5;
CR=0.9;
st=2;

%Operate=ones(1,NP);
EFs=0;
%result=0;




val       = zeros(1,NP);          % create and reset the "cost array"
%------Evaluate the best member after initialization----------------------
ibest   = 1;                      % start with first population member
val(1)=Equations(pop(ibest,:),func_no);
EFs=EFs+1;
DE_gbestval = val(1);                 % best objective function value so far
%-------������Ⱥ�ҵ����ŵ�--------
for i=2:NP                        % check the remaining members
    val(i)=Equations(pop(i,:),func_no);
    EFs=EFs+1;
    if (val(i) < DE_gbestval)           % if member is better
        ibest   = i;                 % save its location
        DE_gbestval = val(i);
    end
end

DE_gbest = pop(ibest,:);         % best member of current iteration
Best_direct=zeros(NP,D);
m=11;
while EFs <= Max_EFs
    numb=m+m*(Max_EFs-EFs)/Max_EFs;
    [fuzzy,ind]=FUZZY(pop,NP,numb,m);
    
    %Point_best=[pop(max(RKNN_Number),:),val(max(RKNN_Number))];
    % dlmwrite('result.txt', Point_best, '-append', 'precision', '%5f', 'delimiter', '\t')
    
    for i=1:NP

        
        bm=DE_gbest;
        popold=pop(i,:);
 
        
        INDX=fuzzy{i};
        newpop1=pop(INDX,:);
        % direction=Best_direct(ind,:);
        direction=Best_direct(ind(i,:),:);

        
        [ui(i,1:D),xk(i,:)]=DE_New(popold,newpop1,bm,st,F,CR,D,size(newpop1,1),direction);
    end
    for i=1:NP
        tempval(i)=Equations(ui(i,:),func_no); 
        EFs=EFs+1;
    end
    for i=1:NP

        [temp, j]=min(sqrt(sum((ones(NP,1)*ui(i,:)-pop).^2,2)));
        if val(j)>tempval(i)
            Best_direct(j,:)=ui(i,:)-xk(i,:)+ui(i,:)-pop(j,:);
            pop(j,:)=ui(i,:);
            val(j)=tempval(i);
            
            if (tempval(i) < DE_gbestval)     % if competitor better than the best one ever
                DE_gbestval = tempval(i);      % new best value
                DE_gbest = ui(i,:);      % new best parameter vector ever
            end
        else
            Best_direct(i,:)=zeros(1,D);
        end
           
        
    end
    
    
    
    


    
    
    
end
result=0;
for i=1:size(root,1)
    [T,k]=sort(sum((ones(size(pop,1),1)*root(i,:)-pop).^2,2));
    
    if D<=5
        if T(1)<1E-2&&Equations(pop(k(1),:),func_no)<1E-6
            result=result+1;
        end
    else
        if T(1)<1E-2&&Equations(pop(k(1),:),func_no)<1E-4
            result=result+1;
        end
    end
end

end


function [fuzzy,ind]=FUZZY(pop,NP,numb,m)


fuzzy={};
numb=floor(numb);
for i=1:NP
    [temp_value,k_I]=sort(sqrt(sum((ones(NP,1)*pop(i,:)-pop).^2,2)));
    ind(i,:)=k_I(1:m);
    temp=temp_value(1:numb)';
    k=k_I(1:numb)';
    
    
    
    nn=size(temp,2);
    
    
    

% PP=1-exp(-temp.^2);                 % 1
%PP=1-exp(-2*temp);                 %2��
 % PP=1./(1+(temp).^-2);             %3
%PP=1/2+1/2*sin((pi/temp(nn))*(temp-temp(nn)/2));    %4��
PP=temp/temp(nn);              %5��

%  PP=(temp/temp(nn)).^2;
    cand=[];
    %           op=5;
    %           while size(cand,2)<4
    %               cand=[];
    for j=1:nn
        if rand>PP(j)
            cand=[cand,k(j)];
        end
    end
    if size(cand,2)<=1
        cand=k_I(1:numb)';
    end
    
    
    
    
    fuzzy{i}=cand;
end

end
