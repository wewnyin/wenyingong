function [ui,xk]=DE_New(popold,pop,bm,st,F,CR,n,NP,best_direct)



global xl xu
mui = rand(1,n) < CR;          % all random numbers < CR are 1, 0 otherwise
if mui==zeros(1,n),nn=randperm(n);mui(nn(1))=1;end
mpo = mui < 0.5;


if best_direct(1,:)~=0
    ui=popold+sum(best_direct,1);
    xk=popold;
else
    if NP>4
        dx = randperm(NP);
        r1 = dx(1);
        r2 = dx(2);
        r3 = dx(3);
        pm1=pop(r1,1:n);
        pm2=pop(r2,1:n);
        pm3=pop(r3,1:n);
        ui= pm3 + F*(pm1 - pm2)+sum(best_direct,1);
    elseif NP>=3
        r1=1;
        r2=2;
        r3=3;
        pm1=pop(r1,1:n);
        pm2=pop(r2,1:n);
        pm3=pop(r3,1:n);
        ui= pm3 + F*(pm1 - pm2)+sum(best_direct,1);
    elseif NP==2
        direct=(pop(2,:)-pop(1,:))/2+sum(best_direct,1);
        xk=pop(1,:);
        pm3=pop(1,:);
        ui=pop(1,:)+direct;
    end
    ui = popold.*mpo + ui.*mui;
    if sum(mui,2)>=n/2
        xk=pm3;
    else
        xk=popold;
    end
end





if rand>0.5
    ui=(ui<xl).*xl+(ui>=xl).*ui;
    ui=(ui>xu).*xu+(ui<=xu).*ui;
else
    ui=(ui<xl).*(xl+rand(1,n).*(xu-xl))+(ui>=xl).*ui;
    ui=(ui>xu).*(xl+rand(1,n).*(xu-xl))+(ui<=xu).*ui;
end

end




