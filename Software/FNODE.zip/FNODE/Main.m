clear
global xl xu
run_num=50;
I=[9,10,11,12,13,14,2,16,17,29,33,19,30,20,34,21,22,23,24,25,26,27,43,28,44,7,38,39,40,41];
for indx=1:30
fun_num=I(indx);


    [Max_EFs,NP,D,XRmin,XRmax,solution_num,root,fun_name] = Parameter(fun_num);
    fun_name 
    pop=[];
    for i=1:NP
        pop(i,:)=XRmin+(XRmax-XRmin).*rand(1,D);
    end
    xl=XRmin;
    xu=XRmax;
    
  

 for i=1:run_num
     i
     
   

     result(indx,i)=FNODE(fun_num,pop,NP,Max_EFs,D,root);
     if result(indx,i)<solution_num
         root_sucess(i)=0;
     else
         root_sucess(i)=1;
     end
 end
     result_SR(indx)=sum(root_sucess)/run_num;
     result_PR(indx)=sum(result(indx,:))/solution_num/run_num;

     
end

