function lable = GetLable(Solution,non_dom)
% Get the label of each solution, 1 represents is

    N = size(Solution,1);
    M = size(non_dom,1);
    Lables = zeros(N,M);

    %% Detect the dominance relation between each solution in Data and fns
    for i = 1 : N
        for j = 1 : M
            k = any(Solution(i,:)<non_dom(j,:)) - any(Solution(i,:)>non_dom(j,:));
            if k == 1 || k == 0
                Lables(i,j) = 1;
            end
        end
    end
    lable = zeros(1,N);
    lable(sum(Lables,2)==M) = 1;
end