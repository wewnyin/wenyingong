classdef CMOES < ALGORITHM
% <multi> <real/binary/permutation> <constrained>
% Even search
% type --- 1 --- Type of operator (1. GA 2. DE)

    methods
        function main(Algorithm,Problem)
            %% Parameter setting
            type = Algorithm.ParameterSet(1);
            
            %% Generate random population
            Population1 = Problem.Initialization();
            Population2 = Problem.Initialization();
            [~,FrontNo,CrowdDis] = EnvironmentalSelection_NSGA2(Population1,Problem.N);
            Fitness2    = CalFitness(Population2.objs);
            Population3 = Population1;
            stage_changed = 0;
            Population = [Population1,Population2];
            CV = sum(max(0,Population.cons),2);
            max_cv = max(CV);

            %% Optimization
            while Algorithm.NotTerminated(Population1)
                gen        = ceil(Problem.FE/Problem.N);
                CV1 = sum(max(0,Population1.cons),2);
                num_fea = sum(CV1==0);
                if num_fea <= 0 || gen <= 0.2 * ceil(Problem.maxFE/Problem.N)
                    MatingPool = TournamentSelection(2,2*Problem.N,FrontNo,-CrowdDis);
                    if type == 1
                        Offspring  = OperatorGA(Population1(MatingPool));
                    else
                        Offspring  = OperatorDE(Population1,Population1(MatingPool(1:end/2)),Population1(MatingPool(end/2+1:end)));
                    end
                    MatingPool2 = TournamentSelection(2,2*Problem.N,Fitness2);
                    if type == 1
                        Offspring2  = OperatorGAhalf(Population2(MatingPool2));
                    else
                        Offspring2  = OperatorDE(Population2,Population2(MatingPool2(1:end/2)),Population2(MatingPool2(end/2+1:end)));
                    end
                    [Population1,FrontNo,CrowdDis] = EnvironmentalSelection_NSGA2([Population1,Offspring,Offspring2],Problem.N);
                    [Population2,Fitness2] = EnvironmentalSelection([Population2,Offspring,Offspring2],Problem.N,false);
                    Population3 = Population2;
                    Population = [Population1,Population2];
                    CV = sum(max(0,Population.cons),2);
                    max_cv = max(max_cv,max(CV));
                else
                    tau = gen/ceil(Problem.maxFE/Problem.N);
                    Population = [Population1,Population2,Population3];
                    CV = sum(max(0,Population.cons),2);
                    max_cv = max(CV);
                    if stage_changed == 0
                        [~,Fitness2,~,Fitness3] = EvenSearch(Population,Population1(CV1==0),Problem.N,tau,max_cv);
                        [~,Fitness1] = EnvironmentalSelection(Population1,Problem.N,true);
                        stage_changed = 1;
                    end
                    
                    if ~isempty(Population2)
                        MatingPool2 = TournamentSelection(2,2*length(Population2),Fitness2);
                        if type == 1
                            Offspring2  = OperatorGAhalf(Population2(MatingPool2));
                        else
                            Offspring2  = OperatorDE(Population2,Population2(MatingPool2(1:end/2)),Population2(MatingPool2(end/2+1:end)));
                        end
                    else
                        Offspring2 = [];
                    end
                    if ~isempty(Population3)
                        MatingPool3 = TournamentSelection(2,2*length(Population3),Fitness3);
                        if type == 1
                            Offspring3  = OperatorGAhalf(Population3(MatingPool3));
                        else
                            Offspring3  = OperatorDE(Population3,Population3(MatingPool3(1:end/2)),Population3(MatingPool3(end/2+1:end)));
                        end
                    else
                        Offspring3 = [];
                    end
                    MatingPool1 = TournamentSelection(2,2*Problem.N,Fitness1);
                    if type == 1
                        Offspring1  = OperatorGAhalf(Population1(MatingPool1));
                    else
                        Offspring1  = OperatorDE(Population1,Population1(MatingPool1(1:end/2)),Population1(MatingPool1(end/2+1:end)));
                    end
                    
                    Offspring = [Offspring1,Offspring2,Offspring3];
                    
                    [Population1,Fitness1] = EnvironmentalSelection([Population,Offspring],Problem.N,true);
                    [Population2,Fitness2,Population3,Fitness3] = EvenSearch([Population,Offspring],Population1(CV1==0),Problem.N,tau,max_cv);
                    
                end
            end
        end
    end
end