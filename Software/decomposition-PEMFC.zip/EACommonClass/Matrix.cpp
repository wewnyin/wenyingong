// Matrix.cpp: implementation of the CMatrix class.
//
//////////////////////////////////////////////////////////////////////

#include "../global.h"
#include "Matrix.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMatrix::CMatrix()
{
	m_Col = 0;
	m_Row = 0;
	m_pData = NULL;
}

CMatrix::~CMatrix()
{
	m_Col = 0;
	m_Row = 0;
	if(m_pData != NULL)
	{
		delete [] m_pData;
		m_pData =NULL;
	}
}

CMatrix::CMatrix(const CMatrix & m)
{
	m_Row = m.m_Row;
	m_Col = m.m_Col;

	Create(m_Row,m_Col,NULL);
	for(int i=0;i<int(m_Row*m_Col);i++)
	{
		m_pData[i] = m.m_pData[i];
	}
}

CMatrix::CMatrix(int Row,int Col,double *Data)
{
	m_Row = Row;
	m_Col = Col;

	Create(m_Row,m_Col,NULL);
	if(Data != NULL)
	{
		for(int i=0;i<m_Row*m_Col;i++)
		{
			m_pData[i]=Data[i];
		}
	}
}

bool CMatrix::Create(int Row,int Col,double * Data)
{
	m_Row = Row;
	m_Col = Col;

	m_pData = new double[m_Row * m_Col];
	if(Data != NULL)
	{
		for(int i = 0;i < m_Row;i++)
		{
			for(int j = 0;j< m_Col;j++)
			{
				m_pData[i+j] = Data[i+j];
			}
		}			
	}
	return TRUE;
}

CMatrix & CMatrix::operator =(double m)
{
	m_Row = 1;
	m_Col = 1;
	Create(m_Row,m_Col,NULL);
	m_pData[0] = m;
	
	return *this;
}

CMatrix & CMatrix::operator =(const CMatrix & m)
{
	m_Row = m.m_Row;
	m_Col = m.m_Col;
	if(m_pData !=NULL)
	{
		delete []m_pData;
		m_pData =NULL;
	}

	Create(m_Row,m_Col,NULL);
	for(int i=0;i<int(m_Row*m_Col);i++)
	{
		m_pData[i]=m.m_pData[i];
	}

	return *this;
}

CMatrix CMatrix::operator *(double m)
{
	CMatrix tp = *this;
	for(int i=0;i<int(m_Row*m_Col);i++)
	{
		tp.m_pData[i] *= m;
	}

	return tp; 
}

CMatrix CMatrix::operator *(const CMatrix & m)
{
	CMatrix temp;
	temp.m_Row=m_Row;
	temp.m_Col=m.m_Col;
	temp.Create(temp.m_Row,temp.m_Col,NULL);
	for(int i=0;i<temp.m_Row;i++)
	{
		for(int j=0;j<temp.m_Col;j++)
		{
			double total=0.0;
			for(int n=0;n<m_Col;n++)
			{
				total += m_pData[i*m_Col+n]*m.m_pData[n*m.m_Col+j];
			}
			temp.m_pData[i*temp.m_Col+j]=total;
		}
	}

	return temp;
}

CMatrix CMatrix::operator +(const CMatrix & m)
{
	CMatrix tp;
	if(m_Row != m.m_Row || m_Col != m.m_Col) 
		return tp;
	tp.m_Row = m_Row;
	tp.m_Col = m_Col;
	tp.Create(tp.m_Row,tp.m_Col,NULL);
	for(int i=0;i<tp.m_Row*tp.m_Col;i++)
	{
		tp.m_pData[i] = m_pData[i] + m.m_pData[i];
	}

	return tp;
}

CMatrix CMatrix::operator -(const CMatrix & m)
{
	CMatrix tp;
	if(m_Row != m.m_Row || m_Col != m.m_Col) 
		return tp;
	tp.m_Row = m_Row;
	tp.m_Col = m_Col;
	tp.Create(tp.GetRowNum(),tp.GetColNum(),NULL);
	for(int i = 0; i < tp.m_Row*tp.m_Col; i++ )
	{
		tp.m_pData[i] = m_pData[i] - m.m_pData[i]; 
	}

	return tp;
}

double CMatrix::Deternimant()
{
	if(m_Row == 0 || m_Col == 0) 
		return 0.0;
	if(m_Row == 1 && m_Col == 1) 
		return m_pData[0];
	if(m_Row == 2 && m_Col == 2) 
		return m_pData[0] * m_pData[3] - m_pData[2] * m_pData[1];

	double sum=0.0;
	double sub=0.0;
	for(int i=0;i<m_Col;i++)
	{
		{
			double total=1.0;
			int tpRow=0;
			int num=0;
			for(int tpCon=i;tpCon<m_Col;tpCon++,tpRow++)
			{
				total*=m_pData[tpRow*m_Col+tpCon];
				num++;
			}
			tpRow=num;
			for(tpCon=0;tpRow<m_Row&&num!=m_Row;tpCon++,tpRow++)
			{
				total*=m_pData[tpRow*m_Col+tpCon];
			}
			sub+=total;
		}
		{
			double total=1.0;
			int tpRow=0;
			int num=0;
			for(int tpCon=i;tpCon>=0;tpCon--,tpRow++)
			{
				total*=m_pData[tpRow*m_Col+tpCon];
				num++;
			}
			tpRow=num;
			for(tpCon=m_Col-1;tpRow<m_Row&&num!=m_Row;tpRow++,tpCon--)
			{
				total*=m_pData[tpRow*m_Col+tpCon];
			}
			sum+=total;
		}
	}

	return (sub-sum);
}

CMatrix CMatrix::Transposed()
{
	CMatrix temp;
	if(m_Row == 0 || m_Col == 0) 
		return temp;
	if(m_Row == 1 && m_Col == 1) 
		return *this;
	temp.Create(m_Col,m_Row,NULL);
	for(int i=0;i<temp.GetRowNum();i++)
	{
		for(int j=0;j<temp.GetColNum();j++)
		{
			temp.m_pData[i*temp.GetColNum()+j] = m_pData[j*m_Col+i];
		}
	}

	return temp;
}

CMatrix CMatrix::GetAccompany()
{
	CMatrix m;
	m.m_Col=m_Col;
	m.m_Row=m_Row;
	m.Create(m_Row,m_Col,NULL);
	for(int i=0;i<m_Row;i++)
	{
		for(int j=0;j<m_Col;j++)
		{
			CMatrix tp;
			tp.m_Col=m_Col-1;
			tp.m_Row=m_Row-1;
			tp.Create(tp.m_Row,tp.m_Col,NULL);
			int num=0;
			for(int g=0;g<m_Row;g++)
			{
				if(g==i) continue;
				for(int h=0;h<m_Col;h++)
				{
					if(h==j) continue;
					else
					{
						tp.m_pData[num]=m_pData[g*m_Col+h];
						num++;
					}
				}
			}
			int tip;
			float fuhao;
			tip=i+j+2;
			fuhao=1.0;
			if(tip%2==1) fuhao=-1.0;
			m.m_pData[i*m_Col+j]=fuhao*tp.Deternimant();
		}
	}

	m = m.Transposed();

	return	m;
}

/*	
	���������û���ø�˹��Ԫ���������㷨̫���ӡ��õ��ǰ�����󷨡�
    ����Ҫ����һ���ж��ܷ���ӡ������ˡ����ĳ�Ա������
    �������ڴ˻�����������Ҫ�ľ�������
*/
CMatrix  CMatrix::GetReverse()
{
	CMatrix tp;
	tp.m_Col=1;
	tp.m_Row=1;
	tp.Create(1,1,NULL);
	tp.m_pData[0] = double(1.0/m_pData[0]);
	if(m_Row==1&&m_Col==1) 
		return tp;
	tp.m_pData[0] = double(1.0/Deternimant());
	
	return GetAccompany()*tp.m_pData[0];
}

/**
     * Hermitian Toeplitz Matrix
     * The matrix A of order n is a Hermitian Toeplitz matrix if and only if:
     * aij = ai-1,j-1    for i = 2, n and j = 2, n
     * 
*/
CMatrix CMatrix::Toeplitz(double *D, int size_D)
{
	CMatrix tp;
	int i, j;

	tp.m_Row = size_D;
	tp.m_Col = size_D;
	tp.Create(size_D,size_D,NULL);

	for (i=0;i<size_D;i++)
	{
		tp.m_pData[0*tp.m_Col + i] = D[i];
	}

	for (i=1;i<size_D;i++)
	{
		tp.m_pData[i*tp.m_Col + 0] = D[i];
	}

	for (i=1;i<size_D;i++)
	{
		for (j=1;j<size_D;j++)
		{
			tp.m_pData[i*size_D + j] = tp.m_pData[(i-1)*size_D + (j-1)];
		}
	}

	return tp;
}

/**
     * @param x - vector operator
     * @param y - vector operator
     * @return a matrix A = diag(x1y1, x2y2, ...., xnyn)
*/
CMatrix CMatrix::Diag(double *x, double *y, int size_n)
{
	CMatrix tp;
	int i, j;

	tp.m_Row = size_n;
	tp.m_Col = size_n;
	tp.Create(size_n,size_n,NULL);
	
	for (i=0;i<size_n;i++)
	{
		for (j=0;j<size_n;j++)
		{
			if (i==j)
			{
				tp.m_pData[i*size_n + j] = x[i]*y[i];
			}
			else
			{
				tp.m_pData[i*size_n + j] = 0.0;
			}
		}
	}

	return tp;
}

/** Generate identity matrix
   @param m    Number of rows.
   @param n    Number of colums.
   @return     An m-by-n matrix with ones on the diagonal and zeros elsewhere.
*/
CMatrix CMatrix::Identity(int m, int n)
{
	CMatrix tp;
	int i, j;

	tp.m_Row = m;
	tp.m_Col = n;
	tp.Create(m,n,NULL);

	for (i=0;i<m;i++)
	{
		for (j=0;j<n;j++)
		{
			if (i==j)
			{
				tp.m_pData[i*n + j] = 1.0;
			}
			else
			{
				tp.m_pData[i*n + j] = 0.0;
			}
		}
	}

	return tp;
}