// ProblemDef.cpp: implementation of the CProblemDef class.
//
//////////////////////////////////////////////////////////////////////


#include "ProblemDef.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CProblemDef::CProblemDef()
{
}

CProblemDef::~CProblemDef()
{
}

void CProblemDef::evaluate_normal_fitness(double *xreal, tFitness &obj, int func_flag, long int &evaluations, 
		double *data_in_datasheet, double *measured_V, double *measured_I, int num_of_measure, double *pv_parameters)
{
	/************************************************************************/
	int i;
	data_len = num_of_measure;
	for(i=0;i<data_len;i++)
	{
		actual_V_data[i] = measured_V[i];
		actual_I_data[i] = measured_I[i];
	}

	// data obtained from the datasheet
	Ns		= data_in_datasheet[0];				// number of cells
	area	= data_in_datasheet[1];				// area
	/************************************************************************/

	switch(func_flag) {		
	case 3:	
		PEMFC_model_6_parameters(xreal, obj, pv_parameters);
		break;		
	case 4:	
		PEMFC_model_2_parameters(xreal, obj, pv_parameters);
		break;
	default:
		printf("The function you selected does not exist.\n");
		exit(0);
		break;
	}

	evaluations++;
}

/*For calculating Determinant of the Matrix */
double CProblemDef::determinant(double a[Matrix_Dim][Matrix_Dim], int k)
{	
	double s=1,det=0,b[Matrix_Dim][Matrix_Dim];
    int i,j,m,n,c;
    if (k==1)
    {
        return (a[0][0]);
    }
    else
    {
        det=0;
        for (c=0;c<k;c++)
        {
            m=0;
            n=0;
            for (i=0;i<k;i++)
            {
                for (j=0;j<k;j++)
                {
                    b[i][j]=0;
                    if (i != 0 && j != c)
                    {
                        b[m][n]=a[i][j];
                        if (n<(k-2))
                            n++;
                        else
                        {
                            n=0;
                            m++;
                        }
                    }
                }
			}
            det=det + s * (a[0][c] * determinant(b,k-1));
            s=-1 * s;
        }
    }
	
    return (det);
}

/*Finding transpose of matrix*/
void CProblemDef::transpose(double num[Matrix_Dim][Matrix_Dim], double fac[Matrix_Dim][Matrix_Dim], double inversion[Matrix_Dim][Matrix_Dim], int r)
{
	int i,j;
    double b[Matrix_Dim][Matrix_Dim],d;
	
    for (i=0;i<r;i++)
    {
        for (j=0;j<r;j++)
        {
            b[i][j]=fac[j][i];
        }
    }
	
    d=determinant(num,r);

    for (i=0;i<r;i++)
    {
        for (j=0;j<r;j++)
        {
            inversion[i][j]=b[i][j] / d;
        }
    }
}

int	CProblemDef::cofactor(double num[Matrix_Dim][Matrix_Dim], double inversion[Matrix_Dim][Matrix_Dim], int f)
{
	double d;
	d = determinant(num, f);
	if (d==0)
	{
		printf("\nInverse of Entered Matrix is not possible\n");
		return 1;
	}

	double b[Matrix_Dim][Matrix_Dim],fac[Matrix_Dim][Matrix_Dim];
    int p,q,m,n,i,j;
    for (q=0;q<f;q++)
    {
        for (p=0;p<f;p++)
        {
            m=0;
            n=0;
            for (i=0;i<f;i++)
            {
                for (j=0;j<f;j++)
                {
                    if (i != q && j != p)
                    {
                        b[m][n]=num[i][j];
                        if (n<(f-2))
                            n++;
                        else
                        {
                            n=0;
                            m++;
                        }
                    }
                }
            }
            fac[q][p]=pow(-1,q + p) * determinant(b,f-1);
        }
    }

    transpose(num, fac, inversion ,f);

	return 0;
}

/* Bare-bones Gauss-Jordan algorithm. Returns '0' on success, '1' if
 * matrix is singular (zero diagonal). No pivoting used.
 *
 * Replaces input matrix with its inverse.
 */
int CProblemDef::matinv(double a[][Matrix_Dim],int n)
{
	double **inv,tmp;
    int i,j,k,retval;
	
    retval = 0;
    inv = new double *[n];
    for (i=0;i<n;i++) {
        inv[i] = new double [n];
    }
	// Initialize identity matrix
    for (i=0;i<n;i++) {
        for (j=0;j<n;j++) {
            inv[i][j] = 0.0;
        }
        inv[i][i] = 1.0;
    }
	
    for (k=0;k<n;k++) {
        tmp = a[k][k];
        if (tmp == 0) {
            retval = 1;
            goto _100;
        }
        for (j=0;j<n;j++) {
            if (j>k) a[k][j] /= tmp;    // Don't bother with previous entries
            inv[k][j] /= tmp;
        }
        for (i=0;i<n;i++) {             // Loop over rows
            if (i == k) continue;
            tmp = a[i][k];
            for (j=0;j<n;j++) {
                if (j>k) a[i][j] -= a[k][j]*tmp;
                inv[i][j] -= inv[k][j]*tmp;
            }
        }
    }
	
	// Copy inverse to source matrix
    for (i=0;i<n;i++) {
        for (j=0;j<n;j++) {
            a[i][j] = inv[i][j];
        }
    }
_100:
    for (i=0;i<n;i++) {
        delete [] inv[i];
    }
    delete [] inv;
    return retval;
}

double CProblemDef::sum(double *data, int n)
{
	double	rst = 0.0;
	int		i;
	for (i=0; i<n; i++)
	{
		rst += data[i];
	}
	return rst;
}

double CProblemDef::sum(double *data1, double *data2, int n)
{
	double	rst = 0.0;
	int		i;
	for (i=0; i<n; i++)
	{
		rst += data1[i]*data2[i];
	}
	return rst;
}

void CProblemDef::PEMFC_model_6_parameters(double *xreal, tFitness &obj, double *pv_parameters)
{
	int j;
	
	//////////////////////////////////////////////////////////////////////////
	// for unknown parameters
	E0		= xreal[0];
	b		= xreal[1];
	r		= xreal[2];
	m		= xreal[3];
	n		= xreal[4];
	i_n		= xreal[5];
	
	pv_parameters[0]  = E0;
	pv_parameters[1]  = b;
	pv_parameters[2]  = r;
	pv_parameters[3]  = m;
	pv_parameters[4]  = n;
	pv_parameters[5]  = i_n;
	pv_parameters[6]  = -1;
	pv_parameters[7]  = -1;
	pv_parameters[8]  = -1;
	pv_parameters[9]  = -1;
	pv_parameters[10] = -1;
	
	//////////////////////////////////////////////////////////////////////////
	double	modeled_V[5000], I;
	assert(data_len<=5000);
	
	for (j=0; j<data_len; j++)
	{
		//I	= actual_I_data[j]*1000.0/area;			// A in dataset, converting into mA/cm^2
		I	= actual_I_data[j];
		
		modeled_V[j] = Ns * ( E0 - b*log(I+i_n) - r*(I+i_n) - m*exp(n*(I+i_n)) );
	}
	
	//////////////////////////////////////////////////////////////////////////
	// calculate the fitness value
	tFitness fitness;
	fitness = 0.0;
	for (j=0;j<data_len;j++)
	{
		fitness += (modeled_V[j]-actual_V_data[j])*(modeled_V[j]-actual_V_data[j]);
	}
	fitness = (fitness)/(double)data_len;
	//fitness = sqrt( (fitness)/(double)data_len );		// root mean square error (RMSE)
	
	obj = fitness;
}


void CProblemDef::PEMFC_model_2_parameters(double *xreal, tFitness &obj, double *pv_parameters)
{
	int j;
	
	//////////////////////////////////////////////////////////////////////////
	// for unknown parameters
	n		= xreal[0];
	i_n		= xreal[1];
	
	//////////////////////////////////////////////////////////////////////////
	double	modeled_V[5000], I_j, V_j;
	assert(data_len<=5000);

	/************************************************************************/
	double	Ck[5000], Dk[5000], Ek[5000], Vk[5000];
	
	for (j=0; j<data_len; j++)
	{
		I_j		= actual_I_data[j]*1000.0/area;
		I_j		= actual_I_data[j];
		V_j		= actual_V_data[j];

		Vk[j]	= V_j/Ns;
		
		Dk[j]	= I_j+i_n;
		Ck[j]	= log(Dk[j]);
		Ek[j]	= exp(n*Dk[j]);
	}

	double	b1, b2, b3, b4;
	double	BB[4];
	BB[0] = b1 = sum(Vk, data_len);
	BB[1] = b2 = -sum(Ck, Vk, data_len);
	BB[2] = b3 = -sum(Dk, Vk, data_len);
	BB[3] = b4 = -sum(Ek, Vk, data_len);

	double	a11, a12, a13, a14;
	double	a21, a22, a23, a24;
	double	a31, a32, a33, a34;
	double	a41, a42, a43, a44;
	double	AAA[Matrix_Dim][Matrix_Dim];
	a11	= data_len;
	a12 = -sum(Ck, data_len);
	a13 = -sum(Dk, data_len);
	a14 = -sum(Ek, data_len);
	a21 = a12;
	a22	= sum(Ck, Ck, data_len);
	a23	= sum(Ck, Dk, data_len);
	a24 = sum(Ck, Ek, data_len);
	a31 = a13;
	a32 = a23;
	a33 = sum(Dk, Dk, data_len);
	a34 = sum(Dk, Ek, data_len);
	a41 = a14; 
	a42 = a24;
	a43 = a34;
	a44 = sum(Ek, Ek, data_len);

	AAA[0][0] = a11;	AAA[0][1] = a12;	AAA[0][2] = a13;	AAA[0][3] = a14;
	AAA[1][0] = a21;	AAA[1][1] = a22;	AAA[1][2] = a23;	AAA[1][3] = a24;
	AAA[2][0] = a31;	AAA[2][1] = a32;	AAA[2][2] = a33;	AAA[2][3] = a34;
	AAA[3][0] = a41;	AAA[3][1] = a42;	AAA[3][2] = a43;	AAA[3][3] = a44;

	int inv_flag;
	inv_flag = matinv(AAA, Matrix_Dim);
	
	if (inv_flag==0)
	{// matrix is inversed successfully.	
		double	xx[Matrix_Dim] = {0};
		for (j=0; j<Matrix_Dim; j++)
		{
			xx[j] = 0.0;
			for (int k=0; k<Matrix_Dim; k++)
			{
				xx[j] += AAA[j][k] * BB[k];
			}
		}
		E0	= xx[0];
		b	= xx[1];
		r	= xx[2];
		m	= xx[3];
	}
	else
	{// matrix is singular (zero diagonal)
		obj = INF;
		return;
	}

	//printf("%f\t%f\t%f\t%f\n", E0, r, A1, B1);getchar();

	//////////////////////////////////////////////////////////////////////////
	if ( E0<=0 || b<=0 || r<=0 || m<=0.0 )
	{
		obj = INF;
		return;
	}
	/************************************************************************/
	
	pv_parameters[0]  = E0;
	pv_parameters[1]  = b;
	pv_parameters[2]  = r;
	pv_parameters[3]  = m;
	pv_parameters[4]  = n;
	pv_parameters[5]  = i_n;
	pv_parameters[6]  = -1;
	pv_parameters[7]  = -1;
	pv_parameters[8]  = -1;
	pv_parameters[9]  = -1;
	pv_parameters[10] = -1;

	//////////////////////////////////////////////////////////////////////////
	for (j=0; j<data_len; j++)
	{
		modeled_V[j] = Ns * ( E0 -b*Ck[j] - r*Dk[j] -m*Ek[j] );
	}
	
	//////////////////////////////////////////////////////////////////////////
	// calculate the fitness value
	tFitness fitness;
	fitness = 0.0;
	for (j=0;j<data_len;j++)
	{
		fitness += (modeled_V[j]-actual_V_data[j])*(modeled_V[j]-actual_V_data[j]);
	}
	fitness = (fitness)/(double)data_len;
	//fitness = sqrt( (fitness)/(double)data_len );		// root mean square error (RMSE)
	
	obj = fitness;
}











