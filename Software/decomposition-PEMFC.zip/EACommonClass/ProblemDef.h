// ProblemDef.h: interface for the CProblemDef class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_)
#define AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../global.h"
#include "Individual.h"
#include "Rand.h"
//#include "Matrix.h"

#define Matrix_Dim	4

// only for unconstrained optimization problems
class CProblemDef  
{
public:
	CProblemDef();
	virtual ~CProblemDef();

	/************************************************************************/
	/* for matrix inversion: method 1                                       */
	double	determinant(double a[Matrix_Dim][Matrix_Dim], int k);
	void	transpose(double num[Matrix_Dim][Matrix_Dim], double fac[Matrix_Dim][Matrix_Dim], double inversion[Matrix_Dim][Matrix_Dim], int r);
	int		cofactor(double num[Matrix_Dim][Matrix_Dim], double inversion[Matrix_Dim][Matrix_Dim], int f);		// 0 for success; 1 for failure

	/* for matrix inversion: method 2                                       */
	int		matinv(double a[][Matrix_Dim],int n);																// inverse of matrix using Gauss-Jordan elimination
	/************************************************************************/

	double	sum(double *data, int n);
	double	sum(double *data1, double *data2, int n);

	// for unconstrained optimization problems
public:
	double	actual_V_data[5000], actual_I_data[5000];
	int		data_len;

public:
	void	evaluate_normal_fitness(double *xreal, tFitness &obj, int func_flag, long int &evaluations, 
		double *data_in_datasheet, double *measured_V, double *measured_I, int num_of_measure, double *pv_parameters);

public:
	// parameters for PEMFC module
	double	Ns, area;							// number of cells, area of cell

	// MODEL: 2004 Proton exchange membrane (PEM) fuel cell stack configuration using genetic algorithms
	// MODEL: 2009 Parameter identification for proton exchange membrane fuel cell model using particle swarm optimization
	// MODEL: 2012 A new stochastic algorithm for proton exchange membrane fuel cell stack design optimization
	double	E0, r, A1, B1;						// dependent parameters
	double	i_o, i_n, i_L;						// independent parameters
	void	PEMFC_model_7_parameters_new(double *xreal, tFitness &obj, double *pv_parameters);
	void	PEMFC_model_3_parameters_new(double *xreal, tFitness &obj, double *pv_parameters);

	// MODEL: 2013 Comparison of proton exchange membrane fuel cell static models
	double	b, m, n;
	void	PEMFC_model_6_parameters(double *xreal, tFitness &obj, double *pv_parameters);
	void	PEMFC_model_2_parameters(double *xreal, tFitness &obj, double *pv_parameters);

};

#endif // !defined(AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_)
