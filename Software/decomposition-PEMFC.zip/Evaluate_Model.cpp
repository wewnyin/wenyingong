// Evaluate_Model.cpp: implementation of the CEvaluate_Model class.
//
//////////////////////////////////////////////////////////////////////

#include "Evaluate_Model.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEvaluate_Model::CEvaluate_Model()
{
}

CEvaluate_Model::~CEvaluate_Model()
{
}

void CEvaluate_Model::evaluate_model(int func_flag, double *data_in_datasheet, double *measured_I, double *measured_V, 
									 int num_of_measure, double *pv, double *modeled_I, double *modeled_V, int n_of_modeled)
{
	/************************************************************************/
	int i;
	data_len = num_of_measure;
	for(i=0;i<data_len;i++)
	{
		actual_V_data[i] = measured_V[i];
		actual_I_data[i] = measured_I[i];
	}

	for (i=0; i<20; i++)
	{
		pv_parameters[i] = pv[i];
	}
	
	// data obtained from the datasheet
	Ns		= data_in_datasheet[0];				// number of cells
	area	= data_in_datasheet[1];				// area
	/************************************************************************/

	switch(func_flag) {
	case 1:
	case 2:
		PEMFC_model_7_parameters(modeled_I, modeled_V, n_of_modeled);
		break;

	case 3:
	case 4:
		PEMFC_model_6_parameters(modeled_I, modeled_V, n_of_modeled);
		break;
	default:
		printf("The function you selected does not exist.\n");
		exit(0);
	}
}

void CEvaluate_Model::PEMFC_model_7_parameters(double *modeled_I, double *modeled_V, int n_of_modeled)
{
	E0		= pv_parameters[0];
	r		= pv_parameters[1];
	A1		= pv_parameters[2];
	B1		= pv_parameters[3];
	i_o		= pv_parameters[4];
	i_n		= pv_parameters[5];
	i_L		= pv_parameters[6];	

	//////////////////////////////////////////////////////////////////////////
	double	I_first	= actual_I_data[0];
	double	I_last	= actual_I_data[data_len-1];

	int j;
	for (j=0; j<n_of_modeled; j++)
	{
		modeled_I[j] = I_first + j*fabs(I_first-I_last)/n_of_modeled;
	}
	modeled_I[n_of_modeled-1] = I_last;

	double I;
	for (j=0; j<n_of_modeled; j++)
	{
		I	= modeled_I[j]*1000.0/area;			// A in dataset, converting into mA/cm^2
		//I	= actual_I_data[j];
		
		modeled_V[j] = Ns * ( E0 - r*(I+i_n) - A1* log((I+i_n)/i_o) +B1*log(1.0-(I+i_n)/i_L) );
	}
}

void CEvaluate_Model::PEMFC_model_6_parameters(double *modeled_I, double *modeled_V, int n_of_modeled)
{
	E0		= pv_parameters[0];
	b		= pv_parameters[1];
	r		= pv_parameters[2];
	m		= pv_parameters[3];
	n		= pv_parameters[4];
	i_n		= pv_parameters[5];

	//////////////////////////////////////////////////////////////////////////
	double	I_first	= actual_I_data[0];
	double	I_last	= actual_I_data[data_len-1];
	
	int j;
	for (j=0; j<n_of_modeled; j++)
	{
		modeled_I[j] = I_first + j*fabs(I_first-I_last)/n_of_modeled;
	}
	modeled_I[n_of_modeled-1] = I_last;
	
	double I;
	for (j=0; j<n_of_modeled; j++)
	{
		I	= modeled_I[j];
		
		modeled_V[j] = Ns * ( E0 - b*log(I+i_n) - r*(I+i_n) - m*exp(n*(I+i_n)) );
	}
}
