// Evaluate_Model.h: interface for the CEvaluate_Model class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EVALUATE_MODEL_H__6AA73701_6BA9_4320_BF50_E6B59AE0F268__INCLUDED_)
#define AFX_EVALUATE_MODEL_H__6AA73701_6BA9_4320_BF50_E6B59AE0F268__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "global.h"

class CEvaluate_Model  
{
public:
	CEvaluate_Model();
	virtual ~CEvaluate_Model();

private:
	double	actual_I_data[5000];
	double	actual_V_data[5000];
	double	pv_parameters[20];
	int		num_of_parameters;
	int		data_len;

private:
	// parameters for PEMFC module
	double	Ns, area;							// number of cells, area of cell

	double	E0, r, A1, B1;						// dependent parameters
	double	i_o, i_n, i_L;						// independent parameters

	void	PEMFC_model_7_parameters(double *modeled_I, double *modeled_V, int n_of_modeled);

	double	b, m, n;
	void	PEMFC_model_6_parameters(double *modeled_I, double *modeled_V, int n_of_modeled);
public:
	void	evaluate_model(int func_flag, double *data_in_datasheet, double *measured_I, double *measured_V, int num_of_measure, double *pv, 
		double *modeled_I, double *modeled_V, int n_of_modeled);

};

#endif // !defined(AFX_EVALUATE_MODEL_H__6AA73701_6BA9_4320_BF50_E6B59AE0F268__INCLUDED_)
