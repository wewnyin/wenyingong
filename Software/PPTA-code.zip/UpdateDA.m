function DA=UpdateDA(DA,Population,N,search_stage)
% Update DA.
% CA is the Archive that has  been updated.
% DA is the Archive that has not been updated.
% Offspring  is the set of Population.

    DA = [DA,Population];
    if search_stage==1
        Fitness = CalFitness(DA.objs);
        %% Environmental selection
        Next = Fitness < 1;
        if sum(Next) < N
            [~,Rank] = sort(Fitness);
            Next(Rank(1:N)) = true;
        elseif sum(Next) > N
            Del  = Truncation(DA(Next).objs,sum(Next)-N);
            Temp = find(Next);
            Next(Temp(Del)) = false;
        end
        % Population for next generation
        DA = DA(Next);
    else
        %% Select feasible solutions
        fIndex = all(DA.cons <= 0,2);
        DA = DA(fIndex);
        
        if isempty(DA)
            return
        elseif size(DA,2) > N
            Fitness = CalFitness(DA.objs,DA.cons);
            Next = Fitness < 1;
            Del  = Truncation(DA(Next).objs,sum(Next)-N);
            Temp = find(Next);
            Next(Temp(Del)) = false;
            DA = DA(Next);
        end
    end
end

function Del = Truncation(PopObj,K)
% Select part of the solutions by truncation

    %% Truncation
    Distance = pdist2(PopObj,PopObj);
    Distance(logical(eye(length(Distance)))) = inf;
    Del = false(1,size(PopObj,1));
    while sum(Del) < K
        Remain   = find(~Del);
        Temp     = sort(Distance(Remain,Remain),2);
        [~,Rank] = sortrows(Temp);
        Del(Remain(Rank(1))) = true;
    end
end