classdef PPTA < ALGORITHM
% <multi/many> <real/binary/permutation> <constrained>
% Push-pull two-archive evolutionary algorithm for constrained MOPs
% delta --- 0.9 --- The probability of choosing parents locally
% nr    ---   2 --- Maximum number of solutions replaced by each offspring

    methods
        function main(Algorithm,Problem)
            %% Parameter setting
            [delta,nr] = Algorithm.ParameterSet(0.9,2);

            %% Generate the weight vectors
            [W,Problem.N] = UniformPoint(Problem.N,Problem.M);
            T = ceil(Problem.N/10);

            %% Detect the neighbours of each solution
            B = pdist2(W,W);
            [~,B] = sort(B,2);
            B = B(:,1:T);
            
            %% Generate random population
            Population = Problem.Initialization();
            
            %% Evaluate the Population
            Tc               = ceil(0.9 * ceil(Problem.maxFE/Problem.N));
            last_gen         = ceil(0.2 * ceil(Problem.maxFE/Problem.N));
            max_push_gen     = ceil(0.6 * ceil(Problem.maxFE/Problem.N));
            change_threshold = 1e-1;
            search_stage     = 1; % 1 for push stage,otherwise,it is in pull stage.
            max_change       = 1;
            epsilon_k        = 0;
            epsilon_0        = 0;
            cp               = 2;
            alpha            = 0.95;
            tao              = 0.05;
            ideal_points     = zeros(ceil(Problem.maxFE/Problem.N),Problem.M);
            nadir_points     = zeros(ceil(Problem.maxFE/Problem.N),Problem.M);
            exchange = 0;
            
            %% initial the archives
            CA = UpdateCA([],Population,Problem.N);            % initial CA
            DA = UpdateDA([],Population,Problem.N,search_stage);         % initial DA
            Z = min(DA.objs,[],1);
            epsilon = [];

            %% Optimization
            while Algorithm.NotTerminated(Population)
                gen        = ceil(Problem.FE/Problem.N);
                da_cons   = DA.cons;
                da_cv         = overall_cv(da_cons);
                da = [DA.decs,DA.objs,da_cv];
                pop_cons   = Population.cons;
                pop_cv         = overall_cv(pop_cons);
                pop = [Population.decs,Population.objs,pop_cv];
                
                if gen > max_push_gen && search_stage == 1
                    search_stage = -1;
                end
                
                if search_stage == 1
                    rf = sum(da_cv <= 1e-6) / Problem.N;
                    ideal_points(gen,:) = Z;
                    nadir_points(gen,:) = max(da(:,Problem.D + 1 : Problem.D + Problem.M),[],1);
                else
                    rf = sum(pop_cv <= 1e-6) / Problem.N;
                end
                % The maximumrate of change of ideal and nadir points rk is calculated.
                if gen >= last_gen && search_stage == 1
                    max_change = calc_maxchange(ideal_points,nadir_points,gen,last_gen);
                end
                
                % The value of e(k) and the search strategy are set. 
                if max_change <= change_threshold && search_stage == 1
                    search_stage = -1;
                    epsilon_0 = max(epsilon_0,max(da(:,end),[],1));
                    epsilon_k = epsilon_0;
                end
                if search_stage == -1
                    epsilon_0 = max(epsilon_0,max(pop(:,end),[],1));
                    epsilon_k =  update_epsilon(tao,epsilon_k,epsilon_0,rf,alpha,gen,Tc,cp);
                end

                if search_stage == 1
                    Fitness1 = CalFitness(Population.objs,Population.cons);
                    MatingPool1 = TournamentSelection(2,Problem.N,Fitness1);
                    Offspring1  = OperatorGAhalf(Population(MatingPool1));
                    Fitness2    = CalFitness(DA.objs);
                    MatingPool2 = TournamentSelection(2,Problem.N,Fitness2);
                    Offspring2  = OperatorGAhalf(DA(MatingPool2));
                    Population = UpdateCA(Population,[Offspring1,Offspring2],Problem.N);
                    DA = UpdateDA(DA,[Offspring1,Offspring2],Problem.N,search_stage);
                    
                    % Update the ideal point
                    Z = min(Z,min(Offspring2.objs));
                else
                    if exchange == 0
                        CA = Population;
                        Population = DA;
                        DA = [];
                        exchange = 1;
                    end
                    
                        % For each solution
                        for i = 1 : Problem.N
                            % Choose the parents
                            if rand < delta
                                P = B(i,randperm(size(B,2)));
                            else
                                P = randperm(Problem.N);
                            end

                            % Generate an offspring
                            Offspring = OperatorDE(Population(i),Population(P(1)),Population(P(2)));

                            % Update the ideal point
                            Z = min(Z,Offspring.obj);

                            % Update the solutions in P by PBI approachc
                            normW   = sqrt(sum(W(P,:).^2,2));
                            normP   = sqrt(sum((Population(P).objs-repmat(Z,length(P),1)).^2,2));
                            normO   = sqrt(sum((Offspring.obj-Z).^2,2));
                            CosineP = sum((Population(P).objs-repmat(Z,length(P),1)).*W(P,:),2)./normW./normP;
                            CosineO = sum(repmat(Offspring.obj-Z,length(P),1).*W(P,:),2)./normW./normO;
                            g_old   = normP.*CosineP + 5*normP.*sqrt(1-CosineP.^2);
                            g_new   = normO.*CosineO + 5*normO.*sqrt(1-CosineO.^2);
                            cv_old = overall_cv(Population(P).cons);
                            cv_new = overall_cv(Offspring.con) * ones(length(P),1);

                            if search_stage == 1 % Push Stage
                                Population(P(find(g_old>=g_new,nr))) = Offspring;
                            else  % Pull Stage  &&  An improved epsilon constraint-handling is employed to deal with constraints
                                Population(P(find(((g_old >= g_new) & (((cv_old <= epsilon_k) & (cv_new <= epsilon_k)) | (cv_old == cv_new)) | (cv_new < cv_old) ), nr))) = Offspring;
                            end
                        end

                        CA = UpdateCA(CA,Population,Problem.N);
                        DA = UpdateDA(DA,Population,Problem.N,search_stage);
                end
                epsilon = [epsilon,epsilon_k];
                % Output the non-dominated and feasible solutions.
                if Problem.FE >= Problem.maxFE
                    CA=UpdateCA(CA,DA,Problem.N);
                    Population = CA;
                    dlmwrite('epsilon.txt',epsilon);
                end
                
            end
        end
    end
end

% The Overall Constraint Violation
function result = overall_cv(cv)
    cv(cv <= 0) = 0;cv = abs(cv);
    result = sum(cv,2);
end

% Calculate the Maximum Rate of Change
function max_change = calc_maxchange(ideal_points,nadir_points,gen,last_gen)
    delta_value = 1e-6 * ones(1,size(ideal_points,2));
    rz = abs((ideal_points(gen,:) - ideal_points(gen - last_gen + 1,:)) ./ max(ideal_points(gen - last_gen + 1,:),delta_value));
    nrz = abs((nadir_points(gen,:) - nadir_points(gen - last_gen + 1,:)) ./ max(nadir_points(gen - last_gen + 1,:),delta_value));
    max_change = max([rz, nrz]);
end

function result = update_epsilon(tao,epsilon_k,epsilon_0,rf,alpha,gen,Tc,cp)
    if rf < alpha && gen < Tc
        result = (1 - tao) * epsilon_k;
    elseif rf >= alpha && gen < Tc
        result = cp * epsilon_0 * ((1 - (gen / Tc))) ^ cp;
    else
        result = epsilon_0;
    end
end