/* Program: 		A-WeB for NES problems in C++ under VS 6.0
   Author: 		Wenyin Gong
   E-mail: 		wygong@cug.edu.cn
   Release Date: 	14/02/2017
   License: 		free
   Reference: 		W. Gong, Y. Wang, Z. Cai, and S. Yang, "A Weighted Biobjective Transformation Technique 
			for Locating Multiple Optimal Solutions of Nonlinear Equation Systems," 
			IEEE Transactions on Evolutionary Computation, In press, 2017.
*/