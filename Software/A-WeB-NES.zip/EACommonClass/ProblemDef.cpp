// ProblemDef.cpp: implementation of the CProblemDef class.
//
//////////////////////////////////////////////////////////////////////


#include "ProblemDef.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CProblemDef::CProblemDef()
{
}

CProblemDef::~CProblemDef()
{
}

void CProblemDef::evaluate_problem(double *xreal, double *f_e_f, double &sum_f_e_f, int func_flag)
{
	switch(func_flag) {
	case 1:
		test_NES_01(xreal, f_e_f);
		break;
	case 2:
		test_NES_02(xreal, f_e_f);
		break;
	case 3:
		test_NES_03(xreal, f_e_f);
		break;
	case 4:
		test_NES_04(xreal, f_e_f);
		break;
	case 5:
		test_NES_05(xreal, f_e_f);
		break;
	case 6:
		test_NES_06(xreal, f_e_f);
		break;
	case 7:
		test_NES_07(xreal, f_e_f);
		break;	
		
	case 8:
		test_NES_08(xreal, f_e_f);
		break;	
	case 9:
		test_NES_09(xreal, f_e_f);
		break;	
	case 10:
		test_NES_10(xreal, f_e_f);
		break;
	case 11:
		test_NES_11(xreal, f_e_f);
		break;
	case 12:
		test_NES_12(xreal, f_e_f);
		break;
	case 13:
		test_NES_13(xreal, f_e_f);
		break;
	case 14:
		test_NES_14(xreal, f_e_f);
		break;

	case 15:
		test_NES_15(xreal, f_e_f);
		break;

	case 16:
		test_NES_16(xreal, f_e_f);
		break;
	case 17:
		test_NES_17(xreal, f_e_f);
		break;
	case 18:
		test_NES_18(xreal, f_e_f);
		break;
	case 19:
		test_NES_19(xreal, f_e_f);
		break;
		
	case 20:
		test_NES_20(xreal, f_e_f);
		break;
	case 21:
		test_NES_21(xreal, f_e_f);
		break;
		
	case 22:
		test_NES_22(xreal, f_e_f);
		break;
	case 23:
		test_NES_23(xreal, f_e_f);
		break;
	case 24:
		test_NES_24(xreal, f_e_f);
		break;
		
	case 25:
		test_NES_25(xreal, f_e_f);
		break;
		
	case 26:
		test_NES_26(xreal, f_e_f);
		break;
		
	case 27:
		test_NES_27(xreal, f_e_f);
		break;
	case 28:
		test_NES_28(xreal, f_e_f);
		break;
	case 29:
		test_NES_29(xreal, f_e_f);
		break;
	case 30:
		test_NES_30(xreal, f_e_f);
		break;
	case 31:
		test_NES_31(xreal, f_e_f);
		break;
	case 32:
		test_NES_32(xreal, f_e_f);
		break;
	case 33:
		test_NES_33(xreal, f_e_f);
		break;

	case 34:
		test_NES_34(xreal, f_e_f);
		break;
	case 35:
		test_NES_35(xreal, f_e_f);
		break;
	case 36:
		test_NES_36(xreal, f_e_f);
		break;
	case 37:
		test_NES_37(xreal, f_e_f);
		break;

	case 38:
		test_NES_38(xreal, f_e_f);
		break;
	case 39:
		test_NES_39(xreal, f_e_f);
		break;
	case 40:
		test_NES_40(xreal, f_e_f);
		break;
		
	case 41:
		test_NES_41(xreal, f_e_f);
		break;
		
	case 42:
		test_NES_42(xreal, f_e_f);
		break;
		
	case 43:
		test_NES_43(xreal, f_e_f);
		break;
		
	case 44:
		test_NES_44(xreal, f_e_f);
		break;	
	case 45:
		test_NES_45(xreal, f_e_f);
		break;
				
	case 46:
		test_NES_46(xreal, f_e_f);
		break;

	case 50:
		test_NES_50(xreal, f_e_f);
		break;
	case 51:
		test_NES_51(xreal, f_e_f);
		break;
	case 52:
		test_NES_52(xreal, f_e_f);
		break;
	case 53:
		test_NES_53(xreal, f_e_f);
		break;
	case 54:
		test_NES_54(xreal, f_e_f);
		break;
	case 55:
		test_NES_55(xreal, f_e_f);
		break;
	case 56:
		test_NES_56(xreal, f_e_f);
		break;
	case 57:
		test_NES_57(xreal, f_e_f);
		break;
		
		
	case 81:
		test_NES_81(xreal, f_e_f);
		break;
	default:
		printf("The problem you selected does not exist in evaluate_problem().\n");
		exit(0);
		break;
	}

	int i;
	sum_f_e_f = 0.0;
	for (i=0; i<CIndividual::num_of_equations; i++)
	{
		f_e_f[i]   = fabs(e_f[i]);
		sum_f_e_f += f_e_f[i];
		//sum_f_e_f += e_f[i]*e_f[i];
	}//sum_f_e_f = sqrt(sum_f_e_f);
}

/*  Test problem NES-01
    # of real variables = 2
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_01(double *xreal, double *f_e_f)
{
	e_f[0] = xreal[0]*xreal[0] + xreal[1]*xreal[1] - 1.0;
	e_f[1] = xreal[0] - xreal[1];
	
	return;
}

/*  Test problem NES-02
    # of real variables = 20
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_02(double *xreal, double *f_e_f)
{
	// nonlinear equation systems
	int		j;
	double	temp1 = 0.0;
	for (j=0; j<CIndividual::N_of_x; j++)
	{
		temp1 += xreal[j]*xreal[j];
	}
	e_f[0] = temp1 - 1.0;

	temp1 = 0.0;
	for (j=2; j<CIndividual::N_of_x; j++)
	{
		temp1 += xreal[j]*xreal[j];
	}
	e_f[1] = fabs(xreal[0] - xreal[1])+temp1;

	return;
}

/*  Test problem NES-03
    # of real variables = 2
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_03(double *xreal, double *f_e_f)
{
	// nonlinear equation systems
	e_f[0] = xreal[1] - sin(5.0*PI*xreal[0]);
	e_f[1] = xreal[0] - xreal[1];

	return;
}

/*  Test problem NES-04
    # of real variables = 2
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_04(double *xreal, double *f_e_f)
{
	// nonlinear equation systems
	e_f[0] = xreal[1] - cos(4.0*PI*xreal[0]);
	e_f[1] = xreal[0]*xreal[0] + xreal[1]*xreal[1] - 1.0;
	
	return;
}

/*  Test problem NES-05
    # of real variables = 3
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_05(double *xreal, double *f_e_f)
{
	// nonlinear equation systems
	e_f[0] = xreal[0] + xreal[1] + xreal[2] - 1.0;
	e_f[1] = xreal[0] - xreal[1]*xreal[1]*xreal[1];
	
	return;
}

/*  Test problem NES-06
    # of real variables = 6
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
	neurophysiology application
    */
void CProblemDef::test_NES_06(double *xreal, double *f_e_f)
{
	// nonlinear equation systems
	e_f[0] = xreal[0]*xreal[0] + xreal[2]*xreal[2] - 1.0;
	e_f[1] = xreal[1]*xreal[1] + xreal[3]*xreal[3] - 1.0;
	e_f[2] = xreal[4]*xreal[2]*xreal[2]*xreal[2] + xreal[5]*xreal[3]*xreal[3]*xreal[3];
	e_f[3] = xreal[4]*xreal[0]*xreal[0]*xreal[0] + xreal[5]*xreal[1]*xreal[1]*xreal[1];
	e_f[4] = xreal[4]*xreal[0]*xreal[2]*xreal[2] + xreal[5]*xreal[1]*xreal[3]*xreal[3];
	e_f[5] = xreal[4]*xreal[2]*xreal[0]*xreal[0] + xreal[5]*xreal[3]*xreal[1]*xreal[1];

	return;
}

/*  Test problem NES-07
    # of real variables = 20
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
	economics modeling application
    */
void CProblemDef::test_NES_07(double *xreal, double *f_e_f)
{
	// nonlinear equation systems
	double	c[19] = {0.0};
	double	temp1 = 0.0;
	int		i, k;
	for (k=1; k<=CIndividual::N_of_x-1; k++)
	{
		temp1 = 0.0;
		for (i=1; i<=CIndividual::N_of_x-k-1; i++)
		{
			temp1 += xreal[i-1]*xreal[i+k-1];
		}
		e_f[i-1] = (xreal[i-1] + temp1) * xreal[CIndividual::N_of_x-1] - c[i-1];
	}
	temp1 = 0.0;
	for (i=0; i<CIndividual::N_of_x-1; i++)
	{
		temp1 += xreal[i];
	}
	e_f[19] = temp1 + 1.0;

	return;
}

/*  Test problem NES-08
    # of real variables = 4
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_08(double *x, double *f_e_f)
{
	// nonlinear equation systems
	e_f[0] = x[0]*x[0] + 2*x[1]*x[1] + cos(x[2]) - x[3]*x[3];
	e_f[1] = 3*x[0]*x[0] + x[1]*x[1] + sin(x[2])*sin(x[2]) - x[3]*x[3];
	e_f[2] = -2*x[0]*x[0] - x[1]*x[1] - cos(x[2]) + x[3]*x[3];
	e_f[3] = -x[0]*x[0] - 2*x[1]*x[1] - cos(x[2])*cos(x[2]) + x[3]*x[3];

	return;
}

/*  Test problem NES-09
    # of real variables = 2
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_09(double *x, double *f_e_f)
{
	// nonlinear equation systems
	e_f[0] = cos(2.0*x[0])-cos(2.0*x[1])-0.4;
	e_f[1] = 2.0*(x[1]-x[0]) + sin(2.0*x[1]) - sin(2.0*x[0]) -1.2 ;

	return;
}

/*  Test problem NES-10
    # of real variables = 2
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_10(double *x, double *f_e_f)
{
	// nonlinear equation systems
	e_f[0] = exp(x[0]) + x[0]*x[1] - 1.0;
	e_f[1] = sin(x[0]*x[1]) + x[0] + (x[1]) - 1.0;

	return;
}

/*  Test problem NES-11
    # of real variables = 10
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
	interval arithmetic benchmark
    */
void CProblemDef::test_NES_11(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1], x3=x[2], x4=x[3], x5=x[4], x6=x[5], x7=x[6], x8=x[7], x9=x[8], x10=x[9];

	e_f[0] = x1 - 0.25428722 - 0.18324757*x4*x3*x9;
	e_f[1] = x2 - 0.37842197 - 0.16275449*x1*x10*x6;
	e_f[2] = x3 - 0.27162577 - 0.16955071*x1*x2*x10;
	e_f[3] = x4 - 0.19807914 - 0.15585316*x7*x1*x6;
	e_f[4] = x5 - 0.44166728 - 0.19950920*x7*x6*x3;
	e_f[5] = x6 - 0.14654113 - 0.18922793*x8*x5*x10;
	e_f[6] = x7 - 0.42937161 - 0.21180486*x2*x5*x8;
	e_f[7] = x8 - 0.07056438 - 0.17081208*x1*x7*x6;
	e_f[8] = x9 - 0.34504906 - 0.19612740*x10*x6*x8;
	e_f[9] = x10 - 0.42651102 - 0.21466544*x4*x8*x1;

	return;
}

/*  Test problem NES-12
    # of real variables = 5
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
	chemical equilibrium application
    */
void CProblemDef::test_NES_12(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1], x3=x[2], x4=x[3], x5=x[4];

	double	R = 10.0, R5 = 0.193, R6 = 0.002597/sqrt(40),  R7 = 0.003448/sqrt(40);
	double	R8 = 0.00001799/(40), R9 = 0.0002155/sqrt(40), R10 = 0.00003846/(40);

	e_f[0] = x1*x2 + x1 - 3*x5;
	e_f[1] = 2*x1*x2 + x1 + x2*x3*x3 + R8*x2 - R*x5 + 2*R10*x2*x2+ R7*x2*x3 + R9*x2*x4;
	e_f[2] = 2*x2*x3*x3 + 2*R5*x3*x3 - 8*x5 + R6*x3 + R7*x2*x3;
	e_f[3] = R9*x2*x4 + 2*x4*x4 - 4*R*x5;
	e_f[4] = x1*(x2 + 1) + R10*x2*x2 + x2*x3*x3 + R8*x2 + R5*x3*x3 + x4*x4 - 1 + R6*x3 + R7*x2*x3 + R9*x2*x4;

	return;
}

/*  Test problem NES-13
    # of real variables = 10
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
	combustion application
    */
void CProblemDef::test_NES_13(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1], x3=x[2], x4=x[3], x5=x[4], x6=x[5], x7=x[6], x8=x[7], x9=x[8], x10=x[9];

	e_f[0] = x2 + 2*x6 + x9 + 2*x10 - 1e-5;
	e_f[1] = x3 + x8 - 3e-5;
	e_f[2] = x1 + x3 + 2*x5 + 2*x8 + x9 + x10 - 5*1e-5;
	e_f[3] = x4 + 2*x7 - 1e-5;
	e_f[4] = 0.5140437 * 1e-7*x5 - x1*x1;
	e_f[5] = 0.1006932 * 1e-6*x6 - 2*x2*x2;
	e_f[6] = 0.7816278 * 1e-15*x7 - x4*x4;
	e_f[7] = 0.1496236 * 1e-6*x8 - x1*x3;
	e_f[8] = 0.6194411 * 1e-7*x9 - x1*x2;
	e_f[9] = 0.2089296 * 1e-14*x10 - x1*x2*x2;

	return;
}

/*  Test problem NES-14
    # of real variables = 8
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
	kinematic application
    */
void CProblemDef::test_NES_14(double *x, double *f_e_f)
{
	// nonlinear equation systems
	// Also see: 2011 Finding all solutions of nonlinear systems using a hybrid metaheuristic with Fuzzy Clustering Means; case 7
	double	x1=x[0], x2=x[1], x3=x[2], x4=x[3], x5=x[4], x6=x[5], x7=x[6], x8=x[7];
	double	a[17][4] = {
						-0.249150680,0.125016350,-0.635550070,1.48947730,
						1.609135400,-0.686607360,-0.115719920,0.23062341,
						0.279423430,-0.119228120,-0.666404480,1.32810730,
						1.4344801600,-0.719940470,0.110362110,-0.25864503,
						0.0000000000,-0.432419270,0.290702030,1.16517200,
						0.4002638400,0.000000000,1.258776700,-0.26908494,
						-0.800527680,0.000000000,-0.629388360,0.53816987,
						0.0000000000,-0.864838550,0.581404060,0.58258598,
						0.0740523880,-0.037157270,0.195946620,-0.20816985,
						-0.083050031,0.035436896,-1.228034200,2.68683200,
						-0.386159610,0.085383482,0.0000000000,-0.69910317,
						-0.755266030,0.00000000,-0.079034221,0.35744413,
						0.504201680,-0.039251967,0.026387877,1.24991170,
						-1.091628700,0.00000000,-0.057131430,1.46773600,
						0.0000000000,-0.432419270,-1.162808100,1.16517200,
						0.049207290,0.0000000000,1.258776700,1.07633970,
						0.0492207290,0.013873010,2.162575000,-0.69686809
					};

	int j=0;
	for (j=0; j<4; j++)
	{
		e_f[j] = x[j]*x[j] + x[j+1]*x[j+1] - 1.0;
	}
//	j=0;
//	e_f[4] = a[0][j]*x1*x3 + a[1][j]*x1*x4 + a[2][j]*x2*x3 + a[3][j]*x2*x4 + a[4][j]*x2*x7 + a[5][j]*x5*x8
//			+ a[6][j]*x6*x7 + a[7][j]*x6*x8 + a[8][j]*x1 + a[9][j]*x2 + a[10][j]*x3 + a[11][j]*x4
//			+ a[12][j]*x5 + a[13][j]*x6 + a[14][j]*x7 + a[15][j]*x8 + a[16][j];
//	j=1;
//	e_f[5] = a[0][j]*x1*x3 + a[1][j]*x1*x4 + a[2][j]*x2*x3 + a[3][j]*x2*x4 + a[4][j]*x2*x7 + a[5][j]*x5*x8
//			+ a[6][j]*x6*x7 + a[7][j]*x6*x8 + a[8][j]*x1 + a[9][j]*x2 + a[10][j]*x3 + a[11][j]*x4
//			+ a[12][j]*x5 + a[13][j]*x6 + a[14][j]*x7 + a[15][j]*x8 + a[16][j];
//	j=2;
//	e_f[6] = a[0][j]*x1*x3 + a[1][j]*x1*x4 + a[2][j]*x2*x3 + a[3][j]*x2*x4 + a[4][j]*x2*x7 + a[5][j]*x5*x8
//			+ a[6][j]*x6*x7 + a[7][j]*x6*x8 + a[8][j]*x1 + a[9][j]*x2 + a[10][j]*x3 + a[11][j]*x4
//			+ a[12][j]*x5 + a[13][j]*x6 + a[14][j]*x7 + a[15][j]*x8 + a[16][j];
//	j=3;
//	e_f[7] = a[0][j]*x1*x3 + a[1][j]*x1*x4 + a[2][j]*x2*x3 + a[3][j]*x2*x4 + a[4][j]*x2*x7 + a[5][j]*x5*x8
//			+ a[6][j]*x6*x7 + a[7][j]*x6*x8 + a[8][j]*x1 + a[9][j]*x2 + a[10][j]*x3 + a[11][j]*x4
//			+ a[12][j]*x5 + a[13][j]*x6 + a[14][j]*x7 + a[15][j]*x8 + a[16][j];
	for (j=0; j<4; j++)
	{
		e_f[4+j] = a[1-1][j]*x1*x3 + a[2-1][j]*x1*x4 + a[3-1][j]*x2*x3 + a[4-1][j]*x2*x4 + a[5-1][j]*x2*x7 + a[6-1][j]*x5*x8
			+ a[7-1][j]*x6*x7 + a[8-1][j]*x6*x8 + a[9-1][j]*x1 + a[10-1][j]*x2 + a[11-1][j]*x3 + a[12-1][j]*x4
			+ a[13-1][j]*x5 + a[14-1][j]*x6 + a[15-1][j]*x7 + a[16-1][j]*x8 + a[17-1][j];
	}

	return;
}

/*  Test problem NES-15
    # of real variables = 2
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_15(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1];

	e_f[0] = 100*(x1 - 0.25);
	e_f[1] = 100*(x1*sin(x2*x2*PI*4)+0.75*x1-0.25);

	return;
}

/*  Test problem NES-16
    # of real variables = 2
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_16(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1];

	e_f[0] = x1*x1-x2-2.0;
	e_f[1] = x1 + sin(PI/2.0*x2);

	return;
}

/*  Test problem NES-17
    # of real variables = 4
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_17(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1], x3=x[2], x4=x[3];

	e_f[0] = 3.0 - x1*x3*x3;
	e_f[1] = x3*sin(PI/x2) - x3 - x4;
	e_f[2] = -x2*x3*exp(1.0-x1*x3) + 0.2707;
	e_f[3] = 2*x1*x1*x3 - x2*x2*x2*x2*x3 - x2;

	return;
}

/*  Test problem NES-18
    # of real variables = 2
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_18(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1];

	double	RR[6] = {0.935, 0.940, 0.945, 0.950, 0.955, 0.960};
	double	R = RR[5];
	double	beta1 = 2, beta2 = 2, gamma = 1000, D = 22;

	e_f[0] = (1.0 - R) * ( D/(10*(1+beta1)) - x1 ) * exp( 10*x1/(1+10*x1/gamma) ) - x1;
	e_f[1] = (1.0 - R) * ( D/10.0 - beta1*x1 - (1+beta2)*x2 ) * exp( 10*x2/(1+10*x2/gamma) ) + x1 - (1+beta2)*x2;

	return;
}

/*  Test problem NES-19
    # of real variables = 3
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_19(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	b=x[0], h=x[1], t=x[2];

	e_f[0] = b*h + (b - 2*t) * (h - 2*t) - 165.0;
	e_f[1] = b*h*h*h/12 - (b-2*t)*pow(h-2*t,3)/12 - 9369.0;
	e_f[2] = 2*(h-t)*(h-t)*(b-t)*(b-t)*t/(b+h-2*t) - 6835.0;

	return;
}

/*  Test problem NES-20
    # of real variables = 5
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_20(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1], x3=x[2], x4=x[3], x5=x[4];

	e_f[0] = 2*x1 + x2 + x3 + x4 + x5 - 6.0;
	e_f[1] = x1 + 2*x2 + x3 + x4 + x5 - 6.0;
	e_f[2] = x1 + x2 + 2*x3 + x4 + x5 - 6.0;
	e_f[3] = x1 + x2 + x3 + 2*x4 + x5 - 6.0;
	e_f[4] = x1*x2*x3*x4*x5 - 1.0;

	return;
}

/*  Test problem NES-21
    # of real variables = 6
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_21(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1], x3=x[2], x4=x[3], x5=x[4], x6=x[5];

	e_f[0] = x1 + pow(x2, 4)*x4*x6/4 + 0.75;
	e_f[1] = x2 + 0.405*exp(1 + x1*x2) - 1.405;
	e_f[2] = x3 - x4*x6/2 + 1.5;
	e_f[3] = x4 - 0.605*exp(1 - x3*x3) - 0.395;
	e_f[4] = x5 - x2*x6/2 + 1.5;
	e_f[5] = x6 - x1*x5;

	return;
}

/*  Test problem NES-22
    # of real variables = 2
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_22(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1];

	e_f[0] = x1*x1 + x2*x2 + x1 + x2 - 8.0;
	e_f[1] = x1*fabs(x2) + x1 + fabs(x2) - 5.0;

	return;
}

/*  Test problem NES-23
    # of real variables = 3
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_23(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1], x3=x[2];

	e_f[0] = 3*x1*x1 + sin(x1*x2) - x3*x3+ 2.0;
	e_f[1] = 2*x1*x1*x1 -x2*x2 - x3 + 3.0;
	e_f[2] = sin(2*x1) + cos(x2*x3) + x2 - 1.0;

	return;
}

/*  Test problem NES-24
    # of real variables = 2
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_24(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1];

	e_f[0] = x1*x1 - fabs(x2) + 1.0 + 1.0/9*fabs(x1 - 1);
	e_f[1] = x2*x2 + 5*x1*x1 - 7.0 + 1.0/9*fabs(x2);

	return;
}

/*  Test problem NES-25
    # of real variables = 2
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_25(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1];

	e_f[0] = sin(x1*x1*x1) - 3*x1*x2*x2 -1;
	e_f[1] = cos(3*x1*x1*x2) - fabs(x2*x2*x2) +1;

	return;
}

/*  Test problem NES-26
    # of real variables = 3
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_26(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1], x3=x[2];

	e_f[0] = exp(x1*x1) - 8*x1*sin(x2);
	e_f[1] = x1+x2-1;
	e_f[2] = pow(x3-1, 3);

	return;
}

/*  Test problem NES-27
    # of real variables = 3
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_27(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1], x3=x[2];

	e_f[0] = 5*pow(x1, 9) - 6*pow(x1, 5)*x2*x2 + x1*pow(x2,4) + 2*x1*x3;
	e_f[1] = -2*pow(x1, 6)*x2 + 2*x1*x1*pow(x2, 3) + 2*x2*x3;
	e_f[2] = (x1*x1 + x2*x2 - 0.265625);

	return;
}

/*  Test problem NES-28
    # of real variables = 2
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_28(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1];

	e_f[0] = 4*x1*x1*x1+4*x1*x2+2*x2*x2-42*x1-14;
	e_f[1] = 4*x2*x2*x2+2*x1*x1+4*x1*x2-26*x2-22;

	return;
}

/*  Test problem NES-29
    # of real variables = 2
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_29(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1];

	e_f[0] = 0.5*sin(x1*x2) - 0.25*x2/PI - 0.5*x1;
	e_f[1] = (1.0-0.25/PI)*(exp(2*x1) - E) + E*x2/PI - 2*E*x1;

	return;
}

/*  Test problem NES-30
    # of real variables = 2
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_30(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1];

	e_f[0] = -sin(x1)*cos(x2) - 2*cos(x1)*sin(x2);
	e_f[1] = -cos(x1)*sin(x2) - 2*sin(x1)*cos(x2);

	return;
}

/*  Test problem NES-31
    # of real variables = 8
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
	kinematic application
    */
void CProblemDef::test_NES_31(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1], x3=x[2], x4=x[3], x5=x[4], x6=x[5], x7=x[6], x8=x[7];

	// 2014 Chaotic quantum behaved particle swarm optimization algorithm for solving nonlinear system of equations, case 8
	e_f[0] = x1*x1 + x2*x2 -1.0;
	e_f[1] = x3*x3 + x4*x4 -1.0;
	e_f[2] = x5*x5 + x6*x6 -1.0;
	e_f[3] = x7*x7 + x8*x8 -1.0;
	e_f[4] = 4.731e-3*x1*x3 - 0.3578*x2*x3 - 0.1238*x1 + x7 - 1.637e-3*x2 - 0.9338*x4 - 0.3571;
	e_f[5] = 0.2238*x1*x3 + 0.7623*x2*x3 + 0.2638*x1 - x7 - 0.07745*x2 - 0.6734*x4 - 0.6022;
	e_f[6] = x6*x8 + 0.3578*x1 + 4.731e-3*x2;
	e_f[7] = -0.7623*x1 + 0.2238*x2 + 0.3461;

	return;
}

/*  Test problem NES-32
    # of real variables = 3
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
	kinematic application
    */
void CProblemDef::test_NES_32(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1], x3=x[2];

	double	eta[4] = {1.3954170041747090114, 1.7444828545735749268, 2.0656234369405315689, 2.4600678478912500533};
	double	phi[4] = {1.7461756494150842271, 2.0364691127919609051, 2.2390977868265978920, 2.4600678409809344550};

	double	EE[3], FF[3];
	int j;
	for (j=0; j<3; j++)
	{
		EE[j] = x2*( cos(phi[j+1])-cos(phi[0]) ) - x2*x3*( sin(phi[j+1])-sin(phi[0]) ) - ( x2*sin(phi[j+1]) - x3 ) * x1;
		FF[j] = -x2*cos(eta[j+1]) - x2*x3*sin(eta[j+1]) + x2*cos(eta[0]) + x1*x3 + (x3-x1)*x2*sin(eta[0]);
	}

	for (j=0; j<3; j++)
	{
		e_f[j] = ( EE[j]*(x2*sin(eta[j+1])-x3) - FF[j]*(x2*sin(phi[j+1])-x3) )*( EE[j]*(x2*sin(eta[j+1])-x3) - FF[j]*(x2*sin(phi[j+1])-x3) ) +
			( FF[j]*(1+x2*cos(phi[j+1])) - EE[j]*(x2*cos(eta[j+1])-1) ) * ( FF[j]*(1+x2*cos(phi[j+1])) - EE[j]*(x2*cos(eta[j+1])-1) ) - 
			( (1+x2*cos(phi[j+1]))*(x2*sin(eta[j+1])-x3)*x1 - (x2*sin(phi[j+1])-x3)*(x2*cos(eta[j+1])-x3)*x1 ) * ( (1+x2*cos(phi[j+1]))*(x2*sin(eta[j+1])-x3)*x1 - (x2*sin(phi[j+1])-x3)*(x2*cos(eta[j+1])-x3)*x1 );
	}

	return;
}

/*  Test problem NES-33
    # of real variables = 3
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
	kinematic application
    */
void CProblemDef::test_NES_33(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	t1=x[0], t2=x[1], t3=x[2];

	double	beta[3][5] = { {-9, -1, -1, 3, 8},{-9, -1, -1, 3, 8}, {-9, -1, -1, 3, 8} };

	e_f[0] = beta[0][0] + beta[0][1]*t2*t2 + beta[0][2]*t3*t3 + beta[0][3]*t2*t2*t3*t3 + beta[0][4]*t2*t3;
	e_f[1] = beta[1][0] + beta[1][1]*t3*t3 + beta[1][2]*t1*t1 + beta[1][3]*t1*t1*t3*t3 + beta[1][4]*t1*t3;
	e_f[2] = beta[2][0] + beta[2][1]*t1*t1 + beta[2][2]*t2*t2 + beta[2][3]*t2*t2*t1*t1 + beta[2][4]*t2*t1;	

	return;
}

/*  Test problem NES-34
    # of real variables = 2
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_34(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1];

	e_f[0] = 4*x1*x1*x1-3*x1-cos(x2);
	e_f[1] = sin(x1*x1)-fabs(x2);

	return;
}

/*  Test problem NES-35
    # of real variables = 20
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_35(double *x, double *f_e_f)
{
	// nonlinear equation systems
	int i, n = CIndividual::N_of_x;
	double temp=0.0;
	for (i=0; i<n; i++)
	{
		temp += x[i];
	}
	for (i=0; i<n-1; i++)
	{
		e_f[i] = x[i] + temp - (n+1);
	}

	temp = 1.0;
	for (i=0; i<n; i++)
	{
		temp *= x[i];
	}
	e_f[n-1] = temp-1.0;

	return;
}

/*  Test problem NES-36
    # of real variables = 4
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_36(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1], x3=x[2], x4=x[3];
	
	double	a1 = -1.697e7, a2 = 2.177e7, a3 = 0.55, a4 = 0.45, a5 = -1.0;
	double	b1 = 1.585e14, b2 = 4.126e7, b3 = -8.285e6;
	double	b4 = 2.284e7, b5 = 1.918e7, b6 = 48.4, b7 = -27.73;

	e_f[0] = a1*x2*x4+a2*x2+a3*x1*x4+a4*x1+a5*x4;
	e_f[1] = b1*x2*x4+b2*x1*x3+b3*x1*x4+b4*x3*x4+b5*x3+b6*x4*b7;
	e_f[2] = x1*x1 - x2;
	e_f[3] = x4*x4 - x3;

	return;
}

/*  Test problem NES-37
    # of real variables = 2
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_37(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1];

	e_f[0] = x1*x1 - 4*x2;
	e_f[1] = x2*x2-2*x1+4*x2;

	return;
}

/*  Test problem NES-38
    # of real variables = 3
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_38(double *x, double *f_e_f)
{
	// nonlinear equation systems
	int i;
	int n = CIndividual::N_of_x;
	double temp = 0.0;
	for (i=0; i<n; i++)
	{
		temp += x[i];
	}

	for (i=0; i<n; i++)
	{
		e_f[i] = x[i] - cos(2*x[i] - temp);
	}

	return;
}

/*  Test problem NES-39
    # of real variables = 2
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_39(double *x, double *f_e_f)
{
	// nonlinear equation systems
	e_f[0] = x[0]*x[0] + x[1]*x[1] - 2.0;
	//e_f[1] = exp(x[0]-1.0) + x[1]*x[1] - 2.0;
	e_f[1] = x[0]*x[0] + x[1]*x[1]/4 - 1.0;

	return;
}

/*  Test problem NES-40
    # of real variables = 2
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
    */
void CProblemDef::test_NES_40(double *x, double *f_e_f)
{
	// nonlinear equation systems
	e_f[0] = exp(x[0]*x[0] + x[1]*x[1]) - 3.0;
	e_f[1] = fabs(x[1])+x[0] - sin(3.0*(fabs(x[1])+x[0]));

	return;
}

/*  Test problem NES-41
    # of real variables = 10
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
	interval arithmetic benchmark
    */
void CProblemDef::test_NES_41(double *x, double *f_e_f)
{
	// nonlinear equation systems
	e_f[0] = (3-5*x[0])*x[0] + 1 - 2*x[1];
	for (int i=1; i<9; i++)
	{
		e_f[i] = (3-5*x[i])*x[i] + 1 - x[i-1] - 2*x[i+1];
	}
	e_f[9] = (3-5*x[9])*x[9] + 1 - x[8];

	return;
}

/*  Test problem NES-42
    # of real variables = 3
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
	interval arithmetic benchmark
    */
void CProblemDef::test_NES_42(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1], x3=x[2];
	double	b[3][5] = //{-310, 959, 774, 1389, 1313,  -365, 755, 917, 1451, 1269,  -413, 837, 838, 1655, 1352};	// 4 real solutions in [-1, 1] 
	{-13, -1, -1, 24, -1,  -13, -1, -1, 24, -1,  -13, -1, -1, 24, -1};	// 16 real solutions in [-15, 15]

	e_f[0] = b[0][0] + b[0][1]*x2*x2 + b[0][2]*x3*x3 + b[0][3]*x2*x3 + b[0][4]*x2*x2*x3*x3;
	e_f[1] = b[1][0] + b[1][1]*x3*x3 + b[1][2]*x1*x1 + b[1][3]*x3*x1 + b[1][4]*x1*x1*x3*x3;
	e_f[2] = b[2][0] + b[2][1]*x1*x1 + b[2][2]*x2*x2 + b[2][3]*x1*x2 + b[2][4]*x2*x2*x1*x1;

	return;
}

/*  Test problem NES-43
    # of real variables = 3
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
	interval arithmetic benchmark
    */
void CProblemDef::test_NES_43(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], x2=x[1], x3 = x[2];

	e_f[0] = -3.84*x1*x1 + 3.84*x1 - x2;
	e_f[1] = -3.84*x2*x2 + 3.84*x2 - x3;
	e_f[2] = -3.84*x3*x3 + 3.84*x3 - x1;

	return;
}

/*  Test problem NES-44
    # of real variables = 3
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
	interval arithmetic benchmark
    */
void CProblemDef::test_NES_44(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], y=x[1], z = x[2];
	double	u, v, w;

	u = 2*x1 - y*y - 3*z;
	v = x1*x1 + 2*y - y*z;
	w = x1*y - 3*z;

	e_f[0] = 2*u - 3*x1*v + v - y*w - 3*x1 - 2*y*z - z +12;
	e_f[1] = u*u + 2*v + y*w - 2*x1 - y*y - x1*z - 2;
	e_f[2] = 3*u - v*w + 2*w + x1 - x1*z + 6;

	return;
}

/*  Test problem NES-45
    # of real variables = 3
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
	interval arithmetic benchmark
    */
void CProblemDef::test_NES_45(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x1=x[0], y=x[1], z = x[2];
	double	u, v;

	u = 3*x1 + y - z;
	v = x1*x1 - y + z;

	e_f[0] = 3*u*u + 2*v - 3*x1 + x1*y + z*z - 24;
	e_f[1] = u - 3*v*v - x1 + 2*y - x1*z + 10;
	e_f[2] = 2*u - v + x1 - y*y + 2*z - 5;

	return;
}

/*  Test problem NES-46
    # of real variables = 1
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
	interval arithmetic benchmark
    */
void CProblemDef::test_NES_46(double *x, double *f_e_f)
{
	// nonlinear equation systems
	e_f[0] = 3.9852 - 10.039*x[0]*x[0] + 7.2338*pow(x[0], 4) - 1.17775*pow(x[0], 6) + (-8.8575*x[0] + 20.091*pow(x[0], 3) - 11.177*pow(x[0], 5)) * sqrt(1 - x[0]*x[0]);

	return;
}

/*  Test problem NES-50
    # of real variables = 3
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
	interval arithmetic benchmark
    */
void CProblemDef::test_NES_50(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double x1 = x[0];
	double x2 = x[1];
	double x3 = x[2];

	e_f[0] = pow(x1, x2) + pow(x2, x1) - 5*x1*x2*x3 - 85.0;
	e_f[1] = x1*x1*x1 - pow(x2, x3) - pow(x3, x2) - 60.0;
	e_f[2] = pow(x1, x3) + pow(x3, x1) - x2 - 2.0;

	return;
}

/*  Test problem NES-51
    # of real variables = 2
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
	interval arithmetic benchmark
    */
void CProblemDef::test_NES_51(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double x1 = x[0];
	double x2 = x[1];

	e_f[0] = x1*x1*x1 - 3*x1*x2*x2 - 1.0;
	e_f[1] = 3*x1*x1*x2 - x2*x2*x2 + 1.0;

	return;
}

/*  Test problem NES-52
    # of real variables = 4
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
	interval arithmetic benchmark
    */
void CProblemDef::test_NES_52(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double x1 = x[0];
	double x2 = x[1];
	double x3 = x[2];

	e_f[0] = 0.1*x1 + cos(2*x2)+ 0.09240;
	e_f[1] = sin(3*x3) + sin(10*x1/3.0) + log(2*x2) - 2.52*x3 + 0.08805;
	e_f[2] = 2*(x1 - 0.75)*(x1 - 0.75) + sin(16*PI*x2 - PI/2.0) - 3.26815;

	return;
}

/*  Test problem NES-53
    # of real variables = 2
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
	interval arithmetic benchmark
    */
void CProblemDef::test_NES_53(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double x1 = x[0];
	double x2 = x[1];

	e_f[0] = 4*x1*x1*x1 - 3*x1 - x2;
	e_f[1] = x1*x1 - x2;

	return;
}

/*  Test problem NES-54
    # of real variables = 2
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
	interval arithmetic benchmark
    */
void CProblemDef::test_NES_54(double *xreal, double *f_e_f)
{
	// nonlinear equation systems
	double x = xreal[0];
	double y = xreal[1];

	double a1 = 25;
	double b1 = 1;
	double c1 = 2;
	double a2 = 3;
	double b2 = 4;
	double c2 = 5;

	e_f[0] = pow(x, 3) - 3*x*y*y + a1*(2*x*x + x*y) + b1*y*y + c1*x + a2*y;
	e_f[1] = 3*x*x*y - pow(y, 3) - a1*(4*x*y - y*y) + b2*x*x + c2;

	return;
}

/*  Test problem NES-55
    # of real variables = 3
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
	interval arithmetic benchmark
    */
void CProblemDef::test_NES_55(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double x1 = x[0];
	double x2 = x[1];
	double x3 = x[2];

	e_f[0] = x1*x1 - x1 - x2*x2 - x2 + x3*x3;
	e_f[1] = sin(x2 - exp(x1));
	e_f[2] = x3 - log(fabs(x2));

	return;
}

/*  Test problem NES-56
    # of real variables = 2
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
	interval arithmetic benchmark
    */
void CProblemDef::test_NES_56(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double x1 = x[0];
	double x2 = x[1];

	e_f[0] = pow(x1, 4) + 4*pow(x2, 4) - 6.0;
	e_f[1] = x1*x1*x2 - 0.6787;
	return;
}

/*  Test problem NES-57
    # of real variables = 3
    # of bin variables  = 0
    # of objectives     = 2
    # of constraints    = 0
	interval arithmetic benchmark
    */
void CProblemDef::test_NES_57(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double x1 = x[0];
	double x2 = x[1];
	double x3 = x[2];

	e_f[0] = pow(x1, 3) + pow(x2, 3) + pow(x3, 3) - 1;
	e_f[1] = 2*x1*x1 + x2*x2 - 4*x3;
	e_f[2] = 3*x1*x1 - 4*x2*x2 + x3*x3;
	
	return;
}

/*  Test problem NES-81
    # of real variables = 9
	The system has 3768 solutions out of which 1816 are nonsingular and the rest of them are singular solutions.
    */
void CProblemDef::test_NES_81(double *x, double *f_e_f)
{
	// nonlinear equation systems
	double	x11, x12, x13, x21, x22, x23, x31, x32, x33;
	x11 = x[0];
	x12 = x[1];
	x13 = x[2];
	x21 = x[3];
	x22 = x[4];
	x23 = x[5];
	x31 = x[6];
	x32 = x[7];
	x33 = x[8];

	e_f[0] = (-cos(x12) - cos(x13) - cos(x21) - cos(x31)) * sin(x11) + cos(x11) * (sin(x12) - sin(x13) + sin(x21) - sin(x31));
	e_f[1] = (-cos(x11) - cos(x13) - cos(x22) - cos(x32)) * sin(x12) + cos(x12) * (sin(x11) + sin(x13) + sin(x22) - sin(x32));
	e_f[2] = (-cos(x11) - cos(x12) - cos(x23) - cos(x33)) * sin(x13) + cos(x13) * (-sin(x11) + sin(x12) + sin(x23) - sin(x33));
	e_f[3] = (-cos(x11) - cos(x22) - cos(x23) - cos(x31)) * sin(x21) + cos(x21) * (sin(x11) + sin(x22) - sin(x23) + sin(x31));
	e_f[4] = (-cos(x12) - cos(x21) - cos(x23) - cos(x32)) * sin(x22) + cos(x22) * (sin(x12) + sin(x21) + sin(x23) + sin(x32));
	e_f[5] = (-cos(x13) - cos(x21) - cos(x22) - cos(x33)) * sin(x23) + cos(x23) * (sin(x13) - sin(x21) + sin(x22) + sin(x33));
	e_f[6] = (-cos(x11) - cos(x21) - cos(x32) - cos(x33)) * sin(x31) + cos(x31) * (-sin(x11) + sin(x21) + sin(x32) - sin(x33));
	e_f[7] = (-cos(x12) - cos(x22) - cos(x31) - cos(x33)) * sin(x32) + cos(x32) * (-sin(x12) + sin(x22) + sin(x31) + sin(x33));
	e_f[8] = cos(x33) * (-sin(x13) + sin(x23) - sin(x31) + sin(x32)) - (cos(x13) + cos(x23) + cos(x31) + cos(x32)) * sin(x33);


	return;
}


