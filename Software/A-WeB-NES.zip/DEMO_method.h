// DEMO_method.h: interface for the CDEMO_method class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEMO_METHOD_H__115FC7EE_687B_44B2_B5C7_1D5EB3EB6988__INCLUDED_)
#define AFX_DEMO_METHOD_H__115FC7EE_687B_44B2_B5C7_1D5EB3EB6988__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "global.h"

#include "./EACommonClass/Individual.h"
#include "./EACommonClass/GenerateMatlab.h"
#include "./EACommonClass/ProblemDef.h"
#include "./EACommonClass/Rand.h"


#include <direct.h>						// include the mkdir() for folder creation
#define SIZEOFBUFFER	256*1024L 

#define out_internal	30

typedef struct lists
{
    int          index;
    struct lists *parent;
    struct lists *child;
}list;

typedef struct 
{
	CIndividual *ind;
}population;

// Structure of velocity of PSO
struct velocity
{
	int    size;
	double v[MAX_N_of_x];
};


class CDEMO_method  
{
public:
	CDEMO_method();
	virtual ~CDEMO_method();

public:
	void init_variables();
	
	void allocate_memory_pop (population *pop, int size);
	void deallocate_memory_pop (population *pop);
	
	void initialize_ind (CIndividual *ind);
	void initialize_pop (population *pop);

	void evaluate_problem (CIndividual *ind);
	void evaluate_ind (CIndividual *ind, double ave_dist);
	void evaluate_pop (population *pop, int size);
	
	void assign_crowding_distance_list (population *pop, list *lst, int front_size);
	void assign_crowding_distance_indices (population *pop, int c1, int c2);
	void assign_crowding_distance (population *pop, int *dist, int **obj_array, int front_size);
	void assign_rank_and_crowding_distance (population *new_pop);

	double	cal_ecu_dist(double *x, double *y, int n);
	double	cal_ecu_dist_normalized(double *x, double *y, int n);

	int  check_dominance (CIndividual *a, CIndividual *b);		// check dominance in objective space
	int	 check_dominance_NES(CIndividual *a, CIndividual *b);	// check dominance in the original NES problem
	int  check_new_dominance(CIndividual *a, CIndividual *b);	// check dominance in the D bi-objective functions

	void fill_nondominated_sort (population *mixed_pop, population *new_pop);
	void crowding_fill (population *mixed_pop, population *new_pop, int count, int front_size, list *cur);

	void insert (list *node, int x);
	list* del (list *node);

	void merge(population *pop1, population *pop2, population *pop3);

	void quicksort_front_obj(population *pop, int objcount, int obj_array[], int obj_array_size);
	void q_sort_front_obj(population *pop, int objcount, int obj_array[], int left, int right);
	void quicksort_dist(population *pop, int *dist, int front_size);
	void q_sort_dist(population *pop, int *dist, int left, int right);

	void report_pop (population *pop, FILE *fpt);
	void report_final_pop (population *pop, FILE *fpt);
	void report_ind (CIndividual *ind, FILE *fpt);

	void random_index(int *array_index, int all_size, int size);

	void shell_sort_pop(population *pop, int *list, int size);
	void shell_sort_array(double *array, int *list, int size);

	void Run_optimizer(int run_no, double seed, int method, int func_flag, int flag_of_read_data);

	/************************************************************************/
	/* Methods for statistics                                               */
	/************************************************************************/
	int			num_of_seeds;			// number of different optima
	int			seeds_indices[population_size];
	void		get_seeds_indices(population *pop, int size, int *seeds_indices);

	int			num_of_optimal_POF;		// number of the optimal solutions in true POF
	double		POS_data[200][MAX_N_of_x];
	double		POF_data[200][2];
	int			flag_of_true_POF;		// the true POF exists or not
	void		read_POS_data(FILE *fpt);
	void		calculate_POS_data();

	void		get_the_archive();
	int			how_many_optima(CIndividual *pop, int size);
	double		IGD_performance(CIndividual *pop, int size);
	double		IGD_performance_objective(CIndividual *pop, int size);

	void		report_NOF_performance(long int gen, int NOF_rst, double peak_ratio, FILE *fpt);
	void		report_IGD_performance(long int gen, double IGD_rst, FILE *fpt);
	void		report_final_archive(FILE *fpt);

	/************************************************************************/
	/* Methods and attributes for batch execution                           */
	/************************************************************************/
public:
	void	create_folders(int method_ii);					// create the folders
	void	copy_files(char *source, char *target);			// copy files from the source directory to the target directory
	long	filesize(FILE *stream);
	int		copyfile(const char* src,const char* dest);

	// for different bi-objective function
	int			D_biobjective;

	int			single_x_biobjective;
	int			single_x;

	int			average_dist_biojective;		// ref: TEC2013 A Bi-objective Differential Evolution Algorithm Enhanced with Mean Distance based Selection for Multimodal Optimization
	double		average_distance[2*population_size];
	
public:
	int    popsize;						// size of the population
	int	   gen;							// current generation
	int    ngen;						// maximum generation of the algorithm
	int    max_evaluation;				// maximum fitness function evaluation
	int    neval;						// number of fitness function evaluation
	double min_realvar[MAX_N_of_x];		// lower bounds of the real variables
	double max_realvar[MAX_N_of_x];		// upper bounds of the real variables

	double max_abs_var;

	int	   nreal;						// number of the real variables
	int	   nobj;						// number of the objective functions

	population *parent_pop;				// pointer of the parent population
	population *child_pop;				// pointer of the child population
	population *mixed_pop;				// pointer of the mixed population
	int        child_size;				// size of the child population (max = popsize)
	
	int		   num_of_optima;
	population *optima_pop;				// pointer of the population saving the optimal solution
	
	CIndividual new_child;
	int			sorted_index[5*population_size];

	CIndividual best_indv, worst_indv;
	int         best_index, worst_index;
	double		worst_sum_e_f;
	double		best_sun_e_f;
	void		get_best_worst_f_e_f(population *pop, int size);

	double		new_min_realvar[MAX_N_of_x], new_max_realvar[MAX_N_of_x];
	void		get_new_interval(population *pop, int size);

	// some class objects may be needed in the algorithm
	double			seed;				// seed of the random number generator
	CRand			m_rnd;
	int				m_func;
	CProblemDef		m_ofunc;
	CGenerateMatlab m_mtb; 

	/* for archive population */
	void	QuickSort(CIndividual* ,int ,int);					// sort the archive
	void	report_archive();									// report the archive in the file

	CIndividual m_ArchivePop[MAX_ARCHIVE_SIZE];					// Archive population = MAX_ARCHIVE_SIZE
	int			m_ArchiveSize;									// size of the current archive
	int			m_MaxOrMin[MAX_N_of_obj];						// type of objectives

public:
	/************************************************************************/
	/* Check the solution whether optimal or not                            */
	/************************************************************************/
	double		weights_x[200];
	int			weights_min_index;
	void		generate_weights(double *a, int n);

	/************************************************************************/
	/* Methods and attributes for JADE methods                              */
	/************************************************************************/
public:	
	double	JADE_mu_CR;
	double	JADE_mu_FF;
	double	JADE_c;

	CIndividual evolutionary_pop[population_size];

	/************************************************************************/
	/* For DE with neighborhood-based mutation                              */
	/************************************************************************/
public:
	int		neighborhood_size;
	int		neighborhood_index[population_size];
	double	dist_t[population_size][population_size];
	
	void	calculate_proximity_prob(population *pop, int size);				// get the neighborhood indices
	void	get_neighborhood_index(int base_index);

	/************************************************************************/
	/* Methods and attributes for the SHADE algorithm                       */
	/************************************************************************/
	// Ref: R. Tanabe and A. Fukunaga, Success-History Based Parameter Adaptation for Differential Evolution, CEC-2013, 71-78.
public:
	int		SHADE_memory_size;
	double	SHADE_M_CR_FF[1000][2];							// The historical memory of CR and F

public:
	int		m_crowding_dist;
	double	m_CR;
	double	m_FF;
	
	void	run_DEMO_SHADE();
	
};

#endif // !defined(AFX_DEMO_METHOD_H__115FC7EE_687B_44B2_B5C7_1D5EB3EB6988__INCLUDED_)
