
#include "global.h"
#include "DEMO_method.h"

void	welcome();
void	run_single();
void	run_multiple();

int main(int argc, char* argv[])
{
	welcome();

	if (0==batch_execution)
	{
		run_single();
	}
	else if (1==batch_execution)
	{
		run_multiple();
	}
	
	return 0;
}

void run_single()
{
	double	seed = 0.0;
	int		method;
	int		output_counter		= 0;
	int		read_data			= 1;
	int		index_of_func		= 1;

	printf("function   = ");
	index_of_func = 1;
	cin>>index_of_func;

	printf("method     = ");
	method = 2;
	cin>>method;

	int RUN_NUMBER;
	printf("RUN_NUMBER = ");
	RUN_NUMBER = 1;
	cin>>RUN_NUMBER;

	srand((unsigned)time(NULL));

	CDEMO_method *DEMO_method;
	for (int i=0;i<RUN_NUMBER;i++)
	{	
		int t = output_counter;				
		int k = t*RUN_NUMBER;
		printf("-------------------------- Run no. is %d --------------------------\n", i+1);
		seed = ((double)(k+i+1))/((double)RUN_NUMBER);
		if (seed == 0.0)
		{
			seed = 0.001;
		}
		if (seed == 1.0)
		{
			seed = 0.99;
		}

		if (i==0)
		{
			read_data = 1;
		}
		else
		{
			read_data = 0;
		}

		DEMO_method = new CDEMO_method;
		DEMO_method->Run_optimizer( k+i, seed, method, index_of_func, read_data);
		delete DEMO_method;
	}
}

void run_multiple()
{
	double	seed				= 0.0;
	int		method				= 1;
	int		output_counter		= 0;
	int		read_data			= 1;
	int		index_of_func		= 1;
	int		RUN_NUMBER			= 50;

	int		func_total_num		= 38;	// 27
	int		func_index_set[38]	= {1, 2, 3, 4, 9, 11, 15, 17, 18, 20, 21, 23, 25, 27, 28, 30, 31, 34, 35, 38, 39, 40, 43,  // 1-23    
		5, 6, 7, 13, // 24-27  
		16, 22, 24, 29, 50, 51, 52, 53, 54, 55, 56}; // 28-38

	srand((unsigned)time(NULL));

	CDEMO_method *DEMO_method;

	for (int mm=7; mm<=8; mm++)				// method level
	{
		method = mm;
		
		for (int kk = 5; kk <= 5; kk++)		// function level  scalable=9,16
		{
			index_of_func = func_index_set[kk-1];

			RUN_NUMBER = 50;
			for (int i=0;i<RUN_NUMBER;i++)	// run # level
			{	
				int t = output_counter;				
				int k = t*RUN_NUMBER;
				printf("-------------------------- Run no. is %d --------------------------\n", i+1);
				seed = ((double)(k+i+1))/((double)RUN_NUMBER);
				if (seed == 0.0)
				{
					seed = 0.001;
				}
				if (seed == 1.0)
				{
					seed = 0.99;
				}

				if (i==0)
				{
					read_data = 1;
				}
				else
				{
					read_data = 0;
				}

				DEMO_method = new CDEMO_method;
				DEMO_method->Run_optimizer( k+i, seed, method, index_of_func, read_data);
				delete DEMO_method;
			}
		}
	}
}

void welcome()
{
	printf("\n");
	printf("***********************************************************\n");
	printf("*           Welcome to use the EA-NES optimizers.         *\n");
	printf("*      You can select and use the following optimizer.    *\n");
	printf("*                method = 1   for Ada-DEMO-W              *\n");
	printf("***********************************************************\n");
	printf("\n");
}

