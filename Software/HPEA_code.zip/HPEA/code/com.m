function c= com(a,b)                  %�Ƚ���������ģ���������ڵ�ʱ�򷵻�true.
if((a(1)+2*a(2)+a(3))/4>(b(1)+2*b(2)+b(3))/4)
    c=1;
else
    if((a(1)+2*a(2)+a(3))/4<(b(1)+2*b(2)+b(3))/4)
      c=0;
    else
        if (a(2)>b(2))
            c=1;
        else
            if(a(2)<b(2))
                c=0;
            else
                if((a(3)-a(1))>(b(3)-b(1)))
                    c=1;
                else
                    c=0;
                end
            end
        end
    end
end
end

