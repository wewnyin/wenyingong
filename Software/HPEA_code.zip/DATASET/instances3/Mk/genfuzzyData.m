
clc;
clear all;
                                    
Gen=200;                              %  ����������
global TM N H SH NM M time ps ;
ps=100;
path='Mk\';
respath='result\';
Data={'Mk01.txt','Mk02.txt','Mk03.txt','Mk04.txt','Mk05.txt','Mk06.txt','Mk07.txt','Mk08.txt','Mk09.txt','Mk10.txt'};
title='F';
for i=1:10
 PATH=[Data{i}];
[TM,N,H,SH,NM,M,time] = readparam(PATH);
respath=[title,Data{i}];
fid=fopen(respath,'w');

total_chose_machine=0;
ftime=time;
for j=1:N
    for k=1:H(j)
        total_chose_machine=total_chose_machine+NM{j,k};
        for h=1:NM{j,k}
            fuzz_time=cell(1,1);
            b=ftime{j,k,M{j,k,h}};
            if b==1%�����������ӹ�ʱ����0�����
                b=b+1;
            end
            a=ceil(rand*(b/2));            
            a=b-a;
            c=ceil(rand*(b/2));
            c=b+c;
            fuzz_time=[a b c];
            ftime{j,k,M{j,k,h}}=fuzz_time;
        end
    end
end
machine_per_operation=floor(total_chose_machine/SH);
fprintf(fid,'%d %d %d\r\n',N,TM,machine_per_operation);

for j=1:N
    fprintf(fid,'%d   ',H(j));%һ�����������ո�
    for k=1:H(j)
        fprintf(fid,'%d   ',NM{j,k});
        for h=1:NM{j,k}
            fprintf(fid,'%d ',M{j,k,h});
            fprintf(fid,'%d %d %d   ',ftime{j,k,M{j,k,h}}(1),ftime{j,k,M{j,k,h}}(2),ftime{j,k,M{j,k,h}}(3));
        end
    end
    fprintf(fid,'\r\n');%д��һ��֮����
end

fclose(fid);

end



