%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% DR-NESO code
% This code is part of the program that produces the results in the following paper:
% Huixiang Zhen, Shijie Xiong, Wenyin Gong, and Ling Wang. "Neighborhood Evolutionary Sampling with Dynamic Repulsion for Expensive Multimodal Optimization", Information Sciences, accepted, 2023.
% This matlab code was written by Huixiang Zhen, School of Computer Science, China University of Geoscience. 
% Date: 2/12/2023
% Written by Huixiang Zhen, zhenhuixiang@cug.edu.cn.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clc;
clear all;
addpath(genpath(pwd));
warning off
format short;
format compact; 

% 0.Experiment setting
output = fopen('result\DRNESO.txt','wt');
DimArr = [1 1 1 2 2   2 2 3 3 2   2 2 2 3 3   5 5 10 10 20 ];
ModalArr = [2 5 1 4 2   18 36 81 216 12   6 8 6 6 8   6 8 6 8 8];
OptimaArr = [200.0 1.0 1.0 200.0 1.03163   186.7309088310240 1.0 2709.0935 1.0 -2.0   zeros(1,10) ];
MaxNFEs = [300*ones(1, 5)    2000*ones(1, 10)    4000*ones(1, 5)];
initDataArr = [100*ones(1, 5)  300*ones(1, 10)  300*ones(1, 5)];
NPArr = [100*ones(1, 5) 100*ones(1, 15)];
problemList =  1 : 20;
show_plot = 0; % plot figure, the variable is dimension. show_plot = 1 for F1-3; show_plot = 2 for F4-7 and F10-13.

for p = 1 :  20 
    clearvars -except output DimArr ModalArr OptimaArr MaxNFEs problemList p NPArr show_plot multimodal_problem initDataArr
    runs = 1;
    
    % 0.Parameter setting
    global initial_flag;
    initial_flag = 0;
    problem = problemList(p);
    UB = get_ub(problem);
    LB = get_lb(problem);
    [temp, ps_x] = mapminmax([LB; UB]',0,1); % normalized search space 
    LB2 = zeros(1,length(LB)); % normalized boundary
    UB2 = ones(1,length(UB));
    D = DimArr(problem);
    MaxNFE = MaxNFEs(problem);
    NP = NPArr(p);
    initData = initDataArr(p);
    finaloutputs = [];
    
    % 0.Run experiment
    tic;  run = 1;
    while run <= runs
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% a. plot function landscape
        if show_plot == 1
            close;
            figure(1)
            nd = ( UB(1)-LB(1) )/200;
            x=LB(1):nd:UB(1);
            for ii = -100:1:100
                f0(ii+101)=nichingFunc(x(ii+101), problem);
            end
            s0=plot(x,f0); hold on;
        end
        if show_plot == 2
            close;
            figure(1)
            nd = ( UB(1)-LB(1) )/200;
            t=LB(1):nd:UB(1);
            [x,y]=meshgrid(t);
            for ii = -100:1:100
                for jj = -100:1:100
                    f0(ii+101,jj+101)=nichingFunc([x(ii+101,jj+101),y(ii+101,jj+101)], problem);
                end
            end
            s0=surf(x,y,f0); 
            shading flat;
            hold on;
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % 1.Initialization
        LHSsamples= lhsdesign(initData, D);
        Data_X2 = LHSsamples; 
        Data_X = mapminmax('reverse',Data_X2',ps_x)'; % mapping from [0,1] (X2) to original search sapce (X)
        Data_fX = nichingFunc(Data_X, problem);
        [temp k]=sort(Data_fX,'descend');
        DB = [Data_X2 Data_fX]; % database
        X2 = Data_X2(k(1:NP),:); % population
        fX = Data_fX(k(1:NP)); % fitness                                               
        NFE = size(DB,1);
        g = 0;                                           
        archive = [];
        archive_val = [];
        global_optimal_val = [];
        global_optimal2 = [];
        found_num = [];
        root_val = 1e-6; 
        max_archive = NP;
        stagnant = zeros(NP,1);
        K_arr = rand(NP,1) * min([20*D, NFE-20, 150]) + 20;
        baseline1 = mean(fX);
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% b. plot initialization population
        if show_plot == 1
            f1 = zeros(201);
            X = mapminmax('reverse',X2',ps_x)';
            f1=nichingFunc(X, problem);
            s1=scatter(X(:,1), f1,'MarkerEdgeColor','k',...
            'MarkerFaceColor',[0 .75 .75]);
        end
        if show_plot == 2
            f1 = zeros(201,201);
            X = mapminmax('reverse',X2',ps_x)';
            f1=nichingFunc(X, problem);
            s1=scatter3(X(:,1),X(:,2), f1,'MarkerEdgeColor','k',...
            'MarkerFaceColor',[0 .75 .75]);
        end
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % 2.Single run
        while NFE < MaxNFE
            g = g+1;
            for i = 1 : NP
                K = K_arr(i);
                restart = 0;
                
                % 2.1 Evolutionary sampling
                if rand > 0.5 
                    % NES1 (neighborhood DE evolutionary screen)
                    [neighbor_X, f_neighbor_X] = neigh_point(DB, X2(i, :),  fX(i), K-1); % Calculate neighbor points containing X2(i, :)
                    Model_A = RBFCreate(neighbor_X,  f_neighbor_X, 'cubic');
                    [temp k]=sort(f_neighbor_X);
                    P = neighbor_X(k,:);
                    rpn = length(f_neighbor_X);
                    NP_last = rpn; NP_next = rpn;
                    Pmin=repmat(LB2,NP_last,1);                 
                    Pmax=repmat(UB2,NP_last,1);            
                    F = 0.5; CR = 0.5;
                    [offspring] = DEoperating(P,NP_last,NP_next,D,P,F,CR,Pmax,Pmin);
                    offspring_f = RBFInterp(offspring, Model_A); 
                    [~, ind] = max(offspring_f);
                    candiate = offspring(ind(1), :);
                else
                    % NES2 (neighborhood surrogate local search)
                    [neighbor_X, f_neighbor_X] = neigh_point(DB, X2(i, :),  fX(i), K-1); 
                    Model_B = RBFCreate(neighbor_X,  f_neighbor_X, 'cubic');
                    lbounds = (min(neighbor_X, [], 1));
                    ubounds = (max(neighbor_X, [], 1));
                    lu = [lbounds; ubounds];
                    candiate =JADE(lu, Model_B, 10, 50 , D);
                end
                
                % 2.2 Repulsion and restart
                threshold = zeros(length(global_optimal_val),1);
                if ~isempty(global_optimal2)
                    threshold = update_threshold(DB, X2, fX, global_optimal2, threshold, baseline1); % update taboo area threshold
                end
                [restart] = repulsion(candiate,global_optimal2,threshold); % repulse individual in taboo area
                if restart == 1 || stagnant(i)>=10 % elite restart of repulsed individual
                    stagnant(i) = 0;
                    NP2 = 10*floor(sqrt(D));
                    restartArr = [];  
                    rand_X = repmat(LB2,NP2,1)+(repmat(UB2,NP2,1)-repmat(LB2,NP2,1)).*rand(NP2, D);
                    for c = 1 : NP2
                        restartArr(c) = repulsion(rand_X(c,:),global_optimal2,threshold); % repulse restarted individual in taboo area
                    end
                    for c = 1 : NP2
                        if restartArr(c) == 1
                            rand_f(c) = -inf;
                        else
                            [neighbor_X, f_neighbor_X] = neigh_point_B(DB(:,1:end), rand_X(c,:), 5); % Calculate neighbor points not containing rand_X
                            Model_C = RBFCreate(neighbor_X,  f_neighbor_X, 'cubic'); 
                            rand_f(c) = RBFInterp(rand_X(c,:), Model_C);
                        end
                    end
                    [maxval, index] = max(rand_f);
                    candiate = rand_X(index,:); % new individual by elite restart
                end
                
                % 2.3 Evaluation
                candiate_f = nichingFunc(mapminmax('reverse',candiate',ps_x)', problem); NFE = NFE + 1; 
                
                % 2.4 update archives
                if abs(candiate_f - max(fX)) < root_val
                    % update temporary optimal archive
                    [archive, archive_val, found_num, restart] = update_archive(candiate, candiate_f, archive, archive_val,D,max_archive,threshold, found_num);
                    [maxval, index] = max(archive_val);
                    archive = archive(abs(archive_val - maxval)<root_val,:);
                    archive_val = archive_val(abs(archive_val - maxval)<root_val); 
                    found_num = found_num(abs(archive_val - maxval)<root_val,:);
                    num = 5;
                    % update taboo area archive that can be considered as optimal solutions
                    global_optimal2 = archive(found_num>num,:);
                    global_optimal_val = archive_val(found_num>num);
                end
                
                % 2.6 updata database and population
                DB = [DB; candiate candiate_f];
                if candiate_f <= fX(i) + root_val
                    stagnant(i) = stagnant(i) + 1;
                end
                if candiate_f > fX(i) || restart == 1 
                    X2(i, :) = candiate;
                    fX(i) = candiate_f;
                end
                
                % 2.7 Termination
                if NFE >= MaxNFE
                    break;
                end
            end
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% c. show plot population and global optimal solutions
            if show_plot == 1
                % plot population
                if s1~=0
                    delete(s1);
                end
                f1 = zeros(201);
                X = mapminmax('reverse',X2',ps_x)';
                f1=nichingFunc(X, problem);
                s1=scatter(X(:,1), f1,'MarkerEdgeColor','k',...
                'MarkerFaceColor',[0 .75 .75]);
                % plot global optimal
                if  ~isempty(global_optimal2)  
                    global_optimal = mapminmax('reverse',global_optimal2',ps_x)';
                    s2=scatter(global_optimal(:,1), global_optimal_val,'MarkerEdgeColor','k',...
                    'MarkerFaceColor',[.75 0 0]);
                end
            end
            if show_plot == 2
                % plot population
                if s1~=0
                    delete(s1);
                end
                f1 = zeros(201,201);
                X = mapminmax('reverse',X2',ps_x)';
                f1=nichingFunc(X, problem);
                s1=scatter3(X(:,1),X(:,2), f1,'MarkerEdgeColor','k',...
                'MarkerFaceColor',[0 .75 .75]);
                % plot global optimal
                if  ~isempty(global_optimal2)  
                    global_optimal = mapminmax('reverse',global_optimal2',ps_x)';
                    s2=scatter3(global_optimal(:,1),global_optimal(:,2), global_optimal_val,'MarkerEdgeColor','k',...
                    'MarkerFaceColor',[.75 0 0]);
                end
            end
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        end
        run = run + 1;
        % How many global optima have been found? 
        DB_original_sapce = DB;
        DB_original_sapce(:,1:end-1) = mapminmax('reverse',DB(:,1:end-1)',ps_x)';
        accuracy = 1E-01;
        [count1, my1] = count_goptima( DB_original_sapce(:,1:end-1), problem, accuracy);
        accuracy = 1E-02;
        [count2, my1] = count_goptima(my1, problem, accuracy);
        accuracy = 1E-03;
        [count3, my1] = count_goptima(my1, problem, accuracy);
        accuracy = 1E-04;
        [count4, my1] = count_goptima(my1, problem, accuracy);
        accuracy = 1E-05;
        [count5, my1] = count_goptima(my1, problem, accuracy);
        count = [count1 count2 count3 count4 count5];
        finaloutputs = [finaloutputs; count];
    end
    toc;
    MeanFinaloutputs = mean(finaloutputs, 1);
    
    % 3.Output
    format short;
    format compact;
    fprintf('**************************************************************************************\n');
    fprintf('F%d: In the precision %f there are %d global optima! ', problem, 1E-01, MeanFinaloutputs(1));
    fprintf('The PR is %f, ', MeanFinaloutputs(1)/ModalArr(problem));
    fprintf('The SR is %f\n', length(find(finaloutputs(:, 1) == ModalArr(problem)))/runs);
    fprintf('F%d: In the precision %f there are %d global optima! ', problem, 1E-02, MeanFinaloutputs(2));
    fprintf('The PR is %f, ', MeanFinaloutputs(2)/ModalArr(problem));
    fprintf('The SR is %f\n', length(find(finaloutputs(:, 2) == ModalArr(problem)))/runs);
    fprintf('F%d: In the precision %f there are %d global optima! ', problem, 1E-03, MeanFinaloutputs(3));
    fprintf('The PR is %f, ', MeanFinaloutputs(3)/ModalArr(problem));
    fprintf('The SR is %f\n', length(find(finaloutputs(:, 3) == ModalArr(problem)))/runs);
    fprintf('F%d: In the precision %f there are %d global optima! ', problem, 1E-04, MeanFinaloutputs(4));
    fprintf('The PR is %f, ', MeanFinaloutputs(4)/ModalArr(problem));
    fprintf('The SR is %f\n', length(find(finaloutputs(:, 4) == ModalArr(problem)))/runs);
    fprintf('F%d: In the precision %f there are %d global optima! ', problem, 1E-05, MeanFinaloutputs(5));
    fprintf('The PR is %f, ', MeanFinaloutputs(5)/ModalArr(problem));
    fprintf('The SR is %f\n', length(find(finaloutputs(:, 5) == ModalArr(problem)))/runs);
    fprintf('**************************************************************************************\n');
    fprintf('\n');
    
    fprintf(output,'**************************************************************************************\n');
    fprintf(output,'F%d: In the precision %f there are %d global optima! ', problem, 1E-01, MeanFinaloutputs(1));
    fprintf(output,'The PR is %f, ', MeanFinaloutputs(1)/ModalArr(problem));
    fprintf(output,'The SR is %f\n', length(find(finaloutputs(:, 1) == ModalArr(problem)))/runs);
    fprintf(output,'F%d: In the precision %f there are %d global optima! ', problem, 1E-02, MeanFinaloutputs(2));
    fprintf(output,'The PR is %f, ', MeanFinaloutputs(2)/ModalArr(problem));
    fprintf(output,'The SR is %f\n', length(find(finaloutputs(:, 2) == ModalArr(problem)))/runs);
    fprintf(output,'F%d: In the precision %f there are %d global optima! ', problem, 1E-03, MeanFinaloutputs(3));
    fprintf(output,'The PR is %f, ', MeanFinaloutputs(3)/ModalArr(problem));
    fprintf(output,'The SR is %f\n', length(find(finaloutputs(:, 3) == ModalArr(problem)))/runs);
    fprintf(output,'F%d: In the precision %f there are %d global optima! ', problem, 1E-04, MeanFinaloutputs(4));
    fprintf(output,'The PR is %f, ', MeanFinaloutputs(4)/ModalArr(problem));
    fprintf(output,'The SR is %f\n', length(find(finaloutputs(:, 4) == ModalArr(problem)))/runs);
    fprintf(output,'F%d: In the precision %f there are %d global optima! ', problem, 1E-05, MeanFinaloutputs(5));
    fprintf(output,'The PR is %f, ', MeanFinaloutputs(5)/ModalArr(problem));
    fprintf(output,'The SR is %f\n', length(find(finaloutputs(:, 5) == ModalArr(problem)))/runs);
    fprintf(output,'**************************************************************************************\n');
    fprintf(output,'\n');
end
fclose(output);