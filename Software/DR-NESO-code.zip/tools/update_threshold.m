function [threshold]=update_threshold(DB, X, fX, archive, threshold, baseline1)
% [threshold]=update_threshold(DB, X, fX, archive, threshold, baseline1)
% update radius thresholds of taboo areas based on data
% Date: 2/12/2023
% Written by Huixiang Zhen, zhenhuixiang@cug.edu.cn

    baseline2 = mean(fX(:,end));
    baseline = baseline1*1/2 + baseline2*1/2;
    for i = 1:length(threshold)
        [temp k]=sort(sqrt(sum((ones(size(DB,1),1)*archive(i)-DB(:,1:end-1)).^2,2)));
        fd =  DB(k,end);
        sfd = smooth(fd,2);
        threshold(i) = temp(find(sfd < baseline,1));
    end
end