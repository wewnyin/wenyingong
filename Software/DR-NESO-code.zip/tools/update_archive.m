function [archive, archive_val, found_num, restart]=update_archive(pop,val,archive,archive_val,D,max_archive,threshold, found_num)
% [archive, archive_val, found_num, restart]=update_archive(pop,val,archive,archive_val,D,max_archive,threshold, found_num)
% Update temporary optimal archive and its found number
% Date: 2/12/2023
% Written by Huixiang Zhen, zhenhuixiang@cug.edu.cn

size_archive=size(archive,1);
restart = 0;
if size_archive==0
    archive=[archive;pop];
    archive_val=[archive_val; val];
    found_num = [found_num; 1];
else
    [temp k]=sort(sqrt(sum((ones(size(archive,1),1)*pop-archive).^2,2)));  % Construct a copy pop with the same number as all archives, calculate the distance from the archive, and find the nearest archive
    subpop=archive(k(1),:); 
    subpop_val=archive_val(k(1));
    distance=sqrt(sum((subpop-pop).^2,2)); 
    threshold = 0.001*sqrt(D);
    if abs(distance)<threshold  % If the distance is less than the threshold and the value is greater than the value in the subpopulation, replace the archive
        found_num(k(1)) = found_num(k(1)) + 1;
        if val>subpop_val
            archive(k(1),:)=pop;
            archive_val(k(1))=val;
        end
        restart = 1; % the distance is less than the threshold, restart the individual
    elseif   size_archive<max_archive  % If the distance is greater than the threshold and the archive is not full, add it to the archive
        archive=[archive;pop];
        archive_val=[archive_val; val];
        found_num = [found_num; 1];
    else                                      % If the distance is greater than the threshold and the archive is full, then find the nearest point in the archive again and replace
        [temp k]=sort(sqrt(sum((ones(size(archive,1),1)*pop-archive).^2,2)));
        subpop_val=archive_val(k(1));
        if val>subpop_val
            archive(k(1),:)=pop;
            archive_val(k(1))=val;
            found_num(k(1)) = 1;
        end
    end
end