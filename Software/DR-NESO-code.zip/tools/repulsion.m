function [restart] = repulsion(pop,global_optimal,threshold)
% judge whether the individual is in the taboo areas
% Date: 2/12/2023
% Written by Huixiang Zhen, zhenhuixiang@cug.edu.cn

size_global_optimal=size(global_optimal,1);
restart = 0;
if size_global_optimal > 0
    [temp k]=sort(sqrt(sum((ones(size(global_optimal,1),1)*pop-global_optimal).^2,2))); 
    subpop=global_optimal(k(1),:); 
    distance=sqrt(sum((subpop-pop).^2,2)); 
    if abs(distance) < threshold(k(1))
        restart = 1;
    end
end