function TSNSGAII(Global)
% <algorithm> <T>

    %% Generate the weight vectors
    [W,Global.N] = UniformPoint(Global.N,Global.M);

    %% Generate random population
    Population = Global.Initialization();
    [~,FrontNo,d2]   = EnvironmentalSelection(Population,W,Global.N);
    
    %% Optimization
    while Global.NotTermination(Population) 
        MatingPool = TournamentSelection(2,Global.N,FrontNo,d2);
        Offspring  = GA(Population(MatingPool));
        if Global.evaluated<(0.8+0.2*(1-3/Global.M))*Global.evaluation  
            [Population,FrontNo,d2] = EnvironmentalSelection([Population,Offspring],W,Global.N);
        else
            Population = EnvironmentalSelection1([Population,Offspring],W,Global.N,Global.M);
            [FrontNo,~]=NDSort(Population.objs,inf);
            d2=DensityEstimate(Population,W);
        end
    end
end