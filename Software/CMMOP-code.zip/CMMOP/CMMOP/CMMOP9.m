classdef CMMOP9< PROBLEM
% <multi> <real> <multimodal><constrained>
% Constrained multi-modal multi-objective test function

    methods
        %% Default settings of the problem
        function Setting(obj)
            obj.M = 2;
            obj.D = 2;
            obj.lower    = [1,-1];
            obj.upper    = [3,1];
            obj.encoding = 'real';
        end
        %% Calculate objective values
        function PopObj = CalObj(obj,X)
%             g = 1 + sum(1 - exp(-10*((X(:,obj.M:end).^(obj.D-obj.M)) - 0.5 - (repmat(obj.M:obj.D,size(X,1),1) - 1)/(2*obj.D)).^2),2);
            PopObj(:,1) = abs(X(:,1)-2);
            PopObj(:,2) = 1 - PopObj(:,1) + 2*(X(:,2) - sin(6*pi*PopObj(:,1)+pi)).^2;
        end
        
        %% Calculate constraint violations
        function PopCon = CalCon(obj,X)
            PopObj = obj.CalObj(X);
            PopCon(:,1) = 1 - sum(PopObj,2);
            PopCon(:,2) = sum(PopObj,2) - 1.1;
            PopCon(:,3) = 1.5 - sum(PopObj,2);
            PopCon(:,4) = sum(PopObj,2) - 2;
            PopCon(PopCon(:,3)<=0 & PopCon(:,4)<=0,1) = 0;
            PopCon(PopCon(:,3)<=0 & PopCon(:,4)<=0,2) = 0;
            PopCon(PopCon(:,1)<=0 & PopCon(:,2)<=0,3) = 0;
            PopCon(PopCon(:,1)<=0 & PopCon(:,2)<=0,4) = 0;
%             if PopCon(:,1) <= 0 && PopCon(:,2) <= 0
%                 PopCon(:,3) = 0;
%                 PopCon(:,4) = 0;
%             end
%             if PopCon(:,3) <= 0 && PopCon(:,4) <= 0
%                 PopCon(:,1) = 0;
%                 PopCon(:,2) = 0;
%             end
       end
        
        %% Generate Pareto optimal solutions
        function R = GetOptimum(obj,N)
            R(:,1) = linspace(1,3,N)';
            R(:,2) = sin(6*pi*abs(R(:,1)-2)+pi);
            PopObj = obj.CalObj(R);
            fes1 = PopObj(:,1) + PopObj(:,2) - 1 < 0;
            fes2 = PopObj(:,1) + PopObj(:,2) - 1.1 > 0;
            R(fes1|fes2,:) = [];
%             fes3 = PopObj(:,1) + PopObj(:,2) - 1.5 > 0;
%             fes4 = PopObj(:,1) + PopObj(:,2) - 2 < 0;
%             R(fes1|fes2|fes3|fes4,:) = [];
        end
        
         %% Generate the image of Pareto front
        function R = GetPF(obj)
            [x,y] = meshgrid(linspace(0,2,400),linspace(0,2,400));
            z     = nan(size(x));
            fes1  = x + y - 1 >= 0;
            fes2  = x + y - 1.1 <= 0;
            fes3  = x + y - 1.5 >= 0;
            fes4  = x + y - 2 <= 0;
            z(fes1 & fes2 & x+y>=1) = 0;
            z(fes3 & fes4 & x+y>=1) = 0;
            R = {x,y,z};
        end
        
        %% Display a population in the objective space
%         function DrawObj(obj,Population)
%             PopDec = Population.decs;
%             temp   = PopDec(:,2)<=1;
%             Draw(Population(temp).objs,'o','MarkerSize',6,'Marker','o','Markerfacecolor',[1 .5 .5],'Markeredgecolor',[1 .2 .2],{'\it f\rm_1','\it f\rm_2',[]});
%             Draw(Population(~temp).objs+0.1,'o','MarkerSize',6,'Marker','o','Markerfacecolor',[.5 .5 1],'Markeredgecolor',[.2 .2 1]);
%             x = linspace(0,1,100)';
%             y = 1 - x;
%             fes   = x + y - 1 - 0.5*sin(2*pi*(sqrt(2)*y-sqrt(2)*x)).^8 <= 0;
%             x(~fes) = nan;
%             y(~fes) = nan;
%             L = [x,y];
% %             L  = [0:0.01:1;1-(0:0.01:1)]';
% %             scatter(L(:,1),L(:,2),10,'r','filled');
% %             scatter(L(:,1)+0.1,L(:,2)+0.1,10,'b','filled');
%             Draw(L,'-','LineWidth',1,'Color',[1 .2 .2]);
%             Draw(L+0.1,'-','LineWidth',1,'Color',[.2 .2 1]);
%         end
    end
end