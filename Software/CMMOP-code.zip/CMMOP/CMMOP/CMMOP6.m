classdef CMMOP6 < PROBLEM
% <multi> <real> <multimodal><constrained>
% Constrained multi-modal multi-objective test function

    methods
        %% Default settings of the problem
        function Setting(obj)
            obj.M = 2;
            obj.D = 2;
            obj.lower    = [0,0];
            obj.upper    = [1,1.5];
            obj.encoding = 'real';
        end
        %% Calculate objective values
        function PopObj = CalObj(obj,X)
            temp = X(:,2)<=0.5 | X(:,2)<1 & X(:,1)>0.25;
            y    = zeros(size(X,1),1);
            y(temp)  = X(temp,2) - sqrt(X(temp,1));
            y(~temp) = X(~temp,2) - 0.5 - sqrt(X(~temp,1));
            PopObj(:,1) = X(:,1);
            PopObj(:,2) = 1.21 - (X(:,1)).^2 + 2*(4*y.^2-2*cos(20*y*pi/sqrt(2))+2);
        end
        
        %% Calculate constraint violations
        function PopCon = CalCon(obj,X)
            PopObj = obj.CalObj(X);
            l      = cos(6*atan(PopObj(:,2)./PopObj(:,1)).^5).^10;
            PopCon = (PopObj(:,1)./(1+0.15*l)).^2 + (PopObj(:,2)./(1+0.75*l)).^2 - 1;
        end
        
        %% Generate Pareto optimal solutions
        function R = GetOptimum(obj,N)
            R(:,1) = linspace(0,1,N/2)';
            R(:,2) = sqrt(R(:,1));
            R = [R;R(:,1),R(:,2)+0.5];
            PopObj = obj.CalObj(R);
            l = cos(6*atan(PopObj(:,2)./PopObj(:,1)).^5).^10;
            c = 1 - (PopObj(:,1)./(1+0.15*l)).^2 - (PopObj(:,2)./(1+0.75*l));
            R(c<0,:) = [];
        end
        
         %% Generate the image of Pareto front
        function R = GetPF(obj)
            [x,y] = meshgrid(linspace(0,1.7,400));
            z     = nan(size(x));
            l     = cos(6*atan(y./x).^5).^10;
            fes   = (x./(1+0.15*l)).^2 + (y./(1+0.75*l)) - 1 <= 0;
            z(fes & x.^2 + y >= 1.21) = 0;
            R = {x,y,z};
        end
        
        %% Display a population in the objective space
%         function DrawObj(obj,Population)
%             PopDec = Population.decs;
%             temp   = PopDec(:,2)<=1;
%             Draw(Population(temp).objs,'o','MarkerSize',6,'Marker','o','Markerfacecolor',[1 .5 .5],'Markeredgecolor',[1 .2 .2],{'\it f\rm_1','\it f\rm_2',[]});
%             Draw(Population(~temp).objs+0.1,'o','MarkerSize',6,'Marker','o','Markerfacecolor',[.5 .5 1],'Markeredgecolor',[.2 .2 1]);
%             x = linspace(0,1,100)';
%             y = 1.21 - x.^2;
%             l     = cos(6*atan(y./x).^4).^10;
%             fes   = (x./(1+0.15*l)).^2 + (y./(1+0.75*l)).^2 - 1 <= 0;
%             x(~fes) = nan;
%             y(~fes) = nan;
%             L = [x,y];
% %             L  = [0:0.01:1;sqrt(1-(0:0.01:1).^2)]';
%             Draw(L,'-','LineWidth',1,'Color',[1 .2 .2]);
%             Draw(L+0.1,'-','LineWidth',1,'Color',[.2 .2 1]);
%         end
    end
end