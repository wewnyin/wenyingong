classdef CMMOP8 < PROBLEM
% <multi> <real> <multimodal><constrained>
% Constrained multi-modal multi-objective test function

    methods
        %% Default settings of the problem
        function Setting(obj)
            obj.M = 2;
            obj.D = 2;
            obj.lower    = [1,-1];
            obj.upper    = [3,1];
            obj.encoding = 'real';
        end
        %% Calculate objective values
        function PopObj = CalObj(obj,X)
            PopObj(:,1) = abs(X(:,1)-2);
            PopObj(:,2) = sqrt(1 - PopObj(:,1).^2) + (X(:,2)-(0.3.*(PopObj(:,1).^2).*cos(24.*pi.*PopObj(:,1)+4.*pi)+0.6.*PopObj(:,1)).*sin(6.*pi.*PopObj(:,1)+pi)).^2;
        end
        
        %% Calculate constraint violations
        function PopCon = CalCon(obj,X)
            PopObj = obj.CalObj(X);
            l1     = atan(PopObj(:,2)./PopObj(:,1));
            l2     = 0.5*pi - 2*abs(l1-0.25*pi);
            PopCon(:,1) = PopObj(:,1).^2 + PopObj(:,2).^2 - (1.7-0.2*sin(2*l1)).^2;
%             PopCon(:,2) = (1+0.5*sin(6*l2.^3)).^2 - PopObj(:,1).^2 - PopObj(:,2).^2;
            PopCon(:,3) = (1-0.7*sin(6*l2.^3)).^2 - PopObj(:,1).^2 - PopObj(:,2).^2;
        end
        
        %% Generate Pareto optimal solutions
        function R = GetOptimum(obj,N)
            R(:,1) = linspace(1,3,N)';
            R(:,2) = (0.3*(R(:,1)-2).^2.*cos(24*pi*abs(R(:,1)-2)+4*pi)+0.6*abs(R(:,1)-2)).*sin(6*pi*abs(R(:,1)-2)+pi);
            PopObj = obj.CalObj(R);
            l1     = atan(PopObj(:,2)./PopObj(:,1));
            l2     = 0.5*pi - 2*abs(l1-0.25*pi);
            fes1 = PopObj(:,1).^2 + PopObj(:,2).^2 - (1.7-0.2*sin(2*l1)).^2 > 0;
%             fes2 = PopObj(:,1).^2 + PopObj(:,2).^2 - (1+0.5*sin(6*l2.^3)).^2 < 0;
            fes3 = PopObj(:,1).^2 + PopObj(:,2).^2 - (1-0.7*sin(6*l2.^3)).^2 < 0;
%             R(fes1|fes2|fes3,:) = [];
            R(fes1|fes3,:) = [];
        end
        
         %% Generate the image of Pareto front
        function R = GetPF(obj)
            [x,y] = meshgrid(linspace(0,1.7,400));
            z     = nan(size(x));
            l1    = atan(y./x);
            l2    = 0.5*pi - 2*abs(l1-0.25*pi);
            fes1  = x.^2 + y.^2 - (1.7-0.2*sin(2*l1)).^2 <= 0;
%             fes2  = (1+0.5*sin(6*l2.^3)).^2 - x.^2 - y.^2 <= 0;
            fes3  = (1-0.7*sin(6*l2.^3)).^2 - x.^2 - y.^2 <= 0;
%             z(fes1 & fes2 & fes3 & x.^2+y.^2>=1) = 0;
            z(fes1 & fes3 & x.^2+y.^2>=1) = 0;
            R = {x,y,z};
        end
        
        %% Display a population in the objective space
%         function DrawObj(obj,Population)
%             PopDec = Population.decs;
%             temp   = PopDec(:,2)<=1;
%             Draw(Population(temp).objs,'o','MarkerSize',6,'Marker','o','Markerfacecolor',[1 .5 .5],'Markeredgecolor',[1 .2 .2],{'\it f\rm_1','\it f\rm_2',[]});
%             Draw(Population(~temp).objs+0.1,'o','MarkerSize',6,'Marker','o','Markerfacecolor',[.5 .5 1],'Markeredgecolor',[.2 .2 1]);
% %             x = linspace(0,1,100)';
% %             y = sqrt(1 - x.^2);
% %             l1    = atan(y./x);
% %             l2    = 0.5*pi - 2*abs(l1-0.25*pi);
% %             fes1  = x.^2 + y.^2 - (1.7-0.2*sin(2*l1)).^2 <= 0;
% %             fes2  = (1+0.5*sin(6*l2.^3)).^2 - x.^2 - y.^2 <= 0;
% %             fes3  = (1-0.45*sin(6*l2.^3)).^2 - x.^2 - y.^2 <= 0;
% %             x(~(fes1 & fes2 & fes3)) = nan;
% %             y(~(fes1 & fes2 & fes3)) = nan;
%             R = [0 1;0.3922 0.9199;0.4862 0.8739;0.5490 0.8358;0.5970 0.8023;0.6359 0.7719;0.6686 0.7436;0.6969 0.7174];
%             R = [R;flip(R,2)];
% %             r1 = r(:,1);
% %             r2 = r(:,2);
% %             x = linspace(0,1,10000)';
% %             is = ismember(x(:,1),r1);
% %             x(~is) = nan;
% %             y(~is) = nan;
% %             
% %             x(is) = r(r(:,1)==x(is));
% %             y(is) = r(r(:,2)==y(is));
% %             L = [x,y];
%             L = R;
% %             L  = [0:0.01:1;sqrt(1-(0:0.01:1).^2)]';
%             Draw(L,'o','LineWidth',1,'Color',[1 .2 .2],'MarkerEdgeColor',[1 .2 .2],'MarkerSize',8);
%             Draw(L+0.1,'o','LineWidth',1,'Color',[.2 .2 1],'MarkerEdgeColor',[.2 .2 1],'MarkerSize',8);
%         end
    end
end