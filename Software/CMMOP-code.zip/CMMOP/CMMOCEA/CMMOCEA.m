classdef CMMOCEA < ALGORITHM
% <multi> <real/binary/permutation> <multimodal><constrained>
% Constrained multi-modal multi-objective optimization coevolutionary algorithm

    methods
        function main(Algorithm,Problem)

            %% Generate random population
            Population1 = Problem.Initialization();
            Population2 = Problem.Initialization();
            
            %% Calculate fitness of populations
            [D_Dec,D_Pop,~]    = CalFitness(Population1.objs,Population1.cons,Population1.decs);
            [D,P,~]    = CalFitness2(Population2.objs,Population2.decs);

            %% Optimization
            while Algorithm.NotTerminated(Population1)
                MatingPool1 = TournamentSelection(2,Problem.N,D_Dec);
                MatingPool2 = TournamentSelection(2,Problem.N,D);
                Offspring1  = OperatorGAhalf(Population1(MatingPool1));
                Offspring2  = OperatorGAhalf(Population2(MatingPool2));
                [Population1,D_Dec,D_Pop] = EnvironmentalSelection([Population1,Offspring1,Offspring2],Problem.N);
                [Population2,D,P] = EnvironmentalSelection2([Population2,Offspring1,Offspring2],Problem.N);
                
            end
        end
    end
end