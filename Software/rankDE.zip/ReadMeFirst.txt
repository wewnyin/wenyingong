
/* Program:   Differential Evolution with Ranking-based Mutation Operators
   Author:    Wenyin Gong
   E-mail:    cug11100304@yahoo.com.cn
   Date:      19/6/2012
   License:   free
   Platform:  Microsoft Visual C++ 6.0
   Reference: W. Gong and Z. Cai, "Differential Evolution with Ranking-based Mutation Operators,"
              IEEE Transactions on Systems, Man, and Cybernetics: Part B -- Cybernetics. Jan. 2013. Accepted.
*/



