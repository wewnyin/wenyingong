function Q_Agent = apdate_Q(Q_Agent,State_pop,Action_pop,objFtrial, conVtrial,popsize,Rtable)

alpha=0.25; %Q-learing learning rate
gamma = 0.9; %discount rate
prc1=[33,67];
prc2=[33,67];
TH1=prctile(objFtrial,prc1);
TH2=prctile(conVtrial,prc2);

fval= [objFtrial,conVtrial ];
for kp=1:popsize
    trial_State(kp)=GetAgentState(fval(kp,:),TH1,TH2);
    Qtemp=Q_Agent;
    AgState=State_pop(kp);
    Action=Action_pop(kp);
    NextState=trial_State(kp);
    temp=max(Qtemp(NextState,:));
    R=Rtable(AgState,NextState);
    Qtemp(AgState,Action)=(1-alpha)*Qtemp(AgState,Action)+alpha*(R+gamma*temp);
    Q_Agent=Qtemp;
    
end