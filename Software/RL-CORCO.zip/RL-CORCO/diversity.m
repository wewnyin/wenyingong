function  [p,objF,conV,FES]=diversity(p,objF,conV,minVar,maxVar,problem,FES)

global gen maxGen

[popsize,n]=size(p);

if std(conV)<1.e-6  && isempty(find(conV==0)) 

    p(1:popsize,:)=repmat(minVar,popsize,1)+rand(popsize,n).*repmat((maxVar-minVar),popsize,1);
      % update evolution population
  [objF, conV] = fitness_2017(p, problem);
 %   [objF, conV]=fitness_2010(p, problem);
    FES=FES+popsize;

end

