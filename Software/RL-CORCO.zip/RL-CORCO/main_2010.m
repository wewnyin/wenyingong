clc;
clear all;
format long;
tic;

global gen maxGen CorIndex learningGenNum DivIndex ExFlag diversityDerta feasibleRatioInitial problemSetNum initial_flag 
problemSetNum=2010


if problemSetNum == 2010
    % problem set of 18 benchmark functions to be tested
    problemSet=[1:18];
    
    % the number of dimensions which can be set as 10 or 30
    n=30
    
    % the size of evolving population
    if n==10
        popsize=60;
    elseif n==30
        popsize=100;
    end
    totalFES = 20000*n;
end
maxGen=ceil(totalFES/popsize);
meanValue = [];
mediaValue = [];
statistic = [];
% choose the function to be tested
for problem = problemSet
    fprintf('problem:%d\n',problem);
    % the value used to record the number of runs
    time=1;
    
    % the value which represents the number of total runs
    totalTime=25;
    
    % the array used to record the best solution of each run
    minValue=[];
    minObj_Conv = [];
    while time <= totalTime
        [minVar,maxVar] = problemSelection2010(problem,n);aaa=0;
        rand('seed',sum(100*clock));
        
        % initialization
        p=repmat(minVar,popsize,1)+rand(popsize,n).*repmat((maxVar-minVar),popsize,1);
        
        
        initial_flag = 0;
        [objF, conV]=fitness_2010(p, problem);
        FES=popsize;
        nondominateIndex=1:popsize;
        archive=p(nondominateIndex,:); archiveobjF=objF(nondominateIndex); archiveconV=conV(nondominateIndex);
        
        %
        gen=0; X=0; ExFlag=0; CorIndex=0; diversityDerta = 0;
        betterRecord=[];learningGenNum=maxGen/20;
        betterRecord1 = [];betterRecord2 = [];
        diversityInitial=sum(std(p)./(maxVar-minVar))/n;
        feasibleNum = size(find(conV==0),1);
        feasibleRatioInitial=feasibleNum/popsize;
        
        conV_record = [];
        Q_Agent = zeros(9,2);% state 9  ，action 2
        Rtable=zeros(9,9);
        Rtable(1,1)=1;
        Rtable(2,[1,2])=[1,1];
        Rtable(3,[2,3])=[1,1];
        Rtable(4,[1,4])=[1,1];
        Rtable(5,[1,2,4,5])=[1,1,1,1];
        Rtable(6,[2,3,5])=[1,1,1];
        Rtable(7,[4,7])=[1,0];
        Rtable(8,[4,5,7])=[1,1,1];
        Rtable(9,[5,6,8])=[1,1,1];
        while gen<=learningGenNum
            
            % weight generation and assignment
            weights = WeightGenerator(X,popsize,conV,objF);
            
            % Evolutionary operation
            [p,objF,conV,archive,archiveobjF,archiveconV,FES,Q_Agent]=EvolutionaryOperation(p,objF,conV,archive,archiveobjF,archiveconV,weights,FES,minVar,maxVar,problem,popsize,aaa,Q_Agent,Rtable);
            
            % record the better number
            [con_obj_betterNum,obj_con_betterNum]=InterCompare(archiveobjF,archiveconV,objF,conV);
            
            % Calculate the DivIndex
            DivIndex=sum(std(p)./(maxVar-minVar))/n;
            
            % Record
            betterRecord1 = [betterRecord1;con_obj_betterNum];
            betterRecord2 = [betterRecord2;obj_con_betterNum];
            
            gen=gen+1;
        end
        
        
        indicator1 = find(betterRecord1 ~= 0);
        indicator2 = find(betterRecord2 ~= 0);
        
        betterLength1 = length(indicator1);
        betterLength2 = length(indicator2);
        betterLength = min(betterLength1,betterLength2);
        CorIndex=betterLength/learningGenNum ;
        %CorIndex = 0.25;
        diversityDerta=diversityInitial - DivIndex;
        Diver = DivIndex;
        abc = 1;
        
        while FES<totalFES
            [p,objF,conV,FES]=diversity(p,objF,conV,minVar,maxVar,problem,FES);   %restart
            weights = WeightGenerator(X,popsize,conV,objF);
            
            [p,objF,conV,archive,archiveobjF,archiveconV,FES]=EvolutionaryOperation(p,objF,conV,archive,archiveobjF,archiveconV,weights,FES,minVar,maxVar,problem,popsize,aaa,Q_Agent,Rtable);
            X=X+1/maxGen; gen=gen+1;
            % end
            conV_record = [conV_record,min(archiveconV)];
            
        end
        % calculate the index of feasible solutions
        feasiIndex=find(archiveconV==0);
        
        if ~isempty(feasiIndex)
            [sortedFeasiVec,~]=sort(archiveobjF(feasiIndex));
            
            if ExFlag==1
                Ex_bestSolution=sortedFeasiVec(1)
                % record the best solution of each run
                minValue=[minValue Ex_bestSolution];
            else
                NonEx_bestSolution=sortedFeasiVec(1)
                % record the best solution of each run
                minValue=[minValue NonEx_bestSolution];
            end
            
        else
            % if the population is infeasible, the best solution is
            % assigned the value of NaN
            [bestconV, bestconVIndex] = min(archiveconV);
            bestIndividual = archive(bestconVIndex);
            fprintf('*bestSolution=%d',min(archiveconV));
        end
        
        % modify the value of "time"
        time=time+1;
    end
    
    % calculate the best value, mean value, worst value and standard error
    % of the array of minValue
    statisticValue=[ mean(minValue) std(minValue)];
    statistic = [statistic;statisticValue];
    %
end
