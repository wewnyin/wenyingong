function State=GetState_RF(fitness_pop,prc1,prc2)
    [m,n]=size(fitness_pop);
    temp=fitness_pop(:,1);
    f1index1=temp<=prctile(temp,prc1(1));
    f1index2=temp<=prctile(temp,prc1(2));
    f1index=3-f1index1-f1index2;
    
    temp=fitness_pop(:,2);
    f2index1=temp<=prctile(temp,prc2(1));
    f2index2=temp<=prctile(temp,prc2(2));
    f2index=3-f2index1-f2index2;
    
   As=[f1index,f2index];
   
       State=zeros(m,1);
    for kp=1:m
           State(kp)=3*(As(kp,1)-1)+As(kp,2);
    end   

end

