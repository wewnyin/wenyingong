function [Action_pop]=Qlearning(p,objF,conV,State_pop,Q_Agent,popsize,Action_pop)
    
   for k =1:popsize
           Agent_current=p(k,:);
           Qtemp=Q_Agent;
           AgState=State_pop(k);
           Qvalue1=Qtemp(AgState,:);
           temp=exp(Qvalue1);
           ratio=cumsum(temp)/sum(temp);
           jtemp=find(rand(1)<ratio);
           Tpolicy=jtemp(1);
           Action_pop(k)=Tpolicy;

   end

   
   
end