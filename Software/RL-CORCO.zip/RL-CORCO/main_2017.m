clc;
clear all;
format long;
tic;

global gen maxGen CorIndex learningGenNum DivIndex ExFlag diversityDerta feasibleRatioInitial problemSetNum initial_flag
problemSetNum=2017
% problem set of 28 benchmark functions to be tested
problemSet=[1:28];

% the number of dimensions
n=50;
popsize=100;
totalFES = 20000*n;
maxGen=ceil(totalFES/popsize);
statistic = [];
% choose the function to be tested
for problem = problemSet
    fprintf('problem:%d\n',problem);
    % the value used to record the number of runs
    time=1;
    
    % the value which represents the number of total runs
    totalTime=25;
    
    % the array used to record the best solution of each run
    minValue=[];
    minObj_Conv = [];
    while time <= totalTime
        [minVar,maxVar] = problemSelection2017(problem,n);aaa=0;
        rand('seed',sum(100*clock));
        
        % initialization
        p=repmat(minVar,popsize,1)+rand(popsize,n).*repmat((maxVar-minVar),popsize,1);
        
        initial_flag = 0;
        %[objF, conV]=fitness_2010(p, problem);
        [objF, conV]=fitness_2017(p, problem);
        
        FES=popsize;
        
        nondominateIndex=1:popsize;
        archive=p(nondominateIndex,:); archiveobjF=objF(nondominateIndex); archiveconV=conV(nondominateIndex);
        
        gen=0; X=0; ExFlag=0; CorIndex=0; diversityDerta = 0;
        betterRecord=[];learningGenNum=maxGen/20;
        betterRecord1 = [];betterRecord2 = [];
        diversityInitial=sum(std(p)./(maxVar-minVar))/n;
        feasibleNum = size(find(conV==0),1);
        feasibleRatioInitial=feasibleNum/popsize;
        
        conV_record = [];
        Q_Agent = zeros(9,2);% state 6  ，action 2
        Rtable=zeros(9,9);   % Reward setting
        Rtable(1,1)=1;
        Rtable(2,[1,2])=[1,1];
        Rtable(3,[2,3])=[1,1];
        Rtable(4,[1,4])=[1,1];
        Rtable(5,[1,2,4,5])=[1,1,1,1];
        Rtable(6,[2,3,5])=[1,1,1];
        Rtable(7,[4,7])=[1,0];
        Rtable(8,[4,5,7])=[1,1,1];
        Rtable(9,[5,6,8])=[1,1,1];
        
        % learning stage
        while gen<=learningGenNum
            
            % weight generation and assignment
            weights = WeightGenerator(X,popsize,conV,objF);
            
            % Evolutionary operation
            [p,objF,conV,archive,archiveobjF,archiveconV,FES,Q_Agent]=EvolutionaryOperation(p,objF,conV,archive,archiveobjF,archiveconV,weights,FES,minVar,maxVar,problem,popsize,aaa,Q_Agent,Rtable);
            
            % record the better number
            [con_obj_betterNum,obj_con_betterNum]=InterCompare(archiveobjF,archiveconV,objF,conV);
            
            % Calculate the DivIndex
            DivIndex=sum(std(p)./(maxVar-minVar))/n;
            
            % Record
            betterRecord1 = [betterRecord1;con_obj_betterNum];
            betterRecord2 = [betterRecord2;obj_con_betterNum];
            
            gen=gen+1;
        end
        
        
        indicator1 = find(betterRecord1 ~= 0);
        indicator2 = find(betterRecord2 ~= 0);
        
        betterLength1 = length(indicator1);
        betterLength2 = length(indicator2);
        betterLength = min(betterLength1,betterLength2);
        CorIndex=betterLength/learningGenNum ;
        diversityDerta=diversityInitial - DivIndex;
        Diver = DivIndex;
        abc = 1;
        
        while FES<totalFES
            [p,objF,conV,FES]=diversity(p,objF,conV,minVar,maxVar,problem,FES);
            weights = WeightGenerator(X,popsize,conV,objF);
            
            % Evolutionary operation
            [p,objF,conV,archive,archiveobjF,archiveconV,FES,Q_Agent]=EvolutionaryOperation(p,objF,conV,archive,archiveobjF,archiveconV,weights,FES,minVar,maxVar,problem,popsize,aaa,Q_Agent,Rtable);
            X=X+1/maxGen; gen=gen+1;
            
            conV_record = [conV_record,min(archiveconV)];
        end
        % calculate the index of feasible solutions
        feasiIndex=find(archiveconV==0);
        
        if ~isempty(feasiIndex)
            
            % sort the feasible solutions according to their objective
            % function values
            archiveFeasibelIndiv = archive(feasiIndex,:);
            archiveFeasibelObjF = archiveobjF(feasiIndex,:);
            [bestObj, bestObjIndex] = min(archiveFeasibelObjF);
            bestIndividual = archive(bestObjIndex,:);
            
            % record the best solution of each run
            minValue=[minValue bestObj];
            
        else
            % if the population is infeasible, the best solution is
            % assigned the value of NaN
            [bestconV, bestconVIndex] = min(archiveconV);
            bestIndividual = archive(bestconVIndex);
            fprintf('*bestSolution=%d',min(archiveconV));
        end
        
        time=time+1;
        
        [bestConV,~]=min(archiveconV);
        [bestObj,~]=min(archiveobjF);
        
        % [~,~,best_conV_range_num] = fitness_2017(bestIndividual, problem);
        minObj_Conv=[minObj_Conv; bestObj bestConV best_conV_range_num];
        
    end
    
    % calculate the index of feasible solutions
    feasiIndex=find(minObj_Conv(:,2)==0);
    Mean=mean(minObj_Conv(:,1));
    Std = std(minObj_Conv(:,1));
    oneStatistic = [Mean,Std];
    statistic = [statistic ;oneStatistic];
    
end
