function [p,objF,conV,archive,archiveobjF,archiveconV,FES,Q_Agent]=EvolutionaryOperation(p,objF,conV,archive,archiveobjF,archiveconV,weights,FES,minVar,maxVar,problem,popsize,aaa,Q_Agent,Rtable)
global problemSetNum initial_flag
   
    [p,objF,conV]=Exchange(p,objF,conV,archive,archiveobjF,archiveconV);

% ====================RL parameter setting=========================
  prc1=[33,67];
  prc2=[33,67];
 fitness =[objF,conV];
State_pop=GetState_RF(fitness,prc1,prc2); %Get population state
  % trial_State=zeros(size(State_pop));
   Action_pop=zeros(size(State_pop));
[Action_pop] = Qlearning(p,objF,conV,State_pop,Q_Agent,popsize,Action_pop); %Acquisition of variation strategy
strategy=Action_pop;
    switch problemSetNum
    	case 2010
            % DE operation
            trial=DEgenerator(p,objF,conV,archive,weights,minVar,maxVar,strategy);
        	[objFtrial, conVtrial]=fitness_2010(trial, problem); 
    	case 2017
        	initial_flag = 0;
            trial=DEgenerator(p,objF,conV,archive,weights,minVar,maxVar,strategy);
         	[objFtrial, conVtrial] = fitness_2017(trial, problem);
    end
   %Update Q table according to offspring
   Q_Agent = apdate_Q(Q_Agent,State_pop,Action_pop,objFtrial, conVtrial,popsize,Rtable);
    
    FES=FES+popsize;
            
    % record the frontier population information for comparison
    objF1=objF;
    conV1=conV;
            
    % update evolution population
    [p,objF,conV]=environmentSelect(p,objF1,conV1,trial,objFtrial,conVtrial,weights);
            
    % update archive population
    [archive,archiveobjF,archiveconV]=Debselect(archive,archiveobjF,archiveconV,trial,objFtrial,conVtrial);

