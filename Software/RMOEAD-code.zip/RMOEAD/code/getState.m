function state=getState(delt_Cv,delt_Dv)
    %get state
     if delt_Cv>0&&delt_Dv>0
         state=1;
     elseif delt_Cv>0&&delt_Dv<=0
         state=2;
     elseif delt_Cv<=0&&delt_Dv>0
         state=3;
     elseif delt_Cv<=0&&delt_Dv<=0
         state=4;   
     end
end