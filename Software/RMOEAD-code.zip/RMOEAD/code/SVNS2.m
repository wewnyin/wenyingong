function [pfit,normfit,ns,nf,p_chrom,m_chrom,fitness]=SVNS2(pfit,normfit,ns,nf,p_chrom,m_chrom,fitness)%VNS based on SaDE
global ps;
numst=5;
learngen = 50;
    % Stochastic universal sampling
      rr = rand;
      spacing = 1/ps;
      randnums = sort(mod(rr : spacing : 1 + rr - 0.5 * spacing, 1));

      sumfit=0;
      for j=1:numst%���Ӹ��ʹ�һ��
          sumfit=pfit(j)+sumfit;
      end
      for j=1:numst
          normfit(j)=pfit(j)/sumfit;
      end
      partsum = 0;
      count(1) = 0;
      stpool = [];
      
      for j = 1 : length(pfit)
         partsum = partsum + normfit(j);
         count(j + 1) = length(find(randnums < partsum));
         select(j, 1) = count(j + 1) - count(j);
         stpool = [stpool; ones(select(j, 1), 1) * j];
      end
      stpool = stpool(randperm(ps));
      scount=zeros(1,numst);%��¼��һ�����ӵ�ѡ���и������ӳɹ��Ĵ���
      lcount=zeros(1,numst);%��¼��һ�����ӵ�ѡ���и�������ʧ�ܵĴ���
      chooseA=stpool(j);
      for j=1:ps %SVNS
        fi{1,1}=fitness{j,1};
        fi{1,2}=fitness{j,2};
        flag=0;
        switch chooseA
        case{1}
          [m_chrom(j,:),fi,flag]=LS1(p_chrom(j,:),m_chrom(j,:),fi); 
        case{2}
          [m_chrom(j,:),fi,flag]=LS2(p_chrom(j,:),m_chrom(j,:),fi);
        case{3}
          [m_chrom(j,:),fi,flag]=LS3(p_chrom(j,:),m_chrom(j,:),fi); 
        case{4}
          [p_chrom(j,:),fi,flag]=LS4(p_chrom(j,:),m_chrom(j,:),fi); 
        case{5}
          [p_chrom(j,:),fi,flag]=LS5(p_chrom(j,:),m_chrom(j,:),fi); 
        end
        if flag==1
            scount(stpool(j))=scount(stpool(j))+1;%��Ӧ���ӳɹ�����+1
        elseif(flag==0)%���������ڿ�ʼͳ��  
            lcount(stpool(j))=lcount(stpool(j))+1;%��Ӧ����ʧ�ܴ���+1
        end
        fitness{j,1}=fi{1,1};
        fitness{j,2}=fi{1,2};
      end
      ns=[ns;scount];
      nf=[nf;lcount];
      [i,~]=size(ns);
      %����50�����¼���ÿ�����ӵ�ѡȡ����
     if i >= learngen
          [ns_row,~]=size(ns);
          [nf_row,~]=size(ns);
          for j = 1 : numst
              sum_ns=0;sum_nf=0;
              for k=1:ns_row
                  sum_ns=sum_ns+ns(k,j);
              end
              for k=1:nf_row
                  sum_nf=sum_nf+nf(k,j);
              end
              if (sum_ns) == 0
                 pfit(j) = 0.01;
               else
                  pfit(j) = sum_ns + 0.01;
               end
          end
           if ~isempty(ns), ns(1, :) = [];  end%ɾ����һ��
           if ~isempty(nf), nf(1, :) = [];  end
     end
end
