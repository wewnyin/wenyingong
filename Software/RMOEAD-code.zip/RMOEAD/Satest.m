 clc
clear
run('code\main.m')

clear
run('code2\main.m')

clear
run('code3\main.m')