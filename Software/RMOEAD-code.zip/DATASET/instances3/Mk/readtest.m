
clc;
clear all;
                                    
Gen=200;                              %  ����������
global TM N H SH NM M time ps ;
ps=100;
path='Mk\';
respath='result\';
Data={'FMk01.txt','FMk02.txt','FMk03.txt','FMk04.txt','FMk05.txt','FMk06.txt','FMk07.txt','FMk08.txt','FMk09.txt','FMk10.txt'};
title='F';
for i=1:10
 PATH=[Data{i}];
[TM,N,H,SH,NM,M,time] = readfuzzydata(PATH);

end



