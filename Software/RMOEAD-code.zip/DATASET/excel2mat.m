% num=xlsread('data1.xlsx');
%  save('data1.mat','num');
load('data5');
