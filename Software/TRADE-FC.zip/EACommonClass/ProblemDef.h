// ProblemDef.h: interface for the CProblemDef class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_)
#define AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../global.h"
#include "Individual.h"
#include "Rand.h"


// only for unconstrained optimization problems
class CProblemDef  
{
public:
	CProblemDef();
	virtual ~CProblemDef();

	// for unconstrained optimization problems
public:
	int		data_len;
	int		flag_once;
	CRand	m_rnd;

	void	evaluate_normal_fitness(double *xreal,tFitness &obj, 
				double *constr, int func_flag, long int &evaluations);

public:	
	double		I_current[1000];
	double		o_data[1000];

	tFitness	noise_value[500];
	tFitness	actual_data[1000], model_data[1000];
	/************************************************************************/
	/* only for the PEM fuel cell problem                                   */
	/************************************************************************/
	tFitness	calculate_V_Cell(double *x, double i, double *given_data);


	// Ref: C. Wang, M. H. Nehrir, and S. R. Shaw, Dynamic models and model validation for PEM fuel cells using electrical circuits,
	//      IEEE TRANSACTIONS ON ENERGY CONVERSION, VOL. 20, NO. 2, JUNE 2005
	void		PEMFC_model_WangCS(double *x,tFitness &obj, double *constr);				// 5

};

#endif // !defined(AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_)
