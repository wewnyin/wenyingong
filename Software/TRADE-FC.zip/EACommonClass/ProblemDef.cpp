// ProblemDef.cpp: implementation of the CProblemDef class.
//
//////////////////////////////////////////////////////////////////////


#include "ProblemDef.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CProblemDef::CProblemDef()
{
	flag_once = 0;
}

CProblemDef::~CProblemDef()
{
}

void CProblemDef::evaluate_normal_fitness(double *xreal, tFitness &obj, double *constr, int func_flag, long int &evaluations)
{
	switch(func_flag) {
	// for PEMFC parameter identification
	case 1:
		PEMFC_model_WangCS(xreal, obj, constr);
		break;
	default:
		printf("The function you selected does not exist.\n");
		exit(0);
		break;
	}
	evaluations++;
}

/************************************************************************/
/*  PEM fuel cell
    # of real variables = 11
    # of objectives     = 1
    # of constraints    = 0                                             */
/************************************************************************/
tFitness CProblemDef::calculate_V_Cell(double *x, double i, double *given_data)
{
	tFitness rst  = 0.0;

	double	 T    = given_data[0];	
	double	 P_H2 = given_data[1];
	double	 P_O2 = given_data[2];
	double	 Ns   = given_data[3];

	double	 A    = x[10];
	double	 l    = x[9]/10000.0;//178.0/10000.0;

	double	 E_Nernst, eta_act, eta_ohm, eta_conc;

	E_Nernst = 1.229 - 8.5e-4*(T-298.15) + 4.31e-5*T*log(P_H2*sqrt(P_O2));

	/************************************************************************/
	/* calculate the eta_act                                                */
	/************************************************************************/
	double C_O2;
	C_O2 = P_O2/(5.08e6*exp(-489/T));
	assert(C_O2>0.0);

	eta_act = -( x[0] + x[1]*T + x[2]*T*log(C_O2) + x[3]*T*log(i + x[7]*A/1000.0) );

	/************************************************************************/
	/* calculate the eta_ohm                                                */
	/************************************************************************/
	double rho_m, R_m;

	rho_m   = 181.6 * ( 1+0.03*(i/A + x[7]/1000.0) + 0.062*(T/303.0)*(T/303.0)*pow(i/A + x[7]/1000.0, 2.5) ) / ( (x[4] - 0.634 - 3.0*(i/A + x[7]/1000.0))*exp(4.18*((T-303.0)/T)) );
	R_m     = rho_m * l / A;
	eta_ohm = (i + x[7]*A/1000.0) * (R_m + x[5]);

	/************************************************************************/
	/* calculate the eta_conc                                               */
	/************************************************************************/
	if ( (i/A + x[7]/1000.0 ) >= x[8]/1000.0 )
	{
		return -1.0;
	}
	eta_conc = -x[6] * log(1.0 - (i + x[7]*A/1000.0)/(x[8]*A/1000.0));
	// x[7], ref: Parameter identification for proton exchange membrane fuel cell model using particle swarm optimization

	rst = Ns * (E_Nernst - eta_act - eta_ohm - eta_conc);

	return rst;
}


void CProblemDef::PEMFC_model_WangCS(double *x, tFitness &obj, double *constr)
{
	int		i, j;

	double given_data[4] = {353.0, 1.5, 1.0, 48};

	if (flag_once == 0)
	{
		flag_once = 1;
		printf("The data is initialized only once.\n");

		/*********************************************************************/
		/* get data from the file                                            */ 
		FILE *fpt;
		fpt = fopen("data/SR12-353K.txt","r");
		
		fscanf(fpt,"%d",&data_len);
		
		for(i=0;i<data_len;i++)
		{
			fscanf(fpt,"%Lf%Lf",&I_current[i], &o_data[i]);
		}

		fclose(fpt);
		/*********************************************************************/

		for (i=0;i<data_len;i++)
		{
			actual_data[i] = o_data[i];
		}
	}
	
	// calculate the model data
	for (i=0;i<data_len;i++)
	{
		model_data[i] = calculate_V_Cell(x, I_current[i], given_data);
		if (model_data[i]<0.0)
		{
			obj = INF;
			return;
		}
	}

	// calculate the fitness value
	tFitness fitness;
	fitness = 0.0;
	for (j=0;j<data_len;j++)
	{
		fitness += (model_data[j]-actual_data[j])*(model_data[j]-actual_data[j]);
	}
	fitness = (fitness)/(double)data_len;

	obj = fitness;
}





