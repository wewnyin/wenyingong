// ProblemDef.h: interface for the CProblemDef class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_)
#define AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../global.h"
#include "Individual.h"
#include "Rand.h"

#define mmv_data_len	50					// only for the inversion problem
#define mmv_N_of_body	(int)(N_of_x/2)		// number of bodys

// only for unconstrained optimization problems
class CProblemDef  
{
public:
	CProblemDef();
	virtual ~CProblemDef();

	// for unconstrained optimization problems
public:
	int		data_len;
	int		flag_once;
	CRand	m_rnd;

	void	evaluate_normal_fitness(double *xreal,tFitness &obj, 
				double *constr, int func_flag, long int &evaluations);

public:	
	double		I_current[1000];
	double		o_data[1000];

	tFitness	noise_value[500];
	tFitness	actual_data[1000], model_data[1000];
	/************************************************************************/
	/* only for the PEM fuel cell problem                                   */
	/************************************************************************/
	// Ref: C. Wang, M. H. Nehrir, and S. R. Shaw, Dynamic models and model validation for PEM fuel cells using electrical circuits,
	//      IEEE TRANSACTIONS ON ENERGY CONVERSION, VOL. 20, NO. 2, JUNE 2005
	tFitness	calculate_V_Cell_SR_12_stack(double *x, double i, double T);
	void		PEMFC_model_SR_12_stack(double *x,tFitness &obj, double *constr);			// 6

};

#endif // !defined(AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_)
