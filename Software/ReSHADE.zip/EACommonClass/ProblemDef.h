// ProblemDef.h: interface for the CProblemDef class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_)
#define AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Individual.h"
#include "Rand.h"

#define mmv_data_len	50					// only for the inversion problem
#define mmv_N_of_body	(int)(N_of_x/2)		// number of bodys

// only for unconstrained optimization problems
class CProblemDef  
{
public:
	CProblemDef();
	virtual ~CProblemDef();

	CRand m_rnd;

	// for unconstrained optimization problems
public:
	double	center[200];
	double  OShift[1000];
	int		flag_once;
	double	TempValue(double x,int a,int k,int m);

	void	evaluate_normal_fitness(double *xreal,tFitness &obj, 
		double *constr, int func_flag, long int &evaluations);

public:
	void test_01(double *xreal,tFitness &obj, double *constr);
	void test_02(double *xreal,tFitness &obj, double *constr);
	void test_03(double *xreal,tFitness &obj, double *constr);
	void test_04(double *xreal,tFitness &obj, double *constr);
	void test_05(double *xreal,tFitness &obj, double *constr);
	void test_06(double *xreal,tFitness &obj, double *constr);
	void test_07(double *xreal,tFitness &obj, double *constr);
	void test_08(double *xreal,tFitness &obj, double *constr);
	void test_09(double *xreal,tFitness &obj, double *constr);
	void test_10(double *xreal,tFitness &obj, double *constr);
	void test_11(double *xreal,tFitness &obj, double *constr);
	void test_12(double *xreal,tFitness &obj, double *constr);
	void test_13(double *xreal,tFitness &obj, double *constr);
	
	void test_14(double *xreal,tFitness &obj, double *constr);
	void test_15(double *xreal,tFitness &obj, double *constr);
	void test_16(double *xreal,tFitness &obj, double *constr);
	void test_17(double *xreal,tFitness &obj, double *constr);
	void test_18(double *xreal,tFitness &obj, double *constr);
	void test_19(double *xreal,tFitness &obj, double *constr);
	void test_20(double *xreal,tFitness &obj, double *constr);
	void test_21(double *xreal,tFitness &obj, double *constr);
	void test_22(double *xreal,tFitness &obj, double *constr);
	void test_23(double *xreal,tFitness &obj, double *constr);
	void test_24(double *xreal,tFitness &obj, double *constr);
	void test_25(double *xreal,tFitness &obj, double *constr);
	void test_26(double *xreal,tFitness &obj, double *constr);
	void test_27(double *xreal,tFitness &obj, double *constr);
	void test_28(double *xreal,tFitness &obj, double *constr);
	void test_29(double *xreal,tFitness &obj, double *constr);
	void test_30(double *xreal,tFitness &obj, double *constr);

	void test_31(double *xreal,tFitness &obj, double *constr);
	void test_32(double *xreal,tFitness &obj, double *constr);
	void test_33(double *xreal,tFitness &obj, double *constr);

	void test_34(double *xreal,tFitness &obj, double *constr);
	void test_35(double *xreal,tFitness &obj, double *constr);

	// add new test problems here...
	// unconstrained application problems
	// Ref: C. Wang, M. H. Nehrir, and S. R. Shaw, Dynamic models and model validation for PEM fuel cells using electrical circuits,
	//      IEEE TRANSACTIONS ON ENERGY CONVERSION, VOL. 20, NO. 2, JUNE 2005
	int			data_len;
	tFitness	actual_data[1000], model_data[1000];
	double		I_current[1000];
	double		o_data[1000];

	tFitness	calculate_V_Cell_SR_12_stack(double *x, double i, double T);
	void		PEMFC_model_SR_12_stack(double *x,tFitness &obj, double *constr);		// 45

	void Chebychev_Polynomial(double *xreal, tFitness &obj, double *constr);			// 46

	double y0[200];
	int	 init_one;
	void FMSoundWave(double *xreal, tFitness &obj, double *constr);						// 47

	// only for Spread Spectrum Radar
	double Phi[4*N_of_x-1];	// Phi[0] is not used here
	double x[N_of_x+1];		// x[0] is not used here
	void SpreadSpectrumRadar(double *xreal, tFitness &obj, double *constr);				// 48

	/************************************************************************/
	/* only for the inversion problem                                       */
	/************************************************************************/
	// for MMV inversion
	// Ref.: N. Qiu, et al, Combining genetic algorithm and generalized least squares for geophysical potential field data optimized inversion,
	//       IEEE Geoscience and remote sensing letters, In press, 2010.
	double	xx[mmv_data_len];
	double	z[mmv_data_len];
	double	Mag_org[mmv_data_len];
	void	mmv_init_parameters();
	void	mmvplate(double *xreal, double *T);
	void	mmvplate_fitness(double *xreal, tFitness &obj, double *constr);		// 49

};

#endif // !defined(AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_)
