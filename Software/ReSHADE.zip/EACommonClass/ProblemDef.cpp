// ProblemDef.cpp: implementation of the CProblemDef class.
//
//////////////////////////////////////////////////////////////////////

#include "../global.h"
#include "ProblemDef.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CProblemDef::CProblemDef()
{
	flag_once	= 0;
	init_one	= 0;
}

CProblemDef::~CProblemDef()
{
}

void CProblemDef::evaluate_normal_fitness(double *xreal, tFitness &obj, double *constr, 
										  int func_flag, long int &evaluations)
{
	if (flag_once==0)
	{
		int		i;
		FILE	*fpt;
		
		fpt=fopen("input_data/shift_data.txt","r");
		if (fpt==NULL)
		{
			printf("\n Error: Cannot open input file for reading \n");
		}
		
		for(i=0;i<N_of_x;i++)
		{
			//fscanf(fpt,"%Lf",&OShift[i]);
			OShift[i] = 0.0;
		}
		fclose(fpt);
		
		flag_once = 1;
		printf("Function has been initialized!\n");
	}

	switch(func_flag) {
	case 1:
		test_01(xreal,obj,constr);
		break;
	case 2:
		test_02(xreal,obj,constr);
		break;
	case 3:
		test_03(xreal,obj,constr);
		break;
	case 4:
		test_04(xreal,obj,constr);
		break;
	case 5:
		test_05(xreal,obj,constr);
		break;
	case 6:
		test_06(xreal,obj,constr);
		break;
	case 7:
		test_07(xreal,obj,constr);
		break;
	case 8:
		test_08(xreal,obj,constr);
		break;
	case 9:
		test_09(xreal,obj,constr);
		break;
	case 10:
		test_10(xreal,obj,constr);
		break;
	case 11:
		test_11(xreal,obj,constr);
		break;
	case 12:
		test_12(xreal,obj,constr);
		break;
	case 13:
		test_13(xreal,obj,constr);
		break;
	case 14:
		test_14(xreal,obj,constr);
		break;
	case 15:
		test_16(xreal,obj,constr);
		break;
	case 16:
		test_17(xreal,obj,constr);
		break;
	case 17:
		test_18(xreal,obj,constr);
		break;
	case 18:
		test_19(xreal,obj,constr);
		break;
	case 19:
		test_20(xreal,obj,constr);
		break;
	case 20:
		test_21(xreal,obj,constr);
		break;
	case 21:
		test_22(xreal,obj,constr);
		break;
	case 22:
		test_23(xreal,obj,constr);
		break;
	case 23:
		test_24(xreal,obj,constr);
		break;
	case 24:
		test_27(xreal,obj,constr);
		break;
	case 25:
		test_28(xreal,obj,constr);
		break;
	case 26:
		test_29(xreal,obj,constr);
		break;
	case 27:
		test_30(xreal,obj,constr);
		break;
	case 28:
		test_31(xreal,obj,constr);
		break;
	case 29:
		test_33(xreal,obj,constr);
		break;
	case 30:
		test_34(xreal,obj,constr);
		break;
	case 31:
		test_25(xreal,obj,constr);
		break;
	case 32:
		test_15(xreal,obj,constr);
		break;


	// for the real-world application problems
	case 46:
		Chebychev_Polynomial(xreal,obj,constr);
		break;
	case 47:
		FMSoundWave(xreal,obj,constr);
		break;
	case 48:
		SpreadSpectrumRadar(xreal,obj,constr);
		break;
	case 49:
		mmvplate_fitness(xreal, obj, constr);
		break;	
	default:
		printf("The function you selected does not exist.\n");
		exit(0);
		break;
	}
	evaluations++;
}

// only for unconstrained optimization problems
// Ellipsoidal function - UM
void CProblemDef::test_01(double *x, tFitness &obj, double *constr)
{
	tFitness fit = 0.0;
	for(int i=0;i<N_of_x;i++)
		fit += ((x[i]-OShift[i])*(x[i]-OShift[i]));
	obj = fit;
}

// Schwefel's function 2.22 - UM
void CProblemDef::test_02(double *x, tFitness &obj, double *constr)
{
	tFitness value = 0.0;
	tFitness temp1 = 0.0;
	tFitness temp2 = 1.0;
	for (int i=0;i<N_of_x;i++)
	{
		 temp1 += fabs(x[i]-OShift[i]);
		 temp2 *= fabs(x[i]-OShift[i]);
	}
	value = temp1+temp2;
	obj = value;
}

// Schwefel's function 1.2 - UM
void CProblemDef::test_03(double *x, tFitness &obj, double *constr)
{
	tFitness fit = 0.0;
	tFitness sumSCH;
	int i,j;
	
	for (i=0;i<N_of_x;i++)
	{
		sumSCH = 0.0;
		for (j=0;j<i+1;j++)
		{
			sumSCH += (x[j]);
		}
		fit += sumSCH*sumSCH;
	}
	obj = fit;
}

// Schwefel's function 2.21 - UM
void CProblemDef::test_04(double *x, tFitness &obj, double *constr)
{
	tFitness temp1 = fabs(x[0]);
	for (int i=1;i<N_of_x;i++)
	{
		if (fabs(x[i]) > temp1)
		{
			temp1 = fabs(x[i]);
		}
	}
	obj = temp1;
}

// Rosenbrock's function - MM
void CProblemDef::test_05(double *x, tFitness &obj, double *constr)
{
	tFitness fit;
	tFitness t0, tt, t1, d=0;
	t0=x[0];
	for (int i=1; i<N_of_x; i++) 
	{
		t1 = x[i];
		tt = (1.0-t0);
		d += tt*tt;
		tt = t1-t0*t0;
		d += 100*tt*tt;				
		t0 = t1;
	}
	fit = d;

	obj = fit;
}

// step function - UM
void CProblemDef::test_06(double *x, tFitness &obj, double *constr)
{
	tFitness temp;
	tFitness value = 0.0;
	for (int i=0;i<N_of_x;i++)
	{
		temp = floor(x[i]-OShift[i]+0.5);
		value += temp*temp; 
	}
	obj = value;
}

// Quartic function - UM
void CProblemDef::test_07(double *xreal, tFitness &obj, double *constr)
{
	tFitness value = 0.0;
	for (int i=0;i<N_of_x;i++)
	{
		value += (i+1)*pow(xreal[i],4.0); 
	}
	CRand rnd;
	obj = value+rnd.randomperc();
}

// Generalized Schwefel's function - MM
void CProblemDef::test_08(double *x, tFitness &obj, double *constr)
{
	tFitness value = 0.0;
	for (int i=0;i<N_of_x;i++)
	{
		value += x[i]*sin(sqrt(fabs(x[i]))); 
	}
	obj = -value + 418.9828872724337998*(double)N_of_x; // modified here
}

// Generalized Rastrigin's function - MM
void CProblemDef::test_09(double *x, tFitness &obj, double *constr)
{
	tFitness value = 0.0;
	for (int i=0;i<N_of_x;i++)
	{
		value += x[i]*x[i]-10.0*cos(2.0*PI*x[i])+10.0; 
	}
	obj = value;
}

// Ackley' function - MM
void CProblemDef::test_10(double *x, tFitness &obj, double *constr)
{
	tFitness value = 0.0;
	tFitness temp1 = 0.0;
	tFitness temp2 = 0.0;
	for (int i=0;i<N_of_x;i++)
	{
		 temp1 += x[i]*x[i];
		 temp2 += cos(2.0*PI*x[i]);
	}
	obj = -20.0*exp(-0.2*sqrt(temp1/N_of_x))-exp(temp2/N_of_x)+20.0+exp(1.0);
}

// Generalized Griewank function - MM
void CProblemDef::test_11(double *x, tFitness &obj, double *constr)
{
	tFitness temp1 = 0.0;
	tFitness temp2 = 1.0;
	for (int i=0;i<N_of_x;i++)
	{
		 temp1 += x[i]*x[i];
		 temp2 *= cos(x[i]/sqrt(i+1));
	}
	obj = temp1/4000.0-temp2+1;
}

double CProblemDef::TempValue(double x,int a,int k,int m)
{
	double temp = 0.0;
	if( x > a)
	{
		temp = k*pow(x-a,m);
	}
	else if( x <= a && x >= -a)
	{
		temp = 0.0;
	}
	else
	{
		temp = k*pow(-x-a,m);
	}
	return temp;
}

// Generalized Penalized function - MM
void CProblemDef::test_12(double *x, tFitness &obj, double *constr)
{
	double *y;	//��ʱ�洢�����еı���

	y=new double[N_of_x];

	for (int i=0;i<N_of_x;i++)
	{
		y[i]=0.0;
	}

	for (i=0;i<N_of_x;i++)
	{
		y[i]=1+(x[i]+1)/4.0;
	}

	tFitness temp1 = 0.0;
	tFitness temp2 = 0.0;
	for (i=0;i<N_of_x-1;i++)
	{
		temp1 += pow(y[i]-1,2.0)*(1.0+10.0*pow(sin(PI*y[i+1]),2.0)); 
	}
	for (i=0;i<N_of_x;i++)
	{
		temp2 += TempValue(x[i],10,100,4);
	}
	obj = (10.0*pow(sin(PI*y[0]),2.0)+temp1+pow(y[N_of_x-1]-1,2))*PI/N_of_x+temp2;
	delete []y;
}

// Generalized Penalized function - MM
void CProblemDef::test_13(double *x, tFitness &obj, double *constr)
{
	tFitness temp1 = 0.0;
	tFitness temp2 = 0.0;
	for (int i=0;i<N_of_x-1;i++)
	{
		temp1 += pow(x[i]-1,2.0)*(1.0+10.0*pow(sin(3*PI*x[i+1]),2.0)); 
	}
	for (i=0;i<N_of_x;i++)
	{
		temp2 += TempValue(x[i],5,100,4);
	}
	obj = (pow(sin(3.0*PI*x[0]),2.0)+temp1+pow(x[N_of_x-1]-1,2.0)
		*(1.0+pow(sin(2.0*PI*x[N_of_x-1]),2.0)))/10.0+temp2;
}

// Sum of different power from ODE - UM
// x = [-1, 1]
// f(0, ..., 0) = 0
void CProblemDef::test_14(double *x, tFitness &obj, double *constr)
{
	tFitness temp = 0.0;
	for (int i=0;i<N_of_x;i++)
	{
		 temp += pow(fabs(x[i]-OShift[i]), i+1);
	}
	obj = temp;
}

// Perm function from ODE - MM
// http://www-optima.amp.i.kyoto-u.ac.jp/member/student/hedar/Hedar_files/TestGO_files/Page2545.htm
// x = [-n, n]
// f(1, 2, ..., n) = 0
void CProblemDef::test_15(double *x, tFitness &obj, double *constr)
{
	tFitness temp1 = 0.0;
	tFitness temp2 = 0.0;
	double b = 10;
	for (int k=0;k<N_of_x;k++)
	{
		temp2 = 0.0;
		for (int j=0; j<N_of_x; j++)
		{
			temp2 += (j+1+b)*( pow(x[j], k+1)  -pow(1.0/(j+1), k+1) );
		}
		temp1 += temp2*temp2;
	}
	obj = temp1;
}

// Michalewitz function x = [0, PI] from ODE - MM
void CProblemDef::test_16(double *x, tFitness &obj, double *constr)
{
	tFitness value = 0.0;
	double   m = 10.0;
	tFitness optimal=0;

	if (N_of_x == 1)
	{
		optimal = -0.801303410098554;
	}
	if (N_of_x == 2)
	{
		optimal = -1.801303410098554;
	}
	if (N_of_x == 5)
	{
		optimal = -4.68765817908815;
	}
	if (N_of_x == 10)
	{
		optimal = -9.66015171564135;
	}
	if (N_of_x == 30)
	{
		optimal = -29.6308838503244;
	}

	for (int i=0;i<N_of_x;i++)
	{
		value = value + sin(x[i]) * pow(sin((i+1)*x[i]*x[i]/PI),2.0*m);
	}
	obj = -value - optimal;
}

// Zakharov function from ODE - UM
// x = [-5, 10]
// f(0,...,0) = 0
void CProblemDef::test_17(double *x, tFitness &obj, double *constr)
{
	tFitness temp1 = 0.0;
	tFitness temp2 = 0.0;
	int i;

	for (i=0; i<N_of_x; i++)
	{
		temp1 += x[i]*x[i];
	}
	for (i=0; i<N_of_x; i++)
	{
		temp2 +=0.5*(i+1)*x[i];
	}

	obj = temp1 + pow(temp2,2) + pow(temp2,4);
}

// Alpine function from ODE - MM
// x = [-10, 10]
// f(0,...,0) = 0
void CProblemDef::test_18(double *x, tFitness &obj, double *constr)
{
	tFitness temp = 0.0;
	for (int i=0;i<N_of_x;i++)
	{
		temp += fabs(x[i]*sin(x[i])+0.1*x[i]);
	}
	obj = temp;
}

// Pathological function from ODE - MM
// x = [-100, 100]
// f(0,...,0) = 0
void CProblemDef::test_19(double *x, tFitness &obj, double *constr)
{
	tFitness temp = 0.0;
	for (int i=0;i<N_of_x-1;i++)
	{
		temp += 0.5 +
			(pow(sin(sqrt((100.0*x[i]*x[i]+x[i+1]*x[i+1]))),2)-0.5)/(1.0+0.001*pow(x[i]*x[i]-2.0*x[i]*x[i+1]+x[i+1]*x[i+1],2));
	}
	
	obj = temp;
}

// Inverted cosine wave function (Masters) from ODE - MM
// x = [-5, 5]
// f(0,...,0) = 0
void CProblemDef::test_20(double *x, tFitness &obj, double *constr)
{
	tFitness temp = 0.0;
	for (int i=0; i<N_of_x-1; i++)
	{
		temp += exp(-(x[i]*x[i]+0.5*x[i]*x[i+1]+x[i+1]*x[i+1])/8.0)
			* cos(4.0*sqrt(x[i]*x[i]+0.5*x[i]*x[i+1]+x[i+1]*x[i+1]));
	}
	obj = temp + N_of_x - 1;
}

// Exponential function from ODE - UM
// x = [-1, 1]
// f(0,...,0) = 0
void CProblemDef::test_21(double *x, tFitness &obj, double *constr)
{
	tFitness temp = 0.0;
	for (int i=0; i<N_of_x; i++)
	{
		temp += x[i]*x[i];
	}
	obj = -exp(-0.5*temp) + 1.0;
}

// Trid function: Neumaier 3 Problem from ODE - MM
// x = [0, n]
// x_i* = i*(n+1-i)
void CProblemDef::test_22(double *x, tFitness &obj, double *constr)
{
	int i;
	tFitness sum=0.0, obj1=0.0, obj2=0.0;
	int n = N_of_x;

	for (i=0; i<n; i++)
	{
		obj1 += pow(x[i]-1.0,2);
	}
	for (i=1; i<n; i++)
	{
		obj2 += x[i]*x[i-1];
	}

	sum = obj1-obj2;

	obj = sum + n*(n+4)*(n-1)/6 + 1e-11;
}

// Odd square function from ODE - MM
// x = [-15, 15]
// -1.143833
void CProblemDef::test_23(double *x, tFitness &obj, double *constr)
{
	int j;
	tFitness result,dist=0,dx=0,max_dist=0;
	static double center_point[]=
		{1., 1.3, .8, -.4, -1.3, 1.6, -.2, -.6, .5, 1.4, 
		1., 1.3, .8, -.4, -1.3, 1.6, -.2, -.6, .5, 1.4,
		1., 1.3, .8, -.4, -1.3, 1.6, -.2, -.6, .5, 1.4, 
		1., 1.3, .8, -.4, -1.3, 1.6, -.2, -.6, .5, 1.4,
		1., 1.3, .8, -.4, -1.3, 1.6, -.2, -.6, .5, 1.4, 
		1., 1.3, .8, -.4, -1.3, 1.6, -.2, -.6, .5, 1.4,
		1., 1.3, .8, -.4, -1.3, 1.6, -.2, -.6, .5, 1.4, 
		1., 1.3, .8, -.4, -1.3, 1.6, -.2, -.6, .5, 1.4,
		1., 1.3, .8, -.4, -1.3, 1.6, -.2, -.6, .5, 1.4, 
		1., 1.3, .8, -.4, -1.3, 1.6, -.2, -.6, .5, 1.4,
		1., 1.3, .8, -.4, -1.3, 1.6, -.2, -.6, .5, 1.4, 
		1., 1.3, .8, -.4, -1.3, 1.6, -.2, -.6, .5, 1.4,
		1., 1.3, .8, -.4, -1.3, 1.6, -.2, -.6, .5, 1.4, 
		1., 1.3, .8, -.4, -1.3, 1.6, -.2, -.6, .5, 1.4,
		1., 1.3, .8, -.4, -1.3, 1.6, -.2, -.6, .5, 1.4, 
		1., 1.3, .8, -.4, -1.3, 1.6, -.2, -.6, .5, 1.4,
		1., 1.3, .8, -.4, -1.3, 1.6, -.2, -.6, .5, 1.4, 
		1., 1.3, .8, -.4, -1.3, 1.6, -.2, -.6, .5, 1.4,
		1., 1.3, .8, -.4, -1.3, 1.6, -.2, -.6, .5, 1.4, 
		1., 1.3, .8, -.4, -1.3, 1.6, -.2, -.6, .5, 1.4};

	for (j=0; j<N_of_x; j++)
	{
		dx   = fabs(x[j]-center_point[j]);
		dist += dx*dx;
		if (dx>max_dist) 
			max_dist=dx;
	}
	dist     = sqrt(dist);
	max_dist = sqrt((double)N_of_x*max_dist*max_dist);
	result   = (exp(-max_dist/(2.*PI))*cos(PI*max_dist))*(1.+0.2*dist/(max_dist+.01));

	obj = -result + 1.143833;
}

// Paviani's function from ODE - UM
// x = [-10, 10]
void CProblemDef::test_24(double *x, tFitness &obj, double *constr)
{
	tFitness temp1 = 0.0;
	tFitness temp2 = 1.0;
	int i;
	for (i=0; i<N_of_x; i++)
	{
		temp1 += log(x[i]-2)*log(x[i]-2)+log(10-x[i])*log(10-x[i]);
	}
	for (i=0; i<N_of_x; i++)
	{
		temp2 *= x[i];
	}
	if (N_of_x==30)
	{
		obj = temp1-pow(temp2,0.2) + 45.778 + 997821.690759785;
	}
	else if (100==N_of_x)
	{
		obj = temp1-pow(temp2,0.2) + 9.99999999072958e+019;
	}
	else
	{
		obj = temp1-pow(temp2,0.2);
	}
	//obj = temp1-pow(temp2,0.2) + 45.778;
}

// Salomon's function: get from DEahcSPX and ODE - MM
// x = [-100, 100]
// f(0,...,0) = 0
void CProblemDef::test_25(double *x, tFitness &obj, double *constr)
{
	tFitness temp = 0.0;
	for (int i=0; i<N_of_x; i++)
	{
		temp += x[i]*x[i];
	}
	obj = -cos(2*PI*sqrt(temp))+0.1*sqrt(temp)+1.0;
}

// Shubert Problem (SBT):  - MM
/* M. M. Ali, C. Khompatraporn, and Z. B. Zabinsky,  "A numerical evaluation
of several stochastic algorithms on selected continuous global
optimization test problems," J. Global Optim., vol. 31, pp. 635�C672,
2005. */
// x = [-10, 10]
// ??     n = 2, f(x*) = -186.730908831024
/*void CProblemDef::test_26(double *x, tFitness &obj, double *constr)
{
	int i,j;
	tFitness sum=0., prod=1.;


	for (i=0; i<N_of_x; i++)
	{
		sum = 0.;
		for (j=1; j<=5; j++)
		{
			sum = sum + j*cos((j+1)*x[i]+j);
		}
		prod = prod*sum;
	}
	
    obj = prod;
}*/

// Sinusoidal Problem (SIN) - MM
/* M. M. Ali, C. Khompatraporn, and Z. B. Zabinsky,  ``A numerical evaluation
of several stochastic algorithms on selected continuous global
optimization test problems," J. Global Optim., vol. 31, pp. 635�C672,
2005. */
// x = [0, PI]
// x* = (PI/2+z, ..., PI/2+z) f(x*) = -A-1
void CProblemDef::test_27(double *x, tFitness &obj, double *constr)
{
	int j;
	tFitness sum=0.0, prod1=1.0, prod2=1.0;
	double   A=2.5, B=5.0, z=PI/6;

	for (j=0; j<N_of_x; j++)
	{
		prod1 *= sin(x[j]-z);
		prod2 *= sin(B*(x[j]-z));
	}
	sum = -1*(A*prod1 + prod2);

	obj = sum + A+1;
}

// Cosine Mixture Problem (CM) - MM
/* M. M. Ali, C. Khompatraporn, and Z. B. Zabinsky,  ``A numerical evaluation
of several stochastic algorithms on selected continuous global
optimization test problems," J. Global Optim., vol. 31, pp. 635�C672,
2005. */
// x = [-1, 1]
// f(0,...,0) = 0
void CProblemDef::test_28(double *x, tFitness &obj, double *constr)
{
	int i;
	tFitness sum1=0., sum2=0., sum=0.;


	for (i=0; i<N_of_x; i++)
	{
		sum1 = sum1 + cos(5*PI*x[i]);
		sum2 = sum2 + pow(x[i],2);
	}
	sum = 0.1*sum1 - sum2;
	obj = 0.1*N_of_x - sum;
}

// weierstrass's function - MM  Ref: A Self-Learning Particle Swarm Optimizer for Global Optimization Problems
// x = [-0.5, 0.5]
// f(x*) = 0
void CProblemDef::test_29(double *x, tFitness &obj, double *constr)
{
	int i, j;
	tFitness res;
	tFitness sum, sum1;
	tFitness a, b;
    int k_max;
    a     = 0.5;
    b     = 3.0;
    k_max = 20;
    res   = 0.0;
    for (i=0; i<N_of_x; i++)
    {
        sum  = 0.0;
		sum1 = 0.0;
        for (j=0; j<=k_max; j++)
        {
            sum  += pow(a,j)*cos(2.0*PI*pow(b,j)*(x[i]+0.5));
			sum1 += pow(a,j)*cos(2.0*PI*pow(b,j)*0.5);
        }
        res += sum;
    }

	obj = res - N_of_x * sum1;
}

// Noncont_Rastrigin's function - MM  Ref: A Self-Learning Particle Swarm Optimizer for Global Optimization Problems
// x = [-5.12, 5.12]
// f(x*) = 0
void CProblemDef::test_30(double *x, tFitness &obj, double *constr)
{
	int i;
	tFitness fit;
	double y[N_of_x];

	for(i=0;i<N_of_x;i++)
	{
		if(fabs(x[i])<0.5) 
		{
			y[i] = x[i];
		}
		else 
		{
			double a, b = 2*x[i];
			if(b-(int)b<=0.5)	a = (int)b;
			else				a = (int)b+1;
			y[i] = a/2;
		}
	}

	fit = 0.0;
	for(i=0;i<N_of_x;i++)
	{
		fit += y[i]*y[i]-10.*cos(2*PI*y[i])+10.;
	}

	obj = fit;
}

// CROSS-IN-TRAY FUNCTION: http://www.sfu.ca/~ssurjano/crossit.html
// x = [-10, 10] - MM
// f(x*) = 0
void CProblemDef::test_31(double *x, tFitness &obj, double *constr)
{
	int i;
	tFitness fit;
	tFitness temp1, temp2;

	temp1 = 1.0;
	for (i=0; i<N_of_x; i++)
	{
		temp1 *= sin(x[i]);
	}

	temp2 = 0.0;
	for (i=0; i<N_of_x; i++)
	{
		temp2 += x[i]*x[i];
	}
	temp2 = exp(fabs(100.0-sqrt(temp2)/PI));

	fit = -0.0001 * pow( fabs(temp1 * temp2) + 1.0, 0.1 );
	if (N_of_x==30)	fit += 1.68347744296513;

	obj = fit;
}

// Gong-AMC-08, f25 - MM
// x = [-5, 5]
// f(x*) = 0
void CProblemDef::test_33(double *x, tFitness &obj, double *constr)
{
	tFitness value = 0.0;
	int i;
	for (i=0;i<N_of_x;i++)
	{
		value += pow(x[i],4)-16*x[i]*x[i]+5*x[i]; 
	}
	value /= N_of_x;

	obj = value + 78.3323314075429;
}

// CEC-2020, Bent Gigar - UM
// x = [-100, 100]
// f(x*) = 0
void CProblemDef::test_34(double *x, tFitness &obj, double *constr)
{
	tFitness value = 0.0;
	int i;
	tFitness sum1=0.0, sum2=0.0;
	for (i=0;i<N_of_x;i++)
	{
		sum1 += x[i]*x[i];
	}
	for (i=1;i<N_of_x;i++)
	{
		sum2 += x[i]*x[i];
	}
	value = sum1 + pow(10.0, 6.0)*sum2;
	
	obj = value;
}

// Trid function - 2020 Differential Evolution - A review of more than two decades of research
// x = [-100, 100]
// f(x*) = 0
void CProblemDef::test_35(double *x, tFitness &obj, double *constr)
{
	tFitness value = 0.0;

	tFitness sum=0.0;
	int i, n = N_of_x;
	sum = 0.0;
	double t1, t2;
	for (i = 0; i < n-1; i++) 
	{
		t1	= sqrt(fabs(x[i+1] + x[i] + 1.0));
		t2	= sqrt(fabs(x[i+1] - x[i] + 1.0));
		sum += (x[i+1] + 1.0) * cos(t2) * sin(t1) + cos(t1) * sin(t2) * x[i];
	}

	obj = sum;
}



/************************************************************************/
/*  PEM fuel cell
    # of real variables = 10
    # of objectives     = 1
    # of constraints    = 0                                             */
/************************************************************************/
tFitness CProblemDef::calculate_V_Cell_SR_12_stack(double *x, double i, double	T)
{
	tFitness	rst  = 0.0;

	//double T   = 283.0;		// 293, 303
	double	A    = 62.5;
	double	l    = x[9]/10000.0;//25.0/10000.0;
	double	P_H2 = 1.5;
	double	P_O2 = 1.0;
	double	Ns   = 48;

	double	E_Nernst, eta_act, eta_ohm, eta_conc;

	E_Nernst = 1.229 - 8.5e-4*(T-298.15) + 4.31e-5*T*log(P_H2*sqrt(P_O2));	assert(E_Nernst>0.);

	/************************************************************************/
	/* calculate the eta_act                                                */
	/************************************************************************/
	double C_O2;
	C_O2 = P_O2/(5.08e6*exp(-489/T));
	assert(C_O2>0.0);

	eta_act = -( x[0] + x[1]*T + x[2]*T*log(C_O2) + x[3]*T*log(i) );		//assert(eta_act>0.);

	/************************************************************************/
	/* calculate the eta_ohm                                                */
	/************************************************************************/
	double rho_m, R_m;

	rho_m   = 181.6 * ( 1+0.03*(i/A) + 0.062*(T/303.0)*(T/303.0)*pow(i/A, 2.5) ) / ( (x[4] - 0.634 - 3.0*(i/A))*exp(4.18*((T-303.0)/T)) );
	R_m     = rho_m * l / A;
	eta_ohm = i * (R_m + x[5]);

	/************************************************************************/
	/* calculate the eta_conc                                               */
	/************************************************************************/
	if ((i/A + x[7]/1000.0 ) >= x[8]/1000.0)
	{
		return -1.0;
	}
	eta_conc = -x[6] * log(1.0 - (i/A + x[7]/1000.0)/(x[8]/1000.0));
	// x[7], ref: Parameter identification for proton exchange membrane fuel cell model using particle swarm optimization

	rst = Ns * (E_Nernst - eta_act - eta_ohm - eta_conc);

	return rst;
}

void CProblemDef::PEMFC_model_SR_12_stack(double *x, tFitness &obj, double *constr)
{
	int		i, j;

	double	T = 323.0;

	if (flag_once == 0)
	{
		flag_once = 1;
		printf("The data is initialized only once.\n");

		/*********************************************************************/
		/* get data from the file                                            */ 
		FILE *fpt;
		fpt = fopen("PEMFC_data/SR12-353K.txt","r");
		
		fscanf(fpt,"%d",&data_len);
		
		for(i=0;i<data_len;i++)
		{
			fscanf(fpt,"%Lf%Lf",&I_current[i], &o_data[i]);
		}

		fclose(fpt);
		/*********************************************************************/

		for (i=0;i<data_len;i++)
		{
			actual_data[i] = o_data[i];
		}
	}
	
	// calculate the model data
	for (i=0;i<data_len;i++)
	{
		model_data[i] = calculate_V_Cell_SR_12_stack(x, I_current[i], T);
		if (model_data[i]<0.0)
		{
			obj = INF;
			return;
		}
	}

	// calculate the fitness value
	tFitness fitness;
	fitness = 0.0;
	for (j=0;j<data_len;j++)
	{
		fitness += (model_data[j]-actual_data[j])*(model_data[j]-actual_data[j]);
	}
	fitness = (fitness)/(double)data_len;

	obj = fitness;
}


// D=9 or D=17
// x in [-pow(2, N_of_x), pow(2, N_of_x)]
void CProblemDef::Chebychev_Polynomial(double *tmp, tFitness &obj, double *constr)
{
	int i,j;
	double px,x=-1,result=0,dx;
	int D = N_of_x;
   
	if ( D == 9 )
		dx = 72.66066;
	if ( D == 17 )
		dx = 10558.145;

	for (i=0;i<=100;i++)
	{
		px=tmp[0];
		for (j=1;j<D;j++) 
			px = x*px+tmp[j];
		if (px<-1 || px>1) 
			result += (1.-px)*(1.-px);
		x += .02;
   }
   px = tmp[0];
   for (j=1;j<D;j++) 
	   px = 1.2*px+tmp[j];
   px = px-dx;
   if (px<0) 
	   result += px*px;
   px = tmp[0];
   for (j=1;j<D;j++) 
	   px = -1.2*px+tmp[j];
   px = px-dx;
   if (px<0) 
	   result += px*px;
   
	obj = result;
}

// D = 6
// x in [-6.4, 6.35]
void CProblemDef::FMSoundWave(double *x, tFitness &obj, double *constr)
{
	int t;
	//double *y0;
	double theta = PI/50.0;
	int num_of_data = 101;

	//y0 = new double[num_of_data];

	if (init_one == 0)
	{
		printf("The data is generated only once.\n");
		init_one = 1;
		for (t=0;t<num_of_data;t++)
		{
			double tt = t*theta;
			y0[t] = 1.0*sin(5.0*tt-1.5*sin(4.8*tt+2.0*sin(4.9*tt)));
		}
	}

	double temp = 0.0;
	double yt;
	for (t=0;t<num_of_data;t++)
	{
		double tt = t*theta;
		yt = x[0]*sin(x[1]*tt+x[2]*sin(x[3]*tt+x[4]*sin(x[5]*tt)));
		temp += (yt-y0[t])*(yt-y0[t]);
	}
	obj = temp;

	//delete y0;
}

// D = 2, 3, ...
// x in [0, 2*PI]
void CProblemDef::SpreadSpectrumRadar(double *xreal, tFitness &obj, double *constr)
{
	int i, j, k;
	int D = N_of_x;
	int m = (2*D-1);
	//double Phi[4*N_of_x-1];	// Phi[0] is not used here
	//double x[N_of_x+1];		// x[0] is not used here
	double temp1;
	double temp2;

	for (i=1;i<D+1;i++)
	{
		x[i] = xreal[i-1];
	}

	// calculate Phi(2*i-1)
	for (i=1;i<=D;i++)
	{
		temp1 = 0.0;
		for (j=i;j<=D;j++)
		{
			temp2 = 0.0;
			for (k=((int)abs(2*i-j-1)+1); k<=j; k++)
			{
				temp2 += x[k];
			}
			temp1 += cos(temp2);
		}
		Phi[2*i-1] = temp1;
	}

	// calculate Phi(2*i)
	for (i=1;i<=D-1;i++)
	{
		temp1 = 0.0;
		for (j=i+1;j<=D;j++)
		{
			temp2 = 0.0;
			for ((k=(int)abs(2*i-j)+1); k<=j; k++)
			{
				temp2 += x[k];
			}
			temp1 += cos(temp2);
		}
		Phi[2*i] = 0.5+temp1;
	}

	// calculate Phi(m+i)
	for (i=1;i<=m;i++)
	{
		Phi[m+i] = -Phi[i];
	}

//	for (i=1; i<2*m+1; i++)
//	{
//		printf("%d\t%f\n", i, Phi[i]);
//	}

	obj = -1e100;
	for (i=1; i<2*m+1; i++)
	{
		if (Phi[i] > obj)
		{
			obj = Phi[i];
		}
	}
}

// D = 9 or D = 25
// x0 in [0,50], x1 - x8 in [0,10]
void CProblemDef::mmv_init_parameters()
{
	int i;

	for (i=0;i<mmv_data_len;i++)
	{
		xx[i] = (double)(i+1);
		z[i] = 0.0;
	}
}

void CProblemDef::mmvplate(double *xreal, double *T)
{
	double incl = PI/3;			// inclination
	double decl = 2*PI/3;		// declination
	double Js   = 1000*1e-3;	// magnetization

	int    b = 1;
	int    N = mmv_N_of_body;	// number of bodys

	double xf;
	double h1[mmv_N_of_body], h2[mmv_N_of_body];
	xf = xreal[0];
	for (int i=0;i<N;i++)
	{
		h1[i] = xreal[i+1];
		h2[i] = xreal[i+N+1];
	}

	for (i=0;i<N;i++)
	{// to ensure that the final h2[i] is greater than h1[i]
		h2[i] = h1[i]+h2[i];
	}

	double is = atan( tan(incl)/sin(decl) );
	
	double xfn[mmv_N_of_body];
	double Ha[mmv_data_len];
	double Za[mmv_data_len];
	double r1_2[mmv_data_len];
	double r2_2[mmv_data_len];

	for (i=0;i<mmv_data_len;i++)
	{
		Ha[i] = 0.0;
		Za[i] = 0.0;
	}

	for (i=0;i<N;i++)
	{
		xfn[i] = xf+i*b;

		for (int j=0;j<mmv_data_len;j++)
		{
			r1_2[j] = (h1[i]-z[j])*(h1[i]-z[j]) +
				(xx[j]-xfn[i])*(xx[j]-xfn[i]);

			r2_2[j] = (h2[i]-z[j])*(h2[i]-z[j]) +
				(xx[j]-xfn[i])*(xx[j]-xfn[i]);
		}

		for (j=0;j<mmv_data_len;j++)
		{
			Ha[j] = Ha[j] - 4*b*Js*( (xx[j]-xfn[i])*(1/r1_2[j]-1/r2_2[j])*sin(is) +
				((h1[i]-z[j])/r1_2[j]-(h2[i]-z[j])/r2_2[j])*cos(is) );

			Za[j] = Za[j] - 4*b*Js*( (xx[j]-xfn[i])*(1/r1_2[j]-1/r2_2[j])*cos(is) -
				((h1[i]-z[j])/r1_2[j]-(h2[i]-z[j])/r2_2[j])*sin(is) );
		}
	}

	for (int j=0;j<mmv_data_len;j++)
	{
		T[j] = Ha[j]*cos(incl)*cos(decl) + Za[j]*sin(incl);
	}
}

void CProblemDef::mmvplate_fitness(double *xreal, tFitness &obj, double *constr)
{
	if (init_one == 0)
	{
		init_one = 1;
		printf("The data is initialized only once.\n");

		mmv_init_parameters();
	
		double x0[2*mmv_N_of_body+1];
		if (mmv_N_of_body == 4)
		{
			double a[9] = {10, 
				4.0, 3.5, 3.0, 2.5, 
				4.0, 4.0, 4.0, 4.0};
//			double a[9] = {25, 
//				3.0, 3.5, 4.0, 4.5, 
//				4.5, 4.0, 3.5, 3.0};

			for (int i=0;i<2*mmv_N_of_body+1;i++)
			{
				x0[i] = a[i];
			}
		}
		else if (mmv_N_of_body == 12)
		{
			double a[25] = {10,
				4.0, 3.5, 3.0, 3.0, 4.0, 5.0, 4.0, 3.0, 2.0, 1.5, 2.0, 3.0,
				1.5, 2.0, 4.0, 5.0, 3.5, 2.5, 4.0, 5.5, 3.5, 4.5, 3.5, 1.5};

			for (int i=0;i<2*mmv_N_of_body+1;i++)
			{
				x0[i] = a[i];
			}
		}	

		// generate the original data
		mmvplate(x0, Mag_org);
	}

	// calculate the inversion data
	double T[mmv_data_len];
	mmvplate(xreal, T);

	// calculate the fitness value
	double fitness;
	fitness = 0.0;
	for (int j=0;j<mmv_data_len;j++)
	{
		fitness += (T[j]-Mag_org[j])*(T[j]-Mag_org[j])/((double)mmv_data_len);
	}
	fitness = sqrt(fitness);

	obj = fitness;
}



