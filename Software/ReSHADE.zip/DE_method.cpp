// DE_method.cpp: implementation of the CDE_method class.
//
//////////////////////////////////////////////////////////////////////

#include "DE_method.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDE_method::CDE_method()
{
	pop_size     = population_size;
	
	/************************************************************************/
	/* default parameter settings for DE method                             */
	/************************************************************************/
	m_F				= 0.5;
	m_CR			= 0.9;
	m_strategy		= 1;		// DE/rand/1/bin
	
	JADE_mu_CR		= 0.5;
	JADE_mu_FF		= 0.5;
	
	JADE_c			= 0.1;
	JADE_p			= 0.05;	// 0.05 ~ 0.2
	archive_size	= 0;
}

CDE_method::~CDE_method()
{
}

void CDE_method::init_variables()
{
	if ((CIndividual::index_of_normal) == 0)
	{
		printf("Are you kidding me?\nThere is no function to be optimized.\n");
		exit(0);
	}

	if (CIndividual::index_of_normal != 0)
	{
		init_normal_variables();
	}

	max_interval = 0;
	double temp;
	for (int i=0;i<N_of_x;i++)
	{
		temp = upper_bounds[i]-lower_bounds[i];
		max_interval += temp*temp;
	}
	max_interval = sqrt(max_interval);
}

void CDE_method::init_normal_variables()
{
	int i;
	int n = N_of_x;
	func_flag = CIndividual::index_of_normal;

	switch(func_flag) {
	case 1:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -100.0;
			upper_bounds[i] = 100.0;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 2:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -100.0;
			upper_bounds[i] = 100.0;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 3:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -100.0;
			upper_bounds[i] = 100.0;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 4:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -100.0;
			upper_bounds[i] = 100.0;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 5:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -30.0;
			upper_bounds[i] = 30.0;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 6:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -100.0;
			upper_bounds[i] = 100.0;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 7:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -1.28;
			upper_bounds[i] = 1.28;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 8:// -418.982887272434*D
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -500.0;
			upper_bounds[i] = 500.0;
		}
		known_optimal = 0.0;	// 7.27595761418343e-012
		MINIMIZE = 1;
		break;
	case 9:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -5.12;
			upper_bounds[i] = 5.12;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 10:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -32.0;
			upper_bounds[i] = 32.0;
		}
		known_optimal = 5.88721779659630e-016;
		MINIMIZE = 1;
		break;
	case 11:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -600.0;
			upper_bounds[i] = 600.0;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 12:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -50.0;
			upper_bounds[i] = 50.0;
		}
		known_optimal = 1.57044103551778e-032;
		MINIMIZE = 1;
		break;
	case 13:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -50.0;
			upper_bounds[i] = 50.0;
		}
		known_optimal = 1.34969464963993e-032;
		MINIMIZE = 1;
		break;
	case 14:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -100.0;
			upper_bounds[i] = 100.0;
		}
		known_optimal = 0;
		MINIMIZE = 1;
		break;
	case 15:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = 0.0;
			upper_bounds[i] = PI;
		}
		known_optimal = 0;
		MINIMIZE = 1;
		break;
	case 16:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -100.0;
			upper_bounds[i] = 100.0;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 17:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -100;
			upper_bounds[i] = 100;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 18:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -100;
			upper_bounds[i] = 100;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 19:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -5;
			upper_bounds[i] = 5;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 20:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -1;
			upper_bounds[i] = 1;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 21:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -N_of_x*N_of_x;
			upper_bounds[i] = N_of_x*N_of_x;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 22:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -15;
			upper_bounds[i] = 15;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 23:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = 2;
			upper_bounds[i] = 10;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 24:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = 0;
			upper_bounds[i] = PI;
		}
		known_optimal = 0;
		MINIMIZE = 1;
		break;
	case 25:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -100;
			upper_bounds[i] = 100;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 26:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -0.5;
			upper_bounds[i] = 0.5;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 27:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -5.12;
			upper_bounds[i] = 5.12;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 28:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -10.0;
			upper_bounds[i] = 10.0;
		}
		known_optimal = 0;
		MINIMIZE      = 1;
		break;
	case 29:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -5.0;
			upper_bounds[i] = 5.0;
		}
		known_optimal = 0;
		MINIMIZE      = 1;
		break;
	case 30:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -100.0;
			upper_bounds[i] = 100.0;
		}
		known_optimal = 0;
		MINIMIZE      = 1;
		break;
	case 31:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -100.0;
			upper_bounds[i] = 100.0;
		}
		known_optimal = 0;
		MINIMIZE      = 1;
		break;
	case 32:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -N_of_x;
			upper_bounds[i] = N_of_x;
		}
		known_optimal = 0;
		MINIMIZE      = 1;
		break;

	case 46: // Chebychev Polynomial problem
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -pow(2.0, N_of_x);
			upper_bounds[i] = pow(2.0, N_of_x);
		}
		known_optimal = 0;
		MINIMIZE      = 1;
		break;
	case 47: // FM Sound Waves' problem
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -6.4;
			upper_bounds[i] = 6.35;
		}
		known_optimal = 0;
		MINIMIZE      = 1;
		break;
	case 48: // Spread Spectrum Radar Polyphase Code Design problem
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = 0.0;
			upper_bounds[i] = 2.0*PI;
		}
		known_optimal = -INF;// unknown...
		MINIMIZE      = 1;
		break;
	case 49: // The inversion problem
		lower_bounds[0] = 0.0;
		upper_bounds[0] = 50.0;
		for (i=1;i<N_of_x;i++)
		{
			lower_bounds[i] = 0.0;
			upper_bounds[i] = 10.0;
		}
		known_optimal = 0;
		MINIMIZE      = 1;
		break;
	default:
		printf("The function you selected does not exist.\n");
		exit(0);
	}
}

void CDE_method::init_pop()
{
	printf("Random based parent_pop initialization method is used.\n");
	init_pop_random();

	// initialize the F and CR of DE
	for (int i=0;i<pop_size;i++)
	{
		parent_pop[i].F        = m_rnd.rndreal(0.1, 1.0);
		parent_pop[i].CR       = m_rnd.rndreal(0.0, 1.0);
		parent_pop[i].accepted = 0;
	}
}

void CDE_method::init_pop_random()
{
	int i, j;
	for (i=0;i<pop_size;i++)
	{
		// for bounded problem
		for (j=0;j<N_of_x;j++)
		{
			parent_pop[i].xreal[j] = m_rnd.rndreal(lower_bounds[j],upper_bounds[j]);
			parent_pop[i].eta[j]   = 3.0;
		}
	}
}

void CDE_method::evaluate_ind(CIndividual &indv)
{
	if (CIndividual::index_of_normal != 0)
	{
		evaluate_normal_ind(indv);
	}

	// convert objective function value into fitness
	indv.fitness = MINIMIZE*indv.obj;

	// sum violation of the constrained functions
	if (N_of_constr == 0)
	{
		indv.constr_violation = 0.0;
		indv.feasible = 1;
	}
}

void CDE_method::evaluate_normal_ind(CIndividual &indv)
{
	func_flag = CIndividual::index_of_normal;

	m_func.evaluate_normal_fitness(indv.xreal,indv.obj,indv.constr,
		func_flag, evaluations);
}

void CDE_method::evaluate_pop(CIndividual *pop, int size)
{
	for (int i=0;i<size;i++)
	{
		evaluate_ind(pop[i]);
	}
}

int CDE_method::compare_ind (CIndividual *indv1, CIndividual *indv2)
{
	if((indv1->feasible==TRUE && indv2->feasible==TRUE))
	{
		if(indv1->fitness < indv2->fitness)
		{
			return 1;
		}
		else if (indv1->fitness > indv2->fitness)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
	else if(indv1->feasible==TRUE && indv2->feasible==FALSE)
	{
		return 1;
	}
	else if (indv1->feasible==FALSE && indv2->feasible==TRUE)
	{
		return -1;
	}
	else
	{
		if(indv1->constr_violation < indv2->constr_violation)
		{
			return 1;
		}
		else if (indv1->constr_violation > indv2->constr_violation)
		{
			return -1;
		}
		else
		{
			//return 0;
			if (indv1->fitness < indv2->fitness)
			{
				return 1;
			}
			else if (indv1->fitness > indv2->fitness)
			{
				return -1;
			}
			else
			{
				return 0;
			}
		}
	}
}

void CDE_method::find_best_index(CIndividual *pop, int size)
{
	int flag;

	best_index = 0;
	for (int i=1;i<size;i++)
	{
		flag = compare_ind(&pop[i], &pop[best_index]);
		if (flag == 1)
		{
			best_index = i;
		}
	}

	worst_index = 0;
	for (i=1;i<size;i++)
	{
		flag = compare_ind(&pop[i], &pop[worst_index]);
		if (flag == -1)
		{
			worst_index = i;
		}
	}
}

void CDE_method::random_index(int *array_index, int all_size, int size)
{
	int i,j,krand;
	int *a;
	a = new int[all_size];

	for(i = 0;i<all_size;i++)
	{
		a[i] = i;
	}
	for(i=0;i<size;i++)
	{
		j     = m_rnd.rndint(i,(all_size-1));
		krand = a[i];
		a[i]  = a[j];
		a[j]  = krand;
	}	
	for(i=0;i<size;i++)
	{
		array_index[i] = a[i];
	}

	//a = NULL;
	delete []a;
}

void CDE_method::shell_sort_pop(CIndividual *pop, int *list, int size)
{
	int done;
	int step, bound, i, j;
	int temp;

	for (i=0;i<size;i++)
	{
		list[i] = i;
	}

	step = size;  // array length
	while (step > 1) 
	{
		step /= 2;	//halve the step size
		do 
		{
			done   = 1;
			bound  = size - step;
			for (j = 0; j < bound; j++) 
			{
				i = j + step + 1;
				if (compare_ind(&pop[list[j]], &pop[list[i-1]]) == -1) 	
				{
					temp      = list[i-1];
					list[i-1] = list[j];
					list[j]   = temp;
					done      = 0; // if a swap has been made we are not finished yet
				}  // if
			}  // for
		} while (done == 0);   // while
	} //while (step > 1)
}

void CDE_method::shell_sort_array(double *array, int *list, int size)
{
	int done;
	int step, bound, i, j;
	int temp;

	for (i=0;i<size;i++)
	{
		list[i] = i;
	}

	step = size;  // array length
	while (step > 1) 
	{
		step /= 2;	//halve the step size
		do 
		{
			done   = 1;
			bound  = size - step;
			for (j = 0; j < bound; j++) 
			{
				i = j + step + 1;
				if (array[list[j]] > array[list[i-1]]) 	
				{
					temp      = list[i-1];
					list[i-1] = list[j];
					list[j]   = temp;
					done      = 0; // if a swap has been made we are not finished yet
				}  // if
			}  // for
		} while (done == 0);   // while
	} //while (step > 1)
}

void CDE_method::shell_sort_array_t(tFitness *array, int *list, int size)
{
	int done;
	int step, bound, i, j;
	int temp;

	for (i=0;i<size;i++)
	{
		list[i] = i;
	}

	step = size;  // array length
	while (step > 1) 
	{
		step /= 2;	//halve the step size
		do 
		{
			done   = 1;
			bound  = size - step;
			for (j = 0; j < bound; j++) 
			{
				i = j + step + 1;
				if (array[list[j]] > array[list[i-1]]) 	
				{
					temp      = list[i-1];
					list[i-1] = list[j];
					list[j]   = temp;
					done      = 0; // if a swap has been made we are not finished yet
				}  // if
			}  // for
		} while (done == 0);   // while
	} //while (step > 1)
}

double CDE_method::median(double *array, int size)
{
	double value = 0.0;

	int list[2000];
	for (int i=0;i<2000;i++)
	{
		list[i] = i;
	}
	shell_sort_array(array, list, size);
	
	if (size%2 == 1)
	{// the size of the array is odd.
		int media_index;
		media_index = size/2;
		value = array[list[media_index]];
	}
	else
	{// the size of the array is even.
		int a = (size-1)/2;
		int b = size/2;
		value = (array[list[a]]+array[list[b]])/2.0;
	}

	return value;
}

double CDE_method::mean_std(double *array, int size, double &stdv)
{
	double value = 0.0;

	assert(size > 0);

	for (int i=0;i<size;i++)
	{
		value += array[i];
	}
	value = value/((double)size);

	stdv = 0.0;
	for (i=0;i<size;i++)
	{
		stdv += (array[i]-value)*(array[i]-value);
	}
	stdv = sqrt(stdv/((double)size-1));

	return value;
}

tFitness CDE_method::mean_std_t(tFitness *array, int size, tFitness &stdv)
{
	tFitness value = 0.0;

	assert(size > 0);

	for (int i=0;i<size;i++)
	{
		value += array[i];
	}
	value = value/((double)size);

	stdv = 0.0;
	for (i=0;i<size;i++)
	{
		stdv += (array[i]-value)*(array[i]-value);
	}
	stdv = sqrt(stdv/((double)size-1));

	return value;
}

void CDE_method::display_result(long int gen)
{
	if(gen%10==0 || gen == 1)
	{
		//???????????
		cout<<setw(5)<<gen;
		cout<<setw(8)<<evaluations;
		//????????
		if (N_of_constr != 0)
		{			
			cout<<setw(15)<<best_individual.constr_violation;
		}
		cout.precision(10);					//??????
		cout<<setw(20)<<MINIMIZE * parent_pop[best_index].fitness;
		cout<<setw(20)<<MINIMIZE * parent_pop[m_rnd.rndint(0, pop_size-1)].fitness;
		cout<<setw(20)<<MINIMIZE * parent_pop[worst_index].fitness<<endl;
	}
}

void CDE_method::report_result(long int gen, ofstream &file)
{
	if (gen < 5 )
	{
		//???????????
		file<<setw(5)<<gen;
		file<<setw(10)<<evaluations;
		file.precision(20);			//??????
		file<<setw(30)<<MINIMIZE * best_individual.fitness;
		file<<setw(30)<<best_individual.constr_violation;
		//file<<setw(30)<<best_individual.CR;
		file<<endl;
	}
	else
	{
		if ((gen % (max_iterations/out_internal) == 0 ||
			gen >= max_iterations ||
			evaluations >= max_NFFEs) )
		{
			//???????????
			file<<setw(5)<<gen;
			file<<setw(10)<<evaluations;
			file.precision(20);			//??????
			file<<setw(30)<<MINIMIZE * best_individual.fitness;
			file<<setw(30)<<best_individual.constr_violation;
			//file<<setw(30)<<best_individual.CR;
			file<<endl;
		}
	}
}

void CDE_method::report_diversity(long int gen, ofstream &file)
{
	// calculate the diversity of the population
	double x_average[2000];
	for (int i=0;i<2000;i++)
	{
		x_average[i] = 0.0;
	}

	for (i=0;i<N_of_x;i++)
	{
		for (int j=0;j<pop_size;j++)
		{
			x_average[i] += parent_pop[j].xreal[i];
		}
		x_average[i] = x_average[i]/((double)pop_size);
	}

	double diversity = 0.0;
	for (i=0;i<pop_size;i++)
	{
		double temp = 0.0;
		double x;
		for (int j=0;j<N_of_x;j++)
		{
			x = parent_pop[i].xreal[j];
			temp += (x-x_average[j])*(x-x_average[j]);
		}
		diversity += sqrt(temp);
	}
	diversity = diversity/(((double)pop_size)*max_interval);

	pop_diversity = diversity;
	if (gen==1)	pop_diversity0 = pop_diversity;
	
	if (gen < 100 )
	{
		//???????????
		file<<setw(5)<<gen;
		file<<setw(10)<<evaluations;
		file.precision(20);			//??????
		file<<setw(30)<<diversity<<endl;
	}
	else
	{
		if ((gen % out_internal == 0 ||
			gen >= max_iterations ||
			evaluations >= max_NFFEs) )
		{
			//???????????
			file<<setw(5)<<gen;
			file<<setw(10)<<evaluations;
			file.precision(20);			//??????
			file<<setw(30)<<diversity<<endl;
		}
	}
}

void CDE_method::report_parameter(long int gen, ofstream &file)
{	
	int counter = max_iterations/20;
	if (method_flag==2 || method_flag==0 )
	{
		if (gen <=10 || gen%counter == 0)
		{
			//???????????
			file<<setw(5)<<gen;
			file<<setw(10)<<evaluations;
			file.precision(20);			//??????
			file<<setw(30)<<JADE_mu_CR;
			file<<setw(30)<<JADE_mu_FF;
			file<<setw(30)<<"0";
			file<<endl;
		}
	}
	else
	{
		if (gen <=10 || gen%counter == 0)
		{
			//???????????
			file<<setw(5)<<gen;
			file<<setw(10)<<evaluations;
			file.precision(20);			//??????
			file<<setw(30)<<best_individual.CR;
			file<<setw(30)<<best_individual.F;
			file<<setw(30)<<"0";
			file<<endl;
		}
	}
}

void CDE_method::sort_pop(CIndividual *pop, int size)
{
	for (int i=0;i<size;i++)
	{
		sort_index[i] = i;
	}
	shell_sort_pop(pop, sort_index, size);
}

// copy files from the source directory to the target directory
void CDE_method::copy_files(char *source, char *target)
{
	FILE *fs,*ft;
	char ma[204];
	unsigned int rd=0;

	fs=fopen(source, "rb");
	ft=fopen(target, "wb"); 
	if (fs&&ft) 
	{
		while (!feof(fs))
		{
			rd=fread(ma,sizeof(char),204,fs);
			fwrite(ma,sizeof(char),rd,ft);
		}
		fclose(fs);
		fclose(ft);
	}
}

long CDE_method::filesize(FILE *stream)
{
	long curpos, length;
	curpos = ftell(stream);
	fseek(stream, 0L, SEEK_END);
	length = ftell(stream);
	fseek(stream, curpos, SEEK_SET);
	return length;
}

int CDE_method::copyfile(const char* src,const char* dest)
{
	FILE *fp1,*fp2;
	int fsize,factread;
	static unsigned char buffer[SIZEOFBUFFER];

	fp1=fopen(src,  "rb");
	fp2=fopen(dest, "wb+");
	if (!fp1 || !fp2) 
	{
		return 0;
	}

    for (fsize=filesize(fp1);fsize>0;fsize-=SIZEOFBUFFER)
    {
		factread=fread(buffer,1,SIZEOFBUFFER,fp1);
		fwrite(buffer,factread,1,fp2);
    }
	fclose(fp1);
	fclose(fp2);
	return 1;
}

// create folders, only for batch execution
void CDE_method::create_folders(int method_ii, int strategy_ii)
{
	int status;
	int func_index;
	if (CIndividual::index_of_normal)	func_index = CIndividual::index_of_normal;

	/************************************************************************/
	/* Create the zero-order folders: function level                         */
	/************************************************************************/
	char f_name_0[150];
	// set the folder name
	sprintf(f_name_0,"%s%s%d", ".\\results", (func_index<10 ? "\\f0" : "\\f"), func_index);

	// create the folders
	status = mkdir(f_name_0);
	//if (!status==0)	printf("Unable to create directory 1\n");
	/************************************************************************/

	/************************************************************************/
	/* Create the first-order folders: method level                         */
	/************************************************************************/
	char f_name0[150];
	// set the folder name
	sprintf(f_name0,"%s%s%d%s%d", ".\\results", (func_index<10 ? "\\f0" : "\\f"), func_index, "\\algorithm_", method_ii);

	// create the folders
	status = mkdir(f_name0);
	//if (!status==0)	printf("Unable to create directory 1\n");
	/************************************************************************/

	/************************************************************************/
	/* Create the second-order folders: strategy level                      */
	/************************************************************************/
	char f_name00[150];
	// set the folder name
	sprintf(f_name00,"%s%s%d%s%d%s%d", ".\\results", (func_index<10 ? "\\f0" : "\\f"), func_index, "\\algorithm_", method_ii, "\\strategy_", strategy_ii);

	// create the folders
	status = mkdir(f_name00);
	//if (!status==0)	printf("Unable to create directory 1\n");
	/************************************************************************/

	/************************************************************************/
	/* Copy the statistic file to the strategy_level folder                 */
	/************************************************************************/
	char source_file_name[150] = ".\\results\\1-DA-50.exe";
	char target_file_name[150];
	sprintf(target_file_name, "%s%s%d%s%d%s%d%s", ".\\results", (func_index<10 ? "\\f0" : "\\f"), func_index, "\\algorithm_", method_ii, "\\strategy_", strategy_ii, "\\1-DA-50.exe");
	//copy_files(source_file_name, target_file_name);
	copyfile(source_file_name, target_file_name);

	/************************************************************************/
	/* Create the third-order folders: results level                        */
	/************************************************************************/
	char f_name1[150];
	char f_name2[150];
	char f_name3[150];
	// set the folder name
	sprintf(f_name1, "%s%s%d%s%d%s%d%s", ".\\results", (func_index<10 ? "\\f0" : "\\f"), func_index, "\\algorithm_", method_ii, "\\strategy_", strategy_ii, "\\process");
	sprintf(f_name2, "%s%s%d%s%d%s%d%s", ".\\results", (func_index<10 ? "\\f0" : "\\f"), func_index, "\\algorithm_", method_ii, "\\strategy_", strategy_ii, "\\diversity");
	sprintf(f_name3, "%s%s%d%s%d%s%d%s", ".\\results", (func_index<10 ? "\\f0" : "\\f"), func_index, "\\algorithm_", method_ii, "\\strategy_", strategy_ii, "\\migration");

	// create the folders
	status = mkdir(f_name1);
	//if (!status==0)	printf("Unable to create directory 2\n");
	status = mkdir(f_name2);
	//if (!status==0)	printf("Unable to create directory 3\n");
	status = mkdir(f_name3);
	//if (!status==0)	printf("Unable to create directory 4\n");
	/************************************************************************/
}

void CDE_method::Run_Optimizer(int func_flag, int run_no, double seed, int method, int strategy_ii)
{
	pop_size = 100;

	switch(method) {
	case 1:
		printf("Algorithm: ReSHADE_method.\n");
		break;
	default:
		printf("The method does not exist!\n");
		exit(0);
	}

	if (func_flag>=1 && func_flag<=50)
	{
		CIndividual::index_of_normal	= func_flag;
		CIndividual::Max_of_NFEs		= 100000;
		
		max_iterations = CIndividual::Max_of_NFEs/pop_size;
		max_NFFEs      = CIndividual::Max_of_NFEs;
	}
	else
	{
		printf("The function to be optimized is not defined!\n");
		exit(0);
	}

	m_strategy   = strategy_ii;

	if (batch_execution==1)
	{
		create_folders(method, strategy_ii);
	}

	/*if (m_strategy==1)
	{
		printf("Strategy:  rand/1/bin.\n");
	}*/
	
	int i = 0; 
	
	method_flag = method;
	rnd_seed    = seed;
	
	int func_index;
	if (CIndividual::index_of_normal)	func_index = CIndividual::index_of_normal;
	
	ofstream SummaryFile;
	char     f_name0[150];
	if (batch_execution==0)	
	{
		SummaryFile.open(".\\results\\summary.txt",ios::app);
	}
	if (batch_execution==1) 
	{
		sprintf(f_name0, "%s%s%d%s%d%s%d%s", ".\\results", (func_index<10 ? ".\\f0" : ".\\f"), func_index, ".\\algorithm_", method, ".\\strategy_", strategy_ii, ".\\summary.txt");
		SummaryFile.open(f_name0, ios::app);
	}

	char f_name1[150];
	if (batch_execution==0)	
	{
		sprintf(f_name1,"%s%d%s",".\\results\\process\\process_",run_no+1,".txt");	
	}
	if (batch_execution==1) 
	{
		sprintf(f_name1, "%s%s%d%s%d%s%d%s%d%s", ".\\results", (func_index<10 ? ".\\f0" : ".\\f"), func_index, ".\\algorithm_", method, ".\\strategy_", strategy_ii, ".\\process/process_" ,run_no+1,".txt");
	}
	ofstream file_process(f_name1);

	char f_name2[150];
	if (batch_execution==0)	
	{
		sprintf(f_name2,"%s%d%s",".\\results\\diversity\\diversity_",run_no+1,".txt");	
	}
	if (batch_execution==1) 
	{
		sprintf(f_name2, "%s%s%d%s%d%s%d%s%d%s", ".\\results", (func_index<10 ? ".\\f0" : ".\\f"), func_index, ".\\algorithm_", method, ".\\strategy_", strategy_ii, ".\\diversity/diversity_",run_no+1,".txt");
	}
	ofstream file_diversity(f_name2);

	char f_name3[150];
	if (batch_execution==0)	
	{
		sprintf(f_name3,"%s%d%s",".\\results\\migration\\migration_",run_no+1,".txt");	
	}
	if (batch_execution==1) 
	{
		sprintf(f_name3, "%s%s%d%s%d%s%d%s%d%s", ".\\results", (func_index<10 ? ".\\f0" : ".\\f"), func_index, ".\\algorithm_", method, ".\\strategy_", strategy_ii, ".\\migration/migration_",run_no+1,".txt");
	}
	ofstream file_migration(f_name3);

	clock_t start, finish;
	double time_consume;

	time_consume = 0.0;
	start = clock();						// starts the clock
	
	srand((unsigned)time(0));
	m_rnd.randomize(seed);

	evaluations = 0;						// reset the NFFEs

	init_variables();	
	init_pop();
	evaluate_pop(parent_pop, pop_size);
	find_best_index(parent_pop, pop_size);
	best_individual = parent_pop[best_index];

	gen = 1;								// current generation number
	int counter=0;							// only for restarting the population

	report_result(gen, file_process);
	report_diversity(gen, file_diversity);
	report_parameter(gen, file_migration);

	int feasible_flag = 0;					// check to get the feasible individual first
	flag_precision = 0;						// check to arrive the required value
	/* -------- add different optimizer here -------- */
	while ( (evaluations < max_NFFEs) && (gen < max_iterations) )
	{
		finish = clock();					// time consuming of this generation
		time_consume = (double)(finish-start)/CLOCKS_PER_SEC;

		// report the results in the screen
		/* comment the following routines to save the time_consuming */
		//display_result(gen);
		
		// ADD YOUR OPTIMIZER HERE
		switch(method) {
		case 1:
			run_reflect_SHADE_method();
			break;
		default:
			printf("The method selected does not exist.\n");
			exit(0);
		}

		gen++;

		find_best_index(parent_pop, pop_size);
		
		if (compare_ind(&parent_pop[best_index], &best_individual) != -1)
		{
			best_individual = parent_pop[best_index];
		}
		
		report_result(gen, file_process);
		report_diversity(gen, file_diversity);
		report_parameter(gen, file_migration);

		if (flag_precision == 0 && 
			fabs(MINIMIZE*best_individual.fitness - known_optimal) < PRECISION
			&& best_individual.feasible == 1)
		{
			flag_precision = 1;
			ofstream SummaryFile1;
			char     f_name00[150];
			if (batch_execution==0)	
			{
				SummaryFile1.open(".\\results\\evaluations.txt",ios::app);	
			}
			if (batch_execution==1) 
			{
				sprintf(f_name00, "%s%s%d%s%d%s%d%s", ".\\results", (func_index<10 ? ".\\f0" : ".\\f"), func_index, ".\\algorithm_", method, ".\\strategy_", strategy_ii, ".\\evaluations.txt");
				SummaryFile1.open(f_name00, ios::app);
			}			
			SummaryFile1<<setw(9)<<evaluations<<endl;
			SummaryFile1.close();
			//break;		// ????????????????????
		}
		if (N_of_constr != 0 && feasible_flag == 0 && best_individual.feasible == 1)
		{
			feasible_flag = 1;
			ofstream SummaryFile1;
			SummaryFile1.open(".\\results\\feasible_NFFEs.txt",ios::app);
			SummaryFile1<<setw(9)<<evaluations<<endl;
			SummaryFile1.close();
		}
	}
	/* -------- add different optimizer here -------- */
	
	printf("The total running time is %f s.\n", time_consume);
	if (CIndividual::index_of_normal != 0)
	{
		printf("The routine in optimizing f(%d) exits successfully.\n\n", CIndividual::index_of_normal);
	}

	SummaryFile.precision(20);
	SummaryFile<<setw(5)<<gen<<setw(9)<<evaluations
		<<setw(25)<<MINIMIZE * best_individual.fitness
		<<setw(8)<<time_consume
		<<setw(25)<<best_individual.constr_violation<<endl;

	/*ofstream file_variable(".\\results\\x_variables.txt", ios::app);
	for (i=0;i<N_of_x;i++)
	{
		file_variable.precision(8);
		file_variable<<setw(15)<<best_individual.xreal[i];
	}
	file_variable<<endl;
	file_variable.close();*/

	/*ofstream final_pop(".\\results\\pop.txt");
	final_pop.precision(8);
	for (int i=0;i<pop_size;i++)
	{
		for (int j=0;j<N_of_x;j++)
		{
			final_pop<<setw(15)<<parent_pop[i].xreal[j];
		}
		final_pop<<setw(15)<<parent_pop[i].fitness<<endl;
	}
	final_pop.close();*/
	file_process.close();
	file_diversity.close();
	file_migration.close();
	SummaryFile.close();
	
	//return;
}

/************************************************************************/
/* For reflection-based DE                                              */
/************************************************************************/
int CDE_method::reflection_find_worst_index(int *t_index, int t_size)
{
	int t_worst_index = -1;
	int i;
	
	t_worst_index = t_index[0];
	for (i=1; i<t_size; i++)
	{
		if (parent_pop[t_index[i]].fitness > parent_pop[t_worst_index].fitness)
		{
			t_worst_index = t_index[i];
		}
	}
	
	return t_worst_index;
}

int CDE_method::reflection_find_best_index(int *t_index, int t_size)
{
	int t_best_index = -1;
	int i;
	
	t_best_index = t_index[0];
	for (i=1; i<t_size; i++)
	{
		if (parent_pop[t_index[i]].fitness < parent_pop[t_best_index].fitness)
		{
			t_best_index = t_index[i];
		}
	}
	
	return t_best_index;
}

void CDE_method::generate_coefficients(double *coef, int size)
{
	double	MaxA = 1.0, MinA = 0.0;
	double	sumA = 0.0, tmpMin, tmpMax, mt1;
	int		i;
	for (i=0; i<size-1;i++)
	{
		mt1		= size-i;
		tmpMin	= 1-sumA-MaxA*mt1;
		tmpMax	= 1-sumA-MinA*mt1;

		if(tmpMin<MinA) tmpMin = MinA;
		if(tmpMax>MaxA) tmpMax = MaxA;

		coef[i]	= m_rnd.rndreal(tmpMin,tmpMax);
		sumA	= sumA+coef[i];
	}
	coef[size-1] = 1.0-sumA;
}

void CDE_method::relfection_center(int *t_index, int t_size, int t_worst_index, double *x_center)
{
	int j, k;
	
	for (j=0;j<N_of_x;j++)
	{// calculate the center of the best points
		x_center[j] = 0;
		for (k=0; k<t_size; k++)
		{
			if (t_index[k] != t_worst_index)
			{
				x_center[j] += parent_pop[t_index[k]].xreal[j];
			}
		}
		x_center[j] /= (t_size-1);
	}
}

void CDE_method::relfection_center(int *t_index, int t_size, int t_worst_index, int t_best_index, double *x_center)
{
	int		j, k;
	double	coef[100];

	generate_coefficients(coef, t_size-2);
	int		tt = 0;
	for (j=0;j<N_of_x;j++)
	{// calculate the center of the best points
		x_center[j] = 0;
		tt			= 0;
		for (k=0; k<t_size; k++)
		{
			if (t_index[k] != t_worst_index && t_index[k] != t_best_index)
			{
				x_center[j] += coef[tt] * parent_pop[t_index[k]].xreal[j];
				tt++;
			}
		}
	}
	
// 	for (j=0;j<N_of_x;j++)
// 	{// calculate the center of the best points
// 		x_center[j] = 0;
// 		for (k=0; k<t_size; k++)
// 		{
// 			if (t_index[k] != t_worst_index && t_index[k] != t_best_index)
// 			{
// 				x_center[j] += parent_pop[t_index[k]].xreal[j];
// 			}
// 		}
// 		x_center[j] /= (t_size-2);
// 	}
}

void CDE_method::run_reflect_SHADE_method()
{
	int    i, j;
	int    r1, r2, r3=-1, r4=-1, r0=-1;
	double low, up;

	double FF[population_size];
	double CR[population_size];
	double indv_prob[population_size];

	/* Step 1: Initialize the JADE-related parameters */
	int    archive_index=-1;	// if r3 is chosen from archive archive_index=1, else =0
	int    p_index = -1;
	if (gen == 1)
	{
		/* Initialize the historical memory of CR and F */
		for (i=0; i<pop_size; i++)
		{
			SHADE_M_CR_FF[i][0] = 0.5;
 			SHADE_M_CR_FF[i][1] = 0.5;
		}

		JADE_p       = 2.0/(double)pop_size;
		archive_size = 0;
	}
	/*------------------------------------------------*/

	sort_pop(parent_pop, pop_size);
	for (i=0;i<pop_size;i++)
	{
		indv_prob[sort_index[i]] = ((double)(pop_size-i))/pop_size;
	}

	/* Generate the CR and F values */
	for (i=0;i<pop_size;i++)
	{
		// select mu_CR and mu_F from the memory
		int kk     = m_rnd.rndint(0, pop_size-1);
		JADE_mu_CR = SHADE_M_CR_FF[kk][0];
		JADE_mu_FF = SHADE_M_CR_FF[kk][1];

		// generate F value for each individual (individual level)
		do {
			FF[i] = m_rnd.cauchy(JADE_mu_FF, 0.1);
		} while (FF[i] <= 0.0);
		if (FF[i] > 1.0)	FF[i] = 1.0;

		// generate CR value for each dimension of each individual (component level)
		if (JADE_mu_CR == -1)
		{
			CR[i] = 0.0;
		}
		else
		{
			CR[i] = m_rnd.gaussian(JADE_mu_CR, 0.1);
			if (CR[i] < 0.0)	CR[i] = 0.0;
			if (CR[i] > 1.0)	CR[i] = 1.0;
		}
	}

	// the minimal value of p
	double p_min = 2.0/(double)pop_size;
	
	double		x_center[N_of_x];
	int			t_size, t_index[100];
	int			t_worst_index=-1, t_best_index=-1, t_median_index=-1;	

	for (i=0;i<pop_size;i++)
	{		
		/************************************************************************/
		/* mutation                                                             */
		// M1: randomly choose the p_best individual		
		JADE_p  = m_rnd.rndreal(p_min, 0.2);					// random generation of p
		p_index = m_rnd.rndint(0, int(JADE_p*pop_size)-1);
		p_index = sort_index[p_index];

		// M2: select different parents based on the corresponding mutation strategy
		do {
			r1 = m_rnd.rndint(0, pop_size-1);
		} while (r1 == i);// || r1==p_index);
		do {
			r2 = m_rnd.rndint(0, pop_size-1);
		} while(r2 == i || r2 == r1);// || r2==p_index);
		do { 
			r3 = m_rnd.rndint(0, pop_size-1);
		} while(r3 == i || r3 == r2 || r3 == r1);// || r3==p_index);
		do { 
			r4 = m_rnd.rndint(0, pop_size-1);
		} while(r4 == i || r4 == r3 || r4 == r2 || r4 == r1);
		
		t_size = 4;
		t_index[0] = p_index;	t_index[1]		= r1;		t_index[2] = r2;		t_index[3] = r3;	t_index[4] = r4;

		// M3: find the best and worst indices
		t_worst_index	= reflection_find_worst_index(t_index, t_size);
		t_best_index	= reflection_find_best_index(t_index, t_size);
		
		// M4: calculate the center
		//relfection_center(t_index, t_size, t_worst_index, x_center);
		relfection_center(t_index, t_size, t_worst_index, t_best_index, x_center);
	
		do { 
			r0 = m_rnd.rndint(0, pop_size-1);
		} while(!m_rnd.flip(indv_prob[r0]) || r0 == i || r0==r4 || r0 == r3 || r0 == r2 || r0 == r1);// || r3==p_index);
		
		// M5: reflection-based mutation
		int t_flag = 0;

		if (parent_pop[t_worst_index].fitness<parent_pop[r0].fitness)
		{
			t_flag = 1;
		}
 		
		for (j=0;j<N_of_x;j++)
		{// reflection
			low = lower_bounds[j];
			up  = upper_bounds[j];
					
			if (1==t_flag)
			{
				child_pop[i].xreal[j] = x_center[j] + FF[i] * (parent_pop[t_worst_index].xreal[j] - parent_pop[r0].xreal[j]) 
					+ FF[i] * (parent_pop[t_best_index].xreal[j] - x_center[j]);
			}
			else
			{
				child_pop[i].xreal[j] = x_center[j] + FF[i] * (parent_pop[r0].xreal[j] - parent_pop[t_worst_index].xreal[j]) 
					+ FF[i] * (parent_pop[t_best_index].xreal[j] - x_center[j]);
			}
			
			if (child_pop[i].xreal[j] < low || child_pop[i].xreal[j] > up)
			{
				child_pop[i].xreal[j] = m_rnd.rndreal(low, up);
			}
		}
		/************************************************************************/

		/* crossover													        */
		int j_rand = m_rnd.rndint(0, N_of_x-1);
		for (j=0;j<N_of_x;j++)
		{
			low = lower_bounds[j];
			up  = upper_bounds[j];
			
			if (m_rnd.rndreal(0,1)<CR[i] || j==j_rand)
			{
				child_pop[i].xreal[j] = child_pop[i].xreal[j];
			}
			else
			{
				child_pop[i].xreal[j] = parent_pop[i].xreal[j];
			}
		}
		/************************************************************************/
	}

	evaluate_pop(child_pop, pop_size);

	double   SS_FF[population_size], SS_CR[population_size];
	tFitness SS_reward[population_size], rr;
	int      SS_size = 0;						// The successful size of S_CR and S_F
	for (i=0;i<pop_size;i++)
	{
		int flag = compare_ind(&child_pop[i], &parent_pop[i]);

		/* save the successful CR and F values */
		if (flag == 1)
		{
			// get the absolute fitness improvement
			rr = parent_pop[i].fitness - child_pop[i].fitness; // for minimization

			/* Step 3: Update the accepting flag and store the successful CR and F values */
			SS_FF[SS_size]     = FF[i];
			SS_CR[SS_size]     = CR[i];
			SS_reward[SS_size] = rr;
			SS_size++;
			/*------------------------------------------------*/
			
			/************************************************************************/
			/* Save the inferior parent into the archive                            */
			/************************************************************************/
			if (archive_size < pop_size)
			{
				archive_pop[archive_size] = parent_pop[i];
				archive_size++;
			}
			else
			{
				archive_size = pop_size;
				
				int ii = m_rnd.rndint(0, archive_size-1);
				archive_pop[ii] = parent_pop[i];
			}
			/************************************************************************/
		}
		
		// update the parent_pop with the better offspring
		if (flag != -1)
		{
			parent_pop[i] = child_pop[i];
		}
	}
	
	/* Step 4: Update mu_CR and mu_F based on the successful CRs and Fs */
	if (SS_size != 0) 
	{
		int kk = (gen-1)%pop_size;
		
		// calculate the weights
		double weights[population_size], tmp_w = 0.0;
		for (i=0; i<SS_size; i++)
		{
			tmp_w += SS_reward[i];
		}
		assert(tmp_w != 0.0);
		for (i=0; i<SS_size; i++)
		{
			weights[i] = SS_reward[i]/tmp_w;		// !!! 2020-11-13 (weighted mean is better for F05, but slightly worse for F04, F15)    1.0/SS_size;//
		}
		
		// calculate the weighted mean of CR
		double mean_cr  = 0.0, tmp_cr = 0.0;	
		for (i=0;i<SS_size;i++)
		{
			tmp_cr += SS_CR[i];
		}
		if (SHADE_M_CR_FF[kk][0]==-1 || tmp_cr==0.0)
		{
			mean_cr = -1;
		}
		else
		{			
			for (i=0;i<SS_size;i++)
			{
				mean_cr += weights[i] * SS_CR[i];
			}
		}
		
		// calculate the weighted mean of FF
		double mean_ff = 0.0;
		double t1      = 0.0;
		double t2      = 0.0;
		for (i=0;i<SS_size;i++)
		{
			t1 += weights[i] * SS_FF[i]*SS_FF[i];
			t2 += weights[i] * SS_FF[i];
		}					
		mean_ff    = t1/t2;					// Lehmer mean
		
		// update the historical memory
		SHADE_M_CR_FF[kk][0] = mean_cr;
		SHADE_M_CR_FF[kk][1] = mean_ff;
	}
}






