// Individual.cpp: implementation of the CIndividual class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Individual.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CIndividual::CIndividual()
{
	xreal = new double[N_of_x];
	obj = new double[MAX];
	box = new double[MAX];
	constr = new double[MAX_CONSTRAINT];
	for (int i=0;i<N_of_x;i++)
	{
		xreal[i] = 0.0;
	}
	for (i=0;i<MAX;i++)
	{
		obj[i] = -1.0;
		box[i] = 0.0;
	}
	for (i=0;i<MAX_CONSTRAINT;i++)
	{
		constr[i] = 0.0;
	}
	constr_violation = 0.0;
	rank = -1;
	crowd_dist = 0.0;
	non_dominated = -1;
}

CIndividual::~CIndividual()
{
	delete []xreal;
	delete []obj;
	delete []box;
	delete []constr;
}

CIndividual::CIndividual(const CIndividual &t)
{
	if(&t == this)
	{
		return;
	}
	
	xreal = new double[N_of_x];
	obj = new double[MAX];
	box = new double[MAX];
	constr = new double[MAX_CONSTRAINT];
	for (int i=0;i<N_of_x;i++)
	{
		xreal[i] = t.xreal[i];
	}
	for (i=0;i<MAX;i++)
	{
		obj[i] = t.obj[i];
		box[i] = t.box[i];
	}
	for (i=0;i<MAX_CONSTRAINT;i++)
	{
		constr[i] = t.constr[i];
	}
	constr_violation = t.constr_violation;
	rank = t.rank;
	crowd_dist = t.crowd_dist;
	non_dominated = t.non_dominated;
}

CIndividual &CIndividual::operator = (const CIndividual &t)
{
	if(&t == this)
	{
		return *this;
	}
	
	if ((N_of_x != 0) && (xreal)) delete[] xreal;
	if((MAX != 0) && (obj)) delete[] obj;
	if((MAX != 0) && (box)) delete[] box;
	if((MAX_CONSTRAINT != 0) && (constr)) delete[] constr;

	xreal = new double[N_of_x];
	obj = new double[MAX];
	box = new double[MAX];
	constr = new double[MAX_CONSTRAINT];
	for (int i=0;i<N_of_x;i++)
	{
		xreal[i] = t.xreal[i];
	}
	for (i=0;i<MAX;i++)
	{
		obj[i] = t.obj[i];
		box[i] = t.box[i];
	}
	for (i=0;i<MAX_CONSTRAINT;i++)
	{
		constr[i] = t.constr[i];
	}
	constr_violation = t.constr_violation;
	rank = t.rank;
	crowd_dist = t.crowd_dist;
	non_dominated = t.non_dominated;

	return *this;
}
