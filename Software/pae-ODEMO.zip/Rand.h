// Rand.h: interface for the CRand class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_RAND_H__5FAB3528_87AB_4B23_9CF9_63BF7D4763D6__INCLUDED_)
#define AFX_RAND_H__5FAB3528_87AB_4B23_9CF9_63BF7D4763D6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRand  
{
public:
	CRand();
	virtual ~CRand();

public:
	// Variable declarations for the random number generator
	static double oldrand[55];
	static int jrand;

public:
	// Function declarations for the random number generator
	void   randomize(double seed);
	void   warmup_random (double seed);
	void   advance_random (void);
	double randomperc(void);
	int    rndint (int low, int high);			// integer value 0~n-1
	double rndreal (double low, double high);	// real value
	double normal();							// Gaussian random number generator
};

#endif // !defined(AFX_RAND_H__5FAB3528_87AB_4B23_9CF9_63BF7D4763D6__INCLUDED_)
