// ProblemDef.h: interface for the CProblemDef class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROBLEMDEF_H__0291FE55_E6EF_47CC_850D_954B71D6CA05__INCLUDED_)
#define AFX_PROBLEMDEF_H__0291FE55_E6EF_47CC_850D_954B71D6CA05__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Individual.h"

class CProblemDef  
{
public:
	CProblemDef();
	virtual ~CProblemDef();
	
	// -----------------------test problems-----------------------
public:
	void test_1_zdt6 (double *xreal,double *obj, double *constr);
};

#endif // !defined(AFX_PROBLEMDEF_H__0291FE55_E6EF_47CC_850D_954B71D6CA05__INCLUDED_)
