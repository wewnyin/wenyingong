// DEMO1.h: interface for the CDEMO1 class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_DEMO1_H__78C238E6_B3D2_4F22_8912_2549BBC73A78__INCLUDED_)
#define AFX_DEMO1_H__78C238E6_B3D2_4F22_8912_2549BBC73A78__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Individual.h"
#include "ProblemDef.h"
#include "Rand.h"

#define MAX_POP_SIZE 500

class CDEMO1  
{
public:
	CDEMO1();
	virtual ~CDEMO1();

	// ---------------------------for DEMO method---------------------------
public:
	void allocate_memory_pop (population *pop, int size);
	void deallocate_memory_pop (population *pop);
	int  check_dominance (CIndividual *a, CIndividual *b);

	void initialize_pop (population *pop);
	void initialize_ind (CIndividual *ind);
	void evaluate_pop (population *pop, int size);
	void evaluate_ind (CIndividual *ind);

	void compete(CIndividual &, int &);

	void quicksort_front_obj(population *pop, int objcount, int obj_array[], int obj_array_size);
	void q_sort_front_obj(population *pop, int objcount, int obj_array[], int left, int right);
	void quicksort_dist(population *pop, int *dist, int front_size);
	void q_sort_dist(population *pop, int *dist, int left, int right);

	void selection (population *old_pop, population *new_pop);
	CIndividual* tournament (CIndividual *ind1, CIndividual *ind2);

	void init_variables();

public:
	int    popsize;			// size of the population
	int    ngen;			// maximum generation of the algorithm
	int    max_evaluation;	// maximum fitness function evaluation
	int    neval;			// number of fitness function evaluation
	double *min_realvar;	// lower bounds of the real variables
	double *max_realvar;	// upper bounds of the real variables

	int    m_Strategy;		// different strategies for DE
	int    R1,R2,R3;		// select indices
	double m_F;				// scale factor
	double m_CR;			// probability of crossover of DE
	CIndividual new_child;	// generate the new child with DE method

	int nreal;				// number of the real variables
	int nobj;				// number of the objective functions
	int ncon;				// number of the constrained functions

	double seed;			// seed of the random number generator

	population *parent_pop;	// pointer of the parent population
	population *child_pop;	// pointer of the child population
	population *mixed_pop;	// pointer of the mixed population
	int        child_size;	// size of the child population (max = popsize)

	// some class objects may be needed in the algorithm
	CRand m_rnd;
	CProblemDef m_ofunc;

	/* the following is for some different methods used for research */
	// ------------------for different constrainst method-------------------
	int    handle_constr (CIndividual *a, CIndividual *b);	// switch different constrainst-handling methods

	// ------------------------for different method-------------------------
public:
	int m_method;			// different method flag (0:DEMO; 1:NSDE)
	int m_crowding_dist;	// wheter use the crowding distance or not (0:nouse; 1:use)
	int m_InitialFlag;		// flag of the population initialization (0:randomly; 1:orthogonal)
	int m_original_epsilon;	// flag of the original epsilon method (1:yes; 0:no)

	// --------------------for epsilon-domination method--------------------
public:
	/* method */
	int check_box_dominance (CIndividual *, 
		CIndividual *);							// check the box domination with constraints
	void QuickSort(CIndividual* ,int ,int);		// sort the archive

	/* attribute */
	CIndividual *m_CombinedPop;				// combine archive and EA population to select individuals for DE recombination
	CIndividual *m_ArchivePop;				// Archive population = MAX_ARCHIVE_SIZE
	int    m_ArchiveSize;					// size of the current archive
	double *m_EPSILON;						// EPSILON values
	double *m_minValue;						// min values of the object functions
	double *m_maxValue;						// max values of the object functions
	double *m_MaxOrMin;						// type of objectives
	bool   m_bEpsilon;						// whether using epsilon-domination or not
	double m_selection;						// elite selection or random selection

	// ----------------orthogonal initial population----------------
public:
	/* method */
	void OrthogonalInitialPopulation();		// generate the initial population based on orthogonal design
	void GenerateOrthogonalArray_initial();	// ����������ƾ���
	void GenerateOrthogonalPop_initial();	// �����ռ�ֽ��ĳ�ʼ����Ⱥ��
	void CreateOrthogonalArchive();			// �ӳ�ʼ����Ⱥ�����γ�archive population
	int  strict_dom_check_orthogonal(int,int);
	int  dom_check(CIndividual&, CIndividual&);
	int  same_fitness(CIndividual&, CIndividual&);// �ж�������������Ŀ�꺯������Ӧ��ֵ�Ƿ���ͬ
		
	/* attribute */
	long m_Q_initial;						// ˮƽ��,����Ϊ����
	long m_J_initial;						// ���ָ�� (M = Q^J)
	long m_M_initial;  						// �����,���� (int)pow(Q,J)
	long m_P_initial;  						// ����,���� (int)((pow(Q,J)-1)/(Q-1))
	long m_S_initial;  						// �ӿռ�ֿ���
	int **m_OrthogonalArray_initial;		// ����������ƾ��� (M*P)
	CIndividual *m_OrthogonalPop_initial;	// ��������Ⱥ�� (M*S)

	double *interval;						// �����ά�Ա����Ĳ�ֵ
	int    *VecterIndex;					// ����
	double **childSpaceLower;				// �����ӿռ�ֽ����Ա����½�
	double **childSpaceUpper;				// �����ӿռ�ֽ����Ա����Ͻ�

	// ---------------Insert the extreme points into the archive----------------
public:
	void find_exetreme(CIndividual *, int, int);	// find the extreme points
	int  update_extreme(CIndividual &);		// update the extreme points with the child
	void combine_extreme();					// insert the extreme points into the final archive
	
	CIndividual *m_Exetreme;				// save the extreme points 
	int m_bExtreme;							// flag of using extreme point (0:no; 1:yes)
	// ---------------Insert the extreme points into the archive----------------

	// ----------------use the pareto adaptive epsilon-dominance----------------
public:
	int  insert_without_epsilon_adaptive(CIndividual *,
		int,CIndividual &);						// insert the individual without epsilon-domination
	int  update_adaptive(CIndividual *,int ,
		CIndividual &,double, double, double);
	int  con_update_adaptive(CIndividual *,int ,
		CIndividual &,double, double, double);
	int  insert_with_epsilon_adaptive(CIndividual *,int ,
		CIndividual &,double, double, double);			// insert the individual with epsilon-domination (a)
	double corner_distance_adaptive(CIndividual &,
		double *);										// calculate the corner distance
	void calculate_box_index_adaptive(CIndividual &);	// calculate the box index of the individual (a)
	void calculate_grid_adaptive(CIndividual *, int);	// recalculate the grid with different P and X (a)
	void sort_pop_adaptive(CIndividual *, int , int);	// sort the population (low --> high) (a)
	void q_sort_adaptive(CIndividual *,int ,int , int);	// quick sort algorithm is used here with respect to the given objective function (a)
	double calculate_P_adaptive(CIndividual *,int ,int);// calculate the P of two objective functions (a)
	double calculate_velocity_adaptive(double , int);	// calculate the velocity (X) (a)
	int    dichotomy_fun_adaptive(double, int, double);	// use Dichotomy method to solve equations (a)
	int    flip(double);								// function that does flip with the received percentage  (a)

public:
	double *min_f;			// min value of the objective (a)
	double *max_f;			// max value of the objective (a)
	double *box_1;			// the first box index (a)
	int NO_EPS;				// Number of points required to build the first grid (a)
	int flag_epsilon;		// flag of using the epsilon dominance or not (0: without; 1: with) (a)
	int T;					// number of points desired by the decision maker (a)
	int flag_recalculation;	// flag of the new efficient point wheter outside of the grid (1: yes; 0: no) (a)
	double P;				// x^p + y^p + z^p = 1 is the best curve/surface (a)
	double X;				// velocity (a)
	int flag_pae_dominance;	// flag of using pareto adaptive epsilon-dominance (0:no; 1:yes)
	// ----------------use the pareto adaptive epsilon-dominance----------------

	// -----------------use MyDE method to optimize the problems-----------------
public:
	void initialize_pop ();						// initialize the primary population
	void evaluate_pop ();						// evaluate the primary population
	void generate_DE(CIndividual *,
		CIndividual *,int,double,int, int);		// use DE operator to update the population
	void find_nondominated(CIndividual *,int);	// find and mark the non-dominated solutions
	double indv_distance(CIndividual &,
		CIndividual &);							// calculate the distance between two individuals
	void RunMyDE(int, double);					// execute the algorithm (pae-MyDE)

public:
	CIndividual *primaryPop;	// the primary population in the pareto adaptive epsilon-domination
	CIndividual *secondaryPop;	// the secondary population in the pareto adaptive epsilon-domination
	double dist_parent;			// distance parents, changed with respect to different problems
	// -----------------use MyDE method to optimize the problems-----------------
};

#endif // !defined(AFX_DEMO1_H__78C238E6_B3D2_4F22_8912_2549BBC73A78__INCLUDED_)
