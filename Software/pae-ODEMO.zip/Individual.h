// Individual.h: interface for the CIndividual class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INDIVIDUAL_H__B926E732_F4AB_4BF9_BDFA_1E0FBD0F6EA0__INCLUDED_)
#define AFX_INDIVIDUAL_H__B926E732_F4AB_4BF9_BDFA_1E0FBD0F6EA0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define N_of_x				10		// Number of decision variables
#define MAX					2		// Number of objective functions
#define MAX_CONSTRAINT		0		// Maximum number of constraints
#define MAX_ARCHIVE_SIZE	2000	// Maximum size possible (the upper bound) of the archive

class CIndividual  
{
public:
	CIndividual();
	virtual ~CIndividual();

public:
	CIndividual(const CIndividual &);							
	CIndividual &CIndividual::operator=(const CIndividual &);

public:
	double *xreal;				// Real Coded Decision Variable     
	double *obj;				// the objective functions
	double constr_violation;	// parameter for constraint violation
	double *box;				// box vectors for the individual
    double *constr;				// defining the constraint values
	int rank;					// the rank value of the individual
	double crowd_dist;			// crowding distance of the individual
	int    non_dominated;		// flag of non-dominated solutaion (0: dominated; 1: non-dominated)
};

typedef struct 
{
	CIndividual *ind;
}population;

#endif // !defined(AFX_INDIVIDUAL_H__B926E732_F4AB_4BF9_BDFA_1E0FBD0F6EA0__INCLUDED_)
