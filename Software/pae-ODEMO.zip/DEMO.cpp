// DEMO.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "DEMO1.h"

int main(int argc, char* argv[])
{
	CDEMO1 *DEMO;
	double seed = 0.0;

	int RUN_NUMBER;
	printf("Please enter the max run number.\n");
	printf("RUN_NUMBER = ");
	RUN_NUMBER = 1;
	cin>>RUN_NUMBER;	

	srand((unsigned)time(NULL));
	
	for (int i=0;i<RUN_NUMBER;i++)
	{
		printf("--------- Run no. is %d ---------\n", i+1);
		seed = ((double)(i+1))/RUN_NUMBER;
		if (RUN_NUMBER == 1)
		{
			seed = 0.6;
		}
		if (seed == 0.0)
		{
			seed = 0.001;
		}
		if (seed == 1.0)
		{
			seed = 0.99;
		}

		DEMO = new CDEMO1;
		DEMO->RunMyDE(i, seed);		
		delete DEMO;	
	}
	
	return 0;
}
