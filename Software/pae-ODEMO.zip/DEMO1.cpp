// DEMO1.cpp: implementation of the CDEMO1 class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DEMO1.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDEMO1::CDEMO1():popsize(100),ngen(750),max_evaluation(5000)
{
	/* the following parameters may be modified for different problems */
	// --------for different methods selected--------
	m_InitialFlag = 1;		// Ⱥ���ʼ��ѡ��(0:randomly; 1:orthogonal)

	m_bExtreme = 1;			// �ж��Ƿ����߽��(0:no; 1:yes)

	m_selection = 0.1;		// smaller value with separable problem (e.g 0.2)
							// larger value with non-separable problem (e.g 0.9)

	// --------only for DE--------
	m_CR = 0.3;				// smaller value with separable problem
							// larger value with non-separable problem
	m_F  = 0.5;				// scale factor

	// --------only for epsilon-domination--------
	m_EPSILON  = new double[MAX];
	m_minValue = new double[MAX];
	m_maxValue = new double[MAX];
	m_MaxOrMin = new double[MAX];
	for (int i=0;i<MAX;i++)
	{
		m_EPSILON[i] = 0.0;
		m_minValue[i] = 0.0;	// min possible values of the object functions
		m_maxValue[i] = 1.0;	// max possible values of the object functions
		m_MaxOrMin[i] = 1.0;	// 1:min; -1:max
	}
	// initialize the global variables
	m_EPSILON[0] = 0.0075;
	m_EPSILON[1] = 0.0075;

	// ---------------for orthogonal initial population---------------	
	m_Q_initial = 11;			// ˮƽ��,����Ϊ����
	if (m_Q_initial%2 == 0)
	{
		m_Q_initial = N_of_x;
	}
	if (m_Q_initial+1 < N_of_x)
	{
		m_Q_initial = N_of_x-1;	// ��֤���������е���������>=�Ա�������
	}
	m_J_initial = 2;			// ���ָ�� (M = Q^J)
	m_S_initial = 1;  			// �ӿռ�ֿ��� (10: n<=100; 20: n>100)
	/* --------------------------------------------------------------- */

	nreal = N_of_x;
	nobj  = MAX;
	ncon  = MAX_CONSTRAINT;

	parent_pop = new population;
	child_pop = new population;
	mixed_pop = new population;
	child_size = 0;

	min_realvar = new double[N_of_x];
	max_realvar = new double[N_of_x];

	// --------for epsilon-domination method--------
	m_ArchivePop = new CIndividual[MAX_ARCHIVE_SIZE];
	m_ArchiveSize = 0;

	// ---------------for orthogonal initial population---------------
	m_M_initial = (int)pow(m_Q_initial,m_J_initial);  						// �����,���� 
	m_P_initial = (int)((pow(m_Q_initial,m_J_initial)-1)/(m_Q_initial-1));  // ����,���� 

	// ����������ƾ��� (M*P)
	m_OrthogonalArray_initial =new int *[m_M_initial];
	for (i=0;i<m_M_initial;i++)
	{
		m_OrthogonalArray_initial[i] = new int[m_P_initial];
	}
	for (i=0;i<m_M_initial;i++)
	{
		for (int j=0;j<m_P_initial;j++)
		{
			m_OrthogonalArray_initial[i][j] = -1;
		}
	}
	// ��������Ⱥ�� (M*S)
	m_OrthogonalPop_initial = new CIndividual[m_M_initial*m_S_initial];
	// ����������������
	interval = new double[N_of_x];
	VecterIndex = new int[N_of_x];
	// �����ӿռ�ֽ����Ա������½�
	childSpaceLower = new double *[m_S_initial];
	childSpaceUpper = new double *[m_S_initial];
	for (i=0;i<m_S_initial;i++)
	{
		childSpaceLower[i] = new double[N_of_x];
		childSpaceUpper[i] = new double[N_of_x];
	}
	// ---------------for orthogonal initial population---------------

	m_Exetreme = new CIndividual[nobj];

	// ----------------use the pareto adaptive epsilon-dominance----------------
	min_f = new double[MAX];
	max_f = new double[MAX];
	box_1 = new double[MAX];
	NO_EPS = 100;
	T = 100;
	flag_epsilon = 0;
	flag_recalculation = 0;
	P = 0.0;
	X = 0.0;
	// ----------------use the pareto adaptive epsilon-dominance----------------

	// -----------------use MyDE method to optimize the problems-----------------
	primaryPop = new CIndividual[MAX_POP_SIZE];
	secondaryPop = new CIndividual[MAX_POP_SIZE];
	// -----------------use MyDE method to optimize the problems----------------
}

CDEMO1::~CDEMO1()
{
	delete parent_pop;
	delete child_pop;
	delete mixed_pop;

	delete []min_realvar;
	delete []max_realvar;
	delete []m_MaxOrMin;

	delete []m_ArchivePop;
	delete []m_minValue;
	delete []m_maxValue;
	delete []m_EPSILON;

	// for orthogonal initial population	
	delete []interval;
	delete []VecterIndex;
	for (int i=0;i<m_M_initial;i++)
	{
		delete []m_OrthogonalArray_initial[i];
	}
	delete []m_OrthogonalArray_initial;
	for (i=0;i<m_S_initial;i++)
	{
		delete []childSpaceLower[i];
		delete []childSpaceUpper[i];
	}
	delete []childSpaceLower;
	delete []childSpaceUpper;
 	delete []m_OrthogonalPop_initial;

	delete []m_Exetreme;

	delete []min_f;
	delete []max_f;
	delete []box_1;

	delete []primaryPop;
	delete []secondaryPop;
}

void CDEMO1::init_variables()
{
	min_realvar[0] = 0.0;
	max_realvar[0] = 1.0;
	for (int i=1;i<N_of_x;i++)
	{
		min_realvar[i] = 0.0;
		max_realvar[i] = 1.0;
	}
}

void CDEMO1::allocate_memory_pop(population *pop, int size)
{
	pop->ind = new CIndividual[size];
}

void CDEMO1::deallocate_memory_pop(population *pop)
{
	delete []pop->ind;
}

int CDEMO1::check_dominance(CIndividual *a, CIndividual *b)
{
	int i = 0;
	int flag1;
	int flag2;
	flag1 = 0;
	flag2 = 0;
	if (a->constr_violation<0 && b->constr_violation<0)
	{
		int temp = 0;
		temp = handle_constr(a, b);		
		return temp;
	}
	else
	{
		if (a->constr_violation < 0 && b->constr_violation == 0)
		{
			return (-1);
		}
		else
		{
			if (a->constr_violation == 0 && b->constr_violation <0)
			{
				return (1);
			}
			else
			{
				for (i=0; i<nobj; i++)
				{
					if (a->obj[i] < b->obj[i])
					{
						flag1 = 1;
					}
					else if (a->obj[i] > b->obj[i])
					{
							flag2 = 1;
					}
				}
				if (flag1==1 && flag2==0)
				{
					return (1);
				}
				else if (flag1==0 && flag2==1)
				{
					return (-1);
				}
				else if (flag1==1 && flag2==1)
				{
					return (0);
				}
				else
				{
					return (2);
				}
			}
		}
	}
}

void CDEMO1::evaluate_pop(population *pop, int size)
{
	for (int i=0;i<size;i++)
	{
		evaluate_ind(&pop->ind[i]);
	}
	return;
}

void CDEMO1::evaluate_ind(CIndividual *indv)
{
	int i;

	m_ofunc.test_1_zdt6(indv->xreal,indv->obj,indv->constr);

	// convert the objective function to minimization or maximization sense
	// which sense is determined by m_MaxOrMin, 1 for minimization; -1 for maximization
	for (i=0;i<MAX;i++)
	{
		indv->obj[i] = m_MaxOrMin[i]*indv->obj[i];
	}

	// calculate the total violation of the constraints
	// where constr_violation=0 means it is feasible
	// and constr_violation<0 means it is infeasible
	if (MAX_CONSTRAINT == 0)
	{
		indv->constr_violation = 0.0;
	}
	else
	{
		indv->constr_violation = 0.0;
		for (i=0;i<MAX_CONSTRAINT;i++)
		{
			if (indv->constr[i] < 0.0)
			{
				indv->constr_violation += (1.0)*indv->constr[i];
			}
		}
	}
	
	neval++;
}

void CDEMO1::initialize_pop(population *pop)
{
	int i;
	for (i=0; i<popsize; i++)
	{
		initialize_ind (&(pop->ind[i]));
	}
	return;
}

void CDEMO1::initialize_ind(CIndividual *ind)
{
	for (int j=0; j<nreal; j++)
	{
		ind->xreal[j] = m_rnd.rndreal (min_realvar[j], max_realvar[j]);
	}
	return;
}

void CDEMO1::compete(CIndividual &NewChild, int &size)
{
	int flag = 0, lg = 0, pp = 0;

	for (int i = 0; i < popsize; i++)
    {
		if (check_dominance(&NewChild, &parent_pop->ind[i]) == 1)
		{//replace
			parent_pop->ind[i] = NewChild;
			flag = 1;
			return;
		}
    }
	if (flag == 1)
		return;
	else
    {
		for (i = 0; i < popsize; i++)
		{
			if (check_dominance(&NewChild, &parent_pop->ind[i]) == -1)
			{// discard
				lg = -1;
				return;
			}
		}
		if (lg == -1)
			return;
		else
		{// add
			if (size < popsize)
			{
				child_pop->ind[size] = NewChild;
				size++;
			}			
		}
    }
}

/* the following is for some different methods used for research */
int CDEMO1::handle_constr(CIndividual *a, CIndividual *b)
{
	if (a->constr_violation > b->constr_violation)
	{
		return (1);
	}
	else
	{
		if (a->constr_violation < b->constr_violation)
		{
			return (-1);
		}
		else
		{
			return (0);
		}
	}
}

int CDEMO1::check_box_dominance (CIndividual *a, CIndividual *b)
{
	int i;
    int flag1;
    int flag2;
    flag1 = 0;
    flag2 = 0;
    if (a->constr_violation<0.0 && b->constr_violation<0.0)
    {
		int temp = 0;
		temp = handle_constr(a, b);	
		if (temp == 1)
		{
			temp = 1;
		}
		else if (temp == -1)
		{
			temp = 2;
		}
		else if (temp == 0)
		{
			temp = 4;
		}
		return temp;
    }
    else
    {
        if (a->constr_violation<0.0 && b->constr_violation==0.0)
        {
            return (2);
        }
        else
        {
            if (a->constr_violation==0.0 && b->constr_violation<0.0)
            {
                return (1);
            }
            else
            {
                for (i=0; i<MAX; i++)
                {
                    if (a->box[i] < b->box[i])
                    {
                        flag1 = 1;
                    }
                    else
                    {
                        if (a->box[i] > b->box[i])
                        {
                            flag2 = 1;
                        }
                    }
                }
                if (flag1==1 && flag2==0)
                {
                    return (1);
                }
                else
                {
                    if (flag1==0 && flag2==1)
                    {
                        return (2);
                    }
                    else
                    {
                        if (flag1==1 && flag2==1)
                        {
                            return(3);
                        }
                        else
                        {
                            return(4);
                        }
                    }
                }
            }
        }
    }
}

void CDEMO1::QuickSort(CIndividual* Individual,int left,int right)
{
	int i,j;
	double pivot;					// �ָ�ָ��
	CIndividual temp;				// ����ʱ����ʱ����

	i=left;
	j=right+1;						// i,j�ֱ�Ϊ���������ָ��
	pivot=Individual[left].obj[0];	// ȡ����ߵ�Ԫ��
	
	if(i<j)
	{
		do 
		{
			do 
			{
				i++;
			} while(Individual[i].obj[0]<=pivot && i<= right);
			do 
			{
				j--;
			} while(Individual[j].obj[0]>=pivot && j>left);
			if(i<j)
			{
				temp=Individual[i];
				Individual[i]=Individual[j];
				Individual[j]=temp;
			}
		} while(i<j);
		
		temp = Individual[left];
		Individual[left] = Individual[j];
		Individual[j] = temp;
		
		QuickSort(Individual,left,j-1);
		QuickSort(Individual,j+1,right);
	}
}

// ---------------------for orthogonal initial population---------------------
// generate the orthogonal array for orthogonal initial population
void CDEMO1::GenerateOrthogonalArray_initial()
{
	int i,j,k;
	int Q = m_Q_initial;
	int J = m_J_initial;
	int M = m_M_initial;
	int P = m_P_initial;
	int S = m_S_initial;

	for (k=1;k<=J;k++)
	{
		j = (int)((pow(Q,k-1)-1)/(Q-1));
		for (i=0;i<M;i++)
		{
			m_OrthogonalArray_initial[i][j] = (int)floor((i)/(pow(Q,J-k)))%Q;
		}
	}

	int s,t;
	for (k=2;k<=J;k++)
	{
		j = (int)((pow(Q,k-1)-1)/(Q-1));
		for (s=0;s<j;s++)
		{
			for (t=1;t<=Q-1;t++)
			{
				for (i=0;i<M;i++)
				{
					m_OrthogonalArray_initial[i][j+s*(Q-1)+t] = 
						(m_OrthogonalArray_initial[i][s]*t+m_OrthogonalArray_initial[i][j])%Q;
				}
			}
		}
	}

	for (i=0;i<M;i++)
	{
		for (j=0;j<P;j++)
		{
			m_OrthogonalArray_initial[i][j] = m_OrthogonalArray_initial[i][j]+1;
		}
	}
}

// generate the orthogonal population
void CDEMO1::GenerateOrthogonalPop_initial()
{
	int i,j,k,t;
	int Q = m_Q_initial;
	int J = m_J_initial;
	int M = m_M_initial;
	int P = m_P_initial;
	int S = m_S_initial;

	for (i=0;i<N_of_x;i++)
	{
		VecterIndex[i] = 0;
		interval[i] = max_realvar[i]-min_realvar[i];
	}
	static int index;
	index = 0;
	double maxx = interval[index];
	for (i=0;i<N_of_x;i++)
	{
		if (maxx < interval[i])
		{
			maxx = interval[i];
			index =i;
		}
	}
	VecterIndex[index] = 1;

	for (i=0;i<S;i++)
	{
		for (j=0;j<N_of_x;j++)
		{
			childSpaceLower[i][j] = min_realvar[j]+
				i*((max_realvar[index]-min_realvar[index])/S)*VecterIndex[j];
			childSpaceUpper[i][j] = max_realvar[j]-
				(S-i-1)*((max_realvar[index]-min_realvar[index])/S)*VecterIndex[j];
		}
	}

	for (t=0;t<S;t++)
	{
		for (i=0;i<M;i++)
		{
			for (j=0;j<N_of_x;j++)
			{
				k = m_OrthogonalArray_initial[i][j];
				if (k == 1)
				{
					m_OrthogonalPop_initial[t*M+i].xreal[j] = childSpaceLower[t][j];
				}
				else if (k>=2 || k<= Q-1)
				{
					m_OrthogonalPop_initial[t*M+i].xreal[j] = childSpaceLower[t][j]+
						(k-1)*((childSpaceUpper[t][j]-childSpaceLower[t][j])/(Q-1));
				}
				else if( k == Q )
				{
					m_OrthogonalPop_initial[t*M+i].xreal[j] = childSpaceUpper[t][j];
				}
			}
		}
	}
}

int CDEMO1::same_fitness(CIndividual &indv1,CIndividual &indv2)
{
	int elag = 1;
	int k;

	if ((indv1.constr_violation != indv2.constr_violation))
	{
		elag = 0;
		return elag;
	}
	else
	{
		for (k=0;k<MAX;k++)
		{
			if ((elag == 1) &&
				(indv1.obj[k] == indv2.obj[k]))
			{
				elag = 1;
			}
			else
			{
				elag = 0;
				break;
			}
		}
	}
		
	return elag;
}

// Strict Domination check function for orthogonal population members indexed by m and n
// returns 1 ( 0 ) meaning m dominates (does not dominate) n in minimization sense
// only for population members _to_be_called_in_  create_archive()
// Here does not consider the constraints
int CDEMO1::strict_dom_check_orthogonal(int m,int n)
{
	int flag = 1;
	for (int p = 0; p < MAX; p++)
    {
		if ((flag == 1) && 
			(m_OrthogonalPop_initial[m].constr_violation > m_OrthogonalPop_initial[n].constr_violation))
			flag = 1;
		else if ((flag == 1)  && 
			(m_OrthogonalPop_initial[m].constr_violation == m_OrthogonalPop_initial[n].constr_violation) && 
			(m_OrthogonalPop_initial[m].obj[p] <= m_OrthogonalPop_initial[n].obj[p]))
		{
			flag = 1;
		}			
		else
		{
			flag = 0;
			break;
		}
    }
	
	return flag;
}

int CDEMO1::dom_check(CIndividual &ind1, CIndividual &ind2)
{
	int flag = 1;
	int elag = 0;
	for (int j = 0; j < MAX; j++)
    {
		if ((flag == 1) && (ind1.constr_violation > ind2.constr_violation))
			flag = 1;	// everyone
		else if ((flag == 1) && 
			(ind1.constr_violation == ind2.constr_violation) &&
			(ind1.obj[j] <= ind2.obj[j]))
		{
			flag = 1;	// everyone
		}			
		else
			flag = 0;

		if ((ind1.constr_violation > ind2.constr_violation) || (elag == 1))
			elag = 1;	// anyone
		else if ((ind1.constr_violation == ind2.constr_violation) 
			&& (ind1.obj[j] < ind2.obj[j]) || (elag == 1))
		{
			elag = 1;
		}
	}

	if ((flag == 1) && (elag == 1))
		return 1;
	else
		return 0;
}

// Create the initial archive from the orthogonal population
// Consists of the non-dominated members of the population
void CDEMO1::CreateOrthogonalArchive()
{	
	find_nondominated(m_OrthogonalPop_initial, m_M_initial*m_S_initial);
	for (int i = 0; i < m_M_initial*m_S_initial; i++)
	{
		if (m_OrthogonalPop_initial[i].non_dominated)
		{
			m_ArchivePop[m_ArchiveSize++] = m_OrthogonalPop_initial[i];
		}

		if (m_ArchiveSize >= MAX_ARCHIVE_SIZE)
		{
			break;
		}
	}
}

void CDEMO1::OrthogonalInitialPopulation()
{
	int  i=0,j=0;

	//assign_rank_and_crowding_distance();
	GenerateOrthogonalArray_initial();
	GenerateOrthogonalPop_initial();
	// calculate the fitness of the orthogonal population
	for (i=0;i<m_M_initial*m_S_initial;i++)
	{
		evaluate_ind(&m_OrthogonalPop_initial[i]);	
	}

	// create the initial archive population from the orthogonal population	
	CreateOrthogonalArchive();
	
	// select non-domination individuals to form the archive and initial population	
	// generate the initial population
	if (m_ArchiveSize >= popsize)
	{
		for (i=0;i<popsize;i++)
		{
			parent_pop->ind[i] = m_ArchivePop[i];
		}
	}
	else
	{
		for (i=0;i<m_ArchiveSize;i++)
		{
			parent_pop->ind[i] = m_ArchivePop[i];
		}
		for (i=m_ArchiveSize;i<popsize;i++)
		{
			parent_pop->ind[i] = 
				m_OrthogonalPop_initial[m_rnd.rndint(0,m_M_initial*m_S_initial-1)];
		}
	}
}

// ---------------Insert the extreme points into the archive----------------
void CDEMO1::find_exetreme(CIndividual *pop, int size, int obj_index)
{
	if (obj_index > nobj)
	{
		cout<<"There are too many indeces in the routine of find_exetreme().\n";
		exit(1);
	}

	int best_index = 0;
	for (int i=1;i<size;i++)
	{
		if (pop[i].obj[obj_index] < pop[best_index].obj[obj_index])
		{
			// consider the constraints
			if (pop[i].constr_violation == 0)
			{
				best_index = i;
			}
			else if (pop[i].constr_violation > pop[best_index].constr_violation)
			{
				best_index = i;
			}
		}
		else if (pop[i].obj[obj_index] == pop[best_index].obj[obj_index])
		{
			if (check_dominance(&pop[i],&pop[best_index]) == 1)
			{
				best_index = i;
			}
		}
	}

	m_Exetreme[obj_index] = pop[best_index];
	return;
}

// 1: the new child updates the extreme points
// 0: the new child does not update the extreme points
int CDEMO1::update_extreme(CIndividual &child)
{
	int flag = -1;

	// the extreme points in the final archive must be feasible
	if (child.constr_violation < 0.0)
	{
		flag = 0;
		return flag;
	}

	for (int i=0;i<nobj;i++)
	{
		if (child.constr_violation == 0 && m_Exetreme[i].constr_violation < 0.0)
		{
			m_Exetreme[i] = child;
			flag = 1;
			return flag;
		}
		else if (child.obj[i] < m_Exetreme[i].obj[i])
		{
			m_Exetreme[i] = child;
			flag = 1;
			return flag;
		}
		else if (child.obj[i] == m_Exetreme[i].obj[i])
		{
			if (check_dominance(&child,&m_Exetreme[i]) == 1)
			{
				m_Exetreme[i] = child;
				flag = 1;
				return flag;
			}
		}
		else
			flag = 0;
	}

	return flag;
}

void CDEMO1::combine_extreme()
{
	int i,j;
	int flag = 0;
	for (i=0;i<nobj;i++)
	{
		for (j=0;j<m_ArchiveSize;j++)
		{
			if (same_fitness(m_Exetreme[i],m_ArchivePop[j]) == 1)
			{// the extreme is in the final archive
				flag = 1;
				return;
			}
		}
		// the extreme is not in the final archive
		if (flag == 0)
		{
			m_ArchivePop[m_ArchiveSize] = m_Exetreme[i];
			m_ArchiveSize++;
		}
	}
}

// ----------------use the pareto adaptive epsilon-dominance----------------
int CDEMO1::flip(double pm)
{
	double ran = m_rnd.rndreal(0.0, 1.0);
	if ( (ran) <= pm)
		return 1;
	else 
		return 0;
}

void CDEMO1::calculate_box_index_adaptive(CIndividual &ind)
{
	int i;
	for(i=0;i<nobj;i++)
	{
		ind.box[i] = floor ((log((box_1[i]*pow(P, X))/(box_1[i]*pow(P,X) + (ind.obj[i]-min_f[i]) * (1 - pow(P, X))))) / (X * log(P)));			
	}
}

double CDEMO1::corner_distance_adaptive(CIndividual &ind1, double *point)
{
	double dist = 0.0;
	int i;

	for (i = 0; i < nobj; i++)
	{
		dist += pow ((ind1.obj[i] - point[i]), 2);
	}
	dist = sqrt (dist);
	return (dist);
}

int CDEMO1::insert_without_epsilon_adaptive(CIndividual *pop, int size, CIndividual &ind)
{
	int flag, i;
	
	if (size == 0)
	{
		pop[size++] = ind;
		return size;
	}
	else
	{
		// To verify if it enters the external file
		for (i=0;i<size;i++)
		{
			flag = check_dominance(&ind, &pop[i]);
			if (flag == 1)
			{
				// If this individual dominates to some of archive one,
				// replace the dominated one and accept the new individual
				pop[i] = ind;

				// remove all dominated individuals by ind from the external
				while (++i < size)
				{
					if (check_dominance(&ind, &pop[i]) == 1)
					{
						pop[i--] = pop[--size];
					}
				}
				return size;
			}
			else if (flag == -1 || flag == 2)
			{
				// If it is dominated by or equal to some of the external individuals, it is not inserted.
				// return the number of non-dominated points immediately
				return size;
			}
		}

		// all of the external are non-dominated by ind, add the ind to the external
		pop[size++] = ind;
		return size;
	}
}

int CDEMO1::update_adaptive(CIndividual *pop, int size, CIndividual &NewChild, double T, double x, double p)
{
	int d = 0, accept_flag, i = 0, no_dom = 0, same_box = 0;
	double esq[MAX], da = 0, dc = 0;
	double child_dist, archive_dist;
	int l = 3;		// this is a user-defined parameter to determine wheter the new point outside the grid or not

	accept_flag = 0;
	calculate_box_index_adaptive(NewChild);  // set the box vectors for the child

	if (size == 0)
	{
		pop[size++] = NewChild;
		return size;
	}
	else
	{
		for (i = 0; i < size; i++)
		{
			calculate_box_index_adaptive(pop[i]);  // set the box vectors for the archive members

			if (check_box_dominance(&pop[i], &NewChild) == 1)
			{// new child is box-dominated by an archive member						
				accept_flag = -1;
				break;
			}
		}
		if (accept_flag == -1)
			return size;  // processing stops here
		else
		{// new child is not box-dominated by an archive member			
			for (i = 0; i < size; i++)
			{
				no_dom = 0;
				if (check_box_dominance(&pop[i], &NewChild) == 2)
				{
					// new child box-dominates some archive member
					// delete the dominated archive member
					no_dom++;
					for (int j = i; j < size - 1; j++)
					{
						pop[j] = pop[j + 1];
					}
					size--;
					d = 1;		// flag to denote that archive member has been deleted
					i = i-1;
				}
			}
			if (d == 1)
			{
				// new child box-dominates some archive member
				// new child enters the archive
				size++;
				pop[size - 1] = NewChild;
				accept_flag = 1;

				// check the new efficient point wheter outside of the grid or not
				for (int j=0;j<nobj;j++)
				{
					if ((NewChild.box[j] < -l) || (NewChild.box[j] > (T + l)))
					{
						flag_recalculation = 1;
						break;
					}
				}

				return size;
			}
			else
			{
				// new case: child and archive members do not box-dominate each other
				for (i = 0; i < size; i++)
				{
					// checking if the any archive member and child are in same box
					if (check_box_dominance(&pop[i], &NewChild) == 4)
					{
						same_box++;
						// inside same box, use the usual dominance concept
						int elag = check_dominance(&NewChild, &pop[i]);
						if (elag == 1)
						{
							pop[i] = NewChild;
							accept_flag = 1;
							return size;
						}
						else if (elag == -1)
						{
							accept_flag = -1;
							return size;
						}
						else
						{
							// neither dominate (usual sense) each other.
							// NOTE: here, both are in same box
							int caso;
							if (NewChild.box[0] < (T /3))
								caso = 1;	
							else if (NewChild.box[0] < (2 * T /3))
								caso = 2;		
							else 
								caso = 3;		

							if (NewChild.obj[0] < pop[i].obj[0] && caso == 1)
							{
								pop[i] = NewChild;
								return size;
							}
							if (NewChild.obj[0] > pop[i].obj[0] && caso == 3)
							{
								pop[i] = NewChild;
								return size;
							}
							if (caso == 2)
							{
								//find the corner of the box
								for (int j = 0; j < nobj; j++)
								{
									esq[j] = min_f[j];
									for (int k = 0; k < NewChild.box[j]; k++)
										esq[j] += (box_1[j] * pow(p,-x*(k)));
								}
								
								child_dist = corner_distance_adaptive (NewChild, esq);
								archive_dist =  corner_distance_adaptive (pop[i], esq);
					  
								if (child_dist < archive_dist)
								{ 
									// child is nearer the corner, so we choose
									// it to enter, note here, we are working with a 
									// minimization problem
									pop[i] = NewChild;
									accept_flag = 1;
									return size;
								}
								else
								{
									accept_flag = -1;
									return size;
								}
							}
						}
					}
				}
			}
			if (d == 0 && accept_flag == 0 && same_box == 0)
			{
				// the new child is a totally new non-dominated point
				size++;
				pop[size - 1] = NewChild;

				// check the new efficient point wheter outside of the grid or not
				for (int j=0;j<nobj;j++)
				{
					if ((NewChild.box[j] < -l) || (NewChild.box[j] > (T + l)))
					{
						flag_recalculation = 1;
						break;
					}
				}

				return size;
			}
		}
		return size;
	}
}

int CDEMO1::con_update_adaptive(CIndividual *pop, int size, CIndividual &NewChild, double T, double x, double p)
{
	int flg = 0, d = 0;
  
	// First Case : the new Child is a feasible solution,
	// i.e. it has zero constraint violation 
	if (NewChild.constr_violation <= DELTA)
    {
		// removing all infeasible solutions from the archive
		for (int i = 0; i < size; i++)
		{
			if (pop[i].constr_violation > DELTA)
			{
				for (int j = i; j < size - 1; j++)
				{
					pop[j] = pop[j + 1];	// move to the forward
				}
				size--;	// reduce the size of the archive
				d = 1;				// set flag to indicate that some archive members have been deleted
				i = i-1;		
			}
		}
		// insert the new child in the usual manner into the archive after
		// removing the infeasible points.
		size = update_adaptive (pop, size,NewChild, T, x, p);
		return size;
    }
	else
    {
		// Second Case : New child is infeasible
		// This case does not use the box_dom and dom_check routine
		for (int k = 0; k < size; k++)
		{
			if (NewChild.constr_violation < pop[k].constr_violation)
			{
				flg = -1;  // reject the child, as there is a better solution in the archive
				return size;
			}
		}
		if (flg == 0)
		{
			// removing all those members whose constraint violation
			// is lower than that of the new child
			for (int k = 0; k < size; k++)
			{
				if (NewChild.constr_violation > pop[k].constr_violation)
				{
					for (int j = k; j < size - 1; j++)
					{
						pop[j] = pop[j + 1];
					}
					size--;
					d = 1;		// set flag to indicate that some archive members have been deleted
					k = k-1;
				}
			}
		}
      
		if (flg == 0)
		{
			size++;
			pop[size - 1] = NewChild;	// new child inserted into archive					
			flg=1;						// flag to indicate this
			return size;
		}
		return size;
    }
}

int CDEMO1::insert_with_epsilon_adaptive(CIndividual *pop, int size, CIndividual &ind, double T, double x, double p)
{
	int flag, i, caso, j, k;
	double esq[MAX];
	double ind_dist, corner_dist;
	int l = 3;		// this is a user-defined parameter to determine wheter the new point outside the grid or not

	if (flag_epsilon)
	{
		calculate_box_index_adaptive(ind);
	}
	
	if (size == 0)
	{
		pop[size++] = ind;
		return size;
	}
	else
	{
		// To verify if it enters the external population
		for (i=0;i<size;i++)
		{
			flag = check_box_dominance(&ind, &pop[i]);
			if (flag == 1)
			{
				// If this individual dominates to some of the external, it replaces the dominated on
				// and accept the new individual
				pop[i] = ind;

				// remove all dominated individuals by ind from the external
				while (++i < size)
				{
					if (check_box_dominance(&ind, &pop[i]) == 1)
					{
						pop[i--] = pop[--size];
					}
				}

				// check the new efficient point wheter outside of the grid or not
				for (j=0;j<nobj;j++)
				{
					if ((ind.box[j] < -l) || (ind.box[j] > (T + l)))
					{
						flag_recalculation = 1;
						break;
					}
				}

				return size;
			}
			else if (flag == 2)
			{
				// If it is dominated by some of the external one, it is not inserted.
				// return the number of non-dominated points immediately
				return size;
			}
			else if (flag == 4)
			{// If both are equal
				flag = check_dominance(&ind, &pop[i]);	// use the traditional dominance
				if (flag == 1 || flag == 2)
				{
					// If ind dominates it or equals to it, it replaces it
					pop[i] = ind;
					return size;
				}
				else if (flag == -1)		// If it is dominated or equal to, then it is not inserted
				{
					return size;
				}
				else
				{
					// neither dominate (usual sense) each other.
					// NOTE: here, both are in same box
					if (ind.box[0] < (T /3))
						caso = 1;		
					else if (ind.box[0] < (2 * T /3))
						caso = 2;		
					else 
						caso = 3;	

					if (ind.obj[0] < pop[i].obj[0] && caso == 1)
					{
						pop[i] = ind;
						return size;
					}
					if (ind.obj[0] > pop[i].obj[0] && caso == 3)
					{
						pop[i] = ind;
						return size;
					}
					if (caso == 2)
					{
						//find the corner of the box
						for (j = 0; j < nobj; j++)
						{
							esq[j] = min_f[j];
							for (k = 0; k < ind.box[j]; k++)
								esq[j] += (box_1[j] * pow(p,-x*(k)));
						}

						ind_dist = corner_distance_adaptive (ind, esq);
						corner_dist = corner_distance_adaptive (pop[i], esq);

						if (ind_dist < corner_dist)
						{
							// the son is near the border, he replaces it
							pop[i] = ind;
							return size;
						}
					}
					return size;
				}
			}
		}

		// If we arrived up to here, that is, it is (non-dominated) with all those of the external one 
		// the new child is a totally new non-dominated point, then it is inserted in the end 
		pop[size++] = ind;

		// check the new efficient point wheter outside of the grid or not
		for (j=0;j<nobj;j++)
		{
			if ((ind.box[j] < -l) || (ind.box[j] > (T + l)))
			{
				flag_recalculation = 1;
				break;
			}
		}

		return size;
	}
}

void CDEMO1::sort_pop_adaptive(CIndividual *pop, int size, int function)
{
	q_sort_adaptive(pop, function, 0, size-1);
}

// low --> high with respect to f[0]
void CDEMO1::q_sort_adaptive(CIndividual *pop, int function, int left, int right)
{
	CIndividual pivot;
	int l_hold, r_hold;
	int aux;

	l_hold = left;
	r_hold = right;
	pivot = pop[left];

	while (left < right)
	{
		while ((pop[right].obj[function] >= pivot.obj[function]) && (left < right))
			right--;
		if (left != right)
		{
			pop[left] = pop[right];
			left++;
		}
		while ((pop[left].obj[function] <= pivot.obj[function]) && (left < right))
			left++;
		if (left != right)
		{
			pop[right] = pop[left];
			right--;
		}
	}
	pop[left] = pivot;

	aux = left;

	left = l_hold;
	right = r_hold;
	if (left < aux)
		q_sort_adaptive(pop, function, left, aux-1);
	if (right > aux)
		q_sort_adaptive(pop, function, aux+1, right);
}

double CDEMO1::calculate_P_adaptive(CIndividual *pop, int size, int pos)
{
	int i; 
	double area_inferior, area_superior, area_total;
	char s1[30];
	FILE *Arch_p;
	double fp, fp1, ufp, ufp1;
	double PP;

	// calculate the area of the curve
	// here the external has been ordered from low to high with f[0]
	area_inferior = area_superior = 0;
	for (i = 0+pos; i < size-1-pos; i++)
	{
		area_inferior += fabs((pop[i+1].obj[0] - pop[i].obj[0]) * 
			(pop[i+1].obj[1] - pop[size-1-pos].obj[1]));
		area_superior += fabs((pop[i+1].obj[0] - pop[i].obj[0]) * 
			(pop[i].obj[1] - pop[size-1-pos].obj[1]));
	}	
	area_total = (area_inferior + area_superior) / 2;
	
	// standardize the area of the curve within (0, 1.0)
	double area = fabs((pop[size-1-pos].obj[0] - pop[0+pos].obj[0]) * 
		(pop[0+pos].obj[1] - pop[size-1-pos].obj[1]));
	area_total = area_total/area;

	if ((Arch_p = fopen("p.txt", "rb"))== NULL)
	{
		printf("\nERROR!!! The file p.txt does not exist.\n");
		exit (1);
	}

	// get the data from the file
	while (	(fgets (s1, 20, Arch_p) != NULL))
	{
		sscanf (s1, "%lf %lf", &fp, &fp1);
		
		if (area_total < fp1)
		{
			PP = ufp + ((area_total - ufp1) * (fp - ufp)) / (fp1 - ufp1);
			fclose (Arch_p);
			return PP;		// get the P value of the curve
		}
		ufp = fp;
		ufp1 = fp1; 
	}

	fclose (Arch_p);
	return 0;
}

int CDEMO1::dichotomy_fun_adaptive(double p, int T, double x)
{
	double fun;	
	
	fun = ((1-pow(2,1/p))*pow(p,T*x))+(pow(2,1/p)*pow(p,T*x/2)-1);
	if (0 < fun)
		return 1;
	else
		return 0;
}

double CDEMO1::calculate_velocity_adaptive(double p, int t)
{
	//Method of Dichotomy to solve the equation
	double precision = 0.00001;
	double liminf = 1e-6;		// the lower bound of velocity x
	double limsup = 1.0;		// the upper bound of velocity x
	double medio;
	int signoinf, signosup, signoaux;

	signoinf = dichotomy_fun_adaptive (p, t, liminf);
	signosup = dichotomy_fun_adaptive (p, t, limsup);

	do
	{
		medio = ((limsup + liminf) / 2.0);
		signoaux = dichotomy_fun_adaptive (p, t, medio);
		if (signoaux == signoinf)
		{
			liminf = medio;
		}
		else 
		{
			limsup = medio;
		}
	}while ((limsup - liminf) > precision);

	return ((limsup + liminf) / 2.0);
}

void CDEMO1::calculate_grid_adaptive(CIndividual *pop, int size)
{
	int i;
	double aux=0.0;
	double hyper1 = 0.0;

	// sort the external with respect to the selected objective (low --> high)
	// It is ordered with respect to the first objective function (f[0])
	sort_pop_adaptive(pop, size, 0);

	int pos = -1;
	do {
		pos++;
		if (pos >= size)
		{
			printf("\n\n!!! The archive population is bad!!!\n\n");
			exit(0);
		}
		if (nobj == 2)
		{
			min_f[0] = pop[0+pos].obj[0];
			max_f[0] = pop[size-1-pos].obj[0];
			min_f[1] = pop[size-1-pos].obj[1];
			max_f[1] = pop[0+pos].obj[1];

			P = calculate_P_adaptive(pop, size, pos);
		}
	} while(P==0 || P==1);

	X = calculate_velocity_adaptive(P,T);

	// Using p, x, and T calculates aux of the first box in each objective
	aux = ((pow(P,X) - 1) * pow (P, X*(T-1))) / ( pow(P, T*X) - 1);

	// The interval in each objective 
	for (i = 0; i < nobj; i++)
		box_1[i] = fabs ((double)(max_f[i] - min_f[i])) * aux;
}

// -----------------use MyDE method to optimize the problems-----------------
void CDEMO1::initialize_pop()
{
	for (int i=0;i<popsize;i++)
	{
		initialize_ind(&primaryPop[i]);
	}
}

void CDEMO1::evaluate_pop()
{
	for (int i=0;i<popsize;i++)
	{
		evaluate_ind(&primaryPop[i]);
	}
}

double CDEMO1::indv_distance(CIndividual &ind1, CIndividual &ind2)
{
	double dist = 0.0;
	int i;

	for (i = 0; i < nobj; i++)
	{
		dist += pow ((ind1.obj[i] - ind2.obj[i]), 2);
	}
	dist = sqrt (dist);
	return (dist);
}

void CDEMO1::generate_DE(CIndividual *pop1, CIndividual *pop2, int size, double F, int selection, int strategy)
{
	int i, j, k, flag;
	int r1, r2, r3;
	double aux;							// temporary variable 
	CIndividual temp;					// temporary point to store the child generated by DE operator
	CIndividual parent;					// reference parent (main parent)
	double d1;

	// calculate the near_distance to select the parents near enough in elitist selection
	if (selection)
	{
		dist_parent = 0.0;
		for (i=0;i<nobj;i++)
		{
			dist_parent += pow(max_f[i]-min_f[i],2);
		}
		dist_parent = sqrt(dist_parent)/pow(2, nobj);
		//printf("near_distance = %.3f.\n", dist_parent);
	}

	for (i=0;i<size;i++)
	{
		// Crossover operator
		// *********  Main parent  ********* //
		if (!selection)
		{
			parent = pop1[i%size];			// select the main parent from the primary population (random selection)
		}		
		else								// new, select the main parent from the archive (elitist selection)
		{
			parent = pop1[m_rnd.rndint(0,m_ArchiveSize-1)];
		}
		//***********************************//

		/************* Generate the selected parents *******************/
		if (!selection)
		{// select the first parent from the primary population	
			do
			{
				r1 = m_rnd.rndint(0, size-1);
			}while(r1 == i);
			// select the second parent from the primary population
			do
			{
				r2 = m_rnd.rndint(0, size-1);
			}while(r2 == i || r2 == r1);
			// select the third parent from the primary population
			do
			{
				r3 = m_rnd.rndint(0, size-1);
			}while(r3 == i || r3 == r2 || r3 == r1 );
		}
		else	
		{// select the parents who are not estimated too far
			if (m_ArchiveSize <= 3)
			{
				printf("Failed!!!\n");
				exit(0);
			}
			else
			{
				k = 0;
				do{
					r1 = m_rnd.rndint(0, m_ArchiveSize-1);
				}while (r1==i);
				do{
					r2 = m_rnd.rndint(0, m_ArchiveSize-1);
					d1 = indv_distance (pop1[r1], pop1[r2]); 
					k++;
				}while ((dist_parent<d1 && k<3) || r2==i || r2==r1);
				k = 0;
				do{
					r3 = m_rnd.rndint(0, m_ArchiveSize-1);
					d1 = indv_distance (pop1[r1], pop1[r3]); 
					k++;
				}while ((dist_parent<d1 && k<3) || r3==i || r3==r1 || r3==r2);
			}
		}
		/************* Generate the selected parents *******************/

		j = m_rnd.rndint(0, nreal-1);

		int L = 0;
		double low = 0, up = 0;
		temp = pop1[i];
		// DE/rand/1/bin strategy			
		for (k=0;k<nreal;k++)
		{
			if ((m_rnd.rndreal(0.0, 1.0)<m_CR) || (k==nreal-1))
			{
				aux = pop1[r3].xreal[j] + F * (pop1[r2].xreal[j] - pop1[r1].xreal[j]);
			}
			else
			{
				aux = pop1[i].xreal[j];
			}

			// make the individual not go beyond the bound
			aux -= min_realvar[j];
			aux = fmod (aux, (double)(max_realvar[j] - min_realvar[j]));
			if (aux < 0)
				aux *= -1;
			aux += min_realvar[j];
				
			temp.xreal[j] = aux;

			j = (j+1) % nreal;
		}

		// Evaluate the fitness of the individual generated by the 3 parents
		evaluate_ind(&temp);

		// update the extreme with the new child
		if (m_bExtreme == 1 && m_InitialFlag == 1)
		{
			int elag = 0;
			elag = update_extreme(temp);
		}

		flag = check_dominance(&temp, &parent);
		if (flag == 1)			// If it is better than the main parent, then it inserts into the secondary population
		{
			pop2[i] = temp;
		}
		else if (flag == -1)	// If it is not better than the main parent, add the main parent to the secondary population
			pop2[i] = parent;		
		// If both are non-dominated, then I let flip to 0.5 to know which remains 
		else if (flip (0.5))
			pop2[i] = parent;
		else
		{
			pop2[i] = temp;
		}

		// update the primary population
		if (!selection)
		{
			if (flag == 1 || flag == 2)
			{
				pop1[i] = temp;
			}
			else if (flag == 0 && flip(0.5))
			{
				pop1[i] = temp;
			}
		}
	}
}

void CDEMO1::find_nondominated(CIndividual *pop, int size)
{
	int i,j,flag;

	// initialize the non-dominated flag of the population
	for (i=0;i<size;i++)
	{
		pop[i].non_dominated = 1;
	}

	for (i = 0; i < size; i++)
	{
		for (j = i; j < size; j++)
		{
			if (i != j)
			{
				if (pop[i].non_dominated && pop[j].non_dominated)
				{
					flag = check_dominance (&pop[i], &pop[j]);	// compare the two individuals
					if (flag == 1 || flag == 2)
						pop[j].non_dominated = 0;		// j is dominated by i, it is marked as dominated 
					else if (flag == -1)
						pop[i].non_dominated = 0;		// i is dominated by j, it is marked as dominated
				}
			}
		}
	}
}

void CDEMO1::RunMyDE(int run_no, double seed)
{
	int i;
	clock_t start, finish;
	double time_consume = 0.0;

	srand((unsigned)time(NULL));

	// initialize the variables
	neval = 0;
	m_ArchiveSize = 0;
	//NO_EPS = 100;
	//T = 100;
	flag_epsilon = 0;
	flag_recalculation = 0;
	P = 0.0;
	X = 0.0;

	start = clock();		// ���߷�ʼ�������������ʱ��ͳ��

	m_rnd.randomize(seed);

	allocate_memory_pop (parent_pop, popsize);
	
	init_variables();

	if (m_InitialFlag == 0)
	{
		printf("The algorithm generates the initial population randomly.\n");
		initialize_pop();
		evaluate_pop();
	}
	else if (m_InitialFlag == 1)
	{
		printf("Orthogonal initial population is used.\n");
		m_ArchiveSize = 0;
		OrthogonalInitialPopulation();
		start = clock();	// ���߷�ʼ�������������ʱ��ͳ��
		for (int j=0;j<popsize;j++)
		{
			primaryPop[j] = parent_pop->ind[j];
		}
	}
	else
	{
		printf("You must select the initial population method.\n");
		exit(0);
	}
	
	// ----find the extreme points in the initial archive----
	if (m_bExtreme == 1 && m_InitialFlag == 1)
	{
		ofstream tmp(".\\results\\extreme.txt",ios::app);
		for (i=0;i<nobj;i++)
		{
			find_exetreme(m_ArchivePop, m_ArchiveSize, i);
			tmp.precision(5);
			for (int j=0;j<nobj;j++)
			{
				tmp<<setw(10)<<m_Exetreme[i].obj[j];
			}
			tmp<<setw(10)<<m_Exetreme[i].constr_violation<<endl;
		}
		//tmp.close();
	}

	int gen = 0;
	int temp_size = 0;
	int tt = (int)(m_selection*ngen);
	int ttt = (int)(m_selection*max_evaluation);
	int no_cal_times = 0;	// number of times of the grids recalculation
	int e_recal = 1;		// for recalculation flag
	int recal = 0;			// for recalculation flag (mutex of e_recal)
	while (gen < ngen && neval < max_evaluation)
	{		
		if (((gen < tt) && (neval < ttt)) || m_ArchiveSize < 4)	// random selection
		{
			generate_DE(primaryPop, secondaryPop, popsize, m_F, 0, m_Strategy);	
		}
		else													// elitist selection
		{
			generate_DE(m_ArchivePop, secondaryPop, popsize, m_F, 1, m_Strategy);
		}
		
		// look for and mark non-dominated solutions, 
		// where non_dominated=1 indicates that the individual is non-dominated
		find_nondominated(secondaryPop, popsize);

		// update the external population with the non-dominated solutions in the second population
		for (i=0;i<popsize;i++)
		{
			//if it is dominated we do not put it in external population
			if (secondaryPop[i].non_dominated)
			{
				if (!flag_epsilon)
				{// do not use the epsilon dominance					
					m_ArchiveSize = insert_without_epsilon_adaptive(m_ArchivePop, m_ArchiveSize, secondaryPop[i]);
				}
				else
				{// use the epsilon dominance
					m_ArchiveSize = insert_with_epsilon_adaptive(m_ArchivePop, m_ArchiveSize, secondaryPop[i], T, X, P);
				}
			}
		}
		
		gen++;

		int a = (int)((8e-1)*ngen);
		int b = (int)((8e-1)*max_evaluation);
		if (((gen>a) || (neval>b)) && (flag_epsilon)
			&& (m_ArchiveSize<T/2 || m_ArchiveSize>3*T/2))
		{
			recal = 1;	
		}

		// generate the pae-dominance grid (!! modigied here !!)
		if ((m_ArchiveSize >= NO_EPS) && (!flag_epsilon || flag_recalculation))// || (recal&&e_recal))
		{
			no_cal_times++;
			// calculate the grid
			// here the external[] has been sorted from low to high with respect to f[0]
			calculate_grid_adaptive(m_ArchivePop, m_ArchiveSize);

			// update the primary population
			if (m_ArchiveSize > popsize)
			{
				for (i=0;i<popsize;i++)
				{
					primaryPop[i] = m_ArchivePop[i];
				}
			}
			else
			{
				for (i=0;i<m_ArchiveSize;i++)
				{
					primaryPop[i] = m_ArchivePop[i];
				}
			}

			CIndividual *temp_pop;
			temp_pop = new CIndividual[MAX_ARCHIVE_SIZE];
			for (i=0;i<m_ArchiveSize;i++)
			{
				temp_pop[i] = m_ArchivePop[i];
			}

			temp_size = m_ArchiveSize;
			m_ArchiveSize = 0;			// reset the size of the external population

			// update the external[] with the new grids
			for (i=0;i<temp_size;i++)
			{
				calculate_box_index_adaptive(temp_pop[i]);
				m_ArchiveSize = insert_with_epsilon_adaptive(m_ArchivePop, m_ArchiveSize, temp_pop[i], T, X, P);
			}
			delete []temp_pop;

			flag_recalculation = 0;	// reset the recalculation flag
			flag_epsilon = 1;		// this value is modified here and only here
			if (recal == 1)
			{
				e_recal = 0;	
			}			
			recal = 0;				// reset the recalculation flag
		}

		finish = clock();
		time_consume = (double)(finish-start)/CLOCKS_PER_SEC;
		// comment the next line to save running time
		//printf ("\n in gen = %d the time is: %5.6f", gen, time_consume);
	}
	
	printf ("The curve value p = %f \nThe speed value x is: %f", P, X);
	printf("\nThe grid is recalculation %d times.",no_cal_times);
	printf ("\nAnd the obtained external size is: %d", m_ArchiveSize);
	printf ("\nThe total time is: %5.6f s", time_consume);
	printf ("\nFunction evaluations are: %d\n\n", neval);

	// combine the extreme points in the final archive
	if (m_bExtreme == 1 && m_InitialFlag == 1)
	{
		combine_extreme();
		ofstream tmp(".\\results\\extreme.txt",ios::app);
		for (i=0;i<nobj;i++)
		{
			find_exetreme(m_ArchivePop, m_ArchiveSize, i);
			tmp.precision(5);
			for (int j=0;j<nobj;j++)
			{
				tmp<<setw(10)<<m_Exetreme[i].obj[j];
			}
			tmp<<setw(10)<<m_Exetreme[i].constr_violation<<endl;
		}
		tmp<<"---------------------------------------"<<endl;
		tmp.close();
	}

	// ----------------output the results in the files----------------
	// ----output the final archive----
	// sort the final archive population with f[0]
	QuickSort(m_ArchivePop,0,m_ArchiveSize-1);
	char f_name[150];
	sprintf(f_name,"%s%d%s",".\\results\\final_archive\\final_archive_",run_no+1,".txt");		
	// output all of the sorted archive population to file to calculate the C(A,B) metric
	//ofstream sortedArchive1(".\\results\\final_archive_all.txt",ios::app);
	ofstream sortedArchive1(f_name);
	sortedArchive1.precision(8);
	for (i = 0; i < m_ArchiveSize; i++)
	{
		for (int j = 0; j < MAX; j++)
		{
			sortedArchive1<<setw(20)<<m_MaxOrMin[j] * m_ArchivePop[i].obj[j];
		}
		sortedArchive1<<endl;
	}
	sortedArchive1.close();

	printf("The statistic values are generated successfully!\n");	
	printf("\nRoutine successfully exited in generation %d!!! \n\n", run_no+1);

	deallocate_memory_pop (parent_pop);
}
