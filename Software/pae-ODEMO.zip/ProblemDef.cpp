// ProblemDef.cpp: implementation of the CProblemDef class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ProblemDef.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CProblemDef::CProblemDef()
{
}

CProblemDef::~CProblemDef()
{
}

/*  Test problem ZDT6
    # of real variables = 10
    # of bin variables = 0
    # of objectives = 2
    # of constraints = 0
    */
void CProblemDef::test_1_zdt6(double *xreal,double *obj, double *constr)
{
	double f1, f2, g, h;
    int i;
    f1 = 1.0 - (exp(-4.0*xreal[0]))*pow((sin(6.0*PI*xreal[0])),6.0);
    g = 0.0;
    for (i=1; i<N_of_x; i++)
    {
        g += xreal[i];
    }
    g = g/(N_of_x-1);
    g = pow(g,0.25);
    g = 1.0 + 9.0*g;
    h = 1.0 - pow((f1/g),2.0);
    f2 = g*h;
    obj[0] = f1;
    obj[1] = f2;
    return;
}
