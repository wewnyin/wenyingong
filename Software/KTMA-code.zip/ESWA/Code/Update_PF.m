function [OS_PF, MS_PF, SS_PF, PF, startEndTime_PF] = Update_PF(OS_PF, MS_PF, SS_PF, PF, startEndTime_PF, OS_Elite, MS_Elite, SS_Elite, objectiveValue_Elite, startEndTime_Elite)

if isempty(PF)
    OS_PF = OS_Elite;
    MS_PF = MS_Elite;
    SS_PF = SS_Elite;
    PF = objectiveValue_Elite;
    startEndTime_PF = startEndTime_Elite;
else
    deleteIndex = zeros(size(PF, 1), 1);    %找寻PF中被支配需要删除的解
    appendIndex = ones(size(objectiveValue_Elite, 1), 1);   %找寻objectiveValue_Elite中支配PF需要添加的解

%     for i = 1:size(objectiveValue_Elite, 1)
%         for j = 1:size(PF, 1)
%             %%%精英解支配PF中的解
%             if all(objectiveValue_Elite(i, :) <= PF(j, :)) && any(objectiveValue_Elite(i, :) < PF(j, :))
%                 deleteIndex(j) = 1;
%                 continue;
%             end
%             
%             %%%PF支配精英解
%             if all(PF(j, :) <= objectiveValue_Elite(i, :)) && any(PF(j, :) < objectiveValue_Elite(i, :))
%                 appendIndex(i) = 0;
%                 break;
%             end
%         end
%     end   

    for i = 1:size(PF, 1)
        for j = 1:size(objectiveValue_Elite, 1)
            %%%精英解支配PF中的解
            if all(objectiveValue_Elite(j, :) <= PF(i, :)) && any(objectiveValue_Elite(j, :) < PF(i, :))
                deleteIndex(i) = 1;
                break;
            end
        end
    end
    
    %%%删除PF中被支配的解
    index = find(deleteIndex == 1);
    OS_PF(index, :) = [];
    MS_PF(index, :) = [];
    SS_PF(index, :) = [];
    PF(index, :) = [];
    startEndTime_PF(index) = [];

    for i = 1:size(objectiveValue_Elite, 1)
        for j = 1:size(PF, 1)
            %%%PF支配精英解
            if all(PF(j, :) <= objectiveValue_Elite(i, :)) && any(PF(j, :) < objectiveValue_Elite(i, :))
                appendIndex(i) = 0;
                break;
            end
        end
    end
    
    %%%添加精英解中的非支配解
    index = find(appendIndex == 1);
    OS_PF = [OS_PF; OS_Elite(index, :)];
    MS_PF = [MS_PF; MS_Elite(index, :)];
    SS_PF = [SS_PF; SS_Elite(index, :)];
    PF = [PF; objectiveValue_Elite(index, :)];
    startEndTime_PF = [startEndTime_PF, startEndTime_Elite(index)];
        
    
    %%%删除重复数据
    deleteIndex = [];
    for i = 1:(size(PF, 1) - 1)
        for j = (i + 1):size(PF, 1)
            if ismember(i, deleteIndex)
                break;
            end

            if isequal(OS_PF(i, :), OS_PF(j, :)) && isequal(MS_PF(i, :), MS_PF(j, :)) && isequal(SS_PF(i, :), SS_PF(j, :))
                deleteIndex = [deleteIndex, j];
            end
        end
    end
    OS_PF(deleteIndex, :) = [];
    MS_PF(deleteIndex, :) = [];
    SS_PF(deleteIndex, :) = [];
    PF(deleteIndex, :) = [];
    startEndTime_PF(deleteIndex) = [];
    
end


end