function machineSequence = Rescheduling_Strategy(operationSequence, operationTimes, machineSequence, speedSequence, processingTime, machineWorkload, pos)

global M H;



for i = pos:length(operationSequence)
    jobNo = operationSequence(i);      %工件号
    availableMachine = find(processingTime{jobNo}(operationTimes(i), :) > 0);     %可选机器号
    
    %%%提取机器负载
    workloadArray = Inf(1, M);
    workloadArray(availableMachine) = machineWorkload(availableMachine);
    
    %%%选取机器负载最小的机器
    machineSet = find(workloadArray == min(workloadArray));
    machineNo = machineSet(randperm(length(machineSet), 1));    %随机性导致每次重调度的序列可能不同，但是可能增加种群多样性
%     machineNo = machineSet(1);    %每次重调度的序列相同，但是减少种群的多样性
    
    %%%重新调度，修改机器码
    machineSequence(sum(H(1:jobNo - 1)) + operationTimes(i)) = machineNo;
    
    %%%更新机器负载
    machineLevel = speedSequence(sum(H(1:jobNo - 1))+ operationTimes(i));     %机器速度等级
    time = processingTime{jobNo}(operationTimes(i), machineNo) / machineLevel;      %工序的实际加工时间
    machineWorkload(machineNo) = machineWorkload(machineNo) + time;

end


end