function TEC = Update_TEC(p_chrom, m_chrom, s_chrom, processingTime, startEndTime, startupShutdownPower, processingPower, idlePower)
%%%更新TEC

global N M H SH;    

%%%先完成解码标记每个工序的工件和工序号
s1 = p_chrom;
s2 = zeros(1, SH);
p = zeros(1, N);
    
for i = 1:SH
    p(s1(i)) = p(s1(i)) + 1;    %记录过程是否加工完成，完成一次加一
    s2(i) = p(s1(i));     %记录加工过程中，工件的次数
end
    
for i = 1:SH
    t1 = s1(i);   %记录到当前是哪个工件
    t2 = s2(i);   %记录当前工件是加工到第几次
    mm(i) = m_chrom(sum(H(1:t1-1)) + t2);   %提取该工序该次加工的机器选择，因为机器码的排列表示该工件第几次加工所选的机器，是一段表示一个工件
    ss(i) = s_chrom(sum(H(1:t1-1)) + t2);   %提取该工序该次加工的机器速度选择
end

TEC = 0;
machineAvailableTime = zeros(1, M);     %机器最早可用时间

%%%更新机器最早可用时间
for i = 1:M
    index = find(mm == i);
    if ~isempty(index)
        job = s1(index(1));
        op = s2(index(1));
        machineAvailableTime(i) = startEndTime{job}(op, 1);
    end
end

for i = 1:SH
    job = s1(i);
    op = s2(i);
    machine = mm(i);
    speed = ss(i);
    
    if op == 1
        workTime = startEndTime{job}(op, 2) - startEndTime{job}(op, 1);     %加工时间
        actual_Processing_Time = processingTime{job}(op, machine) / speed;      %实际加工时间（因为有机器维修时间，这个时间不可以算到加工功率里面去）
        machineAvailableTime(machine) = machineAvailableTime(machine) + workTime;   %更新机器最早可用时间
        TEC = TEC + actual_Processing_Time * processingPower(machine, speed);     %更新TEC
    else
        workTime = startEndTime{job}(op, 2) - startEndTime{job}(op, 1);     %加工时间
        actual_Processing_Time = processingTime{job}(op, machine) / speed;      %实际加工时间（因为有机器维修时间，这个时间不可以算到加工功率里面去）

        %%%计算空闲功率，更新总能量消耗
        idleTime = startEndTime{job}(s2(i) - 1, 2) - machineAvailableTime(machine);
        if idleTime > 0
            TEC = TEC + idleTime * idlePower(machine, speed);   %更新TEC
        end

        machineAvailableTime(machine) = max(startEndTime{job}(s2(i) - 1, 2), machineAvailableTime(machine)) + workTime;   %更新机器最早可用时间
        TEC = TEC + actual_Processing_Time * processingPower(machine, speed);     %更新TEC

    end

end

%%%计算开机/关机功率，更新总能量消耗
for i = 1:M
    TEC = TEC + 2 * startupShutdownPower(i);        %（开机/关机一共2s）
end


end