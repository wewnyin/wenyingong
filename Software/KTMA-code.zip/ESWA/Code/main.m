clc;
clear;
tic;

global N M H P G MU CR SH;

%%%数据中最多有15台机器 
% machineBreakdownInterval = [62, 64, 58, 57, 70, 51, 68, 68, 66, 52, 55, 57, 64, 53, 64];    %机器故障间隔
machineBreakdownInterval = [106, 101, 92, 91, 98, 97, 97, 102, 99, 98, 110, 107, 91, 108, 103];    %机器故障间隔(时间翻3倍)
machineRepairTime = [11, 17, 10, 11, 15, 11, 18, 18, 17, 11, 17, 15, 20, 16, 18];   %机器修复时间
startupShutdownPower = [85.84, 88.63, 80.31, 99.68, 83.34, 82.12, 87.45, 83.96, 89.79, 86.79, 99.03, 98.41, 81.05, 94.76, 85.38]; %机器开机/关机功率
processingPower = [31.21, 49.06, 57.00;
                   35.90, 48.80, 56.39;
                   32.26, 48.18, 50.34;
                   33.85, 42.61, 50.69;
                   35.83, 45.94, 53.20;
                   32.52, 40.23, 55.31;
                   32.90, 44.25, 56.54;
                   36.17, 43.13, 54.08;
                   32.65, 41.61, 58.20;
                   38.24, 41.79, 57.18;
                   39.83, 44.23, 59.69;
                   37.30, 40.94, 55.31;
                   33.44, 45.99, 53.25;
                   35.84, 44.71, 51.06;
                   31.08, 46.96, 56.11];    %机器的加工功率，共有3个Level
idlePower = [6.76, 19.16, 26.07;
             2.89, 10.01, 21.92;
             6.72, 14.62, 27.38;
             6.95, 14.24, 22.43;
             1.68, 14.61, 29.17;
             2.55, 17.70, 22.69;
             2.24, 13.22, 27.66;
             6.68, 17.85, 21.89;
             8.44, 14.71, 22.87;
             3.44, 10.36, 20.91;
             7.81, 11.76, 25.76;
             6.75, 17.22, 26.83;
             5.67, 14.73, 27.47;
             6.02, 11.53, 24.26;
             3.87, 13.41, 26.66];   %机器的空闲功率，共有3个Level

         

filename = 'Data set\Brandimarte_Data\Mk09.txt';
[N, M, H, processingTime] = Load_Data(filename);    %加载工件数，机器数，每个工件的工序数量，加工时间
SH = sum(H);

P = 100;    %种群大小
G = 200;    %迭代次数

CR = 0.8;   	%交叉概率
MU = 0.2;   	%变异概率

PF = [];    %存档集，存储非支配解
OS_PF = [];     %存储非支配解的工序码，便于第二阶段的节能策略
MS_PF = [];     %存储非支配解的机器码，便于第二阶段的节能策略
SS_PF = [];     %存储非支配解的机器速度码，便于第二阶段的节能策略
startEndTime_PF = {};   %存储非支配解的工序开始加工时间和完工时间

for run = 1:1        %独立运行run次
    
    %%%%%第一阶段：初始优化
    %%%混合初始化工序码、机器码、机器速度码
    [OS, MS, SS] = Hybrid_Initialization(processingTime, machineBreakdownInterval, machineRepairTime);
    
    %%%计算最大完工时间和总能量消耗
    [objectiveValue, startEndTime, MS] = Calculate_Objective_Value(OS, MS, SS, processingTime, machineBreakdownInterval, machineRepairTime, startupShutdownPower, processingPower, idlePower);     
    
    %%%快速非支配排序
    [OS, MS, SS, objectiveValue, rank, startEndTime] = Non_Domination_Sort(OS, MS, SS, objectiveValue, startEndTime);      
    
    %%%计算拥挤度并排序
    [OS, MS, SS, objectiveValue, crowdingDistance, startEndTime] = Calculate_Crowding_Distance(OS, MS, SS, objectiveValue, rank, startEndTime);
    
    %%%迭代循环
    for i = 1:G
        fprintf('第%d次迭代\n', i);
        
        %%%采用竞标赛选择出P/2个个体
        [OS_selection, MS_selection, SS_selection] = Tournament_Selection(OS, MS, SS, rank, crowdingDistance);
        
        %%%进行交叉、变异操作，产生大约P个个体
        [OS_offspring, MS_offspring, SS_offspring] = Genetic_operation(OS_selection, MS_selection, SS_selection, processingTime);
        
        %%%计算最大完工时间和总能量消耗
        [objectiveValue_offspring, startEndTime_offspring, MS_offspring] = Calculate_Objective_Value(OS_offspring, MS_offspring, SS_offspring, processingTime, machineBreakdownInterval, machineRepairTime, startupShutdownPower, processingPower, idlePower); 
        
        %%%合并父代和子代
        OS = [OS; OS_offspring];
        MS = [MS; MS_offspring];
        SS = [SS; SS_offspring];
        objectiveValue = [objectiveValue; objectiveValue_offspring];
        for j = 1:length(startEndTime_offspring)
            startEndTime{end + 1} = startEndTime_offspring{j};
        end

        %%%快速非支配排序
        [OS, MS, SS, objectiveValue, rank, startEndTime] = Non_Domination_Sort(OS, MS, SS, objectiveValue, startEndTime);      

        %%%计算拥挤度并排序
        [OS, MS, SS, objectiveValue, ~, startEndTime] = Calculate_Crowding_Distance(OS, MS, SS, objectiveValue, rank, startEndTime);
        
        
        
        %%%随机选取P/4个个体进行变邻域搜索，防止陷入局部最优
        selection = randperm(size(OS, 1), P/4);
        OS_selection = OS(selection, :);
        MS_selection = MS(selection, :);
        SS_selection = SS(selection, :);
        objectiveValue_selection = objectiveValue(selection, :);
        startEndTime_selection = startEndTime(selection);
        
        %%%变邻域搜索
        [OS_offspring, MS_offspring, SS_offspring] = Variable_Neighborhood_Search(OS_selection, MS_selection, SS_selection, processingTime, startEndTime_selection, machineBreakdownInterval, machineRepairTime, startupShutdownPower, processingPower, idlePower);

        %%%计算最大完工时间和总能量消耗
        [objectiveValue_offspring, startEndTime_offspring, MS_offspring] = Calculate_Objective_Value(OS_offspring, MS_offspring, SS_offspring, processingTime, machineBreakdownInterval, machineRepairTime, startupShutdownPower, processingPower, idlePower); 
        
        %%%合并种群
        OS = [OS; OS_offspring];
        MS = [MS; MS_offspring];
        SS = [SS; SS_offspring];
        objectiveValue = [objectiveValue; objectiveValue_offspring];
        for j = 1:length(startEndTime_offspring)
            startEndTime{end + 1} = startEndTime_offspring{j};
        end
        
        
        
        %%%选出P个种群
        %%%快速非支配排序
        [OS, MS, SS, objectiveValue, rank, startEndTime] = Non_Domination_Sort(OS, MS, SS, objectiveValue, startEndTime);      

        %%%计算拥挤度并排序
        [OS, MS, SS, objectiveValue, ~, startEndTime] = Calculate_Crowding_Distance(OS, MS, SS, objectiveValue, rank, startEndTime);
        
        %%%去除种群中重复个体
        [OS, MS, SS, objectiveValue, startEndTime] = Delete_Duplicate_Individuals(OS, MS, SS, objectiveValue, startEndTime);
        
        %%%选出P个种群
        if size(OS, 1) >= P
            OS = OS(1:P, :);
            MS = MS(1:P, :);
            SS = SS(1:P, :);
            objectiveValue = objectiveValue(1:P, :);
            startEndTime = startEndTime(1:P);
            rank = rank(1:P);
        else
            %%%补全种群个体到P
            quantity = P - size(OS, 1);
            [OS_complement, MS_complement, SS_complement] = Complement_Population(processingTime, quantity);

            %%%计算最大完工时间和总能量消耗
            [objectiveValue_complement, startEndTime_complement, MS_complement] = Calculate_Objective_Value(OS_complement, MS_complement, SS_complement, processingTime, machineBreakdownInterval, machineRepairTime, startupShutdownPower, processingPower, idlePower); 

            %%%合并种群
            OS = [OS; OS_complement];
            MS = [MS; MS_complement];
            SS = [SS; SS_complement];
            objectiveValue = [objectiveValue; objectiveValue_complement];
            for j = 1:length(startEndTime_complement)
                startEndTime{end + 1} = startEndTime_complement{j};
            end
        end
        
        %%%快速非支配排序
        [OS, MS, SS, objectiveValue, rank, startEndTime] = Non_Domination_Sort(OS, MS, SS, objectiveValue, startEndTime);      

        %%%计算拥挤度并排序
        [OS, MS, SS, objectiveValue, crowdingDistance, startEndTime] = Calculate_Crowding_Distance(OS, MS, SS, objectiveValue, rank, startEndTime);
    
        
        
        %%%找出精英个体
        index = find(rank == 1);
        OS_Elite = OS(index, :);
        MS_Elite = MS(index, :);
        SS_Elite = SS(index, :);
        objectiveValue_Elite = objectiveValue(index, :);
        startEndTime_Elite = startEndTime(index);
        
        %%%更新PF
        [OS_PF, MS_PF, SS_PF, PF, startEndTime_PF] = Update_PF(OS_PF, MS_PF, SS_PF, PF, startEndTime_PF, OS_Elite, MS_Elite, SS_Elite, objectiveValue_Elite, startEndTime_Elite);


        
        %%%画出非支配解
        clf
        [~, index] = sort(PF(:, 1));
        PF_temp = PF(index, :);
        plot(PF_temp(:, 1), PF_temp(:, 2), '-o');
        title(['KTMA第一阶段：第', num2str(i), '次迭代']);
        xlabel('最大完工时间');
        ylabel('总能量消耗');
        hold on
        scatter(objectiveValue(:, 1), objectiveValue(:, 2));
        drawnow

    end



    %%%%%第二阶段：节能策略
    popSize = size(PF, 1);
    
    E0 = [];    %存储PF
    E1 = [];    %存储节能策略1优化后的PF
    E2 = [];    %存储节能策略2优化后的PF
    
    for i = 1:popSize
        
        E0 = [E0; PF(i, :)];

        %%%%%使用右移策略，在不增加最大完工时间的基础上减小总能量消耗
        startEndTime_PF_ES1 = Energy_Saving_Strategy1(OS_PF(i, :), MS_PF(i, :), SS_PF(i, :), PF(i, 1), startEndTime_PF{i});        
        
        %%%更新总能量消耗
        PF(i, 2) = Update_TEC(OS_PF(i, :), MS_PF(i, :), SS_PF(i, :), processingTime, startEndTime_PF_ES1, startupShutdownPower, processingPower, idlePower);

        E1 = [E1; PF(i, :)];

        %%%%%机器关闭/打开准则（Machine turn off rule）：如果关闭/打开所消耗的能量小于空闲所消耗的能量就将机器关闭/打开
        PF(i, 2) = Energy_Saving_Strategy2(OS_PF(i, :), MS_PF(i, :), SS_PF(i, :), startEndTime_PF_ES1, startupShutdownPower, idlePower, PF(i, 2));

        E2 = [E2; PF(i, :)];

    end

    toc

    clf
    [~, index] = sort(E0(:, 1));
    E0 = E0(index, :);
    plot(E0(:, 1), E0(:, 2), '-o');
    title(['KTMA第二阶段']);
    xlabel('最大完工时间');
    ylabel('总能量消耗');
    hold on
    
    E1 = Find_Nondominated_Solutions(E1);
    [~, index] = sort(E1(:, 1));
    E1 = E1(index, :);
    plot(E1(:, 1), E1(:, 2), '-*');
    hold on
    
    E2 = Find_Nondominated_Solutions(E2);
    [~, index] = sort(E2(:, 1));
    E2 = E2(index, :);
    plot(E2(:, 1), E2(:, 2), '-+');
    legend('PF','Energy Saving Strategy 1','Energy Saving Strategy 2');
    drawnow

    E0 = unique(E0, 'row');
    delete('KTMA.xlsx');
    delete('KTMA_E1.xlsx');
    delete('KTMA_E2.xlsx');
    xlswrite('KTMA.xlsx', E0);
    xlswrite('KTMA_E1.xlsx', E1);
    xlswrite('KTMA_E2.xlsx', E2);
    

end




