function criticalPathBlock = Find_Critical_Path_Block(p_chrom, m_chrom, s_chrom, startEndTime, machineBreakdownInterval, machineRepairTime, startupShutdownPower, processingPower, idlePower, criticalPath)
 
global N M H SH;

%%%提取关键工序
s1 = p_chrom;     
s2 = zeros(1, SH);      
p = zeros(1, N);

for i = 1:SH
    p(s1(i)) = p(s1(i)) + 1;    %记录过程是否加工完成，完成一次加一
    s2(i) = p(s1(i));     %记录加工过程中，工件的次数
end

for i = 1:SH
    t1 = s1(i);   %记录到当前是哪个工件
    t2 = s2(i);   %记录当前工件是加工到第几次
    ms(i) = m_chrom(sum(H(1:t1-1)) + t2);   %提取该工序该次加工的机器选择，因为机器码的排列表示该工件第几次加工所选的机器，是一段表示一个工件
    ss(i) = s_chrom(sum(H(1:t1-1)) + t2);   %提取该工序该次加工的机器速度选择
end

s1 = s1(criticalPath);      %关键工序
s2 = s2(criticalPath);      %关键工件加工次数
ms = ms(criticalPath);      %关键工序的机器选择
ss = ss(criticalPath);      %关键工序的机器速度
    
%%%找出关键路径块
machineAssignment = cell(1, M);
for i = 1:M
    startTime = [];     %存储每个工序的开始加工时间
    index = find(ms == i);
    for j = 1:length(index)
        job = s1(index(j));
        op = s2(index(j));
        startTime(j) = startEndTime{job}(op, 1);
    end
    [~, idx] = sort(startTime);   %将工序按照开始加工时间排序，便于寻找关键路径块
    
    %%%矩阵第一列为关键路径对应的索引值，第二列为关键工序，第三列为关键工件的加工次数
    machineAssignment{i} = [criticalPath(index(idx))', s1(index(idx))', s2(index(idx))'];
end
criticalPathBlock = {};
count = 1;
for i = 1:M
    assignmentArray = machineAssignment{i};
    if ~isempty(assignmentArray)
        block = [];
        index = 1;
        
        while index < size(assignmentArray, 1) 
            job1 = assignmentArray(index, 2);    %工件1
            op1 = assignmentArray(index, 3);     %工序1
            job2 = assignmentArray(index + 1, 2);    %工件2
            op2 = assignmentArray(index + 1, 3);     %工序2

            %%%如果工件1的工序1的完工时间等于工件2的工序2的开始加工时间，则构成关键路径块
            if startEndTime{job1}(op1, 2) == startEndTime{job2}(op2, 1)
                block = [block, assignmentArray(index, 1)];
                while startEndTime{job1}(op1, 2) == startEndTime{job2}(op2, 1) && index < size(assignmentArray, 1)
                    job1 = assignmentArray(index, 2);    %工件1
                    op1 = assignmentArray(index, 3);     %工序1
                    job2 = assignmentArray(index + 1, 2);    %工件2
                    op2 = assignmentArray(index + 1, 3);     %工序2
                    block = [block, assignmentArray(index + 1, 1)];
                    index = index + 1;
                end
                criticalPathBlock{count} = block;
                count = count + 1;
                block = [];
                index = index + 1;
            else
                index = index + 1;
            end
            
        end
            
    end

end
end