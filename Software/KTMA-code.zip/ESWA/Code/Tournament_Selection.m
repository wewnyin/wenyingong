function [OS_selection, MS_selection, SS_selection] = Tournament_Selection(OS, MS, SS, rank, crowdingDistance)

global P;

OS_selection = [];
MS_selection = [];
SS_selection = [];

for i = 1:(P / 2)
    index1 = ceil(rand * P);
    index2 = ceil(rand * P);
    while index1 == index2
        index2 = ceil(rand * P);    %防止两个相同个体
    end
    
    index = 0;
    %%%先比较rank等级，rank等级小的个体较好；rank等级相等的情况下比较拥挤度，拥挤度较大的个体较好
    if rank(index1) < rank(index2)
        index = index1;
    elseif rank(index1) == rank(index2)
        if crowdingDistance(index1) < crowdingDistance(index2)
            index = index2;
        elseif crowdingDistance(index1) > crowdingDistance(index2)
            index = index1;
        else
            if rand > 0.5
                index = index1;
            else
                index = index2;
            end
        end
    else
        index = index2;
    end
        
    OS_selection = [OS_selection; OS(index, :)];
    MS_selection = [MS_selection; MS(index, :)];
    SS_selection = [SS_selection; SS(index, :)];
    
    
end


end