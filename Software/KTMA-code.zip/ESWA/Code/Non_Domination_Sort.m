function [OS, MS, SS, objectiveValue, rank, startEndTime] = Non_Domination_Sort(OS, MS, SS, objectiveValue, startEndTime)       %快速非支配排序，并排序

front = 1;
Front(front).f = [];
individual = [];
len = size(objectiveValue, 1);
rank = zeros(len, 1);

%找出等级最高的非支配解集
for i = 1:len
    individual(i).n = 0;    %n是个体i被支配的个体数量
    individual(i).p = [];   %p是被个体i支配的个体集合
    
    for j = 1:size(objectiveValue, 1)
        if all(objectiveValue(j, :) <= objectiveValue(i, :)) && any(objectiveValue(j, :) < objectiveValue(i, :))
            individual(i).n = individual(i).n + 1;      %说明i受j支配，相应的n加1
        elseif all(objectiveValue(i, :) <= objectiveValue(j, :)) && any(objectiveValue(i, :) < objectiveValue(j, :))
            individual(i).p = [individual(i).p, j];     %说明i支配j，把j加入i的支配集合中
        end
        
    end
    if individual(i).n == 0     %个体i的非支配等级最高，属于当前的最优解
        rank(i) = 1;
        Front(front).f = [Front(front).f, i];   %等级为1的非支配解集
    end
end
 
%给其他个体分级
while ~isempty(Front(front).f)
    Q = [];     %存放下一个front集合
    for i = 1:length(Front(front).f)
        if ~isempty(individual(Front(front).f(i)).p)    %个体i有自己所支配的解集
            for j = 1:length(individual(Front(front).f(i)).p)
                individual(individual(Front(front).f(i)).p(j)).n = individual(individual(Front(front).f(i)).p(j)).n - 1;
                if individual(individual(Front(front).f(i)).p(j)).n == 0    %将非支配集合放入Q
                    rank(individual(Front(front).f(i)).p(j)) = front + 1;
                    Q = [Q, individual(Front(front).f(i)).p(j)];
                end
            end
        end
    end
    front = front + 1;
    Front(front).f = Q;
end
                    
[~, index] = sort(rank);  
OS = OS(index, :);
MS = MS(index, :);
SS = SS(index, :);
objectiveValue = objectiveValue(index, :);
rank = rank(index);
startEndTime = startEndTime(index);



end