function [OS_complement, MS_complement, SS_complement] = Complement_Population(processingTime, quantity)

global N H M SH;

OS_complement = [];
MS_complement = [];
SS_complement = [];

%%%OS的基础序列按照1 1 1 2 2 3 3...排列，后续通过打乱这个初始序列来生成种群
basicSequence = [];

for i = 1:N
    sequence = ones(1, H(i)) * i;
    basicSequence = [basicSequence, sequence];
end

%%%随机初始化工序码、机器速度码
for i = 1:quantity
    
    %随机初始化工序码
    index = randperm(SH);
    operationSequence = basicSequence(index);
    OS_complement = [OS_complement; operationSequence];
    
    %随机初始化机器速度码
    speedSequence = round(rand(1, SH) * 2 + 1);
    SS_complement = [SS_complement; speedSequence];
    
end

%%%机器码初始化遵循以下3个准则: 局部机器负载最小准则(0.5), 最小加工时间准则(0.3), 降低机器速度准则(0.2)
for i = 1:quantity
    
    machineSequence = zeros(1, SH);   %机器码
    machineWorkload = zeros(1, M);  %存储各个机器的机器负载
    
    s1 = OS_complement(i, :);  
    s2 = zeros(1, SH);
    p = zeros(1, N);
    for j = 1:SH
        p(s1(j)) = p(s1(j)) + 1;    %记录过程是否加工完成，完成一次加一
        s2(j) = p(s1(j));     %记录加工过程中，工件的次数
    end
    
    for j = 1:SH
        probability = rand;
        
        if probability <= 0.5  %选择总机器负载最小的机器，若机器不止一个则从中随机选取
            
            job = s1(j);     %待加工工件
            availableMachine = find(processingTime{job}(s2(j), :) > 0);   %可用机器号   
            
            machineOptions = Inf(1, M);
            machineOptions(availableMachine) = machineWorkload(availableMachine);   %可供选择的机器集，根据总机器负载选择，inf表示不可选
            machineSelection = find(machineOptions == min(machineOptions));     %可选机器集
            machineNumber = machineSelection(randperm(length(machineSelection), 1));  %选出机器
            
            machineSequence(sum(H(1:job - 1)) + s2(j)) = machineNumber;       %将机器号加入机器码
            machineWorkload(machineNumber) = machineWorkload(machineNumber) + processingTime{job}(s2(j), machineNumber) / SS_complement(i,j);   %更新机器负载，加工时间为标准加工时间/机器速度
            
        elseif probability <= 0.8  %选择加工时间最小的机器，若机器不止一个则从中随机选取
            
            job = s1(j);     %待加工工件
            availableMachine = find(processingTime{job}(s2(j), :) > 0);   %可用机器号   
            
            machineOptions = Inf(1, M);
            machineOptions(availableMachine) = processingTime{job}(s2(j), availableMachine);   %可供选择的机器集，根据加工时间选择，inf表示不可选
            machineSelection = find(machineOptions == min(machineOptions));     %可选机器集
            machineNumber = machineSelection(randperm(length(machineSelection), 1));  %选出机器
            
            machineSequence(sum(H(1:job - 1)) + s2(j)) = machineNumber;       %将机器号加入机器码
            machineWorkload(machineNumber) = machineWorkload(machineNumber) + processingTime{job}(s2(j), machineNumber) / SS_complement(i,j);   %更新机器负载，加工时间为标准加工时间/机器速度
            
        else    %机器随机选择，降低一档机器的加工速度，若机器加工速度为1则保持不变
            
            job = s1(j);     %待加工工件
            availableMachine = find(processingTime{job}(s2(j), :) > 0);   %可用机器号
            
            machineNumber = availableMachine(randperm(length(availableMachine), 1));  %选出机器
            
            machineSequence(sum(H(1:job - 1)) + s2(j)) = machineNumber;       %将机器号加入机器码
            machineWorkload(machineNumber) = machineWorkload(machineNumber) + processingTime{job}(s2(j), machineNumber) / SS_complement(i,j);   %更新机器负载，加工时间为标准加工时间/机器速度
            
            if SS_complement(i, j) > 1     %机器速度降低一个level
                SS_complement(i, j) = SS_complement(i, j) - 1;
            end
            
        end

    end
    
    MS_complement = [MS_complement; machineSequence];
    
end



end