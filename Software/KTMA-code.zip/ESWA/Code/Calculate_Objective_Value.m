function [objectiveValue, startEndTime, MS] = Calculate_Objective_Value(OS, MS, SS, processingTime, machineBreakdownInterval, machineRepairTime, startupShutdownPower, processingPower, idlePower) 

global N M H SH;

objectiveValue = [];    %存储目标函数值
startEndTime = {};      %存储种群中每个工序的开始加工时间和结束加工时间
len = size(OS, 1);
for i = 1:len
    totalEnergyConsumption = 0;       %总的能量消耗
    machineAvailableTime = zeros(1, M);     %机器最早可用时间
    machineWorkload = zeros(1, M);     %机器的工作负载
    machineEnduranceLoad = zeros(1, M);     %机器的耐久度负载
    
    %%%startEnd{1}(1, 1)表示工件1的第1道工序的开始加工时间，startEnd{1}(1, 2)表示工件1的第1道工序的结束加工时间
    startEnd = {};      
    for j = 1:N
        array = zeros(size(processingTime{j}, 1), 2);
        startEnd{j, 1} = array;
    end
    
    s1 = OS(i, :);     %s1用来存放种群中的每个工序码
    s2 = zeros(1, SH);      %s2用来存放每个工件的是第几个工序
    p = zeros(1, N);
    
    for t = 1:SH
        p(s1(t)) = p(s1(t)) + 1;
        s2(t) = p(s1(t));
    end
    
    for j = 1:SH
        
        if (s2(j) == 1)
            jobNo = s1(j);      %工件号
            machineNo = MS(i, sum(H(1:(jobNo - 1)))+ 1);    %机器号
            machineLevel = SS(i, sum(H(1:(jobNo - 1)))+ 1);     %机器速度等级
            time = processingTime{jobNo}(1, machineNo) / machineLevel;      %工序的实际加工时间
            totalEnergyConsumption = totalEnergyConsumption + time * processingPower(machineNo, machineLevel);      %计算加工功率，更新总能量消耗
            
            startEnd{jobNo}(1, 1) = machineAvailableTime(machineNo);    %记录工序的开始加工时间
            if machineEnduranceLoad(machineNo) + time >= machineBreakdownInterval(machineNo)
                
                startEnd{jobNo}(1, 2) = startEnd{jobNo}(1, 1) + time + machineRepairTime(machineNo);    %记录工序的结束加工时间
                machineAvailableTime(machineNo) = startEnd{jobNo}(1, 2);
                machineWorkload(machineNo) = machineWorkload(machineNo) + time + machineRepairTime(machineNo);     %更新机器负载
                
                %更新机器耐久度负载（如果更新后机器耐久负载仍然大于machineBreakdownInterval，则继续更新，并且加上修复时间，但是在这不会出现这样的情况）
                machineEnduranceLoad(machineNo) = machineEnduranceLoad(machineNo) + time - machineBreakdownInterval(machineNo);   
                
                %重调度策略：机器损坏前的调度序列保持不变，机器损坏后的调度序列按顺序选择机器负载最小的机器插入
                MS(i, :) = Rescheduling_Strategy(s1, s2, MS(i, :), SS(i, :), processingTime, machineWorkload, j + 1);
               
            else
                
                startEnd{jobNo}(1, 2) = startEnd{jobNo}(1, 1) + time;    %记录工序的结束加工时间
                machineAvailableTime(machineNo) = startEnd{jobNo}(1, 2);
                machineWorkload(machineNo) = machineWorkload(machineNo) + time;     %更新机器负载
                machineEnduranceLoad(machineNo) = machineEnduranceLoad(machineNo) + time;   %更新机器耐久度负载
                
            end
               
        else
            jobNo = s1(j);      %工件号
            machineNo = MS(i, sum(H(1:(jobNo - 1)))+ s2(j));    %机器号
            machineLevel = SS(i, sum(H(1:(jobNo - 1)))+ s2(j));     %机器速度等级
            time = processingTime{jobNo}(s2(j), machineNo) / machineLevel;      %工序的实际加工时间
            totalEnergyConsumption = totalEnergyConsumption + time * processingPower(machineNo, machineLevel);      %计算加工功率，更新总能量消耗
            
            startEnd{jobNo}(s2(j), 1) = max(machineAvailableTime(machineNo), startEnd{jobNo}(s2(j) - 1, 2));    %记录工序的开始加工时间
            
            %%%计算空闲功率，更新总能量消耗
            idleTime = startEnd{jobNo}(s2(j) - 1, 2) - machineAvailableTime(machineNo);
            if idleTime > 0
                totalEnergyConsumption = totalEnergyConsumption + idleTime * idlePower(machineNo, machineLevel);      %计算空闲功率，更新总能量消耗
            end
            
            if machineEnduranceLoad(machineNo) + time >= machineBreakdownInterval(machineNo)
                
                startEnd{jobNo}(s2(j), 2) = startEnd{jobNo}(s2(j), 1) + time + machineRepairTime(machineNo);    %记录工序的结束加工时间
                machineAvailableTime(machineNo) = startEnd{jobNo}(s2(j), 2);
                machineWorkload(machineNo) = machineWorkload(machineNo) + time + machineRepairTime(machineNo);     %更新机器负载
                
                %更新机器耐久度负载（如果更新后机器耐久负载仍然大于machineBreakdownInterval，则继续更新，并且加上修复时间，但是在这不会出现这样的情况）
                machineEnduranceLoad(machineNo) = machineEnduranceLoad(machineNo) + time - machineBreakdownInterval(machineNo);   %更新机器耐久度负载
                
                %重调度策略：机器损坏前的调度序列保持不变，机器损坏后的调度序列按顺序选择机器负载最小的机器插入
                MS(i, :) = Rescheduling_Strategy(s1, s2, MS(i, :), SS(i, :), processingTime, machineWorkload, j + 1);
                
            else
                
                startEnd{jobNo}(s2(j), 2) = startEnd{jobNo}(s2(j), 1) + time;    %记录工序的结束加工时间
                machineAvailableTime(machineNo) = startEnd{jobNo}(s2(j), 2);
                machineWorkload(machineNo) = machineWorkload(machineNo) + time;     %更新机器负载
                machineEnduranceLoad(machineNo) = machineEnduranceLoad(machineNo) + time;   %更新机器耐久度负载
                
            end
            
        end
        
    end
    
    makespan = max(machineAvailableTime);       %最大完工时间
    
    %%%计算开机/关机功率，更新总能量消耗
    for k = 1:M
        totalEnergyConsumption = totalEnergyConsumption + 2 * startupShutdownPower(k);
    end
    
    objectiveValue = [objectiveValue; [makespan, totalEnergyConsumption]];
    startEndTime{i} = startEnd;
    
end


end