function [OS_offspring, MS_offspring, SS_offspring] = Genetic_operation(OS_selection, MS_selection, SS_selection, processingTime)
%%%进行交叉、变异操作

global N H SH MU CR;

OS_offspring = [];
MS_offspring = [];
SS_offspring = [];
len = size(OS_selection, 1);

%%%找出各个工序的可用机器
availableMachine = {};
count = 1;
for i = 1:N
    for j = 1:H(i)
        machineSet = find(processingTime{i}(j, :) > 0);
        availableMachine{count} = machineSet;
        count = count + 1;
    end
end

%%%交叉操作，工序码采用IPOX交叉算子；机器码、机器速度码采用MPX交叉算子
for i = 1:len
    if rand < CR
        %%%工序码采用IPOX交叉算子
        index1 = ceil(rand * len);
        index2 = ceil(rand * len);
        while index1 == index2
            index2 = ceil(rand * len);
        end
        o1 = OS_selection(index1, :);
        o2 = OS_selection(index2, :);
        
        save1 = randperm(N, ceil(rand * (N - 1)));       %o1保留的工件
        save2 = [];                     %o2保留的工件
        for j = 1:N
            if ~ismember(j, save1)
                save2 = [save2, j];
            end
        end
        
        o1_offspring = zeros(1, SH);   %存储子代1
        o2_offspring = zeros(1, SH);   %存储子代2
        
        %%%复制o1包含在save1的工件到o1_offspring
        for j = 1:length(save1)
            index = find(o1 == save1(j));
            o1_offspring(index) = o1(index);
        end
        
        %%%复制o2包含在save2的工件到o2_offspring
        for j = 1:length(save2)
            index = find(o2 == save2(j));
            o2_offspring(index) = o2(index);
        end
        
        %%%复制o1包含在save1的工件到o2_offspring；复制o2包含在save2的工件到o1_offspring
        saveSequence1 = o1_offspring(find(o1_offspring > 0));
        saveSequence2 = o2_offspring(find(o2_offspring > 0));
        
        o2_offspring(find(o2_offspring == 0)) = saveSequence1;
        o1_offspring(find(o1_offspring == 0)) = saveSequence2;
        OS_offspring = [OS_offspring; o1_offspring];    %将o1_offspring加入OS_offspring
        OS_offspring = [OS_offspring; o2_offspring];    %将o2_offspring加入OS_offspring
        
        
        
        %%%机器码采用MPX交叉算子
        m1 = MS_selection(index1, :);
        m2 = MS_selection(index2, :);
        exchange = round(rand(1, SH));
        index = find(exchange == 1);
        temp = m1(index);
        m1(index) = m2(index);
        m2(index) = temp;
        MS_offspring = [MS_offspring; m1];    %将m1加入MS_offspring
        MS_offspring = [MS_offspring; m2];    %将m2加入MS_offspring
        
        
        
        %%%机器速度码采用MPX交叉算子
        s1 = SS_selection(index1, :);
        s2 = SS_selection(index2, :);
        exchange = round(rand(1, SH));
        index = find(exchange == 1);
        temp = s1(index);
        s1(index) = s2(index);
        s2(index) = temp;
        SS_offspring = [SS_offspring; s1];    %将s1加入SS_offspring
        SS_offspring = [SS_offspring; s2];    %将s2加入SS_offspring
        


    end
end



%%%变异操作，工序码采用SM（Swapping Mutation）变异算子；机器码、机器速度采用MPM（Multi-point Mutation）变异算子
for i = 1:len
    if rand < MU      %进行变异操作
        %%工序码采用SM变异算子
        index = ceil(rand * len);
        op = OS_selection(index, :);
        
        %%选择两个点
        idx1 = ceil(rand * SH);
        idx2 = ceil(rand * SH);
        while idx1 == idx2
            idx2 = ceil(rand * SH);
        end
        
        %%交换
        temp = op(idx1);
        op(idx1) = op(idx2);
        op(idx2) = temp;
        OS_offspring = [OS_offspring; op];    %将op加入OS_offspring
        
        
        
        %%机器码采用MPM变异算子
        m = MS_selection(index, :);
        exchange = round(rand(1, SH));
        idx = find(exchange == 1);
        for j = 1:length(idx)
            machineSetLength = length(availableMachine{idx(j)});
            if machineSetLength > 1
                machine = availableMachine{idx(j)}(ceil(rand * machineSetLength));
                while m(idx(j)) == machine
                    machine = availableMachine{idx(j)}(ceil(rand * machineSetLength));
                end
                m(idx(j)) = machine;
            end
        end
        MS_offspring = [MS_offspring; m];    %将m加入MS_offspring
        
        
        
        %%机器速度码采用MPM变异算子
        s = SS_selection(index, :);
        exchange = round(rand(1, SH));
        idx = find(exchange == 1);
        for j = 1:length(idx)
            s(idx(j)) = ceil(rand * 3);
        end
        SS_offspring = [SS_offspring; s];    %将s加入SS_offspring
        
        
        
    end
end


end