function TEC = Energy_Saving_Strategy2(p_chrom, m_chrom, s_chrom, startEndTime, startupShutdownPower, idlePower, TEC)
%%%%%机器关闭/打开准则（Machine turn off rule）：如果关闭/打开所消耗的能量小于空闲所消耗的能量就将机器关闭/打开

global N M H SH;   

%%%先完成解码标记每个工序的工件和工序号
s1 = p_chrom;
s2 = zeros(1, SH);
p = zeros(1, N);
    
for i = 1:SH
    p(s1(i)) = p(s1(i)) + 1;    %记录过程是否加工完成，完成一次加一
    s2(i) = p(s1(i));     %记录加工过程中，工件的次数
end
    
for i = 1:SH
    t1 = s1(i);   %记录到当前是哪个工件
    t2 = s2(i);   %记录当前工件是加工到第几次
    mm(i) = m_chrom(sum(H(1:t1-1)) + t2);   %提取该工序该次加工的机器选择，因为机器码的排列表示该工件第几次加工所选的机器，是一段表示一个工件
    ss(i) = s_chrom(sum(H(1:t1-1)) + t2);   %提取该工序该次加工的机器速度选择
end

machineAvailableTime = zeros(1, M);     %机器最早可用时间

%%%更新机器最早可用时间
for i = 1:M
    index = find(mm == i);
    if ~isempty(index)
        job = s1(index(1));
        op = s2(index(1));
        machineAvailableTime(i) = startEndTime{job}(op, 1);
    end
end

for i = 1:SH
    job = s1(i);
    op = s2(i);
    machine = mm(i);
    speed = ss(i);
    
    if op == 1
        workTime = startEndTime{job}(op, 2) - startEndTime{job}(op, 1);     %加工时间
        machineAvailableTime(machine) = machineAvailableTime(machine) + workTime;   %更新机器最早可用时间
    else
        workTime = startEndTime{job}(op, 2) - startEndTime{job}(op, 1);     %加工时间

        %%%计算空闲功率，更新总能量消耗
        idleTime = startEndTime{job}(s2(i) - 1, 2) - machineAvailableTime(machine);
        if idleTime > 0
            %%%如果关闭/打开所消耗的能量小于空闲所消耗的能量就将机器关闭/打开
            if 2 * startupShutdownPower(machine) < idleTime * idlePower(machine, speed)
                TEC = TEC - idleTime * idlePower(machine, speed) + 2 * startupShutdownPower(machine);
            end

        end

        machineAvailableTime(machine) = max(startEndTime{job}(s2(i) - 1, 2), machineAvailableTime(machine)) + workTime;   %更新机器最早可用时间

    end

end


end