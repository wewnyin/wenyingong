function [OS, MS, SS, objectiveValue, crowdingDistance, startEndTime] = Calculate_Crowding_Distance(OS, MS, SS, objectiveValue, rank, startEndTime)

%%%快速非支配排序
layer = unique(rank);    %提取出rank等级
idx = 1;
layerNumber = length(layer);
crowdingDistance = zeros(length(rank), 1);
for i = 1:layerNumber
    index = find(rank == layer(i));
    OS_matrix = OS(index, :);
    MS_matrix = MS(index, :);
    SS_matrix = SS(index, :);
    objectiveValue_matrix = objectiveValue(index, :);
    crowdingDistance_matrix = crowdingDistance(index, :);
    startEndTime_matrix = startEndTime(index);
    
    %%%将同一个前沿面上的点进行排序，方便计算拥挤度
    [~, index] = sort(objectiveValue_matrix(:, 1));
    OS_matrix = OS_matrix(index, :);
    MS_matrix = MS_matrix(index, :);
    SS_matrix = SS_matrix(index, :);
    objectiveValue_matrix = objectiveValue_matrix(index, :);
    crowdingDistance_matrix = crowdingDistance_matrix(index, :);
    startEndTime_matrix = startEndTime_matrix(index);
    
    len = size(crowdingDistance_matrix, 1);
    if len == 1
        crowdingDistance_matrix(1) = inf;
    elseif len == 2
        crowdingDistance_matrix(1) = inf;
        crowdingDistance_matrix(2) = inf;
    else
        crowdingDistance_matrix(1) = inf;
        crowdingDistance_matrix(len) = inf;
        
        max_and_min = zeros(2, 2);      %存储每个目标函数的最大最小值
        for j = 1:2
            max_and_min(1, j) = max(objectiveValue_matrix(:, j));
            max_and_min(2, j) = min(objectiveValue_matrix(:, j));
        end
        
        for j = 2:(len - 1)
            CD = 0;
            for k = 1:2
                CD = CD + abs((objectiveValue_matrix(j + 1, k) - objectiveValue_matrix(j - 1, k)) / (max_and_min(1, k) - max_and_min(2, k)));
            end
            crowdingDistance_matrix(j) = CD;
        end
    end
    
    
    
    %将拥挤度排序，拥挤度越高越好
    [~, index] = sort(crowdingDistance_matrix, 'descend');
    
    OS_matrix = OS_matrix(index, :);
    MS_matrix = MS_matrix(index, :);
    SS_matrix = SS_matrix(index, :);
    objectiveValue_matrix = objectiveValue_matrix(index, :);
    crowdingDistance_matrix = crowdingDistance_matrix(index, :);
    startEndTime_matrix = startEndTime_matrix(index);
    

    
    OS(idx:(idx + len - 1), :) = OS_matrix;
    MS(idx:(idx + len - 1), :) = MS_matrix;
    SS(idx:(idx + len - 1), :) = SS_matrix;
    objectiveValue(idx:(idx + len - 1), :) = objectiveValue_matrix;
    crowdingDistance(idx:(idx + len - 1), :) = crowdingDistance_matrix;
    startEndTime(idx:(idx + len - 1)) = startEndTime_matrix;
    idx = idx + len;                
            
end


end
  