function criticalPath = Find_Critical_Path(p_chrom, m_chrom, s_chrom, processingTime, machineBreakdownInterval, machineRepairTime)

%将工序码构建成有向图的结构，有向图中包含节点集，即所有工序
%包含边集，即两个节点之间是否含有有向边
%每个节点包含一个加工时间。每个工件的第一个工序作为开始节点的下一个节点。最多只有N个路径，N为工件个数。每个工序的最后一个工序作为结束节点的上一个工序。
%由于柔性车间调度的特殊性，导致有向图中每个节点只有两条出度两条入度。即当前工件的下一个工序，和当前机器的下一个工序。
%在这个有向图中求出，从开始节点到结束节点的最大完工时间的关键路径。
%采用的数据结构为数组加链表。数据用来存储每个工序的下标。每个数据元素后第一个元素为当前工件工序的下一个工序，第二个元素为当前机器工序的下一个工序。
%这两个元素都采用双向链表连接在数据的元素后面。实际为SH*4的矩阵。
%遍历每个工件的第一个工序，从第一个工序开始，广度遍历第二列求出一条路径，再深度遍历第三列求出一条路径。每条路径的结束标准都是，最后工序的下一列的值为0.

global N H M SH;

%%%每一列分布表示：当前工件工序下一个工序的索引，当前工序所在机器的下一个工序索引，当前工序工件的上一个工序的索引，当前工序所在机器的上一个工序的索引
digraph = zeros(SH, 4);    %由于矩阵自身的行号本身就可以表示索引值，所以省略一列
dflag = zeros(SH, 4);  %用于标记该点是否找到

%%%先完成解码标记每个工序的工件和工序号
s1 = p_chrom;
s2 = zeros(1, SH);
p = zeros(1, N);
criticalPath=[];    %关键路径，其中包含关键工序的下标
    
for i = 1:SH
    p(s1(i)) = p(s1(i)) + 1;    %记录过程是否加工完成，完成一次加一
    s2(i) = p(s1(i));     %记录加工过程中，工件的次数
end
    
for i = 1:SH
    t1 = s1(i);   %记录到当前是哪个工件
    t2 = s2(i);   %记录当前工件是加工到第几次
    mm(i) = m_chrom(sum(H(1:t1-1)) + t2);   %提取该工序该次加工的机器选择，因为机器码的排列表示该工件第几次加工所选的机器，是一段表示一个工件
    ss(i) = s_chrom(sum(H(1:t1-1)) + t2);   %提取该工序该次加工的机器速度选择
end

%%%构建有向图
for i = 1:SH
    to = s1(i);
    tm = mm(i);
    for j= i+1:SH
        %%%找当前工件工序的下一个工序
        if to == s1(j) && dflag(i, 1) == 0
            digraph(i, 1)=j;
            dflag(i, 1) = 1;    %下指针已经找到
            digraph(j, 3) = i;
            dflag(j, 3) = 1;    %上指针已经找到
        end
        %%%找当前机器工序的下一个工序
        if tm == mm(j) && dflag(i, 2) == 0
            digraph(i, 2) = j;
            dflag(i, 2) = 1;
            digraph(j, 4) = i;
            dflag(j, 4) = 1;
        end
        
        %%%全部都找完跳出当前循环，或者如果当前工序当前工件的是最后一个工序
        if (dflag(i, 1) == 1 || s2(i) == H(s1(i))) && dflag(i,2) == 1
            break;
        end
           
    end
end

VELTime = cell(SH, 2);     %每个工序的最早开始时间和最晚开始时间
e = 0;


%%%采用广度遍历更新每个顶点的最早开始时间和最晚开始时间,如果不采用广度优先遍历，则会在更新后续层的时候，出现前序结点来不及计算，而导致计算错误。
%%%广度优先遍历的顺序是，先算所有工件的第一个工序，再是所有工件的第二个工序。
level = zeros(1, SH);
len = 1;
L = 1;
while len < SH
    for i = 1:SH
        if s2(i) == L
            level(len) = i;
            len = len + 1;
        end
    end
    L = L + 1;
end


%%%需要考虑机器损坏
machineWorkload = zeros(1, M);      %机器负载


%%%计算最早开始时间
LastNode = e;
for i = 1:SH
    Index = level(i);
%     VELTime{Index, 1} = e;      %VELTime{Index,2}=e; 
    t1 = e;
    t2 = e;
    if digraph(Index, 3) ~= 0
        last = digraph(Index, 3);
        if machineWorkload(mm(last)) + processingTime{s1(last)}(s2(last), mm(last)) / ss(last) >= machineBreakdownInterval(mm(last))
            processingTime{s1(last)}(s2(last), mm(last)) = processingTime{s1(last)}(s2(last), mm(last)) + machineRepairTime(mm(last)) * ss(last);
            t1 = processingTime{s1(last)}(s2(last), mm(last)) / ss(last) + VELTime{last, 1};
            machineWorkload(mm(last)) = machineWorkload(mm(last)) + processingTime{s1(last)}(s2(last), mm(last)) / ss(last) - machineBreakdownInterval(mm(last));      %机器修复完毕后重置机器负载
        else
            t1 = processingTime{s1(last)}(s2(last), mm(last)) / ss(last) + VELTime{last, 1};
            machineWorkload(mm(last)) = machineWorkload(mm(last)) + processingTime{s1(last)}(s2(last), mm(last)) / ss(last);
        end
    end
       
    if digraph(Index, 4) ~= 0
        last = digraph(Index, 4);
        if isempty(VELTime{last, 1})     
            [VELTime{last, 1}, machineWorkload, processingTime] = CalculateLastOperation(s1, s2, mm, ss, digraph, last, VELTime, processingTime, machineWorkload, machineBreakdownInterval, machineRepairTime);
        end
        if machineWorkload(mm(last)) + processingTime{s1(last)}(s2(last), mm(last)) / ss(last) >= machineBreakdownInterval(mm(last))
            processingTime{s1(last)}(s2(last), mm(last)) = processingTime{s1(last)}(s2(last), mm(last)) + machineRepairTime(mm(last)) * ss(last);
            t2 = processingTime{s1(last)}(s2(last), mm(last)) / ss(last) + VELTime{last, 1};
            machineWorkload(mm(last)) = machineWorkload(mm(last)) + processingTime{s1(last)}(s2(last), mm(last)) / ss(last) - machineBreakdownInterval(mm(last));      %机器修复完毕后重置机器负载
        else
            t2 = processingTime{s1(last)}(s2(last), mm(last)) / ss(last) + VELTime{last, 1};
            machineWorkload(mm(last)) = machineWorkload(mm(last)) + processingTime{s1(last)}(s2(last), mm(last)) / ss(last);
        end
    end
    
    if t1 > t2       %如果t1大于t2则
        VELTime{Index, 1} = t1;
    else
        VELTime{Index, 1} = t2;
    end
       
    %%%如果是工件的最后一个工序则说明下一个节点是LastNode虚拟结束节点, 则虚拟节点的上一个节点是所有工件的最后一个工序
    if digraph(Index, 1) == 0 
        if machineWorkload(mm(Index)) + processingTime{s1(Index)}(s2(Index), mm(Index)) / ss(Index) >= machineBreakdownInterval(mm(Index))
            processingTime{s1(Index)}(s2(Index), mm(Index)) = processingTime{s1(Index)}(s2(Index), mm(Index)) + machineRepairTime(mm(Index)) * ss(Index);
            t1 = processingTime{s1(Index)}(s2(Index), mm(Index)) / ss(Index) + VELTime{Index, 1};%选最大的作为最后的虚拟节点
            machineWorkload(mm(Index)) = machineWorkload(mm(Index)) + processingTime{s1(Index)}(s2(Index), mm(Index)) / ss(Index) - machineBreakdownInterval(mm(Index));      %机器修复完毕后重置机器负载
        else
            t1 = processingTime{s1(Index)}(s2(Index), mm(Index)) / ss(Index) + VELTime{Index, 1};%选最大的作为最后的虚拟节点
            machineWorkload(mm(Index)) = machineWorkload(mm(Index)) + processingTime{s1(Index)}(s2(Index), mm(Index)) / ss(Index) - machineBreakdownInterval(mm(Index));      %机器修复完毕后重置机器负载
        end
        if t1 > LastNode
            LastNode = t1;
        end
    end
    
end


%%%计算最晚开始时间
for i = SH:-1:1
    Index = level(i); 
%     if digraph(Index, 1) == 0 && digraph(Index, 2) == 0     %该工件既没有后续工序，所在机器上又没有后续机器
%         VELTime{Index, 2} = LastNode - processingTime{s1(Index)}(s2(Index), mm(Index)) / ss(Index); %最后一个拓扑有序的结点的工序的最晚开始时间等于最早开始时间
%         continue;
%     end
% 
%     VELTime{Index, 2} = LastNode - processingTime{s1(Index)}(s2(Index), mm(Index)) / ss(Index); %最后一个拓扑有序的结点的工序的最晚开始时间等于最早开始时间
    t1 = LastNode - processingTime{s1(Index)}(s2(Index), mm(Index)) / ss(Index);
    t2 = LastNode - processingTime{s1(Index)}(s2(Index), mm(Index)) / ss(Index);
    
    if digraph(Index, 1) ~= 0
        next = digraph(Index, 1);
        t1 = VELTime{next, 2} - processingTime{s1(Index)}(s2(Index), mm(Index)) / ss(Index);%下一个节点减当前这条边的时间，但是时间在节点上所有减当前节点是时间                       
    end
       
    if digraph(Index,2) ~= 0
        next = digraph(Index, 2);
        if isempty(VELTime{next, 2})
            VELTime{next, 2} = CalculateNextOperation(s1, s2, mm, ss, digraph, next, VELTime, processingTime, LastNode);  
        end
        t2 = VELTime{next, 2} - processingTime{s1(Index)}(s2(Index), mm(Index)) / ss(Index); 
    end
        
    if t1 > t2      %选最小的
        VELTime{Index, 2} = t2;
    else
        VELTime{Index, 2} = t1;
    end

end


%%%用最晚开始时间减最早开始时间，剩余时间最小的结点，则为关键路径上的结点。
Idletime = cell(SH, 1);
for i = 1:SH
    Idletime{i, 1} = VELTime{i, 2} - VELTime{i, 1};
end

%%%找到松弛时间最小的工序则为关键路径上的工序
MinIndex = 1;
MinIdleT = Idletime{1,1};
for i = 2:SH
    if MinIdleT > Idletime{i, 1}
        MinIndex = i;
        MinIdleT = Idletime{i,1};
    end
end

for i = 1:SH
    if MinIdleT == Idletime{i, 1}
        criticalPath = [criticalPath, i];
    end
end



end