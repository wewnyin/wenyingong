function [OS_offspring, MS_offspring, SS_offspring] = Variable_Neighborhood_Search(OS_selection, MS_selection, SS_selection, processingTime, startEndTime_selection, machineBreakdownInterval, machineRepairTime, startupShutdownPower, processingPower, idlePower)
global N P SH;

OS_offspring = [];
MS_offspring = [];
SS_offspring = [];

for i = 1:P/4
    p_chrom = OS_selection(i, :);
    m_chrom = MS_selection(i, :);
    s_chrom = SS_selection(i, :);
    startEndTime = startEndTime_selection{i};

    %%%找出关键路径
    criticalPath = Find_Critical_Path(p_chrom, m_chrom, s_chrom, processingTime, machineBreakdownInterval, machineRepairTime);
    
    %%%找出关键路径块
    criticalPathBlock = Find_Critical_Path_Block(p_chrom, m_chrom, s_chrom, startEndTime, machineBreakdownInterval, machineRepairTime, startupShutdownPower, processingPower, idlePower, criticalPath);
    
    s1 = p_chrom;
    s2 = zeros(1, SH);
    p = zeros(1, N);
    for i = 1:SH
        p(s1(i)) = p(s1(i)) + 1;    %记录过程是否加工完成，完成一次加一
        s2(i) = p(s1(i));     %记录加工过程中，工件的次数
    end
    
    
    %%%VNS1：交换关键路径块上的前两个工序，如果不存在关键路径块则随机交换关键路径上的两个工件
    [OS_offspring1, MS_offspring1, SS_offspring1] = Neighborhood_Search_Operator1(p_chrom, m_chrom, s_chrom, criticalPath, criticalPathBlock, s2, processingTime);
    OS_offspring = [OS_offspring; OS_offspring1];
    MS_offspring = [MS_offspring; MS_offspring1];
    SS_offspring = [SS_offspring; SS_offspring1];
    
    
    %%%VNS2：交换关键路径块上的后两个工序，如果不存在关键路径块则随机交换关键路径上的两个工件
    [OS_offspring2, MS_offspring2, SS_offspring2] = Neighborhood_Search_Operator2(p_chrom, m_chrom, s_chrom, criticalPath, criticalPathBlock, s2);
    OS_offspring = [OS_offspring; OS_offspring2];
    MS_offspring = [MS_offspring; MS_offspring2];
    SS_offspring = [SS_offspring; SS_offspring2];
    
    
    %%%VNS3：随机选取关键路径上的一个工序，将其随机插入到不同的备选机器上
    [OS_offspring3, MS_offspring3, SS_offspring3] = Neighborhood_Search_Operator3(p_chrom, m_chrom, s_chrom, criticalPath, s2, processingTime);
    OS_offspring = [OS_offspring; OS_offspring3];
    MS_offspring = [MS_offspring; MS_offspring3];
    SS_offspring = [SS_offspring; SS_offspring3];
    
    
    %%%VNS4：随机选取非关键路径上的一个工序，将其加工机器的机器速度降低一档
    [OS_offspring4, MS_offspring4, SS_offspring4] = Neighborhood_Search_Operator4(p_chrom, m_chrom, s_chrom, criticalPath, s2, processingTime);
    OS_offspring = [OS_offspring; OS_offspring4];
    MS_offspring = [MS_offspring; MS_offspring4];
    SS_offspring = [SS_offspring; SS_offspring4];
 
end


end