


function [solution]=DDER(func_no,optima,tolerance,popSize,Max_gen,t_dis)

% function cde(runs,func_no)
warning off;

global xl xu

st=2;
F=0.5;
CR=0.9;

NP=popSize;

[Gm,NP,D,XRmin,XRmax,solution_num1,Threshold,fun_name,kesi,radius] = Parameter(func_no);



Max_FES=NP*Max_gen;


numOpt=size(optima,1);
OptFit=zeros(numOpt,1);
% OptFit=eobj(optima,func_no);

for i=1:popSize
    pop(i,:)=XRmin+(XRmax-XRmin).*rand(1,D);
end

val       = zeros(1,popSize);          % create and reset the "cost array"
DE_gbest   = zeros(1,D);           % best population member ever
nfeval    = 0;                    % number of function evaluations

%------Evaluate the best member after initialization----------------------

ibest   = 1;                      % start with first population member

 val(1)=eobj(pop(ibest,:),func_no);


DE_gbestval = val(1);                 % best objective function value so far
nfeval  = nfeval + 1;
for i=2:popSize                        % check the remaining members

    val(i)=eobj(pop(i,:),func_no);
    
    nfeval  = nfeval + 1;
    if (val(i) < DE_gbestval)           % if member is better
        ibest   = i;                 % save its location
        DE_gbestval = val(i);
    end   
end
DE_gbest = pop(ibest,:);         % best member of current iteration
bestvalit = DE_gbestval;              % best value of current iteration


%------popold is the population which has to compete. It is--------
%------static through one iteration. pop is the newly--------------
%------emerging population.----------------------------------------

  
iter = 0;
solution_archive=[];
num1=0;
while nfeval < Max_FES
    
    if iter==0 | mod(iter,100)==0
    
    [sortval,sortindex]=sort(val,'ascend');
    popsort=pop(sortindex,:);
    valsort=val(sortindex);
    clear spop;
    i=1;
    if size(popsort,1)>NP
        popsort=popsort(1:NP,:);
        valsort=valsort(1:NP);
    end
    

  %---------------------------�����������----------------------------------  
     distmat=pdist(popsort);
     dis_maxtrix = squareform(distmat);
  %------------------------------------------------------------------------  

    
  %-------------------------������С����------------------------------------  
    delta=[];
    delta=[delta;0.1];
    
    for i=2:NP
         %��ȡ��Ӧ�ľ������
         distance=dis_maxtrix(i,1:i-1);
         %���i��Ԫ�ص��������ŵĸ���֮�����С����
         delta=[delta;min(distance)];
    end
     
    %����delta(1)
    delta(1)=max(delta)+0.1;
  
  %------------------------------------------------------------------------
  
  %----------------------------ȷ������-------------------------------------
  seed=[];

    delta1=mean(delta);
    valsort_ref=mean(valsort);
    
    if valsort_ref<1e-06
        valsort_ref=1e-05;
    elseif delta1<0.01
        delta1=0.01;
    end

  for i=1:NP
        if valsort(i)<valsort_ref & delta(i)>delta1
          seed=[seed;i,popsort(i,:),valsort(i)];
        end
  end
%   

%-------------------------------------------------------------------------
  spop=[];
  for k=1:size(seed,1);
      spop(k).species=seed(k,2:end-1);
      spop(k).speciesval=seed(k,end);
      spop(k).pop=seed(k,2:end-1);
      spop(k).val=seed(k,end);
  end
  
%--------------------------------------------------------------------------


  %---------------��ÿ��������䵽���������seed���γ�����Ⱥ------------------
  for i=1:NP
      %ȡ���ӵ��±�
      seed_index=seed(:,1);
      flag=ismember(i,seed_index);
      if flag~=1
           inter_distance=[];
          %����������ӣ���������������ӣ�����Ϊһ��
           for j=1:size(seed_index,1)
              inter_distance=[inter_distance;j,dis_maxtrix(i,seed_index(j))];
           end
             [min_dis,index]=min(inter_distance(:,2));
              %���ø�������Ӧ��cluster����
              spop(inter_distance(index)).pop=[spop(inter_distance(index)).pop;popsort(i,:)];
              spop(inter_distance(index)).val=[spop(inter_distance(index)).val;valsort(i)];             
      end
  end
    
%--------------------------------------------------------------------------     
    end
  
     for i=1:size(spop,2)  
         while size(spop(i).pop,1)<5
          
              newpop=normrnd(spop(i).species,0.1);
%
         
           newpopval=eobj(newpop,func_no);
           spop(i).pop=[spop(i).pop;newpop];
           spop(i).val=[spop(i).val;newpopval];
           nfeval  = nfeval + 1;
         end
         
         if size(spop(i).pop,1)>20
             temp_pop=[];
             superior_pop=[];
             worst_pop=[];
             [minvalue11,minindex11]=sort(spop(i).val);
             temp_pop=[spop(i).val(minindex11),spop(i).pop(minindex11,:)];
            superior_pop=minindex11(1:floor(size(spop(i).pop,1)/2));
            worst_pop=minindex11(ceil(size(spop(i).pop,1))/2:size(spop(i).pop,1));
         end
       
         for j=1:size(spop(i).pop,1)
             
               if size(spop(i).pop,1)>20
                   if ismember(j,superior_pop)==1
                       st=1;
                     checkdis1=sum((ones(size(temp_pop,1),1)*spop(i).pop(j,:)-temp_pop(:,2:end)).^2,2);
                    [minval1,minindex1]=sort(checkdis1,'ascend');
                    newpop1=temp_pop(minindex1(1:floor(size(spop(i).pop,1)/2)),2:end);
                   elseif  ismember(j,worst_pop)==1
                       st=2;
                      checkdis2=sum((ones(size(temp_pop,1),1)*spop(i).pop(j,:)-temp_pop(:,2:end)).^2,2);
                      [minval2,minindex2]=sort(checkdis2,'ascend');
                     newpop1=temp_pop(minindex2(1:ceil(size(spop(i).pop,1)/2)),2:end);
                   end
              
               else  
                   st=2;    
                   newpop1=spop(i).pop;
               end      
               popold=spop(i).pop(j,:); 

            bm=spop(i).species;
            ui(j,1:D)=DE(popold,newpop1,bm,st,F,CR,D,size(newpop1,1),XRmin,XRmax);
            tempval(j,1)=eobj(ui(j,:),func_no);
            nfeval  = nfeval + 1;

           checkdis=sum((ones(size(spop(i).pop,1),1)*ui(j,:)-spop(i).pop).^2,2);
           [minval,minindex]=min(checkdis);
            if tempval(j,1)<spop(i).val(minindex)
               spop(i).val(minindex)=tempval(j,1);
               spop(i).pop(minindex,:)=ui(j,:);
             end
            
            if tempval(j,1)<tolerance               
                solution_archive=[solution_archive;tempval(j,1),ui(j,:)];
                     for k=1:size(spop(i).pop,1)
                      spop(i).pop(k,:)=XRmin+(XRmax-XRmin).*rand(1,D);
                      spop(i).val(k)=eobj(spop(i).pop(k,:),func_no);
                      nfeval=nfeval+1;
                     end
            end          
         end
     end
     
     pop=[];
     val=[];
     for i=1:size(spop,2)
         pop=[pop;spop(i).pop];
         val=[val,spop(i).val'];
     end

    iter = iter + 1;

end %---end while ((iter < Max_Gen) ...
  traceInfo(iter,1)=nfeval;
      traceInfo(iter,2)=max(val);      % recording the best fitness
      traceInfo(iter,3)=mean(val);     % recording the Avg fitness
      traceInfo(iter,4)=std(val);      % recording the StdDev of fitness

      peaks=-10000*ones(numOpt,1);
       distance=10000*ones(numOpt,1);
       peakslocation=10000*ones(numOpt,D);  
       
       if size(solution_archive,1)~=0
       for u=1:numOpt
           checkdis=sum((ones(size(solution_archive,1),1)*optima(u,:)-solution_archive(:,2:end)).^2,2);
           [minval,minindex]=min(checkdis);
           if  minval<=0.01
               
                   peaks(u)=solution_archive(minindex,1);
                   peakslocation(u,:)=solution_archive(minindex,2:end);
           
           end
       end
       else
           peakslocation=10000*ones(numOpt,D);
       end

solution=peakslocation;
end

