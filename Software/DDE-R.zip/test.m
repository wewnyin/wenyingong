


    tic
    
   
    Iter_final_max=10;
    total_percentage=zeros(Iter_final_max,1);
    mean_root=zeros(Iter_final_max,1);
    mean_iter=zeros(Iter_final_max,1);
    store_NPF=zeros(Iter_final_max,1);
    store_FE=zeros(Iter_final_max,1);

       for p=3:3
        fun_num=p;
  
        Iter_final=1;
        total_mean_outcome=zeros(Iter_final_max,2);
         
        t=1;
       [Gm,NP,D,XRmin,XRmax,solution_num1,Threshold,fun_name,kesi,radius] = Parameter(fun_num);

       exact_solution=Exact_solution(fun_num);
       optima=exact_solution(:,2:end);
       tolerance=kesi;
       popSize=NP;
       Max_gen=Gm;
       t_dis=radius;
       solution_num=solution_num1;
     
    while Iter_final<=Iter_final_max
        
    
        Iter_final
        fun_name
         
    G1=1;
    solution = [];
    q=0;
    It=1;
    outCome=[];  
    total_iter=0;
    
    
    solution=DDER(fun_num,optima,tolerance,popSize,Max_gen,t_dis);
    
    
    id=find(solution(:,1)==10000);
    solution(id,:)=[];
    
    S1=size(solution,1);
    
    store_FE(Iter_final,1)=total_iter;
    
    
    if S1<solution_num
        total_percentage(Iter_final)=0;
        mean_root(Iter_final)=S1;
        store_NPF(Iter_final,1)=S1;
    else
            total_percentage(Iter_final)=100;
            mean_root(Iter_final)=S1;
            store_NPF(Iter_final,1)=S1;
    end

 
     
    total_mean_outcome(Iter_final,:)=[mean(outCome),std(outCome)];
   
   Iter_final=Iter_final+1;
    end
 
     total_mean_outcome(any(isnan(total_mean_outcome)'),:)=[];   %Remove the rows that have 'NAN' in the matrix
     PR=sum(store_NPF)/(solution_num*Iter_final_max);            %calculate the peak ratio
     AveFEs=sum(store_FE)/Iter_final_max;                        %calculate the convergence speed
     
     store_data(p,:)=[mean(total_percentage),mean(mean_root),PR,AveFEs];  

     Result(p,:)=mean(total_mean_outcome);
     end
    
     toc




  
 


