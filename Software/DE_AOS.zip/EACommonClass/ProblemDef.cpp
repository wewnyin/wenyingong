// ProblemDef.cpp: implementation of the CProblemDef class.
//
//////////////////////////////////////////////////////////////////////

#include "../stdafx.h"
#include "ProblemDef.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CProblemDef::CProblemDef()
{
	flag_once = 0;
}

CProblemDef::~CProblemDef()
{
}

void CProblemDef::evaluate_normal_fitness(double *xreal, double &obj, double *constr, 
										  int func_flag, long int &evaluations)
{
	switch(func_flag) {
	case 1:
		test_01(xreal,obj,constr);
		break;
	case 2:
		test_02(xreal,obj,constr);
		break;
	default:
		printf("The function you selected does not exist.\n");
		exit(0);
		break;
	}
	evaluations++;
}

// only for unconstrained optimization problems
// Ellipsoidal function
void CProblemDef::test_01(double *x, double &obj, double *constr)
{
	double fit = 0.0;

	for(int i=0;i<N_of_x;i++)
		fit += ((x[i])*(x[i]));

	obj = fit;
}

// Schwefel's function 2.22
void CProblemDef::test_02(double *x, double &obj, double *constr)
{
	double value = 0.0;
	double temp1 = 0.0;
	double temp2 = 1.0;

	for (int i=0;i<N_of_x;i++)
	{
		 temp1 += fabs(x[i]);
		 temp2 *= fabs(x[i]);
	}
	value = temp1+temp2;

	obj = value;
}
