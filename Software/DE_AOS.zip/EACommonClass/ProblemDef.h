// ProblemDef.h: interface for the CProblemDef class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_)
#define AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Individual.h"
#include "Rand.h"

// only for unconstrained optimization problems
class CProblemDef  
{
public:
	CProblemDef();
	virtual ~CProblemDef();

	// for unconstrained optimization problems
public:
	int		flag_once;

	void	evaluate_normal_fitness(double *xreal,double &obj, 
		double *constr, int func_flag, long int &evaluations);

public:
	void test_01(double *xreal,double &obj, double *constr);
	void test_02(double *xreal,double &obj, double *constr);
};

#endif // !defined(AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_)
