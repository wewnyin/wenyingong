// Individual.h: interface for the CIndividual class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INDIVIDUAL_H__A05E59DB_40D8_4282_9D3C_A0201898ACA8__INCLUDED_)
#define AFX_INDIVIDUAL_H__A05E59DB_40D8_4282_9D3C_A0201898ACA8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/* global parameters (changed with different problems sloved) */
#define param_adaptation	0			// DE with parameter adaptation

#define N_of_strategy		4			// only for the strategy self-adaptation

#define global_CR			0.9			// DE CR value

/* the following parameters are problem dependent */
// real world problems begin from 27...
#define index_of_normal		1			// index of the normal function, 0 means no normal function

#define N_of_constr			0			// number of the constrained functions

#define N_of_x				30			// number of the decision variables
#define Max_of_NFEs			(N_of_x*5000)		// the maximal number of function evaluations

#define PRECISION			1e-8		// value to reach (VTR)
/* ---------------------------------------------- */

#define population_size		100			// size of the population
/* -------------------------------------------------------------- */

class CIndividual  
{
public:
	CIndividual();
	virtual ~CIndividual();

public:
	CIndividual(const CIndividual &);							// �������캯��
	CIndividual &operator=(const CIndividual &);	// ����"="�����

public:
	double *xreal;				// Real Coded Decision Variable     
	double obj;					// value of the objective function
	double fitness;				// fitness of the objective function
	double constr_violation;	// parameter for constraint violation
    double *constr;				// defining the constraint values
	int    feasible;			// check the individual is feasible or not (1: feasible; 0: infeasible)
	int    no_of_violation;		// number of the violated constraint functions

	double F;					// only for DE
	double CR;					// only for DE

	int    successful_flag;
	double strategy;			// the strategy index for strategy self-adaptation

	int    *neighbor;			// the neighbor indices of the individual
	int    neighbor_size;		// the size of the neighborhood
};

#endif // !defined(AFX_INDIVIDUAL_H__A05E59DB_40D8_4282_9D3C_A0201898ACA8__INCLUDED_)
