// DE_method.cpp: implementation of the CDE_method class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "DE_method.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDE_method::CDE_method()
{
	max_iterations = Max_of_NFEs/population_size;
	max_NFFEs      = Max_of_NFEs;
	pop_size       = population_size;

	parent_pop   = new CIndividual[2*pop_size];
	child_pop    = new CIndividual[2*pop_size];
	upper_bounds = new double[N_of_x];
	lower_bounds = new double[N_of_x];
	sort_index   = new int[2*pop_size];

	/* -------------------- only for DE method -------------------- */
	m_F        = 0.5;
	m_CR       = global_CR;

	/* ------------------ only for PM & AP AOS-DE method ------------------ */
	strategy_num = N_of_strategy;

	p_min = 0.05;
	alpha = 0.1;
	beta  = 0.1;
	uniform_AOS = 0;
	for (int i=0;i<strategy_num;i++)
	{
		Reward[i]      = 0.0;
		Quality[i]     = 0.0;
		Probability[i] = 1.0/((double)strategy_num);

		adaptive_alpha[i] = 0.1;
	}

	/* ----- AOS-based DE with different credit assignment methods ----- */
	window_size = 100;
	normalized  = 0;
	reward_type = 0;
	
	for (i=0;i<strategy_num;i++)
	{// initialize the reward_array size
		reward_array[i].size = 0;
	}
}

CDE_method::~CDE_method()
{
	delete []parent_pop;
	delete []child_pop;
	delete []upper_bounds;
	delete []lower_bounds;
	delete []sort_index;
}

void CDE_method::init_variables()
{
	if (index_of_normal != 0)
	{
		init_normal_variables();
	}

	max_interval = 0;
	double temp;
	for (int i=0;i<N_of_x;i++)
	{
		temp = upper_bounds[i]-lower_bounds[i];
		max_interval += temp*temp;
	}
	max_interval = sqrt(max_interval);
}

void CDE_method::init_normal_variables()
{
	int i;
	int n = N_of_x;
	func_flag = index_of_normal;

	switch(func_flag) {
	case 1:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -100.0;
			upper_bounds[i] = 100.0;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 2:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -10.0;
			upper_bounds[i] = 10.0;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	default:
		printf("The function you selected does not exist.\n");
		exit(0);
	}
}

void CDE_method::init_pop()
{
	printf("Random based parent_pop initialization method is used.\n");
	init_pop_random();

	// initialize the F and CR of DE
	for (int i=0;i<pop_size;i++)
	{
		parent_pop[i].F               = m_rnd.rndreal(0.1, 1.0);
		parent_pop[i].CR              = m_rnd.rndreal(0.0, 1.0);
		parent_pop[i].successful_flag = 0;
		parent_pop[i].strategy        = m_rnd.rndreal(0.0, 1.0);
		if (parent_pop[i].CR > 1.0)
		{
			parent_pop[i].CR = 1.0;
		}
	}
}

void CDE_method::init_pop_random()
{
	for (int i=0;i<pop_size;i++)
	{
		for (int j=0;j<N_of_x;j++)
		{
			parent_pop[i].xreal[j] 
				= m_rnd.rndreal(lower_bounds[j],upper_bounds[j]);
		}
	}
}

void CDE_method::evaluate_ind(CIndividual &indv)
{
	if (index_of_normal != 0)
	{
		evaluate_normal_ind(indv);
	}

	// convert objective function value into fitness
	indv.fitness = MINIMIZE*indv.obj;

	// sum violation of the constrained functions
	if (N_of_constr == 0)
	{
		indv.constr_violation = 0.0;
		indv.feasible = 1;
	}
}

void CDE_method::evaluate_normal_ind(CIndividual &indv)
{
	func_flag = index_of_normal;

	m_func.evaluate_normal_fitness(indv.xreal,indv.obj,indv.constr, func_flag, evaluations);
}

void CDE_method::evaluate_pop(CIndividual *pop, int size)
{
	for (int i=0;i<size;i++)
	{
		evaluate_ind(pop[i]);
	}
}

int CDE_method::compare_ind (CIndividual *indv1, CIndividual *indv2)
{
	if((indv1->feasible==TRUE && indv2->feasible==TRUE))
	{
		if(indv1->fitness < indv2->fitness)
		{
			return 1;
		}
		else if (indv1->fitness > indv2->fitness)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
	else if(indv1->feasible==TRUE && indv2->feasible==FALSE)
	{
		return 1;
	}
	else if (indv1->feasible==FALSE && indv2->feasible==TRUE)
	{
		return -1;
	}
	else
	{
		if(indv1->constr_violation < indv2->constr_violation)
		{
			return 1;
		}
		else if (indv1->constr_violation > indv2->constr_violation)
		{
			return -1;
		}
		else
		{
			//return 0;
			if (indv1->fitness < indv2->fitness)
			{
				return 1;
			}
			else if (indv1->fitness > indv2->fitness)
			{
				return -1;
			}
			else
			{
				return 0;
			}
		}
	}
}

void CDE_method::find_best_index(CIndividual *pop, int size)
{
	int flag;

	best_index = 0;
	for (int i=1;i<size;i++)
	{
		flag = compare_ind(&pop[i], &pop[best_index]);
		if (flag == 1)
		{
			best_index = i;
		}
	}

	worst_index = 0;
	for (i=1;i<size;i++)
	{
		flag = compare_ind(&pop[i], &pop[worst_index]);
		if (flag == -1)
		{
			worst_index = i;
		}
	}
}

void CDE_method::random_index(int *array_index, int all_size, int size)
{
	int i,j,krand;
	int *a;
	a = new int[all_size];

	for(i = 0;i<all_size;i++)
	{
		a[i] = i;
	}
	for(i=0;i<size;i++)
	{
		j = m_rnd.rndint(i,(all_size-1));
		krand = a[i];
		a[i] = a[j];
		a[j] = krand;
	}	
	for(i=0;i<size;i++)
	{
		array_index[i] = a[i];
	}
	a = NULL;

	delete []a;
}

void CDE_method::shell_sort_pop(CIndividual *pop, int *list, int size)
{
	int done;
	int step, bound, i, j;
	int temp;

	step = size;  // array length
	while (step > 1) 
	{
		step /= 2;	//halve the step size
		do 
		{
			done   = 1;
			bound  = size - step;
			for (j = 0; j < bound; j++) 
			{
				i = j + step + 1;
				if (compare_ind(&pop[list[j]], &pop[list[i-1]]) == -1) 	
				{
					temp      = list[i-1];
					list[i-1] = list[j];
					list[j]   = temp;
					done = 0; // if a swap has been made we are not finished yet
				}  // if
			}  // for
		} while (done == 0);   // while
	} //while (step > 1)
}

void CDE_method::shell_sort_array(double *array, int *list, int size)
{
	int done;
	int step, bound, i, j;
	int temp;

	step = size;  // array length
	while (step > 1) 
	{
		step /= 2;	//halve the step size
		do 
		{
			done   = 1;
			bound  = size - step;
			for (j = 0; j < bound; j++) 
			{
				i = j + step + 1;
				if (array[list[j]] < array[list[i-1]]) 	
				{
					temp      = list[i-1];
					list[i-1] = list[j];
					list[j]   = temp;
					done = 0; // if a swap has been made we are not finished yet
				}  // if
			}  // for
		} while (done == 0);   // while
	} //while (step > 1)
}

double CDE_method::distance(double *x1, double *x2, int size)
{
	double rst = 0.0;

	for (int i=0;i<size;i++)
	{
		rst += (x1[i]-x2[i])*(x1[i]-x2[i]);
	}
	rst = sqrt(rst);

	return rst;
}

double CDE_method::mean(double *array, int size)
{
	double value = 0;

	for (int i=0;i<size;i++)
	{
		value += array[i];
	}
	value = value/size;

	return value;
}

double CDE_method::median(double *array, int size)
{
	double value = 0.0;

	int list[2000];
	for (int i=0;i<2000;i++)
	{
		list[i] = i;
	}
	shell_sort_array(array, list, size);
	
	if (size%2 == 1)
	{// the size of the array is odd.
		int media_index;
		media_index = size/2;
		value = array[list[media_index]];
	}
	else
	{// the size of the array is even.
		int a = (size-1)/2;
		int b = size/2;
		value = (array[list[a]]+array[list[b]])/2.0;
	}

	return value;
}

void CDE_method::statistic_pop_fitness(CIndividual *pop, int size)
{
	int i;
	
	min_fitness = best_individual.fitness;
	max_fitness = parent_pop[worst_index].fitness;

	avg_fitness = 0.0;
	for (i=0;i<size;i++)
	{
		avg_fitness += pop[i].fitness;
	}
	avg_fitness = avg_fitness/(double)size;

	double value = 0.0;
	for (i=0;i<size;i++)
	{
		value += fabs(pop[i].fitness-avg_fitness);
	}
	std_fitness = value/(double)size;

	double array[population_size];
	for (i=0;i<size;i++)
	{
		array[i] = pop[i].fitness;
	}
	media_fitness = median(array, size);
}

void CDE_method::display_result(int gen)
{
	if(gen%10==0 || gen == 1)
	{
		//��ǰ��ø����������Ļ
		cout<<setw(5)<<gen;
		cout<<setw(8)<<evaluations;
		//��ʾԼ��������ֵ
		if (N_of_constr != 0)
		{			
			cout<<setw(15)<<best_individual.constr_violation;
		}
		cout.precision(10);					//�����������
		cout<<setw(20)<<MINIMIZE * parent_pop[best_index].fitness;
		cout<<setw(20)<<MINIMIZE * parent_pop[m_rnd.rndint(0, pop_size-1)].fitness;
		cout<<setw(20)<<MINIMIZE * parent_pop[worst_index].fitness<<endl;
	}
}

void CDE_method::report_result(int gen, ofstream &file)
{
	if (gen < 100 )
	{
		//��ǰ��ø���������ļ�
		file<<setw(5)<<gen;
		file<<setw(10)<<evaluations;
		file.precision(20);			//�����������
		file<<setw(30)<<MINIMIZE*best_individual.fitness - known_optimal;
		file<<setw(30)<<best_individual.constr_violation;
		//file<<setw(30)<<best_individual.CR;
		file<<endl;
	}
	else
	{
		if ((gen % out_internal == 0 ||
			gen >= max_iterations ||
			evaluations >= max_NFFEs) )
		{
			//��ǰ��ø���������ļ�
			file<<setw(5)<<gen;
			file<<setw(10)<<evaluations;
			file.precision(20);			//�����������
			file<<setw(30)<<MINIMIZE * best_individual.fitness;
			file<<setw(30)<<best_individual.constr_violation;
			//file<<setw(30)<<best_individual.CR;
			file<<endl;
		}
	}
}

void CDE_method::report_diversity(int gen, ofstream &file)
{
	// calculate the diversity of the population
	double x_average[2000];
	for (int i=0;i<2000;i++)
	{
		x_average[i] = 0.0;
	}

	for (i=0;i<N_of_x;i++)
	{
		for (int j=0;j<pop_size;j++)
		{
			x_average[i] += parent_pop[j].xreal[i];
		}
		x_average[i] = x_average[i]/((double)pop_size);
	}

	double diversity = 0.0;
	for (i=0;i<pop_size;i++)
	{
		double temp = 0.0;
		double x;
		for (int j=0;j<N_of_x;j++)
		{
			x = parent_pop[i].xreal[j];
			temp += (x-x_average[j])*(x-x_average[j]);
		}
		diversity += sqrt(temp);
	}
	diversity = diversity/(((double)pop_size)*max_interval);

	pop_diversity = diversity;
	
	if (gen < 100 )
	{
		//��ǰ��ø���������ļ�
		file<<setw(5)<<gen;
		file<<setw(10)<<evaluations;
		file.precision(20);			//�����������
		file<<setw(30)<<diversity<<endl;
	}
	else
	{
		if ((gen % out_internal == 0 ||
			gen >= max_iterations ||
			evaluations >= max_NFFEs) )
		{
			//��ǰ��ø���������ļ�
			file<<setw(5)<<gen;
			file<<setw(10)<<evaluations;
			file.precision(20);			//�����������
			file<<setw(30)<<diversity<<endl;
		}
	}
}

void CDE_method::report_parameter(int gen, ofstream &file)
{
	int counter = max_iterations/20;
	int i;

	if (gen==1 || gen%counter == 0)
	{
		file<<setw(5)<<gen;
		file<<setw(10)<<evaluations;
		file.precision(10);			//�����������

		for (i=0;i<strategy_num;i++)
		{
			file<<setw(25)<<Probability[i];
		}
		if (strategy_num < 4)
		{
			for (i=0;i<4-strategy_num;i++)
			{
				file<<setw(25)<<"0";
			}
		}

		file<<endl;
	}
}

void CDE_method::read_parameters()
{
	// get the data from the file
    FILE *fpt;
    fpt = fopen("parameters.txt","r");
    if (fpt==NULL)
    {
        fprintf(stderr,"\n Error: Cannot open input file for reading \n");
        exit(0);
    }

	int row_num;
	int col_num;

	double a;
	fscanf(fpt, "%lg", &a);
	row_num = (int)a;

	fscanf(fpt, "%lg", &a);
	col_num = (int)a;

	int i, j;
    for (i=0; i<row_num; i++)			// need to be modified for different algorithms
    {
        for (j=0; j<col_num; j++)		// need to be modified for different algorithms
        {
            fscanf(fpt, "%lg", &parameters[i][j]);
        }
    }
    fclose(fpt);

	/*printf("%d\t%d\n", row_num, col_num);
	for (i=0; i<row_num; i++)
	{
		for (j=0; j<col_num; j++)
		{
			printf("%.2f ", parameters[i][j]);
		}
		printf("\n");
	}exit(0);*/

	return;
}

void CDE_method::sort_pop(CIndividual *pop, int size)
{
	for (int i=0;i<size;i++)
	{
		sort_index[i] = i;
	}
	shell_sort_pop(pop, sort_index, size);
}

void CDE_method::Run_Optimizer(int run_no, double seed, int method, 
							   int strategy_ii, int credit_assignment, int norm)
{	
	m_strategy          = strategy_ii;

	//read_parameters();
	
	switch(method) {
	case 1:
		printf("You have selected the DE method.\n");
		break;
	case 2:
		printf("You have selected the PM-AOS-DE method.\n");
		break;
	default:
		printf("The method does not exist!\n");
		exit(0);
	}

	// show the used reward type
	reward_type = credit_assignment;
	normalized  = norm;
	if (1)
	{
		if (normalized==0)		printf("Non-normalized.\n");
		else if (normalized==1)	printf("Normalized.\n");
		else
		{
			printf("Error in normalization flag.\n");
			exit(0);
		}
		if (reward_type==0)		printf("Averaged reward.\n");
		else if (reward_type==1)printf("Extreme reward.\n");
		else if (reward_type==2)printf("Instantaneous reward.\n");
		else
		{
			printf("Error in reward assignment flag.\n");
			exit(0);
		}
	}

	int i = 0; 
	
	method_flag = method;
	rnd_seed = seed;

	ofstream SummaryFile;
	SummaryFile.open(".\\results\\summary.txt",ios::app);

	char f_name1[150];
	sprintf(f_name1,"%s%d%s",".\\results\\process\\process_",run_no+1,".txt");		
	ofstream file_process(f_name1);

	char f_name2[150];
	sprintf(f_name2,"%s%d%s",".\\results\\diversity\\diversity_",run_no+1,".txt");		
	ofstream file_diversity(f_name2);

	char f_name3[150];
	sprintf(f_name3,"%s%d%s",".\\results\\migration\\migration_",run_no+1,".txt");		
	ofstream file_migration(f_name3);

	clock_t start, finish;
	double time_consume;

	time_consume = 0.0;
	start = clock();						// starts the clock
	
	srand((unsigned)time(0));
	m_rnd.randomize(seed);

	evaluations = 0;						// reset the NFFEs

	init_variables();
	init_pop();
	evaluate_pop(parent_pop, pop_size);
	find_best_index(parent_pop, pop_size);
	best_individual = parent_pop[best_index];

	gen = 1;								// current generation number
	int counter=0;							// only for restarting the population

	statistic_pop_fitness(parent_pop, pop_size);

	report_result(gen, file_process);
	report_diversity(gen, file_diversity);
	report_parameter(gen, file_migration);

	int feasible_flag = 0;					// check to get the feasible individual first
	flag_precision = 0;						// check to arrive the required value
	double diversity_max = pop_diversity;
	/* -------- add different optimizer here -------- */
	while ( (evaluations < max_NFFEs) && (gen < max_iterations) )
	{
		finish = clock();					// time consuming of this generation
		time_consume = (double)(finish-start)/1000.0;

		// report the results in the screen
		/* comment the following routines to save the time_consuming */
		//display_result(gen);

		if (pop_diversity > diversity_max)
		{
			diversity_max = pop_diversity;
		}
		diversity_flag = pop_diversity/diversity_max;
		
		// ADD YOUR OPTIMIZER HERE
		switch(method) {
		case 1:// DE method
			run_DE_method();
			break;
		case 2:// PM-AOS-based DE method
			run_DE_AOS();
			break;
		default:
			printf("The method selected does not exist.\n");
			exit(0);
		}

		gen++;

		find_best_index(parent_pop, pop_size);
		
		if (compare_ind(&parent_pop[best_index], &best_individual) != -1)
		{
			best_individual = parent_pop[best_index];
		}

		statistic_pop_fitness(parent_pop, pop_size);
		
		report_result(gen, file_process);
		report_diversity(gen, file_diversity);
		report_parameter(gen, file_migration);

		if (flag_precision == 0 && 
			MINIMIZE*best_individual.fitness - known_optimal < PRECISION
			&& best_individual.feasible == 1)
		{
			flag_precision = 1;
			ofstream SummaryFile1;
			SummaryFile1.open(".\\results\\evaluations.txt",ios::app);			
			SummaryFile1<<setw(9)<<evaluations<<endl;
			SummaryFile1.close();
			//break;		// ������һ���ľ���ͳ����Ӧֵ���۴���ʱʹ��
		}
		if (N_of_constr != 0 && feasible_flag == 0 && best_individual.feasible == 1)
		{
			feasible_flag = 1;
			ofstream SummaryFile1;
			SummaryFile1.open(".\\results\\feasible_NFFEs.txt",ios::app);
			SummaryFile1<<setw(9)<<evaluations<<endl;
			SummaryFile1.close();
		}
	}
	/* -------- add different optimizer here -------- */
	
	printf("The total running time is %f s.\n", time_consume);

	SummaryFile.precision(15);
	SummaryFile<<setw(5)<<gen<<setw(9)<<evaluations
		<<setw(25)<<MINIMIZE*best_individual.fitness - known_optimal
		<<setw(8)<<time_consume
		<<setw(25)<<best_individual.constr_violation<<endl;
		
	file_process.close();
	file_diversity.close();
	file_migration.close();
	SummaryFile.close();
	
	return;
}

/* -------------------- only for DE method -------------------- */
void CDE_method::run_DE_method()
{
	int    i;
	int    r1, r2, r3, r4, r5;
	double low, up;

	for (i=0;i<pop_size;i++)
	{
		// select five parents randomly
		do {
			r1 = m_rnd.rndint(0, pop_size-1);
		} while (r1 == i);
		do {
			r2 = m_rnd.rndint(0, pop_size-1);
		} while(r2 == i || r2 == r1);
		do { 
			r3 = m_rnd.rndint(0, pop_size-1);
		} while(r3 == i || r3 == r2 || r3 == r1);
		do { 
			r4 = m_rnd.rndint(0, pop_size-1);
		} while(r4 == i || r4 == r3 || r4 == r2 || r4 == r1);
		do { 
			r5 = m_rnd.rndint(0, pop_size-1);
		} while(r5 == i || r5 == r4 || r5 == r3 || r5 == r2 || r5 == r1);

		// parameter self-adaptation
		if (param_adaptation == 1)
		{
			child_pop[i].F  = parent_pop[i].F;
			child_pop[i].CR = parent_pop[i].CR;
			if (m_rnd.flip(0.1))
			{
				child_pop[i].F  = 0.1+m_rnd.randomperc()*0.9;
			}		
			if (m_rnd.flip(0.1))
			{
				child_pop[i].CR = m_rnd.rndreal(0.0, 1.0);
			}
			m_F  = child_pop[i].F;	// F
			m_CR = child_pop[i].CR;	// CR
		}
		else
		{
			m_CR = 0.9;
			m_F  = 0.5;//m_rnd.rndreal(0.1, 1.0);
		}

		int j_rand = m_rnd.rndint(0, N_of_x-1);
		for (int j=0;j<N_of_x;j++)
		{
			low = lower_bounds[j];
			up  = upper_bounds[j];

			if (m_rnd.rndreal(0,1)<m_CR || j==j_rand)
			{
				switch(m_strategy) {
				case 1:// DE/rand/1/bin
					child_pop[i].xreal[j] = parent_pop[r1].xreal[j]
						+ m_F*(parent_pop[r2].xreal[j]-parent_pop[r3].xreal[j]);
					break;
				case 2:// DE/rand/2/bin
					child_pop[i].xreal[j] = parent_pop[r1].xreal[j]
						+ m_F*(parent_pop[r2].xreal[j]-parent_pop[r3].xreal[j])
						+ m_F*(parent_pop[r4].xreal[j]-parent_pop[r5].xreal[j]);
					break;
				case 3:// DE/rand-to-best/2/bin
					child_pop[i].xreal[j] = parent_pop[r1].xreal[j]
						+ m_F*(parent_pop[best_index].xreal[j]-parent_pop[r1].xreal[j])
						+ m_F*(parent_pop[r2].xreal[j]-parent_pop[r3].xreal[j])
						+ m_F*(parent_pop[r4].xreal[j]-parent_pop[r5].xreal[j]);
					break;
				case 4:// // DE/current-to-rand/1/bin
					child_pop[i].xreal[j]=parent_pop[i].xreal[j]
						+(m_F*(parent_pop[r1].xreal[j]-parent_pop[i].xreal[j]))
						+(m_F*(parent_pop[r2].xreal[j]-parent_pop[r3].xreal[j]));
					break;
				default:
					printf("The scheme in DE method does not exist.\n");
					exit(0);
				}

				if (child_pop[i].xreal[j] < low || child_pop[i].xreal[j] > up)
				{
					child_pop[i].xreal[j] = m_rnd.rndreal(low, up);
				}
			}
			else
			{
				child_pop[i].xreal[j] = parent_pop[i].xreal[j];
			}
		}
	}

	evaluate_pop(child_pop, pop_size);

	for (i=0;i<pop_size;i++)
	{
		int flag = compare_ind(&child_pop[i], &parent_pop[i]);
		if (flag != -1)
		{
			parent_pop[i] = child_pop[i];
		}
	}
}

/* -------------------- only for AOS-DE method -------------------- */
void CDE_method::initial_AOS_parameter()
{
	p_min = 0.05;
	alpha = 0.3;
	beta  = 0.8;

	for (int i=0;i<strategy_num;i++)
	{
		Reward[i]      = 0.0;
		Quality[i]     = 0.0;
		Probability[i] = 1.0/((double)strategy_num);
	}
}

void CDE_method::update_quality()
{
	int i;

	/* normalize the reward */
	if (normalized)
	{
		normalize_reward();
	}
	
	for (i=0;i<strategy_num;i++)
	{
		Quality[i] = Quality[i] + alpha * (Reward[i]-Quality[i]);
		if (Quality[i] < 0)
		{
			printf("alpha=%f\tquality=%f\n", alpha, Quality[i]);
			getchar();
		}
	}
}

void CDE_method::update_probability_PM()
{
	double sum = 0.0; 
	for(int i=0; i<strategy_num; i++)
	{
		sum += Quality[i];
	}
	for(i=0; i<strategy_num; i++)
	{
		if (sum==0)
		{
			Probability[i] = 1.0/strategy_num;
		}
		else
		{
			Probability[i] = p_min + ((1.0 - ((double)strategy_num) * p_min) * (Quality[i]/sum));
			if (Probability[i] < 0)
			{
				printf("ERROR in PM probability updating process.\n");
				exit(0);
			}
		}
	}
}

int CDE_method::select_strategy_prob()
{
	int op;

	// roulette wheel selection
	double sorted = m_rnd.rndreal(0.0, 1.0);
	double sum = 0;
	for(op = 0; op < strategy_num-1; op++)
	{
		sum += Probability[op];
		if(sum > sorted)
		{
			return op;
		}
	}

	return op;
}

/* AOS-baded DE with Probability Matching and Adaptive Pursuit method */
void CDE_method::run_DE_AOS()
{
	int		i;
	int     r1, r2, r3, r4, r5;
	double	low, up;

	double rr;
	int    ss;
	for (i=0;i<strategy_num;i++)
	{// initialization: IMPORTANT!
		reward_array[i].size = 0;	// do not use the window size
	}

	// only for calculating the adaptive alpha values
	int	successful_runs[10];
	int failed_runs[10];
	for (i=0;i<strategy_num;i++)
	{// initialization: IMPORTANT!
		successful_runs[i] = 0;
		failed_runs[i]     = 0;
	}

	if (gen==1 || uniform_AOS==1)
	{// initialize the parameters of AOS at the first generation
		initial_AOS_parameter();
	}
	else
	{
		update_quality();
		// probability matching for AOS
		update_probability_PM();
	}

	// get the strategy index of each target solution
	for (i=0;i<pop_size;i++)
	{
		if (uniform_AOS == 1)
		{
			strategy_index[i] = m_rnd.rndint(0, strategy_num-1) + 1;
		}
		else
		{
			strategy_index[i] = select_strategy_prob() + 1;
		}
	}

	for (i=0;i<pop_size;i++)
	{
		// select five parents randomly
		do {
			r1 = m_rnd.rndint(0, pop_size-1);
		} while (r1 == i);
		do {
			r2 = m_rnd.rndint(0, pop_size-1);
		} while(r2 == i || r2 == r1);
		do { 
			r3 = m_rnd.rndint(0, pop_size-1);
		} while(r3 == i || r3 == r2 || r3 == r1);
		do { 
			r4 = m_rnd.rndint(0, pop_size-1);
		} while(r4 == i || r4 == r3 || r4 == r2 || r4 == r1);
		do { 
			r5 = m_rnd.rndint(0, pop_size-1);
		} while(r5 == i || r5 == r4 || r5 == r3 || r5 == r2 || r5 == r1);

		// parameter adaptation of DE
		if (param_adaptation == 1)
		{
			child_pop[i].F  = parent_pop[i].F;
			child_pop[i].CR = parent_pop[i].CR;
			if (m_rnd.flip(0.1))
			{
				child_pop[i].F  = 0.1+m_rnd.randomperc()*0.9;
			}		
			if (m_rnd.flip(0.1))
			{
				child_pop[i].CR = m_rnd.rndreal(0.0, 1.0);
			}
			m_F  = child_pop[i].F;	// F
			m_CR = child_pop[i].CR;	// CR
		}
		else
		{
			m_CR = global_CR;
			m_F  = 0.5;//m_rnd.rndreal(0.1, 1.0);
		}

		int j_rand = m_rnd.rndint(0, N_of_x-1);
		for (int j=0;j<N_of_x;j++)
		{
			low = lower_bounds[j];
			up  = upper_bounds[j];

			if (m_rnd.rndreal(0,1)<m_CR || j==j_rand)
			{
				switch(strategy_index[i]) {
				case 1:// DE/rand/1/bin
					child_pop[i].xreal[j] = parent_pop[r1].xreal[j]
						+ m_F*(parent_pop[r2].xreal[j]-parent_pop[r3].xreal[j]);
					break;
				case 2:// DE/rand/2/bin
					child_pop[i].xreal[j] = parent_pop[best_index].xreal[j]
						+ m_F*(parent_pop[r2].xreal[j]-parent_pop[r3].xreal[j])
						+ m_F*(parent_pop[r4].xreal[j]-parent_pop[r5].xreal[j]);
					break;
				case 3:// DE/rand-to-best/2/bin
					child_pop[i].xreal[j] = parent_pop[r1].xreal[j]
						+ m_F*(parent_pop[best_index].xreal[j]-parent_pop[r1].xreal[j])
						+ m_F*(parent_pop[r2].xreal[j]-parent_pop[r3].xreal[j])
						+ m_F*(parent_pop[r4].xreal[j]-parent_pop[r5].xreal[j]);
					break;
				case 4:// DE/current-to-rand/1
					child_pop[i].xreal[j]=parent_pop[i].xreal[j]
						+(m_F*(parent_pop[r1].xreal[j]-parent_pop[i].xreal[j]))
						+(m_F*(parent_pop[r2].xreal[j]-parent_pop[r3].xreal[j]));
					break;
				default:
					printf("The scheme in DE method does not exist.\n");
					exit(0);
				}

				if (child_pop[i].xreal[j] < low || child_pop[i].xreal[j] > up)
				{
					child_pop[i].xreal[j] = m_rnd.rndreal(low, up);
				}
			}
			else
			{
				child_pop[i].xreal[j] = parent_pop[i].xreal[j];
			}
		}
	}

	evaluate_pop(child_pop, pop_size);

	for (i=0;i<pop_size;i++)
	{
		// get the strategy index for this target solution
		ss = strategy_index[i]-1;

		int flag = compare_ind(&child_pop[i], &parent_pop[i]);
		if (flag != -1)
		{
			// get the absolute fitness improvement
			rr = parent_pop[i].fitness - child_pop[i].fitness; // for minimization

			// replace the inferior parent
			parent_pop[i] = child_pop[i];

			// calculate the relative fitness improvement
			if (child_pop[i].fitness > 0.0)
			{
				rr = (best_individual.fitness*rr)/child_pop[i].fitness;	// !!!
			}

			successful_runs[ss]++;
		}	
		else
		{// penalize the worse results, set the reward equals 0
			rr = 0.0;

			failed_runs[ss]++;
		}

		// insert the reward into the array (FIFO)
		insert_reward(ss, rr);
	}

	get_reward();

	// calculate the adaptive alpha values
	int temp;
	for (i=0;i<strategy_num;i++)
	{
		temp = successful_runs[i]+failed_runs[i];
		if (temp != 0)
		{
			adaptive_alpha[i] = 1.0 - 
				((double)successful_runs[i])/(temp);
		}
		else
		{
			adaptive_alpha[i] = 1.0;
		}
	}
}

////////////////////////////////////////////////////////////////////
/* AOS-based DE with different credit assignment methods */
void CDE_method::insert_reward(int i, double rr)
{
	int size;
	// FIFO
	size = reward_array[i].size%window_size;
	// store the reward
	reward_array[i].reward[size] = rr;
	// increase the total size
	reward_array[i].size++;
	if (reward_array[i].size > 2*window_size)
	{
		reward_array[i].size -= window_size;	// avoid integer over-flow
	}
}

void CDE_method::get_reward()
{
	int    type = reward_type;
	double rr;

	for (int i=0;i<strategy_num;i++)
	{
		if (type == 0)
		{// average
			rr = get_avg_reward(i);
		}
		else if (type == 1)
		{// extreme
			rr = get_ext_reward(i);
		}
		else if (type == 2)
		{// instantaneous
			rr = get_ins_reward(i);
		}
		else
		{
			rr = 0.0;
		}

		Reward[i] = rr;
	}
}

double CDE_method::get_avg_reward(int i)
{
	double rr;
	double sum = 0.0;

	int j;
	int size;
	size = reward_array[i].size;
	if (size > window_size)
	{
		size = window_size;
	}

	if (size == 0)
	{
		rr = 0.0;
	}
	else
	{
		for (j=0;j<size;j++)
		{
			sum += reward_array[i].reward[j];
		}
		rr = sum/size;		//////////////////!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!  �ɹ�����/��ѡ�����
	}

	return rr;
}

double CDE_method::get_ext_reward(int i)
{
	double rr;
	double temp_rr = 0.0;

	int j;
	int size;
	size = reward_array[i].size;
	if (size > window_size)
	{
		size = window_size;
	}

	if (size == 0)
	{
		rr = 0.0;
	}
	else
	{
		for (j=0;j<size;j++)
		{
			if (reward_array[i].reward[j] > temp_rr)
			{
				temp_rr = reward_array[i].reward[j];
			}
		}

		rr = temp_rr;
	}

	return rr;
}

double CDE_method::get_ins_reward(int i)
{
	double rr;

	int j;
	int size;
	size = reward_array[i].size;
	if (size > window_size)
	{
		size = window_size;
	}

	if (size == 0)
	{
		rr = 0.0;
	}
	else
	{
		j  = (size-1)%window_size;
		rr = reward_array[i].reward[j];
	}

	return rr;
}

void CDE_method::normalize_reward()
{
	int i;
	/* normalize the reward */
	double max_rr = Reward[0];
	for (i=1;i<strategy_num;i++)
	{
		if (Reward[i] > max_rr)
		{
			max_rr = Reward[i];
		}
	}
	if (max_rr != 0.0)
	{
		for (i=0;i<strategy_num;i++)
		{
			Reward[i] = Reward[i]/max_rr;
		}
	}
}
