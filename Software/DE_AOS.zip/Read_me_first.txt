========================================================================
       DE_AOS: DE with strategy adaptive selection
========================================================================

If you used these codes, pls refer the following two papers:

1. W. Gong, A. Fialho, and Z. Cai, "Adaptive strategy selection in differential evolution," proceedings of Genetic and Evolutionary Computation Conference (GECCO 2010). ACM Press. 2010.7: 409 - 416. Portland, USA. 

2. W. Gong, A. Fialho, Z. Cai, and H. Li, "Adaptive strategy selection in differential evolution for numerical optimization: An empirical study," Information Sciences. Accepted in Aug. 2011. DOI:10.1016/j.ins.2011.07.049 

These codes are only used for academic purpose.

Just enjoy them.

If you find any problems, pls contact Dr. Wenyin Gong (cug11100304@yahoo.com.cn)
