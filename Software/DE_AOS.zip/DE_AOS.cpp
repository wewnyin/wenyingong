// DE_AOS.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "DE_method.h"

void welcome();
 
int main(int argc, char* argv[])
{
	welcome();

	double seed = 0.0;

	int method;
	int RUN_NUMBER;
	int strategy_index = 1;		// strategy used in DE and JADE
	int output_counter = 0;

	int reward_flag = 1;		// average reward. 0: average; 1: extreme; 2: instantaneous.
	int normalized  = 1;		// non-normalized. 0: non-normalized; 1: non-normalized.
	
	printf("method = ");
	method = 1;
	cin>>method;

	printf("\nPlease enter the max run number.\n");
	printf("RUN_NUMBER = ");
	RUN_NUMBER = 1;
	cin>>RUN_NUMBER;

	srand((unsigned)time(NULL));

	CDE_method *DE_method;
	for (int i=0;i<RUN_NUMBER;i++)
	{
		int t = output_counter;				// ��������̫����������ô����з���
		int k = t*RUN_NUMBER;
		printf("--------- Run no. is %d ---------\n", k+i+1);
		//seed = ((double)(k+i+1))/((double)RUN_NUMBER);
		seed = ((double)(k+i+1))/50.0;		// ............
		if (RUN_NUMBER == 1)
		{
			seed = 3/50.0;
		}
		if (seed == 0.0)
		{
			seed = 0.001;
		}
		if (seed == 1.0)
		{
			seed = 0.99;
		}

		DE_method = new CDE_method;
		DE_method->Run_Optimizer(k+i, seed, method, strategy_index,
			reward_flag, normalized);
		delete DE_method;

		if ((i+1)%100 == 0 && (i+1) != RUN_NUMBER)	// pause
		{
			printf("\nPlease press ENTER key to continue.\n");
			getchar();
		}
	}
	
	return 0;
}

void welcome()
{
	printf("\n");
	printf("***************************************************************\n");
	printf("*             Welcome to use the DE optimizers.               *\n");
	printf("*        You can select and use the following optimizer.      *\n");
	printf("*                method = 1   for DE                          *\n");
	printf("*                method = 2   for PM-AOS-DE                   *\n");
	printf("***************************************************************\n");
	printf("\n");
}
