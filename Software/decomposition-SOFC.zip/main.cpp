
#include "global.h"
#include "DE_method.h"

void	welcome();
void	run_single();
void	run_multiple();

int main(int argc, char* argv[])
{
	welcome();

	if (0==batch_execution)
	{
		run_single();
	}
	else if (1==batch_execution)
	{
		run_multiple();
	}
	
	return 0;
}

void run_single()
{
	double seed = 0.0;
	
	int method;
	int RUN_NUMBER;
	int strategy_index			= 1;		// strategy used in DE (1: rand/1; )
	int output_counter			= 0;
	int	index_of_func			= 1;
	
	int	index_dataset			= 1;
	printf("dataset		= ");
	index_dataset = 1;
	cin>>index_dataset;
	
	printf("function	= ");
	index_of_func = 1;
	cin>>index_of_func;
	
	printf("method		= ");
	method = 7;
	cin>>method;
	
	printf("RUN_NUMBERs	= ");
	RUN_NUMBER = 5;
	//cin>>RUN_NUMBER;
	
	srand((unsigned)time(NULL));
	
	CDE_method *DE_method;
	for (int i=0;i<RUN_NUMBER;i++)
	{
		int t = output_counter;				// ��������̫����������ô����з���
		int k = t*RUN_NUMBER;
		printf("--------- Run no. is %d ---------\n", k+i+1);
		//seed = ((double)(k+i+1))/((double)RUN_NUMBER);
		seed = ((double)(k+i+1))/100.0;		// ............
		if (RUN_NUMBER == 1)
		{
			//seed = 0.86564;
			seed = 0.2;
		}
		//seed = ((double)(46+1))/50.0;			// test seed
		//seed = (double)(rand()%1000)/1000.0;	// test seed
		if (seed == 0.0)
		{
			seed = 0.001;
		}
		if (seed == 1.0)
		{
			seed = 0.99;
		}
		
		DE_method = new CDE_method;
		DE_method->Run_Optimizer(k+i, seed, method, strategy_index, index_of_func, index_dataset);
		delete DE_method;
		
		if ((i+1)%100 == 0 && (i+1) != RUN_NUMBER)	// pause
		{
			printf("\nPlease press ENTER key to continue.\n");
			getchar();
		}
	}
}

void run_multiple()
{
	double	seed				= 0.0;
	int		method				= 1;
	int		output_counter		= 0;
	int		index_of_func		= 1;
	int		strategy_index		= 1;
	int		RUN_NUMBER			= 100;
	
	int		index_dataset		= 1;
	
	int		func_total_num		= 3;
	int		func_index_set[2]	= {1, 2};
	
	srand((unsigned)time(NULL));
	
	CDE_method *DE_method;
	
	for (int dd=25; dd<=25; dd++)		// 22 in total, 25 for benchmark problem
	{// dataset level
		index_dataset = dd;
		
		for (int mm=3; mm<=7; mm++)
		{// method level
			method = mm;
			
			for (int kk = 1; kk <= 2; kk++)
			{// function level
				index_of_func = func_index_set[kk-1];
				
				CIndividual::N_of_x = 7;
				
				RUN_NUMBER = 100;
				for (int i=0;i<RUN_NUMBER;i++)
				{// run no level	
					int t = output_counter;				
					int k = t*RUN_NUMBER;
					printf("-------------------------- Run no. is %d --------------------------\n", i+1);
					seed = ((double)(k+i+1))/((double)RUN_NUMBER);
					if (seed == 0.0)
					{
						seed = 0.001;
					}
					if (seed == 1.0)
					{
						seed = 0.99;
					}
					
					DE_method = new CDE_method;
					DE_method->Run_Optimizer(k+i, seed, method, strategy_index, index_of_func, index_dataset);
					delete DE_method;
				}
			}
		}
	}
}

void welcome()
{
	printf("\n");
	printf("***************************************************************\n");
	printf("*             Welcome to use the DE optimizers.               *\n");
	printf("*        You can select and use the following optimizer.      *\n");
	printf("*                method = 1   for jDE                         *\n");
	printf("*                method = 2   for Rcr_IJADE                   *\n");
	printf("***************************************************************\n");
	printf("\n");
}