// ProblemDef.cpp: implementation of the CProblemDef class.
//
//////////////////////////////////////////////////////////////////////


#include "ProblemDef.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CProblemDef::CProblemDef()
{
}

CProblemDef::~CProblemDef()
{
}

void CProblemDef::evaluate_normal_fitness(double *xreal, tFitness &obj, int func_flag, long int &evaluations, 
		double *data_in_datasheet, double *measured_V, double *measured_I, int num_of_measure, double *pv_parameters)
{
	/************************************************************************/
	int i;
	data_len = num_of_measure;
	for(i=0;i<data_len;i++)
	{
		actual_V_data[i] = measured_V[i];
		actual_I_data[i] = measured_I[i];
	}

	// data obtained from the datasheet
	area	= data_in_datasheet[0];
	T		= data_in_datasheet[1];
	Z		= data_in_datasheet[2];
	/************************************************************************/

	switch(func_flag) {
	case 1:
		SOFC_model_7_parameters(xreal, obj, pv_parameters);
		break;
	case 2:
		SOFC_model_3_parameters(xreal, obj, pv_parameters);
		break;
	default:
		printf("The function you selected does not exist.\n");
		exit(0);
		break;
	}

	evaluations++;
}

/* Bare-bones Gauss-Jordan algorithm. Returns '0' on success, '1' if
 * matrix is singular (zero diagonal). No pivoting used.
 *
 * Replaces input matrix with its inverse.
 */
int CProblemDef::matinv(double a[][4],int n)
{
	double **inv,tmp;
    int i,j,k,retval;
	
    retval = 0;
    inv = new double *[n];
    for (i=0;i<n;i++) {
        inv[i] = new double [n];
    }
	// Initialize identity matrix
    for (i=0;i<n;i++) {
        for (j=0;j<n;j++) {
            inv[i][j] = 0.0;
        }
        inv[i][i] = 1.0;
    }
	
    for (k=0;k<n;k++) {
        tmp = a[k][k];
        if (tmp == 0) {
            retval = 1;
            goto _100;
        }
        for (j=0;j<n;j++) {
            if (j>k) a[k][j] /= tmp;    // Don't bother with previous entries
            inv[k][j] /= tmp;
        }
        for (i=0;i<n;i++) {             // Loop over rows
            if (i == k) continue;
            tmp = a[i][k];
            for (j=0;j<n;j++) {
                if (j>k) a[i][j] -= a[k][j]*tmp;
                inv[i][j] -= inv[k][j]*tmp;
            }
        }
    }
	
	// Copy inverse to source matrix
    for (i=0;i<n;i++) {
        for (j=0;j<n;j++) {
            a[i][j] = inv[i][j];
        }
    }
_100:
    for (i=0;i<n;i++) {
        delete [] inv[i];
    }
    delete [] inv;
    return retval;
}

double CProblemDef::sum(double *data, int n)
{
	double	rst = 0.0;
	int		i;
	for (i=0; i<n; i++)
	{
		rst += data[i];
	}
	return rst;
}

double CProblemDef::sum(double *data1, double *data2, int n)
{
	double	rst = 0.0;
	int		i;
	for (i=0; i<n; i++)
	{
		rst += data1[i]*data2[i];
	}
	return rst;
}

void CProblemDef::SOFC_model_7_parameters(double *xreal, tFitness &obj, double *pv_parameters)
{
	int j;

	E0	= xreal[0];
	A	= xreal[1];
	R	= xreal[2];
	B	= xreal[3];

	I_a	= xreal[4];
	I_b	= xreal[5];
	I_l	= xreal[6];

	for (j=0; j<7; j++)
	{
		pv_parameters[j] = xreal[j];
	}

	double	u;
	double	u1;
	
	// calculate the fitness value
	tFitness fitness, error_value=0.0;
	double	 V_m, I_m;
	fitness = 0.0;
	for (j=0;j<data_len;j++)
	{
		V_m			= actual_V_data[j];
		I_m			= actual_I_data[j]*1000.0/area;

		// constraints are penalized herein
		if ( (I_a>I_b) || (I_m-I_l>=1e-13) )
		{
			obj = INF;
			return;
		}

		u	= (I_m)/(2*I_a);
		u1	= (I_m)/(2*I_b);
		if (I_m != 0.0)
		{
			V_ohm	= I_m * R;
			V_act	= A*log( u + sqrt(1.0 + u*u) ) + A*log( u1 + sqrt(1.0 + u1*u1) );
			V_con	= -B*log(1.0 - I_m/I_l);
		}	
		else
		{		
			V_ohm = 0.0;
			V_act = 0.0;
			V_con = 0.0;
		}
		
		error_value	 = Z * ( E0 - V_con - V_act - V_ohm ) - V_m;
		
		fitness     += error_value * error_value;
	}
	fitness = (fitness)/(double)data_len;
	//fitness = sqrt( (fitness)/(double)data_len );		// root mean square error (RMSE)
	
	obj = fitness;
}

void CProblemDef::SOFC_model_3_parameters(double *xreal, tFitness &obj, double *pv_parameters)
{
	int j;
	
	I_a	= xreal[0];
	I_b	= xreal[1];
	I_l	= xreal[2];

	double	u;
	double	u1;
	double	V_m, I_m;

	/************************************************************************/
	double	Ck[5000], Dk[5000], Ek[5000];
	assert(data_len<=5000);
	for (j=0;j<data_len;j++)
	{
		I_m		= actual_I_data[j]*1000.0/area;	
		
		// constraints are penalized herein
		if ( (I_a>I_b) || (I_m-I_l>=1e-13) )
		{
			obj = INF;
			return;
		}

		u		= (I_m)/(2*I_a);
		u1		= (I_m)/(2*I_b);

		Ck[j]	= ( log( u + sqrt(1.0 + u*u) ) + log( u1 + sqrt(1.0 + u1*u1) ) );
		Dk[j]	= I_m;
		Ek[j]	= log(1.0 - I_m/I_l);
	}

	double	b1, b2, b3, b4;
	double	 BB[4];
	BB[0] = b1 = sum(actual_V_data, data_len)/Z;
	BB[1] = b2 = -sum(Ck, actual_V_data, data_len)/Z;
	BB[2] = b3 = -sum(Dk, actual_V_data, data_len)/Z;
	BB[3] = b4 = sum(Ek, actual_V_data, data_len)/Z;

	double	a11, a12, a13, a14;
	double	a21, a22, a23, a24;
	double	a31, a32, a33, a34;
	double	a41, a42, a43, a44;
	double	AA[16];
	AA[0]	= a11 = data_len;
	AA[1]	= a12 = -sum(Ck, data_len);
	AA[2]	= a13 = -sum(Dk, data_len);
	AA[3]	= a14 = sum(Ek, data_len);
	AA[4]	= a21 = a12;
	AA[5]	= a22 = sum(Ck, Ck, data_len);
	AA[6]	= a23 = sum(Ck, Dk, data_len);
	AA[7]	= a24 = -sum(Ck, Ek, data_len);
	AA[8]	= a31 = a13;
	AA[9]	= a32 = a23;
	AA[10]	= a33 = sum(Dk, Dk, data_len);
	AA[11]	= a34 = -sum(Dk, Ek, data_len);
	AA[12]	= a41 = a14;
	AA[13]	= a42 = a24;
	AA[14]	= a43 = a34;
	AA[15]	= a44 = sum(Ek, Ek, data_len);

	//////////////////////////////////////////////////////////////////////////	method 1
	/* ERROR in method 1 when the inversion matrix is used.
	double	xx[4] = {0};
	CMatrix AAA(4, 4, AA), BBB(4, 1, BB), CCC(4, 1, xx), DDD;
	DDD	= AAA.GetReverse();

	E0	= 0.0;
	for (j=0; j<4; j++)
	{
		E0  += DDD.m_pData[j] * BB[j];
	}
	A	= 0.0;
	for (j=0; j<4; j++)
	{
		A	+= DDD.m_pData[4+j] * BB[j];
	}
	R	= 0.0;
	for (j=0; j<4; j++)
	{
		R	+= DDD.m_pData[8+j] * BB[j];
	}
	B	= 0.0;
	for (j=0; j<4; j++)
	{
		B	+= DDD.m_pData[12+j] * BB[j];
	}*/

	//////////////////////////////////////////////////////////////////////////	method 2
	/*double den;
	den = a11*a22*a33*a44 - a11*a24*a33*a42 + a12*a21*a34*a43 - a12*a23*a34*a41 + a13*a24*a31*a42 - a13*a22*a31*a44 + a14*a23*a32*a41 - a14*a21*a32*a43 +
		  a11*a23*a34*a42 - a11*a22*a34*a43 + a13*a21*a32*a44 - a13*a24*a32*a41 + a14*a22*a31*a43 - a14*a23*a31*a42 + a12*a24*a33*a41 - a12*a21*a33*a44 +
		  a11*a24*a32*a43 - a11*a23*a32*a44 + a14*a21*a33*a42 - a14*a22*a33*a41 + a12*a23*a31*a44 - a12*a24*a31*a43 + a13*a22*a34*a41 - a13*a21*a34*a42;

	E0	= ( (a22*a33*a44 + a23*a34*a42 + a32*a43*a24 - a42*a33*a24 - a23*a32*a44 - a34*a43*a22)*b1 - (a21*a33*a44 + a31*a43*a24 + a23*a34*a41 - a41*a33*a24 - a31*a23*a44 - a34*a43*a21)*b2 +
		    (a21*a32*a44 + a31*a42*a24 + a22*a34*a41 - a24*a32*a41 - a34*a42*a21 - a22*a31*a44)*b3 - (a21*a32*a43 + a22*a33*a41 + a31*a42*a23 - a23*a32*a41 - a33*a42*a21 - a22*a31*a43)*b4 )/den;
	A	= (-(a12*a33*a44+a13*a34*a42+a32*a43*a14-a14*a33*a42-a13*a32*a44-a34*a43*a12)*b1+(a11*a33*a44+a31*a43*a14+a13*a34*a41-a14*a33*a41-a34*a43*a11-a13*a31*a44)*b2-
		(a11*a32*a44+a12*a34*a41+a31*a42*a14-a14*a32*a41-a34*a42*a11-a12*a31*a44)*b3+(a11*a32*a43+a12*a33*a41+a31*a42*a13-a13*a32*a41-a33*a42*a11-a12*a31*a43)*b4)/den;
	R	= ((a12*a23*a44+a13*a24*a42+a22*a43*a14-a14*a23*a42-a24*a43*a12-a13*a22*a44)*b1-(a11*a23*a44+a21*a43*a14+a13*a24*a41-a14*a23*a41-a24*a43*a11-a13*a21*a44)*b2+
		(a11*a22*a44+a12*a24*a41+a21*a42*a14-a14*a22*a41-a12*a21*a44-a24*a42*a11)*b3-(a11*a22*a43+a12*a23*a41+a21*a42*a13-a13*a22*a41-a23*a42*a11-a12*a21*a43)*b4)/den;
	B	= (-(a12*a23*a34+a13*a24*a32+a22*a33*a14-a14*a23*a32-a24*a33*a12-a13*a22*a34)*b1+(a11*a23*a34+a13*a24*a31+a21*a33*a14-a14*a23*a31-a24*a33*a11-a13*a21*a34)*b2-
		(a11*a22*a34+a12*a24*a31+a21*a32*a14-a14*a22*a31-a24*a32*a11-a12*a21*a34)*b3+(a11*a22*a33+a12*a23*a31+a21*a32*a13-a13*a22*a31-a23*a32*a11-a12*a21*a33)*b4)/den;*/

	//////////////////////////////////////////////////////////////////////////	method 3
	/**/double	AAA[4][4];
	AAA[0][0] = a11;	AAA[0][1] = a12;	AAA[0][2] = a13;	AAA[0][3] = a14;
	AAA[1][0] = a21;	AAA[1][1] = a22;	AAA[1][2] = a23;	AAA[1][3] = a24;
	AAA[2][0] = a31;	AAA[2][1] = a32;	AAA[2][2] = a33;	AAA[2][3] = a34;
	AAA[3][0] = a41;	AAA[3][1] = a42;	AAA[3][2] = a43;	AAA[3][3] = a44;

	int inv_flag = matinv(AAA, 4);

	if (inv_flag==0)
	{// matrix is inversed successfully.	
		double	xx[4] = {0};
		for (j=0; j<4; j++)
		{
			xx[j] = 0.0;
			for (int k=0; k<4; k++)
			{
				xx[j] += AAA[j][k] * BB[k];
			}
		}
		E0	= xx[0];
		A	= xx[1];
		R	= xx[2];
		B	= xx[3];

		if (R <= 0)
		{
			BB[2]		= 1e-4;
			AAA[2][0]	= 0;	AAA[2][1] = 0;	AAA[2][2] = 1;	AAA[2][3] = 0;

			double	xx[4] = {0};
			for (j=0; j<4; j++)
			{
				xx[j] = 0.0;
				for (int k=0; k<4; k++)
				{
					xx[j] += AAA[j][k] * BB[k];
				}
			}
			E0	= xx[0];
			A	= xx[1];
			R	= xx[2];
			B	= xx[3];
		}
	}
	else
	{// matrix is singular (zero diagonal)
		obj = INF;
		return;
	}

	//////////////////////////////////////////////////////////////////////////
// 	if ( E0<=0 || A<=0 || R<=0 || B<=0 )			// commented on 2017-12-20
// 	{
// 		obj = INF;
// 		return;
// 	}

	//printf("%e\t%e\t%e\t%e\n", E0, A, R, B);getchar();
	/************************************************************************/

	pv_parameters[0] = E0;
	pv_parameters[1] = A;
	pv_parameters[2] = R;
	pv_parameters[3] = B;
	pv_parameters[4] = xreal[0];
	pv_parameters[5] = xreal[1];
	pv_parameters[6] = xreal[2];
		
	// calculate the fitness value
	tFitness fitness, error_value=0.0;
	fitness = 0.0;
	for (j=0;j<data_len;j++)
	{
		V_m			= actual_V_data[j];
		I_m			= actual_I_data[j]*1000.0/area;
		
		/*
		// constraints are penalized herein
		if ( (I_a>I_b) || (I_m-I_l>=1e-13) )
		{
			obj = INF;
			return;
		}
		
		u	= (I_m)/(2*I_a);
		u1	= (I_m)/(2*I_b);
		if (I_m != 0.0)
		{
			V_ohm	= I_m * R;
			V_act	= A*log( u + sqrt(1.0 + u*u) ) + A*log( u1 + sqrt(1.0 + u1*u1) );
			V_con	= -B*log(1.0 - I_m/I_l);
		}	
		else
		{		
			V_ohm = 0.0;
			V_act = 0.0;
			V_con = 0.0;
		}	
		error_value	 = Z * ( E0 - V_con - V_act - V_ohm ) - V_m;
		*/
			
		error_value	 = Z * ( E0 - A*Ck[j] - R*Dk[j] + B*Ek[j]) - V_m;

		fitness     += error_value * error_value;
	}
	fitness = (fitness)/(double)data_len;
	//fitness = sqrt( (fitness)/(double)data_len );		// root mean square error (RMSE)
	
	obj = fitness;
}





