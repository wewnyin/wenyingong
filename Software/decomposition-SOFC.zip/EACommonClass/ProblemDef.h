// ProblemDef.h: interface for the CProblemDef class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_)
#define AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../global.h"
#include "Individual.h"
#include "Rand.h"
#include "Matrix.h"


// only for unconstrained optimization problems
class CProblemDef  
{
public:
	CProblemDef();
	virtual ~CProblemDef();

	int		matinv(double a[][4],int n);					// inverse of matrix using Gauss-Jordan elimination

	double	sum(double *data, int n);
	double	sum(double *data1, double *data2, int n);

	// for unconstrained optimization problems
public:
	double	area, T;		// area and T of the SOFC module

	double	actual_V_data[5000], actual_I_data[5000];
	int		data_len;

	// parameters for SOCF module
	double	Z;				// number of cells
	double	E0, A, R, B;	// dependent parameters
	double	I_a, I_b, I_l;	// independent parameters

	double	V_ohm, V_act, V_con;

public:
	void	evaluate_normal_fitness(double *xreal, tFitness &obj, int func_flag, long int &evaluations, 
		double *data_in_datasheet, double *measured_V, double *measured_I, int num_of_measure, double *pv_parameters);

	void	SOFC_model_7_parameters(double *xreal, tFitness &obj, double *pv_parameters);
	void	SOFC_model_3_parameters(double *xreal, tFitness &obj, double *pv_parameters);

};

#endif // !defined(AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_)
