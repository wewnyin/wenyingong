// Individual.h: interface for the CIndividual class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INDIVIDUAL_H__A05E59DB_40D8_4282_9D3C_A0201898ACA8__INCLUDED_)
#define AFX_INDIVIDUAL_H__A05E59DB_40D8_4282_9D3C_A0201898ACA8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../global.h"

/* global parameters (changed with different problems solved) */
#define batch_execution			1			// 1: for batch execution; 0: original execution (mannual)


/* the following parameters are problem dependent */
// #define index_of_normal			2			// index of the normal function, 0 means no normal function
// 
// #define N_of_x					7			// number of the decision variables
// #define Max_of_NFEs				20000		// the maximal number of function evaluations

#define N_of_constr				0			// number of the constrained functions

#define PRECISION				1e-6		// value to reach (VTR)
/* ---------------------------------------------- */

#define population_size			1000		// size of the population  (rank-JADE with mu_CR=0.9 and NP=50 is the potential best one)

#define Limit_ABC				(500)		// Control parameter in order to abandon the food source
/* -------------------------------------------------------------- */

class CIndividual  
{
public:
	CIndividual();
	virtual ~CIndividual();

	static int index_of_normal;
	static int N_of_x;
	static int Max_of_NFEs;

public:
	CIndividual(const CIndividual &);							// �������캯��
	CIndividual &operator=(const CIndividual &);				// ����"="�����

public:
	double		*xreal;				// Real Coded Decision Variable     
	tFitness	obj;				// value of the objective function
	tFitness	fitness;			// fitness of the objective function
	double		constr_violation;	// parameter for constraint violation
    double		*constr;			// defining the constraint values
	int			feasible;			// check the individual is feasible or not (1: feasible; 0: infeasible)
	int			no_of_violation;	// number of the violated constraint functions

	double		PV_parameters[10];

	double		F;					// only for DE
	double		CR;					// only for DE
	
	tFitness	normal_fitness;		// only for rcGA
	
	double		eta[500];			// only for EP method
	
	int			limit_age;			// only for ABC algorithm
};

#endif // !defined(AFX_INDIVIDUAL_H__A05E59DB_40D8_4282_9D3C_A0201898ACA8__INCLUDED_)
