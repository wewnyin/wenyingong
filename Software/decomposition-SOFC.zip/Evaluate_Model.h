// Evaluate_Model.h: interface for the CEvaluate_Model class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EVALUATE_MODEL_H__B552D86B_28CF_4B01_A94C_26A0F8B88C65__INCLUDED_)
#define AFX_EVALUATE_MODEL_H__B552D86B_28CF_4B01_A94C_26A0F8B88C65__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "global.h"

class CEvaluate_Model  
{
public:
	CEvaluate_Model();
	virtual ~CEvaluate_Model();

private:
	double	area, T;		// area and T of the SOFC module
	
	double	actual_V_data[5000], actual_I_data[5000];
	int		data_len;
	double	pv_parameters[7];
	
	// parameters for SOCF module
	double	Z;				// number of cells
	double	E0, A, R, B;	// dependent parameters
	double	I_a, I_b, I_l;	// independent parameters
	
	double	V_ohm, V_act, V_con;

private:
	void	SOFC_model_7_parameters(double *modeled_I, double *modeled_V, int n_of_modeled);

public:
	void	evaluate_model(int func_flag, double *data_in_datasheet, double *measured_I, double *measured_V, int num_of_measure, double *pv, 
		double *modeled_I, double *modeled_V, int n_of_modeled);
};

#endif // !defined(AFX_EVALUATE_MODEL_H__B552D86B_28CF_4B01_A94C_26A0F8B88C65__INCLUDED_)
