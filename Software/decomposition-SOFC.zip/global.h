// --------------------include files--------------------
#include <iostream.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <windows.h>
#include <fstream.h>
#include <iomanip.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>


// --------------------Global variables--------------------
#define E	exp(1.0)
#define PI	acos(-1.0)
#define INF	1.0e99
#define EPS 1.0e-14		// the precision of the constraints

#define max(a,b) (((a) > (b)) ? (a) : (b))
#define min(a,b) (((a) < (b)) ? (a) : (b))

#define DBL_MAX 1.7976931348623158e+308 

typedef long double tFitness;
