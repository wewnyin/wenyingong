// Evaluate_Model.cpp: implementation of the CEvaluate_Model class.
//
//////////////////////////////////////////////////////////////////////

#include "Evaluate_Model.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEvaluate_Model::CEvaluate_Model()
{
}

CEvaluate_Model::~CEvaluate_Model()
{
}

void CEvaluate_Model::evaluate_model(int func_flag, double *data_in_datasheet, double *measured_I, double *measured_V, 
									 int num_of_measure, double *pv, double *modeled_I, double *modeled_V, int n_of_modeled)
{
	/************************************************************************/
	int i;
	data_len = num_of_measure;
	for(i=0;i<data_len;i++)
	{
		actual_V_data[i] = measured_V[i];
		actual_I_data[i] = measured_I[i];
	}
	
	for (i=0; i<7; i++)
	{
		pv_parameters[i] = pv[i];
	}
	
	// data obtained from the datasheet
	area	= data_in_datasheet[0];				// area
	T		= data_in_datasheet[1];				// temperature
	Z		= data_in_datasheet[2];				// number of cells
	/************************************************************************/

	SOFC_model_7_parameters(modeled_I, modeled_V, n_of_modeled);
}

void CEvaluate_Model::SOFC_model_7_parameters(double *modeled_I, double *modeled_V, int n_of_modeled)
{	
	E0	= pv_parameters[0];
	A	= pv_parameters[1];
	R	= pv_parameters[2];
	B	= pv_parameters[3];
	
	I_a	= pv_parameters[4];
	I_b	= pv_parameters[5];
	I_l	= pv_parameters[6];

	//////////////////////////////////////////////////////////////////////////
	double	I_first	= actual_I_data[0];
	double	I_last	= actual_I_data[data_len-1];
	
	int j;
	for (j=0; j<n_of_modeled; j++)
	{
		modeled_I[j] = I_first + j*fabs(I_first-I_last)/n_of_modeled;
	}
	modeled_I[n_of_modeled-1] = I_last;

	double	u;
	double	u1;
	
	// calculate the fitness value
	tFitness fitness, error_value=0.0;
	double	 I_m;
	fitness = 0.0;
	for (j=0;j<n_of_modeled;j++)
	{
		I_m	= modeled_I[j]*1000.0/area;		// A in dataset, converting into mA/cm^2
		
		// constraints are penalized herein
		if ( (I_a>I_b) || (I_m-I_l>=1e-13) )
		{
			modeled_V[j] = INF;
			continue;
		}
		
		u	= (I_m)/(2*I_a);
		u1	= (I_m)/(2*I_b);
		if (I_m != 0.0)
		{
			V_ohm	= I_m * R;
			V_act	= A*log( u + sqrt(1.0 + u*u) ) + A*log( u1 + sqrt(1.0 + u1*u1) );
			V_con	= -B*log(1.0 - I_m/I_l);
		}	
		else
		{		
			V_ohm = 0.0;
			V_act = 0.0;
			V_con = 0.0;
		}
		
		modeled_V[j] = Z * ( E0 - V_con - V_act - V_ohm );
	}
}