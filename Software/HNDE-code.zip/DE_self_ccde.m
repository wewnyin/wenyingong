function [pop, val, tempval, CR1, valParents, nfeval, Dis, DE_gbestval]=DE_self_ccde(pop, val, F, r1, r2, r3, NP, D, CR, nfeval, func_no, DE_gbestval)
global xl xu

% Mutation
vi=pop(r1,:)+F*(pop(r2,:)-pop(r3,:));

% Binomial crossover
for i = 1:NP
    j_rand = floor(rand * D) + 1;
    t = rand(1, D) < CR(i);
    t(1, j_rand) = 1;
    t_ = 1 - t;
    ui(i, :) = t .* vi(i, :) + t_ .* pop(i, :);
    nfeval  = nfeval + 1;
    % Handle the elements of the mutant vector which violate the boundary
    if rand>0.5
        ui(i, :)=(ui(i, :)<xl).*xl+(ui(i, :)>=xl).*ui(i, :);
        ui(i, :)=(ui(i, :)>xu).*xu+(ui(i, :)<=xu).*ui(i, :);
    else
        ui(i, :)=(ui(i, :)<xl).*(xl+rand(1,D).*(xu-xl))+(ui(i, :)>=xl).*ui(i, :);
        ui(i, :)=(ui(i, :)>xu).*(xl+rand(1,D).*(xu-xl))+(ui(i, :)<=xu).*ui(i, :);
    end
end

Dis=sum(sqrt(sum((pop-ui).^2,2)))/NP;

%Select which vectors are allowed to enter the new population
for i=1:NP
tempval(i,1)=-NES_func(ui(i,:),func_no);
end
for i=1:NP
    [~, j]=min(sqrt(sum((ones(NP,1)*ui(i,:)-pop).^2,2)));
    
    valParents(i,:)=val(j);
    CR1(i,:)=CR(j,:);
    
    if val(j)<tempval(i)
        pop(j,:)=ui(i,:);
        val(j)=tempval(i);
        
        if (tempval(i) > DE_gbestval)     % if competitor better than the best one ever
            DE_gbestval = tempval(i);      % new best value
%             DE_gbest = ui(i,:);      % new best parameter vector ever
        end
    end
end %---end for imember=1:NP
