function [solution]=ANDE(fun_num,root,root_num,pop,D,NP,Max_FES,XRmin,XRmax)
warning off
F=0.9;
CR=0.1;
FES=0;
st=2;
lambda=0.9;
if D<=5
    min_valthresold=1e-6;
    thresold=0.001;
else
    min_valthresold=1e-4;
    thresold=0.01;
end
for i=1:NP
    val(i)=NES_func(pop(i,:),fun_num);
    FES=FES+1;
end
X=[];
R=zeros(NP,NP);%responsibilities
A=zeros(NP,NP);%availabilities
S=zeros(NP,NP);
while FES<Max_FES
    %PCA
    if D>3
        X=pop';
        average=mean(X,2);
        average=average*ones(1,NP);
        X=X-average;
        C=X*(X')/D;
        [eigenvector eigenvalue]=eig(C);
        eigenvalue=diag(eigenvalue);
        [sortvalue sortindex]=sort(eigenvalue, 'descend');
        P=eigenvector(:,sortindex(1:3));
        P=P';
        X=P*X;
        X=X';
    end
    %APC
    mintemp=[];
    for i=1:NP
        if D>3
            S(i,:)=-sqrt(sum((ones(size(X,1),1)*X(i,:)-X).^2,2));
        else
            S(i,:)=-sqrt(sum((ones(size(pop,1),1)*pop(i,:)-pop).^2,2));
        end
        mintemp=[mintemp,S(i,1:i-1),S(i,i+1:NP)];
    end
    for i=1:NP
        S(i,i)= median(mintemp);
    end
    T=zeros(NP,NP);
    E=zeros(NP,NP);
    center=[];
    c_cit=0;
    %find the exemplar
    for iter=1:100
        % Compute responsibilities
        Rold=R;
        AS=A+S;
        [Y,I]=max(AS,[],2);
        for i=1:NP
            AS(i,I(i))=-1000;
        end;
        [Y2,I2]=max(AS,[],2);
        R=S-repmat(Y,[1,NP]);
        for i=1:NP
            R(i,I(i))=S(i,I(i))-Y2(i);
        end;
        R=(1-lambda)*R+lambda*Rold; % Dampen responsibilities
        % Compute availabilities
        Aold=A;
        Rp=max(R,0);
        for k=1:NP
            Rp(k,k)=R(k,k);
        end;
        A=repmat(sum(Rp,1),[NP,1])-Rp;
        dA=diag(A);
        A=min(A,0);
        for k=1:NP
            A(k,k)=dA(k);
        end;
        A=(1-lambda)*A+lambda*Aold; % Dampen availabilities
    end;
    
    for i=1:NP
        E(i,i) = R(i,i) +A(i,i);
        if E(i,i)>0
            center=[center;i];
        end
    end
    
    for i=1:NP
        idxForI = 0;
        maxSim = -1e100;
        for j=1:size(center,1)
            c = center(j);
            if  S(i,c)>maxSim
                maxSim = S(i,c);
                idxForI = c;
            end
        end
        idx(i) = idxForI;
    end
    %�ж�
    spop=[];
    for j=1:size(center,1)
        spop(j).pop=pop(idx==center(j),:);
        spop(j).val=val(idx==center(j));
        spop(j).seed=pop(center(j),:);
        spop(j).seedval=val(center(j));
    end
    for j=1:size(center,1)
        if size(spop(j).pop,1)>3
            for k=1:size(spop(j).pop,1)
                u(k,:)=DE(spop(j).pop(k,:),spop(j).pop,spop(j).seed,st,F,CR,D,size(spop(j).pop,1),XRmin,XRmax);
                u_val(k)=NES_func(u(k,:),fun_num);
                FES=FES + 1;
                checkdis=sqrt(sum((ones(size(spop(j).pop,1),1)*u(k,:)-spop(j).pop).^2,2));%���㵱ǰ��Ⱥ���¸����ŷʽ����
                [minval,minindex]=min(checkdis);
                if u_val(k)<spop(j).val(minindex)
                    spop(j).val(minindex)=u_val(k);
                    spop(j).pop(minindex,:)=u(k,:);
                end
            end
            %CPA
            [sortval,sortindex] =sort(spop(j).val,'ascend');
            best=spop(j).pop(sortindex(1),:);
            best_val=spop(j).val(sortindex(1));
            [checkdis index]=sort(sqrt(sum((ones(size(spop(j).pop,1),1)*best-spop(j).pop).^2,2)),'ascend');%���㵱ǰ��Ⱥ��best��ŷʽ����
            if size(spop(j).pop,1)>5
                spop1=spop(j).pop(index(2:5),:);
                spop1_val=spop(j).val(index(2:5));
            else
                spop1=spop(j).pop(index(2:4),:);
                spop1_val=spop(j).val(index(2:4));
            end
            temp=zeros(1,D);
            for e=1:size(spop1,1)
                temp1=spop1(e,:)+(-0.2*best_val-0.1)/(spop1_val(e)-best_val)*(spop1(e,:)-best);
                for m=1:D
                    if temp1(m)<XRmin(m)
                        temp1(m)=XRmin(m);
                    elseif temp1(m)>XRmax(m)
                        temp1(m)=XRmax(m);
                    end
                end
                spop1(e,:)=temp1;
                temp=temp+spop1(e,:);
        end
        temp=temp/size(spop1,1);
        temp_val=NES_func(temp,fun_num);
        FES=FES+1;
        if temp_val<best_val
            spop(j).pop(sortindex(1),:)=temp;
            spop(j).val(sortindex(1))=temp_val;
        end
    end
end

%TLLS
Y=10^(-1-((10/D+3)*FES)/Max_FES);
temp=[];
for i=1:size(spop,2)
    temp=[temp;spop(i).seedval];
end
[sortval sortindex]=sort(temp,'descend');
for i=1:size(spop,2)
    spop(sortindex(i)).P=i/size(spop,2);
end
for i=1:size(spop,2)
    if rand<spop(i).P
        for j=1:size(spop(i).pop,1)
            [sortval sortindex]=sort(spop(i).val,'descend');
            spop(i).Pr(sortindex(j))=j/size(spop(i).pop,1);
        end
        for j=1:size(spop(i).pop,1)
            if rand<spop(i).Pr(j)
            for m=1:D
                xnew1(m)=normrnd(spop(i).pop(j,m), Y);
                while xnew1(m)>XRmax(m)||xnew1(m)<XRmin(m)
                    xnew1(m)=normrnd(spop(i).pop(j,m), Y);
                end
                xnew2(m)=normrnd(spop(i).pop(j,m), Y);
                while xnew2(m)>XRmax(m)||xnew2(m)<XRmin(m)
                    xnew2(m)=normrnd(spop(i).pop(j,m), Y);
                end
            end
            xnew1val=NES_func(xnew1,fun_num);
            xnew2val=NES_func(xnew2,fun_num);
            FES=FES+2;
            if xnew2val<xnew1val
                xnew=xnew2;
                xnewval=xnew2val;
            else
                xnew=xnew1;
                xnewval=xnew1val;
            end
            if xnewval<spop(i).val(j)
                spop(i).pop(j,:)=xnew;
                spop(i).val(j)=xnewval;
            end
          end
            
        end
    end
end
pop=[];
val=[];
for i=1:size(spop,2)
    pop=[pop;spop(i).pop];
    val=[val,spop(i).val];
end
% FES
% plot(pop(1:NP,1),pop(1:NP,2),'o')
% hold on
% plot(root(1:size(root,1),1),root(1:size(root,1),2),'*')
% hold off

end
archive=[];
archiveval=[];
for j=1:size(pop,1)
    if val(j)<min_valthresold
        archive= [archive;pop(j,:)];
        archiveval= [archiveval,val(j)];
    end
end

final_pop=[archive];
final_val=[archiveval];
solution=[];
root_index=1;
for s=1:root_num
    if size(final_pop,1)>0
        [minval,minindex]=min(sqrt(sum((ones(size(final_pop,1),1)*root(s,:)-final_pop).^2,2)));
        if final_val(minindex)<min_valthresold&&minval<=1e-1
            solution(root_index,:)=[s,final_pop(minindex,:)];
            root_index=root_index+1;
        end
    end
end
end
