function [solution]=my_ncde(fun_num,root,root_num,pop,D,NP,Max_FES,XRmin,XRmax)
warning off
solution=[];
F=0.5;
CR=0.9;
st=2;
FES=0;
peakslocation=[];
for i=1:NP
    val(i)=NES_func(pop(i,:),fun_num);
    FES=FES+1;
end
if fun_num>=101
    min_valthresold=1e-8;
    thresold=0.1;
end
sw=0;
MPR1=[];
UI=[];
UI_VAL=[];
while FES<Max_FES
        subpop=[];
        for j=1:size(pop,1)
            num=5+5*((Max_FES-FES)/Max_FES);
            st=2;
            [temp k]=sort(sqrt(sum((ones(size(pop,1),1)*pop(j,:)-pop).^2,2)));
            subpop(j).pop=pop(k(1:num),:);
            subpop(j).val=val(k(1:num));
            ui(j,1:D)=DE( pop(j,:),subpop(j).pop, pop(j,:),st,F,CR,D,size(subpop(j).pop,1),XRmin,XRmax);
        end
        for i=1:NP
            ui_val(i)=NES_func(ui(i,:),fun_num);
            FES=FES+1;
        end
        for j=1:NP
            [temp index]=min(sqrt(sum((ones(NP,1)*ui(j,:)-pop).^2,2)));
            if val(index)>ui_val(j)
                pop(index,:)=ui(j,:);
                val(index)=ui_val(j);
            end
        end
        sw=sw+1;
        if mod(sw,10)==0
        solution1=[];
    root_index=1;
    for s=1:root_num
        [minval,minindex]=min(sqrt(sum((ones(NP,1)*root(s,:)-pop).^2,2)));
        if D<=5
            if val(minindex)<1e-6&&minval<1e-1
                solution1(root_index,:)=[s,pop(minindex,:)];
                root_index=root_index+1;
            end
        else
            if val(minindex)<1e-4&&minval<1e-1
                solution1(root_index,:)=[s,pop(minindex,:)];
                root_index=root_index+1;
            end
        end
    end
     PR1=size(solution1,1)/root_num;%calculate the peak ratio  
     MPR1=[MPR1,PR1];    
 end
end
    solution=[];
    root_index=1;
    for s=1:root_num
        [minval,minindex]=min(sqrt(sum((ones(NP,1)*root(s,:)-pop).^2,2)));
        if D<=5
            if val(minindex)<1e-6&&minval<1e-1
                solution(root_index,:)=[s,pop(minindex,:)];
                root_index=root_index+1;
            end
        else
            if val(minindex)<1e-4&&minval<1e-1
                solution(root_index,:)=[s,pop(minindex,:)];
                root_index=root_index+1;
            end
        end
    end
   
        xxx=[1:size(MPR1,2)];
        xx=linspace(1,size(MPR1,2));
        yy=spline(xxx,MPR1,xx);
         plot(xxx,MPR1,'ro-');
        hold on
% solution=[];
%     root_index=1;
%     for s=1:root_num
%         [minval,minindex]=min(sqrt(sum((ones(NP,1)*root(s,:)-pop).^2,2)));
%         if D<=5
%             if val(minindex)<=1e-6&&minval<=1e-1
%                 solution(root_index,:)=[s,pop(minindex,:)];
%                 root_index=root_index+1;
%             end
%         else
%             if val(minindex)<=1e-4&&minval<=1e-1
%                 solution(root_index,:)=[s,pop(minindex,:)];
%                 root_index=root_index+1;
%             end
%         end
%     end
end

