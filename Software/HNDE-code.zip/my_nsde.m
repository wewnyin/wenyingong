function [solution]=my_nsde(fun_num,root,root_num,pop,D,NP,Max_FES,XRmin,XRmax)
warning off
solution=[];
F=0.5;
CR=0.9;
st=1;
FES=0;
archive=[];
archive_val=[];
if D<=5
    min_valthresold=1e-6;
    thresold=0.001;
else
    min_valthresold=1e-4;
    thresold=0.01;
end
val = zeros(1,NP);    
for i=1:NP
    val(i)=NES_func(pop(i,:),fun_num);
    FES=FES+1;
end
sw=0;
MPR1=[];
while FES<Max_FES
    [sortval,sortindex]=sort(val,'ascend');
    popsort=pop(sortindex,:);%������Ӧֵ��С��������
    valsort=val(sortindex);
    clear spop;
if size(popsort,1)>NP%��֤��Ⱥֻȡ100��
        popsort=popsort(1:NP,:);
        valsort=valsort(1:NP);
end
  for i=1:(NP/5)
        [temp k]=sort(sqrt(sum((ones(size(popsort,1),1)*popsort(1,:)-popsort).^2,2)));
         spop(i).species=popsort(1,:);%��ǰ��Ⱥ����õ�  
         spop(i).speciesval=valsort(1); %��ǰ��õ���Ӧֵ
        checker=ones(size(popsort,1),1);
        checker(k(1:5),:)=0;
        spop(i).pop=popsort(checker==0,:);%�ҳ�����õ�m=5����������µ���ȺͶ��DE��
        spop(i).val=valsort(checker==0);%��¼������������Ӧֵ
        popsort=popsort(checker==1,:);%�����ʣ��ģ�Ȼ����ʣ���������
        valsort=valsort(checker==1);
  end
   for i=1:size(spop,2)  
         for j=1:size(spop(i).pop,1)
            popold=spop(i).pop(j,:);
            newpop1=spop(i).pop;
            newval1=spop(i).val;
            bm=spop(i).species;
            ui(j,1:D)=DE(popold,newpop1,bm,st,F,CR,D,size(newpop1,1),XRmin,XRmax);
            tempval(j)=NES_func(ui(j,:),fun_num);
            FES=FES + 1;
           checkdis=sum((ones(size(spop(i).pop,1),1)*ui(j,:)-spop(i).pop).^2,2);%���㵱ǰ��Ⱥ���¸����ŷʽ����
           [minval,minindex]=min(checkdis);
            if tempval(j)<spop(i).val(minindex)
               spop(i).val(minindex)=tempval(j);
               spop(i).pop(minindex,:)=ui(j,:);
            end      
         end
     end
pop=[];
val=[];
     for i=1:size(spop,2)
        pop=[pop;spop(i).pop];
        val=[val,spop(i).val];
     end
       sw=sw+1;
        if mod(sw,10)==0
        solution1=[];
    root_index=1;
    for s=1:root_num
        [minval,minindex]=min(sqrt(sum((ones(NP,1)*root(s,:)-pop).^2,2)));
        if D<=5
            if val(minindex)<1e-6&&minval<1e-1
                solution1(root_index,:)=[s,pop(minindex,:)];
                root_index=root_index+1;
            end
        else
            if val(minindex)<1e-4&&minval<1e-1
                solution1(root_index,:)=[s,pop(minindex,:)];
                root_index=root_index+1;
            end
        end
    end
     PR1=size(solution1,1)/root_num;%calculate the peak ratio  
     MPR1=[MPR1,PR1];    
 end
end
archive=pop;
archive_val=val;
final_pop=[archive];
final_val=[archive_val];
%  final_pop=[pop;archive];
%  final_val=[val,archive_val];
solution=[];
root_index=1;
for s=1:root_num
    if size(final_pop,1)>0
    [minval,minindex]=min(sqrt(sum((ones(size(final_pop,1),1)*root(s,:)-final_pop).^2,2)));
    if final_val(minindex)<min_valthresold&&minval<1e-1
        solution(root_index,:)=[s,final_pop(minindex,:)];
        root_index=root_index+1;
    end
    end
end
        xxx=[1:size(MPR1,2)];
        xx=linspace(1,size(MPR1,2));
        yy=spline(xxx,MPR1,xx);
        plot(xxx,MPR1,'b*-');
end

