function [solution]=self_csde(fun_num,root,root_num,pop,D,NP,Max_FES,XRmin,XRmax)
warning off;
global xl xu
%CR0=0.1;
CR0=0.9;
MPR1=[];
sw=0;
% Set the lower and upper bounds for function
  xl=XRmin;
   xu=XRmax;
if D<=5
    min_valthresold=1e-6;
    thresold=0.001;
else
    min_valthresold=1e-4;
    thresold=0.01;
end

 
 % OptFit=zeros(numOpt,1);
 % OptFit=eobj(optima,func_no);
% Generate initial population
%   for i=1:popSize
%      pop(i,:)=xl+(xu-xl).*rand(1,D);
%   end
% for i=1:NP
%     val(i)=NES_func(pop(i,:),fun_num);
% end
% val       = zeros(1,popSize);     % create and reset the "cost array"
DE_gbest  = zeros(1,D);           % best population member ever
nfeval    = 0;                    % number of function evaluations

%------Evaluate the best member after initialization----------------------

ibest   = 1;                      % start with first population member
val(1)=-NES_func(pop(ibest,:),fun_num);
DE_gbestval = val(1);                 % best objective function value so far
nfeval  = nfeval + 1;
for i=2:NP                       % check the remaining members

    val(i)=-NES_func(pop(i,:),fun_num);
    
    nfeval  = nfeval + 1;
    if (val(i) > DE_gbestval)           % if member is better
        ibest   = i;                 % save its location
        DE_gbestval = val(i);
    end   
end
DE_gbest = pop(ibest,:);         % best member of current iteration
bestvalit = DE_gbestval;              % best value of current iteration


%------popold is the population which has to compete. It is--------
%------static through one iteration. pop is the newly--------------
%------emerging population.----------------------------------------

%======================================== The main procedure of Self_CSDE================================================
%iter = 0;
while nfeval < Max_FES
    
    %===============================cluetring=================================     
     
     spop=cluster_self_csde(pop, val, NP);
 
    %======================Implement DE operators to generate the offspring==================
    
    [nfeval, pop, val]=DE_self_csde(spop, D, fun_num, nfeval, CR0);

   %=========================================================================================
%        iter = iter + 1;
%        traceInfo(iter,1)=nfeval;
%        traceInfo(iter,2)=max(val);      % recording the best fitness
%        traceInfo(iter,3)=mean(val);     % recording the Avg fitness
%        traceInfo(iter,4)=std(val);      % recording the StdDev of fitness
% 
%        peaks=-10000*ones(numOpt,1);
%        distance=10000*ones(numOpt,1);
%        peakslocation=10000*ones(numOpt,D);  
%        
%        % How many global optima have been found?
%        for u=1:numOpt
%            checkdis=sum((ones(size(pop,1),1)*optima(u,:)-pop).^2,2);
%            [minval,minindex]=min(checkdis);
%            if abs(val(minindex)-OptFit(u))<=tolerance & minval<=t_dis
%                if val(minindex)>peaks(u)
%                    peaks(u)=val(minindex);
%                    peakslocation(u,:)=pop(minindex,:);
%                end
%            end
%        end
%        foundIn=0;
%        for u=1:numOpt
%            if peaks(u)>-10000
%                foundIn=foundIn+1;
%            end
%        end
       
%        traceInfo(iter,5)=foundIn/numOpt;  
%        traceInfo(iter,6)=0;    
%        traceInfo(iter,7:numOpt+6)=peaks;  
 
%       if traceInfo(iter,5)==1 
%           break;
%       end
 sw=sw+1;
        if mod(sw,10)==0
        solution1=[];
    root_index=1;
    for s=1:root_num
        [minval,minindex]=min(sqrt(sum((ones(NP,1)*root(s,:)-pop).^2,2)));
        if D<=5
            if val(minindex)<1e-6&&minval<1e-1
                solution1(root_index,:)=[s,pop(minindex,:)];
                root_index=root_index+1;
            end
        else
            if val(minindex)<1e-4&&minval<1e-1
                solution1(root_index,:)=[s,pop(minindex,:)];
                root_index=root_index+1;
            end
        end
    end
     PR1=size(solution1,1)/root_num;%calculate the peak ratio  
     MPR1=[MPR1,PR1];    
 end
end %---end while ((iter < Max_Gen) ...
final_pop=[pop];
final_val=[val];
solution=[];
root_index=1;
for s=1:root_num
    if size(final_pop,1)>0
        [minval,minindex]=min(sqrt(sum((ones(size(final_pop,1),1)*root(s,:)-final_pop).^2,2)));
        if abs(final_val(minindex))<min_valthresold&&minval<=1e-1
            solution(root_index,:)=[s,final_pop(minindex,:)];
            root_index=root_index+1;
        end
    end
end
%  xxx=[1:size(MPR1,2)];
%         xx=linspace(1,size(MPR1,2));
%         yy=spline(xxx,MPR1,xx);
%         plot(xx,yy,'b',xxx,MPR1,'*');
%         hold on
end
% finalpeak=[peakslocation,peaks];
% PAcc=0;
% DAcc=0;
% for u=1:numOpt
%     checkdis=sqrt(sum((ones(size(pop,1),1)*optima(u,:)-pop).^2,2));  
%     [minval,minindex]=min(checkdis);  
%     PAcc=PAcc+abs(eobj(pop(minindex,:),func_no)-OptFit(u));
% %     DAcc=DAcc+minval;
%     DAcc=DAcc+norm(pop(minindex,:)-optima(u,:));
% end
% PA=PAcc/numOpt;
% DA=DAcc/numOpt;
% 
% finalpeak=[peakslocation,peaks];
% endPop=[pop val'];
% dlmwrite(strcat('self_csde_info',char(num2str(func_no)),'_',char(num2str(runs)),'.txt'),traceInfo,'newline','pc');
% dlmwrite(strcat('self_csde_result',char(num2str(func_no)),'_',char(num2str(runs)),'.txt'),endPop,'newline','pc');
% dlmwrite(strcat('self_csde_peak',char(num2str(func_no)),'_',char(num2str(runs)),'.txt'),finalpeak,'newline','pc');
%clear all
