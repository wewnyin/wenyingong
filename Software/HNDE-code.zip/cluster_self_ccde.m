function [subpop,subv,r1,r2,r3]=cluster_self_ccde(NP,D,pop,val)
global xl xu
referPoint = xl+(xu-xl).*rand(1,D);

if NP<=100
    NS=NP/(NP/5);
else
    NS=NP/(NP/10);
end


r1=zeros(1,NP)';
r2=zeros(1,NP)';
r3=zeros(1,NP)';
p=pop;
va=val;
subpop=[];
subv=[];
Fn1=zeros(1,NP);
for k=1:NP/NS
    [nearestVal, nearestIndex] = min(sum((ones(size(p, 1), 1) * referPoint - p).^2, 2));
    [neighborVal, neighborIndex] = sort(sum((ones(size(p, 1), 1) * p(nearestIndex, :) - p).^2, 2));
    subpop =[subpop; p(neighborIndex(1 : NS), :)];
    subv=[subv  va(neighborIndex(1 : NS))];
    [su1,su2,su3] =getindex(NS);
    vt=va(neighborIndex(1 : NS));
    Fbest=max(vt);
    Fworst=min(vt);
    if Fworst~=Fbest
        Fn11=(vt(su2)-vt(su3))/(Fworst-Fbest);
    else
        Fn11=0.9*ones(NS,1);
    end
    r1((k-1)*NS+1:k*NS)=(k-1)*NS+su1;
    r2((k-1)*NS+1:k*NS)=(k-1)*NS+su2;
    r3((k-1)*NS+1:k*NS)=(k-1)*NS+su3;
    Fn1((k-1)*NS+1:k*NS)=Fn11;
    p(neighborIndex(1 : NS), :) = [];
    va(neighborIndex(1 : NS))=[];
end
