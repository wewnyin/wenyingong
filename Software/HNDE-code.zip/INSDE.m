function [solution]=PSDE(fun_num,root,root_num,pop,D,NP,Max_FES,XRmin,XRmax)
warning off
F=0.5;
CR=0.9;
FES=0;
archive=[];
archive_val=[];
if D<=5
    min_valthresold=1e-6;
    thresold=0.001;
else
    min_valthresold=1e-4;
    thresold=0.01;
end
for i=1:NP
    val(i)=NES_func(pop(i,:),fun_num);
    FES=FES+1;
end
UI=[];
UI_VAL=[];
%iw=0;
while FES<Max_FES
        [sortval,sortindex]=sort(val,'ascend');
        popsort=pop(sortindex,:);%������Ӧֵ��С��������
        valsort=val(sortindex);
        clear spop;
        for i=1:(size(popsort,1)/5)
            [temp k]=sort(sqrt(sum((ones(size(popsort,1),1)*popsort(1,:)-popsort).^2,2)));
            spop(i).species=popsort(1,:);%��ǰ��Ⱥ����õ�
            spop(i).speciesval=valsort(1); %��ǰ��õ���Ӧֵ
            checker=ones(size(popsort,1),1);
            checker(k(1:5),:)=0;
            spop(i).pop=popsort(checker==0,:);%�ҳ�����õ�m=5����������µ���ȺͶ��DE��
            spop(i).val=valsort(checker==0);%��¼������������Ӧֵ
            popsort=popsort(checker==1,:);%�����ʣ��ģ�Ȼ����ʣ���������
            valsort=valsort(checker==1);
        end
        for i=1:size(spop,2)
            [temp1 index]=sort(sqrt(sum((ones(size(spop(i).pop,1),1)*spop(i).species-spop(i).pop).^2,2)),'descend');
            for j=1:size(spop(i).pop,1)
                popold=spop(i).pop(j,:);
                newpop1=spop(i).pop;
                bm=spop(i).species;
                st=1;
                ui(j,1:D)=DE(popold,newpop1,bm,st,F,CR,D,size(newpop1,1),XRmin,XRmax);
                ui_val(j)=NES_func(ui(j,:),fun_num);
                FES=FES + 1;
                checkdis=sqrt(sum((ones(size(spop(i).pop,1),1)*ui(j,:)-spop(i).pop).^2,2));%���㵱ǰ��Ⱥ���¸����ŷʽ����
                [minval,minindex]=min(checkdis);
                if ui_val(j)<spop(i).val(minindex)
                    spop(i).val(minindex)=ui_val(j);
                    spop(i).pop(minindex,:)=ui(j,:);
                else
%                     distance=sqrt(sum((ui(j,:)-bm).^2,2));
%                     [temp4,k4]=sort(spop(i).val,'descend');
%                     if ui_val(j)<min_valthresold&&minval>thresold
%                         [archive,archive_val]=Repulsion_archive(ui(j,:),ui_val(j),archive,archive_val,D,NP,thresold);
%                     else
%                     if (distance>temp1(1))||ui_val(j)<temp4(1)
%                             [UI,UI_VAL]=Repulsion_archive(ui(j,:),ui_val(j),UI,UI_VAL,D,NP,0.1);
%                         end
%                     end
                end
            end
        end
        pop=[];
        val=[];
        for i=1:size(spop,2)
            pop=[pop;spop(i).pop];
            val=[val,spop(i).val];
        end
%     X=[];
%     for i=1:size(UI,1)
%         [minval,minindex]=min(sqrt(sum((ones(size(pop,1),1)*UI(i,:)-pop).^2,2)));
%         if val(minindex)>=UI_VAL(i)
%             pop(minindex,:)=UI(i,:);
%             val(minindex)=UI_VAL(i);
%             X=[X,i];
%         end
%     end
%     checker=ones(size(UI,1),1);
%     checker(X(1:size(X,2)),:)=0;
%     UI=UI(checker==1,:);%�ҳ��Ѿ�����ԭʼ��Ⱥ�ĸ���
%     UI_VAL=UI_VAL(checker==1);
    for j=1:size(pop,1)
        if val(j)<min_valthresold
            [archive,archive_val]=Repulsion_archive(pop(j,:),val(j),archive,archive_val,D,NP,thresold);
            a=size(UI,1);
                pop(j,:)=XRmin+(XRmax-XRmin).*rand(1,D);
                val(j)=NES_func(pop(j,:),fun_num);
                FES=FES+1;
        end
    end
end
final_pop=[archive];
final_val=[archive_val];
solution=[];
root_index=1;
for s=1:root_num
    if size(final_pop,1)>0
        [minval,minindex]=min(sqrt(sum((ones(size(final_pop,1),1)*root(s,:)-final_pop).^2,2)));
        if final_val(minindex)<min_valthresold&&minval<=1e-1
            solution(root_index,:)=[s,final_pop(minindex,:)];
            root_index=root_index+1;
        end
    end
end
end
