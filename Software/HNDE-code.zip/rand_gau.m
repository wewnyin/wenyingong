function a=rand_gau(mu, thegma)
	if  phase == 0 
		while 1
			U1 = rand /32767;
		    U2 = rand/32767;
			V1 = 2 * U1 - 1;
			V2 = 2 * U2 - 1;
			S = V1 * V1 + V2 * V2;
            if S<1&&S~=0 break;end
        end
		X = V1 * sqrt(-2 * log(S) / S);
  else
		X = V2 * sqrt(-2 * log(S) / S);
        end
	phase = 1 - phase;
	a=mu+X*thegma;
end