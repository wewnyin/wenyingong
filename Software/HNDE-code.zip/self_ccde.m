

function solution=self_ccde(fun_num,root,root_num,pop,D,NP,Max_FES,XRmin,XRmax);
   warning off;
sw=0;MPR1=[];
   global xl xu 
%    F=0.9;
%    CRm=0.5;
F=0.5;
CRm=0.9;
  xl=XRmin;
   xu=XRmax;
   popSize=NP;
if D<=5
    min_valthresold=1e-6;
    thresold=0.001;
else
    min_valthresold=1e-4;
    thresold=0.01;
end
func_no=fun_num
% Generate initial population
  for i=1:popSize
     pop(i,:)=xl+(xu-xl).*rand(1,D);
  end


  val        = zeros(1,popSize);      % create and reset the "cost array"
  DE_gbest   = zeros(1,D);           % best population member ever
  nfeval     = 0;                     % number of function evaluations

%===========Evaluate the best member after initialization========================

ibest   = 1;                      % start with first population member

val(1)=-NES_func(pop(ibest,:),func_no);


DE_gbestval = val(1);                 % best objective function value so far
nfeval  = nfeval + 1;
for i=2:popSize                        % check the remaining members

    val(i)=-NES_func(pop(i,:),func_no);
    
    nfeval  = nfeval + 1;
    if (val(i) > DE_gbestval)           % if member is better
        ibest   = i;                 % save its location
        DE_gbestval = val(i);
    end   
end
DE_gbest = pop(ibest,:);         % best member of current iteration
bestvalit = DE_gbestval;              % best value of current iteration


%------popold is the population which has to compete. It is--------
%------static through one iteration. pop is the newly--------------
%------emerging population.----------------------------------------

%======================================== The main procedure of Self_CCDE================================================
iter = 0;
while nfeval < Max_FES
                
                if nfeval > NP && sum(goodCR)>0  % If goodF and goodCR are empty, pause the update
                     c=0.1;
                     CRm =(1 - c) * CRm + c *mean(goodCR);
                end
               
               [~, CR] = randFCRg(NP, CRm, 0.10, CRm, 0.1); 
     
              %===============================cluetring================================= 
              
              [subpop,subv,r1,r2,r3]=cluster_self_ccde(NP,D,pop,val);

              %=========================================================================================
              
              pop=subpop;
              val=subv;
  
              %======================Implement DE operators to generate the offspring==================
              
              [pop, val, tempval, CR1, valParents, nfeval, Dis, DE_gbestval]=DE_self_ccde(pop, val, F, r1, r2, r3, NP, D, CR, nfeval, func_no, DE_gbestval);
%          
              %=========================================================================================
              
              
              % Update goodCR
              [valParents, I] = min([val', tempval], [], 2);
              goodCR = CR1(I == 2);
              
%               iter = iter + 1;
%               
%               traceInfo(iter,1)=nfeval;
%               traceInfo(iter,2)=max(val);      % recording the best fitness
%               traceInfo(iter,3)=mean(val);     % recording the Avg fitness
%               traceInfo(iter,4)=std(val);      % recording the StdDev of fitness
%               
%               peaks=-10000*ones(numOpt,1);
%               distance=10000*ones(numOpt,1);
%               peakslocation=10000*ones(numOpt,D);
%               
%               % How many global optima have been found?
%               for u=1:numOpt
%                   checkdis=sum((ones(size(pop,1),1)*optima(u,:)-pop).^2,2);
%                   
%                   [minval,minindex]=min(checkdis);
%                   if abs(val(minindex)-OptFit(u))<=tolerance & minval<=t_dis^2
%                       if val(minindex)>peaks(u)
%                           peaks(u)=val(minindex);
%                           peakslocation(u,:)=pop(minindex,:);
%                       end
%                   end
%               end
%               foundIn=0;
%               for u=1:numOpt
%                   if peaks(u)>-10000
%                       foundIn=foundIn+1;
%                   end
%               end
%               
%               traceInfo(iter,5)=foundIn/numOpt;
%               traceInfo(iter,6)=0;
%               traceInfo(iter,7:numOpt+6)=peaks;
%               Diss(iter,:)=Dis;
    
%nfeval
  sw=sw+1;
        if mod(sw,10)==0
        solution1=[];
    root_index=1;
    for s=1:root_num
        [minval,minindex]=min(sqrt(sum((ones(NP,1)*root(s,:)-pop).^2,2)));
        if D<=5
            if val(minindex)<1e-6&&minval<1e-1
                solution1(root_index,:)=[s,pop(minindex,:)];
                root_index=root_index+1;
            end
        else
            if val(minindex)<1e-4&&minval<1e-1
                solution1(root_index,:)=[s,pop(minindex,:)];
                root_index=root_index+1;
            end
        end
    end
     PR1=size(solution1,1)/root_num;%calculate the peak ratio  
     MPR1=[MPR1,PR1];    
 end
end %---end while ((iter < Max_Gen) ...
archive=[];
archiveval=[];
for j=1:size(pop,1)
    if abs(val(j))<min_valthresold
        archive= [archive;pop(j,:)];
        archiveval= [archiveval,val(j)];
    end
end

final_pop=[archive];
final_val=[archiveval];
solution=[];
root_index=1;
for s=1:root_num
    if size(final_pop,1)>0
        [minval,minindex]=min(sqrt(sum((ones(size(final_pop,1),1)*root(s,:)-final_pop).^2,2)));
        if  minval<=1e-1
            solution(root_index,:)=[s,final_pop(minindex,:)];
            root_index=root_index+1;
        end
    end
end
%  xxx=[1:size(MPR1,2)];
%         xx=linspace(1,size(MPR1,2));
%         yy=spline(xxx,MPR1,xx);
%         plot(xx,yy,'r',xxx,MPR1,'o');
%         hold on
end
