function [F,CR] = randFCRg(NP, CRm, CRsigma, Fm,  Fsigma)

% this function generate CR according to a normal distribution with mean "CRm" and sigma "CRsigma"
%           If CR > 1, set CR = 1. If CR < 0, set CR = 0.
% this function generate F  according to a cauchy distribution with location parameter "Fm" and scale parameter "Fsigma"
%           If F > 1, set F = 1. If F <= 0, regenrate F.
%
% Version: 1.1   Date: 11/20/2007
% Written by Jingqiao Zhang (jingqiao@gmail.com)

%% generate CR
% CR = CRm + CRsigma * randn(NP, 1);
% CR = min(1, max(0, CR));                % truncated to [0 1]

% CR =  max(0, CR);    
% pos=(CR>0.9);
% CR(pos)=rand(sum(pos),1);

CR = randCauchy(NP, 1, CRm, CRsigma);
% CR =  min(1, CR);                % truncated to [0 1]
% CR = min(1, max(0, CR));                % truncated to [0 1]
% % % CR = min(0.9, CR);                          % truncation
% pos=(CR>1);
% CR(pos)=zeros(sum(pos),1);


pos = find(CR <0|CR >1);
while ~ isempty(pos)
    CR(pos) = randCauchy(length(pos), 1, CRm, CRsigma);
%      CR(pos) = CRm + CRsigma * randn(length(pos), 1);
%     CR = min(1, CR);                     % truncation
    pos = find(CR <0|CR >1);
end




%% generate F
F = Fm + Fsigma * randn(NP, 1);
% F = min(1, max(0, F));                % truncated to [0 1]
% pos=(F>0.8);
% F(pos)=rand(sum(pos),1);

% F = randCauchy(NP, 1, Fm, Fsigma);
% F = min(1, max(0, F));                % truncated to [0 1]
% F = max(0, F);                          % truncation
% pos=(F>0.9);
% F(pos)=rand(sum(pos),1);

% we don't want F = 0. So, if F<=0, we regenerate F (instead of trucating it to 0)
pos = find(F >1|F<0);
while ~ isempty(pos)
%     F(pos) = randCauchy(length(pos), 1, Fm, Fsigma);
     F(pos) = Fm + Fsigma * randn(length(pos), 1);
%     F = max(0, F);                      % truncation
    pos = find(F >1|F<0);
end

% Cauchy distribution: cauchypdf = @(x, mu, delta) 1/pi*delta./((x-mu).^2+delta^2)
function result = randCauchy(m, n, mu, delta)

% http://en.wikipedia.org/wiki/Cauchy_distribution
result = mu + delta * tan(pi * (rand(m, n) - 0.5));
