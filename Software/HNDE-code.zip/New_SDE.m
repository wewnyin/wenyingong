function solution1=New_SDE(fun_num,root,root_num,pop,D,NP,MaxFEs,XRmin,XRmax)
warning off
tic
solution1=[];
solution2=[];
solution3=[];
F=0.5;%ԭʼ����F=0.9,CR=0.1�ñ�Ĳ������ܲ�
CR=0.9;
FES=0;
if D<=5
    min_valthresold=1e-6;
    thresold=0.001;
else
    min_valthresold=1e-4;
    thresold=0.01;
end
UI=[];
UI_VAL=[];
archive=[];
archiveval=[];
bestval=-Inf;
thresold=[0.01*ones(1,4) 0.5  0.5 0.2 0.5 0.2 0.01*ones(1,100)];
UI_archive_size=NP;%���
root_archive_size=5*NP;
dis=0.01;
min_val=1e-7;
root_val=1e-4;
for i=1:size(pop,1)
    val(i)=NES_func(pop(i,:),fun_num);
end
FES=FES+NP;
num=0;
iw=1;
W=0;
p1=0.5;
ct1=1;
ct2=1;
maxT=50;
while FES<MaxFEs
    p1=ct1/(ct1+ct2);
    ct1=1;
    ct2=1;
    [sortval,sortindex]=sort(val,'ascend');
    popsort=pop(sortindex,:);%������Ӧֵ��С��������
    valsort=val(sortindex);
    clear spop;
    for i=1:(size(popsort,1)/5)
        [temp k]=sort(sqrt(sum((ones(size(popsort,1),1)*popsort(1,:)-popsort).^2,2)));
        spop(i).species=popsort(1,:);%��ǰ��Ⱥ����õ�
        spop(i).speciesval=valsort(1); %��ǰ��õ���Ӧֵ
        checker=ones(size(popsort,1),1);
        checker(k(1:5),:)=0;
        spop(i).pop=popsort(checker==0,:);%�ҳ�����õ�m=5����������µ���ȺͶ��DE��
        spop(i).val=valsort(checker==0);%��¼������������Ӧֵ
        popsort=popsort(checker==1,:);%�����ʣ��ģ�Ȼ����ʣ���������
        valsort=valsort(checker==1);
    end
    for i=1:size(spop,2)
        [temp1 index]=sort(sqrt(sum((ones(size(spop(i).pop,1),1)*spop(i).species-spop(i).pop).^2,2)),'descend');
        for j=1:size(spop(i).pop,1)
            popold=spop(i).pop(j,:);
            newpop1=spop(i).pop;
            bm=spop(i).species;
            if rand>p1
            st=1;
            else 
            st=2;
            end
            ui(j,1:D)=DE(popold,newpop1,bm,st,F,CR,D,size(newpop1,1),XRmin,XRmax);
            ui_val(j)=NES_func(ui(j,:),fun_num);
            FES=FES + 1;
            checkdis=sqrt(sum((ones(size(spop(i).pop,1),1)*ui(j,:)-spop(i).pop).^2,2));%���㵱ǰ��Ⱥ���¸����ŷʽ����
            [minval,minindex]=min(checkdis);
            if ui_val(j)<spop(i).val(minindex)
                spop(i).val(minindex)=ui_val(j);
                spop(i).pop(minindex,:)=ui(j,:);
                if st==1
                    ct1=ct1+1;
                else
                     ct2=ct2+1;
                end
            else
                [UI,UI_VAL]=Repulsion_archive(ui(j,:),ui_val(j),UI,UI_VAL,D,NP,0.01);
            end
        end
    end
    pop=popsort;
    val=valsort;
    for i=1:size(spop,2)
        pop=[pop;spop(i).pop];
        val=[val,spop(i).val];
    end
     Q=ones(size(pop,1),1);
        for j=1:size(pop,1)
        if val(j)<min_valthresold
            [archive,archiveval]=Repulsion_archive(pop(j,:),val(j),archive,archiveval,D,NP,thresold);
              pop(j,:)=XRmin+(XRmax-XRmin).*rand(1,D);
            val(j)=NES_func(pop(j,:),fun_num);
            FES=FES+1;
         % Q(j,:)=0;
        end
        end
     pop=pop(Q==1,:);
        val=val(Q==1);
   
    if size(pop,1)<=NP
        [sortval,sortindex]=sort(UI_VAL,'ascend');
        UI=UI(sortindex,:);%������Ӧֵ��С��������
        UI_VAL=UI_VAL(sortindex);
        pop=[pop;UI];
        val=[val,UI_VAL];
        UI=[];
        UI_VAL=[];
    end
    TEMP=[pop;archive];
    TEMPVAL=[val,archiveval];
    TEMP2=[];
    TEMPVAL2=[];
    for i=1:size(TEMP,1)
        if TEMPVAL(i)<min_valthresold
            TEMP2=[TEMP2;TEMP(i,:)];
            TEMPVAL2=[TEMPVAL2,TEMPVAL(i)];
        end
    end
    solution1=[];
    solution_index=1;
    for s=1:root_num
        if size(TEMP2,1)~=0
            [minval,minindex]=min(sqrt(sum((ones(size(TEMP2,1),1)*root(s,:)-TEMP2).^2,2)));
            if minval<thresold(fun_num)
                solution1(solution_index,:)=[s,TEMP2(minindex,:)];
                solution_index=solution_index+1;
            else
                [mind,minindex]=min(sqrt(sum((ones(size(TEMP,1),1)*root(s,:)-TEMP).^2,2)));
                fprintf('F%d: not found solution %d the minium distance %d the val difference%f', fun_num, s, mind, abs(TEMPVAL(minindex)));
                fprintf('\n');
            end
        else
            [mind,minindex]=min(sqrt(sum((ones(size(TEMP,1),1)*root(s,:)-TEMP).^2,2)));
            fprintf('F%d: not found solution %d the minium distance %d the val difference%f', fun_num, s, mind, abs(TEMPVAL(minindex)));
            fprintf('\n');
        end
    end
    fprintf('FES=%d,MaxFEs=%d,NP=%d,size of population=%d,the number of solution%d',FES,MaxFEs,NP,size(pop,1),size(solution1,1));
    fprintf('\n');
end
final_pop=[pop;archive];
final_val=[val,archiveval];
archive1=[];
archiveval1=[];
for i=1:size(final_pop,1)
    if final_val(i)<=min_valthresold
        archive1=[archive1;final_pop(i,:)];
        archiveval1=[archiveval1,final_val(i)];
    end
end
solution_index1=1;
for s=1:root_num
    if size(archive1,1)>0
        [minval,minindex]=min(sqrt(sum((ones(size(archive1,1),1)*root(s,:)-archive1).^2,2)));
        if minval< 0.1
            solution1(solution_index1,:)=[s,archive1(minindex,:)];
            solution_index1=solution_index1+1;
        end
    end
end
% figure( Iter_final);
% plot(solution(:,1),solution(:,2),'*');
% hold on
% plot(solution1(:,2),solution1(:,3),'p');
% plot(pop(:,1),pop(:,2),'>');
% legend('�м���Ⱥ','��','�ҵ��ĸ�','�����Ⱥ�ֲ�');
toc
end