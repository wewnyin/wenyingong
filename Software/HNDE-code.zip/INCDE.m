function [solution]=INCDE(fun_num,root,root_num,pop,D,NP,Max_FES,XRmin,XRmax)
warning off
F=0.5;
CR=0.9;
FES=0;
archive=[];
archive_val=[];
if D<=5
    min_valthresold=1e-6;
    thresold=0.001;
else
    min_valthresold=1e-4;
    thresold=0.01;
end
for i=1:NP
    val(i)=NES_func(pop(i,:),fun_num);
    FES=FES+1;
end
UI=[];
UI_VAL=[];
while FES<Max_FES
        S=[pop;UI];
        VAL=[val,UI_VAL];
        subpop=[];
        for j=1:size(pop,1)
            num=5+5*((Max_FES-FES)/Max_FES);
            st=2;
            [temp k]=sort(sqrt(sum((ones(size(S,1),1)*pop(j,:)-S).^2,2)));
            subpop(j).pop=S(k(1:num),:);
            subpop(j).val=VAL(k(1:num));
            ui(j,1:D)=DE( pop(j,:),subpop(j).pop, pop(j,:),st,F,CR,D,size(subpop(j).pop,1),XRmin,XRmax);
        end
        for i=1:NP
            ui_val(i)=NES_func(ui(i,:),fun_num);
            FES=FES+1;
        end
        for j=1:NP
            [temp index]=min(sqrt(sum((ones(NP,1)*ui(j,:)-pop).^2,2)));
            if val(index)>ui_val(j)
                pop(index,:)=ui(j,:);
                val(index)=ui_val(j);
            else
                [temp4,k4]=sort(subpop(j).val,'descend');
                    if ui_val(j)<temp4(1)
                        [UI,UI_VAL]=Repulsion_archive(ui(j,:),ui_val(j),UI,UI_VAL,D,NP,0.1);
                    end
            end
        end
    for j=1:size(pop,1)
        if val(j)<min_valthresold
            [archive,archive_val]=Repulsion_archive(pop(j,:),val(j),archive,archive_val,D,NP,thresold);
                pop(j,:)=XRmin+(XRmax-XRmin).*rand(1,D);
                val(j)=NES_func(pop(j,:),fun_num);
                FES=FES+1;
        end
    end
end
final_pop=[archive];
final_val=[archive_val];
solution=[];
root_index=1;
for s=1:root_num
    if size(final_pop,1)>0
        [minval,minindex]=min(sqrt(sum((ones(size(final_pop,1),1)*root(s,:)-final_pop).^2,2)));
        if final_val(minindex)<min_valthresold&&minval<=1e-1
            solution(root_index,:)=[s,final_pop(minindex,:)];
            root_index=root_index+1;
        end
    end
end
end
