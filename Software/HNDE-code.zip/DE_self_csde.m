function [nfeval, pop, val]=DE_self_csde(spop, D, func_no, nfeval, CR0)
global xl xu
for i=1:size(spop,2)
    ui=zeros(size(spop(i).pop,1),D);
    vi=zeros(size(spop(i).pop,1),D);
    
    [r1,r2,r3] =getindex(size(spop(i).pop,1));
    
    for j=1:size(spop(i).pop,1)
        popold=spop(i).pop(j,:);
        newpop1=spop(i).pop;
        newval1=spop(i).val;
        bm=spop(i).species;
        Fbest=max(newval1);
        Fworst=min(newval1);
        if Fworst~=Fbest
            Fn1=(newval1(r2(j))-newval1(r3(j)))/(Fbest-Fworst);
        else
            Fn1=0.9*ones(1,1);
        end
        % Mutation
        vi(j,:)=newpop1(r1(j),:)+Fn1*(newpop1(r2(j),:)-newpop1(r3(j),:));
        % Binomial crossover
        j_rand = floor(rand * D) + 1;
        t = rand(1, D) < CR0;
        t(1, j_rand) = 1;
        t_ = 1 - t;
        ui(j, :) = t .* vi(j, :) + t_ .* popold;
        % Handle the elements of the mutant vector which violate the boundary
        if rand>0.5
            ui(j, :)=(ui(j, :)<xl).*xl+(ui(j, :)>=xl).*ui(j, :);
            ui(j, :)=(ui(j, :)>xu).*xu+(ui(j, :)<=xu).*ui(j, :);
        else
            ui(j, :)=(ui(j, :)<xl).*(xl+rand(1,D).*(xu-xl))+(ui(j, :)>=xl).*ui(j, :);
            ui(j, :)=(ui(j, :)>xu).*(xl+rand(1,D).*(xu-xl))+(ui(j, :)<=xu).*ui(j, :);
        end
        
        tempval(j,1)=-NES_func(ui(j,:),func_no);
        nfeval  = nfeval + 1;
        %Select which vectors are allowed to enter the new population
        checkdis=sum((ones(size(spop(i).pop,1),1)*ui(j,:)-spop(i).pop).^2,2);
        [~,minindex]=min(checkdis);
        if tempval(j,1)>spop(i).val(minindex)
            spop(i).val(minindex)=tempval(j,1);
            spop(i).pop(minindex,:)=ui(j,:);
        end
        
    end
    
end
pop=[];
val=[];
for i=1:size(spop,2)
    pop=[pop;spop(i).pop];
    val=[val,spop(i).val'];
end

