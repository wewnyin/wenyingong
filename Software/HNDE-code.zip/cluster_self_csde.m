function spop=cluster_self_csde(pop, val, NP)
    [~,sortindex]=sort(val,'descend');
    popsort=pop(sortindex,:);
    valsort=val(sortindex);
    clear spop;
   
    if size(popsort,1)>NP
        popsort=popsort(1:NP,:);
        valsort=valsort(1:NP);
    end

    if NP<=200
       NS=10;
   %  NS=5;
    else
        NS=25;
    end

    for i=1:(NP/NS)
       [temp k]=sort(sqrt(sum((ones(size(popsort,1),1)*popsort(1,:)-popsort).^2,2)));
        spop(i).species=popsort(1,:);
        spop(i).speciesval=valsort(1);        
        checker=ones(size(popsort,1),1);
        checker(k(1:NS),:)=0;
        spop(i).pop=popsort(checker==0,:);
        spop(i).val=valsort(checker==0)';
        popsort=popsort(checker==1,:);
        valsort=valsort(checker==1);
    end