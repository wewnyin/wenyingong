function [ Solution ,Value ,NFEs ] = EJADE( ObjectionFunc ,type ,Max_NFE )
%JADE �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

%%%%%%%%%%%%%%%%%  ����CR�����NP��̬����
    addpath('./CauchyFunction');
%     [LB,UB,kesi,bestValue,Max_NFE,VTR,Gm] = Parameters(type,D);
    [LB,UB,D] = Parameter(type);
    
    %% ��ʼ������
    NP =50; %����30ά��NP����Ϊ100
%     Gm = Max_NFE/NP;  
    NFE = 0;
    % JADE����
    mu_CR = 0.5;
    mu_F = 0.5;
    c = 0.1;
    p = 0.05;
    A = [];
    
    NPmin = 4;
    NPmax = 50;
    
    
    %%%%%
    
    %Max_NFE = NP*Gm;
     %% ��ʼ����Ⱥ
     X = zeros(NP,D);
     for i=1:NP
         for j=1:D
             X(i,j) = LB(j)+rand*(UB(j)-LB(j));
         end
     end
     
     %% �����ʼ����ÿ�������Ŀ�꺯��ֵ
     OFV = zeros(1,NP);
     
     for i=1:NP
         OFV(i) = ObjectionFunc(type,X(i,:));
     end   
     NFE = NFE+NP;
     
     [sorted,indices] = sort(OFV);
     
      Solution = X(indices(1),:);
      Value = sorted(1);
     
     %for g=1:Gm
     while NFE<Max_NFE
        
        [mm,nn] = size(A);
        Num_A = mm+1; 
        Sf = [];
        Scr = [];
        count = 1;
  
        CR = [];
        F = [];
        for i=1:NP
            % ����CR(i)
            CR(i)=normrnd(mu_CR,0.1);
            if CR(i)<0
                CR(i) = 0;
            end
            if CR(i)>1
                CR(i) = 1;
            end
            % ����F(i)
            F(i)=cauchyrnd(mu_F,0.1);
            while F(i)<=0
                F(i)=cauchyrnd(mu_F,0.1);
            end
            
            if F(i)>1
                F(i) = 1;
            end
        end
        
        % CR����
        [CR,~] = sort(CR);
    
        for i=1:NP
            % ѡ��Xpbest
            [sorted,indices] = sort(OFV);
            X = X(indices,:);
            OFV = sorted;
            pid = ceil(NP*p);
            pbestid = randi(pid);
            Xpbest = X(pbestid,:); 
            
            [Xr1,Xr2] = selectR(X,A,i);
            % ͻ��
            
            v(i,:) = X(i,:)+F(i).*(Xpbest-X(i,:))+F(i).*(Xr1-Xr2);
            
            % �߽紦��
            for j=1:D
                if v(i,j)<LB(j)
                    v(i,j) = LB(j)+rand()*(UB(j)-LB(j));
                end
                
                if v(i,j)>UB(j)
                    v(i,j) = LB(j)+rand()*(UB(j)-LB(j));
                end 
            end
            
            % ����
            jrand = randi(D);
            for j=1:D
                if j==jrand || rand()<CR(i)
                    u(i,j) = v(i,j);
                else
                    u(i,j) = X(i,j);
                end
            end
            
            % ������������ui��Ŀ�꺯��ֵ
            New_OFV(i) = ObjectionFunc(type,u(i,:));
            NFE = NFE+1;
            
            % ѡ��
            if OFV(i)<=New_OFV(i)
                X(i,:) = X(i,:);
            else
                A(Num_A,:) = X(i,:);
                X(i,:) = u(i,:);
%                 CR(i) = cr(i);
                OFV(i) = New_OFV(i);
                Sf(count) = F(i);
                Scr(count) = CR(i);
                count = count+1;
                Num_A = Num_A+1;
                
            end
        end
        
        % ����A
        A = updateA(A,NP);
        if count<=1
            mu_CR = mu_CR;
            mu_F = mu_F;
        else
            mu_CR = (1-c)*mu_CR+c*mean(Scr);
            mu_F = (1-c)*mu_F+c*(sum(Sf.^2))/(sum(Sf));
        end
        
         %%%% ��̬��Ⱥ
        New_NP =floor(NFE*(NPmin-NPmax)/(Max_NFE)+NPmax);
        if New_NP<NP
            [S,index] = sort(OFV);
            X = X(index(1:New_NP),:);
            OFV = S(index(1:New_NP));
            NP = New_NP;
         
        end

     end
     [sorted,indices] = sort(OFV);
     Solution = X(indices(1),:);
     Value = sorted(1);
     NFEs = NFE;
                
               
end

