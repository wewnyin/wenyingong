function density = DensityEstimate(PopObj,W)
% estimate the density of each individual
    
    Zmax=max(PopObj,[],1);
    Zmin=min(PopObj,[],1);
    SPopObj=(PopObj-repmat(Zmin,size(PopObj,1),1))./(repmat(Zmax,size(PopObj,1),1)-repmat(Zmin,size(PopObj,1),1));
    [~,Region] = max(1-pdist2(SPopObj,W,'cosine'),[],2);
    [value,~]=sort(Region,'ascend');
    flag=max(value);
    counter=histc(value,1:flag);
    density=counter(Region);
end