function CMME(Global)
% <algorithm> <C>

    %% Generate Uniform Reference Points
    [W,Global.N] = UniformPoint(Global.N,Global.M);

    %% Generate random population
    Population = Global.Initialization();
 
    %% Optimization
    while Global.NotTermination(Population)
        density=DensityEstimate(Population.objs,W);
        Fitness = CalFitness2(Population.objs,Population.cons);
        MatingPool = TournamentSelection(2,Global.N,Fitness,density);
        Offspring  = GA(Population(MatingPool));
        Population = EnvironmentalSelection([Population,Offspring],W,Global.N);
    end
end