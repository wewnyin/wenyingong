clear all

a=[1,1,1,1,1];
b=[2,2,2,2,2];
C={};D={};
C=[C,a,b];
D=[D;a;b];
E=[C,a];