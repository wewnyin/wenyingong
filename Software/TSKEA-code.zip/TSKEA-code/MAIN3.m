clc;
clear all;

DataPath='..\..\T2FJSP_instances\';
J={20,30,40,50,80,100};
M1={6,7,8,9,10};
name='Type2FJSP';line='_';txt='.txt';J_name='J';M_name='M';

[~,m]=size(J);[~,n]=size(M1);k=1;
for i=1:m
    for j=1:n
        RealPath{k}=[DataPath,name,line,num2str(J{i}),line,num2str(M1{j}),txt];
        ResultPath{k}=[J_name,num2str(J{i}),M_name,num2str(M1{j})];
        k=k+1;
    end
end

global  N H SH NM ps M TM time AP AM AF AN;

fout=fopen('parameter.txt','r');
A=fscanf(fout,'%d %d %f %f %d');
fclose(fout);
MaxNFEs=A(1);%������۴���
ps=A(2);%��Ⱥ��С
Pc=A(3);%crossover��������
Pm=A(4);%mutation��������
NFEs1=A(5);%������۴���

RP=[[0,0],[5,0],[10,0],[0,5],[0,10]];%GDָ����Ҫ�Ĳο���

for File=19:20
    [N,TM,H,NM,M,SH,time]=DataReadT2FPT(RealPath{File});
     
    respath='result\';
    tmp6='\';
    respath=[respath,ResultPath{File},tmp6];
    %����޹ر���
    clear tmp6
    a=['mkdir ' respath];%����д������ļ���
    system(a);%����Windows����������ִ��dos����
    fprintf('%s %s\r\n','Calculating ',RealPath{File});
    for round=1:20   
    CV=[];
    [p_chrom,m_chrom,f_chrom]=initialmix5();
    
    NFEs=0;
    
    fitness=cell(ps,3);
    for i=1:ps
        [fitness{i,1},fitness{i,2},fitness{i,3}]=fitDFJSP(p_chrom(i,:),m_chrom(i,:),f_chrom(i,:));
        NFEs=NFEs+1;
    end  
    
    AP=[];AM=[];AF=[];AN=[];
     % Suprisely popular Algorithm VNS
   numst=4;
   pfit = ones(1, numst)./4;
   normfit=zeros(1, numst); 
  
   i=1;
    while NFEs<NFEs1 %����������
%     for i=1:100
     fprintf('%s %s %d %s %d\r\n',RealPath{File},'round',round,'iter',i);
        i=i+1;
   
     [Par_p,Par_m,Par_f,Par_Fit]=TSelection(p_chrom,m_chrom,f_chrom,fitness);
     CP=[];CM=[];CN=[];CF=[];
     %MOIG
      for j=1:ps
        [new_p1,new_m1,new_f1,new_p2,new_m2,new_f2]= evolution(Par_p,Par_m,Par_f,j,Pc,Pm);
        [f1{1,1},f1{1,2},f1{1,3}]=fitDFJSP(new_p1,new_m1,new_f1);
        [f2{1,1},f2{1,2},f2{1,3}]=fitDFJSP(new_p2,new_m2,new_f2);
        NFEs=NFEs+2;
            
        CP=[CP;new_p1;new_p2];CM=[CM;new_m1;new_m2];CN=[CN;new_f1;new_f2];CF=[CF;f1;f2]; %��������Ⱥ
      end%J END
     
      %����ѡ��
      QP=[];QM=[];QN=[];QF=[];
      QP=[p_chrom;CP];QM=[m_chrom;CM];QN=[f_chrom;CN];QF=[fitness;CF];
      [QP,QM,QN,QF]=DeleteRpeatQF(QP,QM,QN,QF);
      [TopPSRank]=FastNDS(QF);

      %��������Ⱥ
      p_chrom=QP(TopPSRank,:);m_chrom=QM(TopPSRank,:);f_chrom=QN(TopPSRank,:);fitness=QF(TopPSRank,:);
      %Energy-saving 
      for j=1:ps
          [p_chrom(j,:),m_chrom(j,:),f_chrom(j,:),fitness(j,:)]=EnergySaveDFJSP(p_chrom(j,:),m_chrom(j,:),f_chrom(j,:),fitness(j,:));
        NFEs=NFEs+1;
      end
      
    %Update Elite Archive
    [PF,~]=pareto1(fitness);
    AP=[AP;p_chrom(PF,:)];AM=[AM;m_chrom(PF,:)];AN=[AN;f_chrom(PF,:)];AF=[AF;fitness(PF,:)];   
    [PF,~]=pareto1(AF);
    AP=AP(PF,:);AM=AM(PF,:);AN=AN(PF,:);AF=AF(PF,:);
    DeleteRpeat(); 
    end%IEND
    
    while NFEs<MaxNFEs
      fprintf('%s %s %d %s %d\r\n',RealPath{File},'round',round,'iter',i);
        i=i+1;
      [L,~]=size(AP);  
      for j=1:L
          for k=1:5
            switch k
                case{1}
                    [P1,M1,N1]=LSN6(AP(j,:),AM(j,:),AN(j,:),AF(j,:));%���������
                case{2}
                    [P1,M1,N1]=LSTEN(AP(j,:),AM(j,:),AN(j,:),AF(j,:));%���������
                case{3}
                    [P1,M1,N1]=LSRIN(AP(j,:),AM(j,:),AN(j,:),AF(j,:));%���������
                case{4}
                    [P1,M1,N1]=LSRFA(AP(j,:),AM(j,:),AN(j,:),AF(j,:));%���������
                case{5}
                    [P1,M1,N1]=LSRMS(AP(j,:),AM(j,:),AN(j,:),AF(j,:));%���������
            end
            [F1{1,1},F1{1,2},F1{1,3}]=fitDFJSP(P1,M1,N1);
            NFEs=NFEs+1;
            if NDS(F1,AF(j,:))==1 %�½�֧��ɽ�
                AP(j,:)=P1;
                AM(j,:)=M1;
                AN(j,:)=N1;
                AF(j,:)=F1;
                AP=[AP;P1];
                AM=[AM;M1];
                AF=[AF;F1];
                AN=[AN;N1];                                    
            elseif NDS(F1,AF(j,:))==0 %�½⻥��֧��ɽ�
                if ~eql(F1{1,1},AF{j,1})&&~eql(F1{1,2},AF{j,2})
                AP=[AP;P1];
                AM=[AM;M1];
                AF=[AF;F1];
                AN=[AN;N1];  
                end
            elseif NDS(F1,AF(j,:))==2 %�½ⱻ�ɽ�֧��
                
            end
         end %KEND
      end %JEND
      [PF,~]=pareto1(AF);
      AP=AP(PF,:);AM=AM(PF,:);AN=AN(PF,:);AF=AF(PF,:);
      DeleteRpeat(); 
    end

    [PF,~]=pareto1(AF);
    AP=AP(PF,:);AM=AM(PF,:);AN=AN(PF,:);AF=AF(PF,:);

    [PF,~]=pareto1(AF);
    L=length(PF);
    obj=AF(:,1:2);
    newobj=[];
    obj=finalvalue(obj);
    for i=1:L
        newobj(i,:)=obj(PF(i),:);   
    end
    newobj=unique(newobj,'rows');%ɾ���ظ���
    tmp5=newobj';%����õ�ǰ�ؽ⼯ת��
    %scatter(newobj(:,1),newobj(:,2));
    tmp1='res';%�����ַ�����д������洢��·��
    resPATH=[respath tmp1 num2str(round) txt];
    fout=fopen(resPATH,'w');
    fprintf(fout,'%5.2f %6.3f\r\n',tmp5);%����matlab�ǰ����д洢�Ͷ�ȡ������д���ļ���ʱ��Ҳ�ǰ�������д�����Ҫת�ô���
    fclose(fout);
    end
end