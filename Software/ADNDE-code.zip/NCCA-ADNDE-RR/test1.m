clear all;
clc

Iter_final_max=30;
total_percentage1=zeros(Iter_final_max,1);
store_NPF1=zeros(Iter_final_max,1);
total_percentage2=zeros(Iter_final_max,1);
store_NPF2=zeros(Iter_final_max,1);
M_PR1=[];
M_PR2=[];
M_SR1=[];
M_SR2=[];
%A=[101,102,105];
A=[9,10,11,12,13,14,2,16,17,29,33,19,30,20,34,21,22,23,24,25,26,27,43,28,44,7,38,39,40,41];
timeA = [];
for w=1:30
    tic
    fun_num=A(w);
    %fun_num=53;
    pop=[];
    final_solution1=[];
    final_solution2=[];
    Iter_final=1;
    [Max_FES,NP,D,XRmin,XRmax,root_num,root,fun_name]= Parameter1(fun_num);
    Max_FES=Max_FES*2;
    solution1 =[];
    solution2=[];
    while Iter_final<=Iter_final_max
        for i=1:NP
            pop(i,:)=XRmin+(XRmax-XRmin).*rand(1,D);
        end
        %         solution1=self_ccde(fun_num,root,root_num,pop,D,NP,Max_FES,XRmin,XRmax);
        
        [solution1,NSDE_RMP]=ADNDE(fun_num,root,root_num,pop,D,NP,Max_FES,XRmin,XRmax);
        %        solution2=self_csde(fun_num,root,root_num,pop,D,NP,Max_FES,XRmin,XRmax);
        %            final_solution1=[final_solution1;solution1];
        %            final_solution2=[final_solution2;solution2];
        S1=size(solution1,1);
        if S1<root_num
            total_percentage1(Iter_final)=0;
            store_NPF1(Iter_final,1)=S1;
        else
            total_percentage1(Iter_final)=100;
            store_NPF1(Iter_final,1)=S1;
        end
        S2=size(solution2,1);
        if S2<root_num
            total_percentage2(Iter_final)=0;
            store_NPF2(Iter_final,1)=S2;
        else
            total_percentage2(Iter_final)=100;
            store_NPF2(Iter_final,1)=S2;
        end
        fprintf('The %d time of %d function has been completed\n',Iter_final,w);
        Iter_final=Iter_final+1;
    end
    PR1=sum(store_NPF1)/(root_num*Iter_final_max);%calculate the peak ratio
    M_PR1=[M_PR1;fun_num,PR1];
    SR1=mean(total_percentage1)/100;
    M_SR1=[M_SR1;SR1];
    if size(final_solution1,1)>0
        [a,b]=unique(final_solution1(:,1));
        final_solution1=final_solution1(b,:);
    end
    PR2=sum(store_NPF2)/(root_num*Iter_final_max);            %calculate the peak ratio
    M_PR2=[M_PR2;PR2];
    SR2=mean(total_percentage2)/100;
    M_SR2=[M_SR2;SR2];
    if size(final_solution2,1)>0
        [a,b]=unique(final_solution2(:,1));
        final_solution2=final_solution2(b,:);
    end
    tt = toc;
    timeA(w) = tt/30;
end

toc
fprintf('PR = %4f\n',mean(M_PR1(:,2)));
fprintf('SR = %4f\n',mean(M_SR1));
save timeA;








