function [ pop, val, FES,seed, seed_val, spop,muCR,muF] = NSDE( popsort, valsort,fun_num,FES,muCR,muF)

[Max_FES,NP,D,XRmin,XRmax,root_num,root,fun_name]= Parameter1(fun_num);
%F=0.5;CR=0.9;
seed=[];
seed_val=[];

seed_num=1;
pop_num=0;
numb_pop=size(popsort,1);

while pop_num<numb_pop%����Ҫѭ���ж�����
    
    aa=randi([4,7],1,1);
    
    [temp k]=sort(sqrt(sum((ones(size(popsort,1),1)*popsort(1,:)-popsort).^2,2)));
    spop(seed_num).species=popsort(1,:);
    spop(seed_num).speciesval=valsort(1);
    checker=ones(size(popsort,1),1);
    
    if size(checker,1)>aa
        
        checker(k(1:aa),:)=0;
        
    else
        
        checker(k(1:size(checker,1)))=0;
        
    end
    
    seed=[seed;spop(seed_num).species];
    seed_val=[seed_val;spop(seed_num).speciesval];
    
    spop(seed_num).pop=popsort(checker==0,:);
    spop(seed_num).val=valsort(checker==0);
    
    
    popsort=popsort(checker==1,:);
    valsort=valsort(checker==1);
    
    
    nn=size(spop(seed_num).pop,1);
    
    seed_num=seed_num+1;
    pop_num = pop_num + nn;
end

SF = [];
SCR = [];
count = 1;

for i=1:size(spop,2)
    [temp1 index]=sort(sqrt(sum((ones(size(spop(i).pop,1),1)*spop(i).species-spop(i).pop).^2,2)),'descend');
    Len = size(spop(i).pop,1);
    F = [];
    CR = [];
    [F,CR] = randFCR(Len, muCR, 0.1, muF, 0.1);
    %[CR,~] = sort(CR);
     
    for j=1:size(spop(i).pop,1)
        popold=spop(i).pop(j,:);
        newpop1=spop(i).pop;
        bm=spop(i).species;
        st=1;
        
        while size(newpop1,1)<5
            newpop=normrnd(spop(i).species,0.1);
            newpop1=[newpop1;newpop];
        end
        
        
        ui(j,1:D)=DE(popold,newpop1,bm,st,F(j),CR(j),D,size(newpop1,1),XRmin,XRmax);
        ui_val(j)=NES_func(ui(j,:),fun_num);
        FES=FES + 1;
        checkdis=sqrt(sum((ones(size(spop(i).pop,1),1)*ui(j,:)-spop(i).pop).^2,2));%���㵱ǰ��Ⱥ���¸����ŷʽ����
        [minval,minindex]=min(checkdis);
        if ui_val(j)<spop(i).val(minindex)
            spop(i).val(minindex)=ui_val(j);
            spop(i).pop(minindex,:)=ui(j,:);
            SF(count) = F(j);
            SCR(count) = CR(j);
            count = count+1;
        end
    end
end

%%%%%����muF��muCR
c = 0.1;
if count<=1
    muF = muF;
    muCR = muCR;
else
    muCR = (1-c)*muCR+c*mean(SCR);
    muF = (1-c)*muF+c*(sum(SF.^2))/(sum(SF));
end

pop=[];
val=[];
for i=1:size(spop,2)
    pop=[pop;spop(i).pop];
    val=[val;spop(i).val];
end
seed1=seed;
seed_val1=seed_val;

end

