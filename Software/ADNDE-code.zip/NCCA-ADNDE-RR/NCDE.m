function [ pop1,val1, FES,muCR,muF] = NCDE( pop1,val1,fun_num,FES,muCR,muF)

[Max_FES,NP,D,XRmin,XRmax,root_num,root,fun_name]= Parameter1(fun_num);
%  F=0.5;CR=0.9;
subpop=[];
SF = [];
SCR = [];
count = 1;
Len = size(pop1,1);
[F,CR] = randFCR(Len, muCR, 0.1, muF, 0.1);
%[CR,~] = sort(CR);
for j=1:size(pop1,1)
    num=randi([4,7],1,1);
    st=2;
    [temp k]=sort(sqrt(sum((ones(size(pop1,1),1)*pop1(j,:)-pop1).^2,2)));
    subpop(j).pop=pop1(k(1:num),:);
    subpop(j).val=val1(k(1:num));
    ui1(j,1:D)=DE( pop1(j,:),subpop(j).pop, pop1(j,:),st,F(j),CR(j),D,size(subpop(j).pop,1),XRmin,XRmax);
end
for i=1:NP
    ui_val1(i)=NES_func(ui1(i,:),fun_num);
    FES=FES+1;
end
for j=1:NP
    [temp index]=min(sqrt(sum((ones(size(pop1,1),1)*ui1(j,:)-pop1).^2,2)));
    if val1(index)>ui_val1(j)
        pop1(index,:)=ui1(j,:);
        val1(index)=ui_val1(j);
        SF(count) = F(j);
        SCR(count) = CR(j);
        count = count+1;
    end
end

c = 0.1;
if count<=1
    muF = muF;
    muCR = muCR;
else
    muCR = (1-c)*muCR+c*mean(SCR);
    muF = (1-c)*muF+c*(sum(SF.^2))/(sum(SF));
end


end

