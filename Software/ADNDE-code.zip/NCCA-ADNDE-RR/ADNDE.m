function [solution,r_NSDE_RMP]=ADNDE(fun_num,root,root_num,pop,D,NP,Max_FES,XRmin,XRmax)
warning off

FES=0;
M = 40;
archive=[];
archive_val=[];
if D<=5
    min_valthresold=1e-6;
    thresold=0.001;
    t_dis=0.01;
else
    min_valthresold=1e-4;
    thresold=0.01;
    t_dis=0.1;
end

for i=1:NP
    val(i)=NES_func(pop(i,:),fun_num);
    FES=FES+1;
end

g=1;
val=val';
FES=NP;
HCpop = {};

FES1 = 0;
FES2 = 0;

muCR = 0.9;
muF = 0.5;

while FES<Max_FES
    if g<3
        [~,sortindex]=sort(val,'ascend');
        popsort=pop(sortindex(1:NP),:);%������Ӧֵ��С��������
        valsort=val(sortindex(1:NP));
        clear spop;
        HCpop{g} = pop;
        [pop, val, FES1,seed,seed_val,spop,muCR,muF] = NSDE(popsort,valsort,fun_num,FES1,muCR,muF);
        FES = FES+FES1;
        pop=pop(1:NP,:);
        val=val(1:NP);
        HCpop{g+1} = pop;
        FES1 = 0;
    else
        %%%%%%%%%%%���㵱ǰ��Ⱥ������%%%%%%%%%%
        s1 = cal_simi(HCpop{g-1}, HCpop{g},D);
        s2 = cal_simi(HCpop{g-2}, HCpop{g-1},D);
        if (s1+s2)==0
            NSDE_rmp = 0.1;
        else
            NSDE_rmp = s1./(s1+s2);
        end   
        r_NSDE_RMP(g-2) = NSDE_rmp;
        
        if rand>NSDE_rmp  %%%%%˵�������ԽϺã�����NSDE�ӿ������ٶ�
            [~,sortindex]=sort(val,'ascend');
            popsort=pop(sortindex(1:NP),:);%������Ӧֵ��С��������
            valsort=val(sortindex(1:NP));
            [pop, val, FES1,seed,seed_val,spop,muCR,muF] = NSDE(popsort,valsort,fun_num,FES1,muCR,muF); 
            FES = FES+FES1;
            FES1 = 0;
            %%%% added
            temp_pop = pop;
            temp_val = val;
            [~,valindex] = sort(temp_val);
            mu_vector = mean(temp_pop(valindex(1:M),:),1);
            std_vector = std(temp_pop(valindex(1:M),:),1);
            pop = [];
            val = [];
            for j=1:size(spop,2)
                [minval, minindex]=min(spop(j).val);
                if minval<min_valthresold %���������Ⱥ����
                    [archive,archive_val]=Repulsion_archive(spop(j).pop(minindex,:),minval,archive,archive_val,D,NP,thresold);
                    len = size(spop(j).pop,1); %%%%Ҫ���³�ʼ���ĸ�����
%                     %%%%�����˹ģ�͵ľ�ֵ�ͱ�׼��
%                      mu_vector = spop(j).pop(minindex,:);
%                     mu_vector = mean(HCpop{g}(1,:),1);
%                     std_vector = std(HCpop{g}(1:10,:),1);

%                     std_vector = 0.1*ones(1,D);
%                     mu_vector = mean(archive,1);
%                     std_vector = std(archive,1);
                    for i=1:len
                        if mod(i,2)~=0
%                         if i~=1
                            spop(j).pop(i,:) = unifrnd(XRmin,XRmax);
                        else
                            spop(j).pop(i,:) = normrnd(mu_vector,std_vector);
                            lowerx = spop(j).pop(i,:)<XRmin;
                            indexxx = find(lowerx==1);
                            if ~isempty(indexxx)
                                spop(j).pop(i,indexxx) = XRmin(indexxx);
                            end
                            
                            upperx = spop(j).pop(i,:)>XRmax;
                            indexxx1 = find(upperx==1);
                            if ~isempty(indexxx1)
                                spop(j).pop(i,indexxx1) = XRmax(indexxx1);
                            end
                        end
                            
                        spop(j).val(i)=NES_func(spop(j).pop(i,:),fun_num);
%                         pop(loca,:) = spop(j).pop(i,:);
%                         val(loca) = spop(j).val(i);
                        FES=FES+1;
                    end
                end 
                pop = [pop;spop(j).pop];
                val = [val;spop(j).val];
            end
            clear spop;
            HCpop{g+1} = pop(1:NP,:);
        else %%%%%%%%%˵�������Խϲ����NCDE�ӿ������ٶ�
            [pop,val, FES2,muCR,muF]=NCDE(pop,val,fun_num,FES2,muCR,muF);  
            FES = FES+FES2;
            FES2 = 0;
            temp_pop = pop;
            temp_val = val;
            [~,valindex] = sort(temp_val);
            mu_vector = mean(temp_pop(valindex(1:M),:),1);
            std_vector = std(temp_pop(valindex(1:M),:),1);
%             std_vector = std(HCpop{g}(1:10,:),1);
%             std_vector = 0.1*ones(1,D);
%             mu_vector = mean(archive,1);
%             std_vector = std(archive,1);
            for j=1:size(pop,1)
                if val(j)<min_valthresold
                    [archive,archive_val]=Repulsion_archive(pop(j,:),val(j),archive,archive_val,D,NP,thresold);
%                     mu_vector = pop(j,:);
                    if mod(j,2)~=0
%                     if j~=1
                       pop(j,:) = unifrnd(XRmin,XRmax);
                    else
                        pop(j,:)=normrnd(mu_vector,std_vector);
                        %%%%%Խ�紦��
                        lowerx =  pop(j,:)<XRmin;
                        indexxx = find(lowerx==1);
                        if ~isempty(indexxx)
                             pop(j,indexxx) = XRmin(indexxx);
                        end

                        upperx =  pop(j,:)>XRmax;
                        indexxx1 = find(upperx==1);
                        if ~isempty(indexxx1)
                             pop(j,indexxx1) = XRmax(indexxx1);
                        end
                    end
                    val(j)=NES_func(pop(j,:),fun_num);
                    FES=FES+1;
                end
            end
            [sort_value, index] = sort(val);
            pop = pop(index(1:NP),:);
            val = val(index(1:NP));
            HCpop{g+1} = pop(1:NP,:);
        end
    end  
    g = g+1;
end
%===============================% End While

%%%%% �жϸ��Ĳ���

final_pop=[archive];
final_val=[archive_val];
solution=[];
root_index=1;
for s=1:root_num
    if size(final_pop,1)>0
        [minval,minindex]=min(sqrt(sum((ones(size(final_pop,1),1)*root(s,:)-final_pop).^2,2)));
        if final_val(minindex)<min_valthresold&&minval<=t_dis
            solution(root_index,:)=[s,final_pop(minindex,:)];
            root_index=root_index+1;
        end
    end
end
% solution=archive;
%%%%% ���������Ժ���
    function similarity = cal_simi(pop0, pop1,D)
        cov1=cov(pop1); cov0=cov(pop0);
              %��������
              tr1 = sum(diag(inv(cov1).*cov0));
              tr0 = sum(diag(inv(cov0).*cov1));
              %����Ⱥƽ��ֵ
              u1=mean(pop1);u0=mean(pop0);
              %���������ʽ
              cov1_det = det(cov1); cov0_det = det(cov0);
              %��ǰ��Ⱥ����һ����Ⱥ��KLD
              KLD_10=0.5*(tr1+(u1-u0)*inv(cov1)*(u1-u0)'-D+ log(cov1_det/cov0_det));
              KLD_01=0.5*(tr0+(u0-u1)*inv(cov0)*(u0-u1)'-D+ log(cov0_det/cov1_det));
              %��������������ƶ�
              similarity=0.5*(KLD_10+KLD_01);
    end


end
