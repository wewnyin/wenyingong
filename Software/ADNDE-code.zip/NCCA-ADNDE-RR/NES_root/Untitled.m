[filename,pathname]=uigetfile({'*.mat'},'ѡ��EXCEL');
Readfiles=dir(fullfile(pathname,'*.mat'));
NN=length(Readfiles);
for i=1:NN
    name=Readfiles(i).name;
     load(name)
    roots_of_NES=roots;
     save(name,'num_of_roots','roots_of_NES')
end
