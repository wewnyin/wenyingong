function [p_chrom, m_chrom, w_chrom] = Initial_MINW(PS)
    global N H SH NM M MW TW TM NW;

    % 初始化工序码、机器码和工人码
    p_chrom = zeros(PS, SH); % 工序码
    m_chrom = zeros(PS, SH); % 机器码
    w_chrom = cell(PS, SH); % 工人码
    worker_tasks_count = zeros(TW, 1); % 记录工人已参加工序次数的数组

    %生成工序码
    for i=1:N%将工序按顺序排开
        for j=1:H(i)%假如工件i有j个工序就生成j个i
            k=sum(H(1,1:i))-H(i)+j;
            chrom(k)=i;
        end
    end
    tmp=chrom;
    p_chrom(1,:)=tmp(randperm(length(tmp)));%将工序码打乱
    
    for i=2:PS   
        tmp=p_chrom(i-1,:);
        p_chrom(i,:)=tmp(randperm(length(tmp)));%再根据上一个生成后续的种群个体
    end
    %工序码种群生成完毕

    % 对每个个体应用MNW规则重新排列机器码和工人码
    for k = 1:PS
        for i = 1:N
            for j = 1:H(i)
                % 计算工件i的第j道工序的起始索引
                idx = sum(H(1, 1:i - 1)) + j;
                % 获取工件i的第j道工序可选的机器集合
                %available_machines = M{i, j};
                % 获取工序i对应的可选机器数
                num_machines = NM{i, j};
                % 存储每台机器可选工人数量的数组
                num_available_workers = zeros(1, num_machines);
                % 统计每台机器的可选工人数量
                for m = 1:num_machines
                    %disp(num_machines)
                    %disp(['机器：', num2str(M{i,j,m})])
                    %disp(['机器可用工人数：', num2str(NW(M{i,j,m}))])
                    %disp(length(MW{M{i,j,m}}))
                    num_available_workers(m) = NW(M{i,j,m});
                end
                % 找到可选工人数量最少的机器
                min_workers_idx = find(num_available_workers == min(num_available_workers));
                num_min_workers_machines = length(min_workers_idx);
                %disp(['可选工人数最少的机器数：', num2str(num_min_workers_machines)])
                
                % 随机选择一个可选工人数量最少的机器
                selected_machine_idx = min_workers_idx(randi(num_min_workers_machines));
                %disp(['选择的机器索引：', num2str(selected_machine_idx)])
                min_machine = M{i,j,selected_machine_idx};
                %disp(['选择的机器：', num2str(min_machine)])
                
                % 将找到的机器存储到机器码中
                m_chrom(k, idx) = min_machine;
                % 从该机器的可选工人集中根据最小工人负载的原则选择一个工人
                available_workers = MW{min_machine};
                % 统计每个工人已参加工序的次数
                num_tasks_completed = zeros(1, length(available_workers));
                for w = 1:length(available_workers)
                    worker = available_workers(w);
                    num_tasks_completed(w) = worker_tasks_count(worker);
                end
                % 找到已加工次数最少的工人
                min_completed_idx = find(num_tasks_completed == min(num_tasks_completed));
                num_min_completed_workers = length(min_completed_idx);
                % 随机选择一个已加工次数最少的工人
                selected_worker_idx = min_completed_idx(randi(num_min_completed_workers));
                selected_worker = available_workers(selected_worker_idx);
                % 更新工人已参加工序次数的数组
                worker_tasks_count(selected_worker) = worker_tasks_count(selected_worker) + 1;
                % 将选定的工人存储到工人码中
                w_chrom{k, idx} = selected_worker;
            end
        end
    end
end
