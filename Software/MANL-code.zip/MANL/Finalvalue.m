function obj = Finalvalue(fitness)
    % 将所有的适应值经过归一化处理，便于在画散点图中动态的展示种群的变化

    % 计算归一化后的适应值
    normalized_fitness = zeros(size(fitness));

    % 对每一列适应值进行归一化处理
    for col = 1:size(fitness, 2)
        col_fitness = fitness(:, col);  % 获取当前列的适应值
        min_fitness = min(col_fitness);  % 最小适应值
        max_fitness = max(col_fitness)*1.001;  % 最大适应值
        normalized_fitness(:, col) = (col_fitness - min_fitness) / (max_fitness - min_fitness);  % 归一化处理
    end

    obj = normalized_fitness;
end
