function [best_solution_indices, good_solution_indices, potential_solution_indices] = LS_select(p_chrom, m_chrom, w_chrom)
    ps = size(p_chrom, 1);
    % 计算适应度
    fitness = zeros(ps, 2);
    for i = 1:ps
        [fitness(i, 1), fitness(i, 2)] = Fit2(p_chrom(i, :), m_chrom(i, :), w_chrom(i,:));
    end
    
    % 计算 Pareto 前沿
    [PF] = pareto(fitness);
    
    % 计算随机抽取的个数
    num_random_solutions = ceil(0.3 * size(PF, 2));

    % 从 Pareto 前沿中随机选择 30% 的解
    random_indices = randperm(size(PF, 2), num_random_solutions);
    random_solution_indices = PF(random_indices);  

    % 选择每一层上拥挤度最大的解
    [max_crowded_solution_indices, num_per_layer] = max_crowded(fitness);

    % 选择有潜力解
 
    potential_solution_indices = [];
    current_index = 0;  % 初始化 current_index
    for i = 1:length(num_per_layer)
        layer_indices = current_index + 1:current_index + num_per_layer(i);
        current_index = current_index + num_per_layer(i);
        % 找到每一层上对两个目标分别最差的解的索引
        [~, worst_index_first] = min(fitness(layer_indices, 1));
        [~, worst_index_second] = min(fitness(layer_indices, 2));
        % 将每个目标上最差解的索引添加到 potential_solution_indices 中
        worst_indices = layer_indices([worst_index_first, worst_index_second]);
        potential_solution_indices = [potential_solution_indices, worst_indices];
    end
    
   %{
    % 计算解的全局频率
    solution_frequency = histcounts(1:ps, 1:ps);

    % 选择全局频率最小的 10 个解的索引
    [~, min_frequency_indices] = mink(solution_frequency, length(num_per_layer));

    % 将选定的索引添加到 potential_solution_indices 中
    potential_solution_indices = min_frequency_indices;
%}
    % 选择最优解和优秀解
    best_solution_indices = random_solution_indices;
    good_solution_indices = [max_crowded_solution_indices{:}];
end
