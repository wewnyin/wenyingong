function selected_indices = Selection(PS, fitness, gen, max_gens,tournament_size, seq_threshold,num)
    % 预分配选中个体的索引
    selected_indices = zeros(PS, 1);
    
    % 计算当前世代数相对于总世代数的比例
    ratio = gen / max_gens;

    seq_current=seq_threshold* ratio; %1.3*0.75=0.975 后1/4个体执行顺序选择
    
    % 遍历种群中的每个个体
    for i = 1:PS
        % 生成随机数，用于决定选择策略
        rand_num = rand();
        
        if rand_num < seq_current
            %使用顺序选择策略 后期
            selected_indices(i)=SeqSelection(fitness,num,i);
        else
            % 使用锦标赛选择策略 前期
            selected_indices(i) = TournamentSelection(fitness, tournament_size);
        end
    end
end
