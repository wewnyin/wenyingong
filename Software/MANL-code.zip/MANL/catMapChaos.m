function [cat_map_chaos] = catMapChaos(a, b, x0, n)
    % 使用猫图谱混沌函数生成长度为n的序列
    cat_map_chaos = zeros(200, n); % 初始化混沌序列
    cat_map_chaos(1, :) = 1:n; % 初始值

    for i = 2:200
        % 应用猫图谱混沌函数
        cat_map_chaos(i, :) = mod(a * cat_map_chaos(i-1, :) + b * sin(pi * cat_map_chaos(i-1, :)) + x0, n) + 1;
    end
end
