function [p_chrom,m_chrom,w_chrom] = Initial_new(PS)%该函数采用完全随机初始化的方法以及三层编码形式。
global  N H SH NM ps M MW Wmax;%PS种群大小，SH总工序数 NM各工序可选机器数 M各工序可选机器集 
                               % H(i)为i工件的工序数 N为工件数 MW为各机器可选工人集 Wmax为各机器最大协作人数
m_chrom=zeros(PS,SH);%机器码
p_chrom=zeros(PS,SH);%工序码
w_chrom = cell(PS, SH); % 工人码（单元数组）
chrom=zeros(1,SH);

%生成工序码
for i=1:N%将工序按顺序排开
    for j=1:H(i)%假如工件i有j个工序就生成j个i
        k=sum(H(1,1:i))-H(i)+j;
        chrom(k)=i;
    end
end
tmp=chrom;
p_chrom(1,:)=tmp(randperm(length(tmp)));%将工序码打乱
%{
for i=2:PS   
    tmp=p_chrom(i-1,:);
    p_chrom(i,:)=tmp(randperm(length(tmp)));%再根据上一个生成后续的种群个体
end
%}

% 使用猫图谱混沌函数生成更多个体
cat_map_chaos = catMapChaos(4, 0.7, 0.5,SH);
for i = 2:PS
    % 根据猫图谱混沌序列来重新排列工序码
    [~, idx] = sort(cat_map_chaos(i-1, :)); % 获取排序后的索引
    p_chrom(i, :) = p_chrom(1, idx); % 使用第一个个体进行重新排列
end

%工序码种群生成完毕

%生成机器码
for k=1:PS
    for i=1:N
        for j=1:H(i)
            t=ceil(rand*NM{i,j});%可选机器集中第t台机器
            t1=sum(H(1,1:i-1))+j;
            m_chrom(k,t1)=M{i,j,t};
        end
    end
end
%机器码种群生成完毕

% 生成工人码
    for k = 1:PS
        for i = 1:N
            for j = 1:H(i)
                t1 = sum(H(1, 1:i - 1)) + j;
                machine = m_chrom(k, t1);
                % 随机选择不超过对应机器的协作工人数 Wmax 的工人
                num = randi(min(Wmax(machine), length(MW{machine}))); % 随机生成协作的人数
                selected_workers = MW{machine}(randperm(num));%每个单元存储的是工人编号的组合 而不是索引
                w_chrom{k, t1} = selected_workers;
            end
        end
    end
end