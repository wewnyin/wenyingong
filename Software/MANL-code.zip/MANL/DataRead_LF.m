function [N, TM, TW, H, NM, M, SH, time, Wmax, NW, MW, PRO,Lrate,Frate,Sim] = DataRead_LF(RealPath)
    fin = fopen(RealPath, 'r'); % 打开txt文件
    A = fscanf(fin, '%f');
    A = A';

    N = A(1); % 总工件数
    H = zeros(1, N); % 各工件工序数
    NM = {}; % 各工序可选机器数
    M = {}; % 各工序可选机器号 每个val的对应位置代表对应工序 比如O11(第一道工序)有3台机器 就是每个val(val1-3，第一个val到第三个val)的第一个元素 
    time = {};

    p = 5; % 当前位置
    TM = A(2); % 可选机器数
    TW = A(3); % 可选工人数
    for i = 1:N
        H(i) = A(p);
        for j = 1:H(i)
            p = p + 1;
            NM{i, j} = A(p);
            for k = 1:NM{i, j}
                p = p + 1;
                M{i, j, k} = A(p);
                time{i, j, M{i, j, k}} = A(p + 1);
                p = p + 1;
            end
        end
        p = p + 1;
    end

    SH = sum(H);

    % 读取Wmax
    Wmax = zeros(1, TM);
    for i = 1:TM
        Wmax(i) = A(p);
        p = p + 1;
    end

    % 读取NW
    NW = zeros(1, TM);
    for i = 1:TM
        NW(i) = A(p);
        p = p + 1;
    end

    % 读取MW
    MW = cell(1, TM);
    for i = 1:TM
        MW{i} = A(p:p+NW(i)-1);
        p = p + NW(i);
    end

    % 读取PRO
    PRO = zeros(TW, TM);
    for i = 1:TW
        for j = 1:TM
            PRO(i, j) = A(p);
            p = p + 1;
        end
    end
    
    % 读取学习率Lrate
    Lrate = zeros(1, TW);
    for i = 1:TW
        Lrate(i) = A(p);
        p = p + 1;
    end
    
    % 读取遗忘率Frate
    Frate = zeros(1, TW);
    for i = 1:TW
        Frate(i) = A(p);
        p = p + 1;
    end
    
    % 读取工件之间相似度
    Sim = zeros(N, N);
    for i = 1:N
        for j = 1:N
            Sim(i, j) = A(p);
            p = p + 1;
        end
end

    fclose(fin);
end
