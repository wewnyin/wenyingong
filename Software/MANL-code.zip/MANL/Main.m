        clc;
        clear all;
        
        DataPath = '.\data\Brandimarte_Data\'; % 替换为你要读取的文件夹路径
        ResPath = 'result\'; % 结果要保存的文件夹路径
        %DataPath = '.\data\Dauzere_Data\'; % 替换为你要读取的文件夹路径
        %ResPath = 'result_DP\'; % 结果要保存的文件夹路径
        fileList = dir(fullfile(DataPath));  % 获取文件夹中的所有文件
        validExtensions = {'.txt', '.fjs'};  % 有效的文件扩展名
        
        % 循环读取数据文件夹下的文件
        file_num = 1;
        for i = 1:numel(fileList)
            [~, ~, fileExt] = fileparts(fileList(i).name);  % 获取文件扩展名
            if ~fileList(i).isdir && any(ismember(validExtensions, fileExt))
                RealPath{file_num} = fullfile(DataPath, fileList(i).name);
                file_num = file_num + 1;
            end 
        end
        
        global N H SH NM NW M TM TW time ps Pc Pm PRO MW Wmax Lrate Frate Sim max_gens;
        
        fout = fopen('parameter.txt', 'r');
        A = fscanf(fout, '%d %f %f %f');
        fclose(fout);
        ps = A(1); % 种群大小
        Pc = A(2); % 交叉概率
        Pm = A(3); % 变异概率
        seq_threshold=1.3;
        tournament_size =2;       % 设置锦标赛选择的竞争个体数量
        F=1;
        num=25;
        max_iter = A(4); % 最大迭代次数
        max_gens = A(5); % 最大进化次数
        
        h_array=zeros(1,max_iter);%用于存储30次独立运行的hv值
        L_array=zeros(1,max_iter);%用于存储每一次前沿中解集的个数
        PF = cell(1, max_iter); 
        totalPF=[];%将30轮迭代的PF存入该变长数组，最后统计最大值和最小值，用于hv值的坐标系的统一
        best_fitness_array = zeros(max_iter * max_gens, 2); % 初始化最优适应度数组

        for File = 1:10 % 对每一个数据集
            [N, TM, TW,H, NM, M, SH, time, Wmax, NW, MW, PRO,Lrate,Frate,Sim] = DataRead_LF(RealPath{File}); % 读取数据
            respath = [ResPath, extractBefore(extractAfter(RealPath{File}, max(strfind(RealPath{File}, '\'))), '.'), '\']; % 结果路径
            if ~isfolder(respath)
                mkdir(respath);
            else
                rmdir(respath, 's');
                mkdir(respath);
            end
        
            totalPF=[];
            totalPF0=[];

            for iter = 1:max_iter
                [p_chrom, m_chrom, w_chrom] = InitializePopulation(ps); % 种群初始化
                p_chrom_pre=p_chrom;
                fitness = zeros(ps, 2); % 种群适应度值                fitness_pre = zeros(ps, 2); % 种群适应度值
                for i = 1:ps
                    [p_chrom_pre(i, :)] = PreDecode(p_chrom(i, :), m_chrom(i, :), w_chrom(i, :));
                    [fitness_pre(i, 1), fitness_pre(i, 2)] = Fit2(p_chrom_pre(i, :), m_chrom(i, :), w_chrom(i, :));
                    [fitness(i, 1), fitness(i, 2)] = Fit2(p_chrom(i, :), m_chrom(i, :), w_chrom(i, :));
                    if fitness_pre(i, 1)<fitness(i, 1)
                        fitness(i,:)=fitness_pre(i, :);
                        p_chrom(i,:)=p_chrom_pre(i,:);
                    end
                end
        
                
                for gen = 1:max_gens
                    fprintf('%s %s %d %s %d\r\n', RealPath{File}, 'iter', iter, 'gen', gen);
                    Off_p_chrom = zeros(ps, SH);
                    Off_m_chrom = zeros(ps, SH);
                    Off_w_chrom = cell(ps, SH);
                    
                    L = size(p_chrom, 1);
                    selection_fitness = zeros(L, 2);
            
                    for i = 1:L
                        [selection_fitness(i, 1), selection_fitness(i, 2)] = Fit2(p_chrom(i, :), m_chrom(i, :), w_chrom(i,:));
                    end
                    
                    
                    if gen<max_gens
                            % 选择
                            selected_indices = Selection(ps/2,selection_fitness, gen,max_gens,tournament_size, seq_threshold,num);
                            % 根据选择的索引更新编码行
                            p_chrom_new = p_chrom(selected_indices, :);
                            m_chrom_new = m_chrom(selected_indices, :);
                            w_chrom_new = w_chrom(selected_indices, :);
                            
                            % 将更新后的编码行赋值给原始编码行
                            p_chrom(1:ps/2, :) = p_chrom_new;
                            m_chrom(1:ps/2, :) = m_chrom_new;
                            w_chrom(1:ps/2, :) = w_chrom_new;
                    end
                    
                    for indiv = 1:ps/2
                        [new_p1, new_m1, new_w1, new_p2, new_m2, new_w2] = Evolution(p_chrom, m_chrom, w_chrom, indiv); % 进化
                        Off_p_chrom(2 * indiv - 1, :) = new_p1;
                        Off_m_chrom(2 * indiv - 1, :) = new_m1;
                        Off_p_chrom(2 * indiv, :) = new_p2;
                        Off_m_chrom(2 * indiv, :) = new_m2;
                        for i = 1:numel(new_w1)
                            Off_w_chrom(2 * indiv - 1, i) = new_w1(i);
                            Off_w_chrom(2 * indiv,i) = new_w2(i);
                        end
                    end

                    % 将 Off_p_chrom、Off_m_chrom 和 Off_w_chrom 合并为一个种群
                    new_p_chrom = vertcat(p_chrom, Off_p_chrom);
                    new_m_chrom = vertcat(m_chrom, Off_m_chrom);
                    new_w_chrom = vertcat(w_chrom, Off_w_chrom);
        
                    L = size(new_p_chrom, 1);
                    new_fitness = zeros(L, 2);
                    new_fitness_pre = zeros(L, 2);
                    new_p_chrom_pre=new_p_chrom;

                    [best_solution, good_solution, potential_solution]=LS_select(new_p_chrom, new_m_chrom, new_w_chrom);
                    % 根据 F 的值确定后续代码执行的概率
                    if F <= 0.1
                        f_LS = 0.3; 
                    elseif F <= 0.6
                        f_LS = 0.6; 
                    else
                        f_LS = 1.0; 
                    end
                    % 生成一个随机数，如果小于执行概率，则执行后续代码
                    if rand() <= f_LS
                        [F, new_p_chrom, new_m_chrom, new_w_chrom] = LS(best_solution, good_solution, potential_solution, new_p_chrom, new_m_chrom, new_w_chrom);
                    end

                    for i = 1:L
                        [new_p_chrom_pre(i, :)] = PreDecode(new_p_chrom(i, :), new_m_chrom(i, :), new_w_chrom(i,:));
                        [new_fitness_pre(i, 1), new_fitness_pre(i, 2)] = Fit2(new_p_chrom_pre(i, :), new_m_chrom(i, :), new_w_chrom(i,:));
                        [new_fitness(i, 1), new_fitness(i, 2)] = Fit2(new_p_chrom(i, :), new_m_chrom(i, :), new_w_chrom(i,:));
                        if new_fitness_pre(i, 1)<new_fitness(i, 1)
                            new_fitness(i, :)=new_fitness_pre(i, :);
                            new_p_chrom(i, :)=new_p_chrom_pre(i, :);
                        end
                    end
                    [indiv_list, num] = FastNDS(new_fitness); % 快速非支配排序，基于拥挤度产生新种群
                    p_chrom = new_p_chrom(indiv_list, :);
                    m_chrom = new_m_chrom(indiv_list, :);
                    w_chrom = new_w_chrom(indiv_list, :);
                end


                [fit(1, 1), fit(1, 2)] = Fit2(p_chrom(1, :), m_chrom(1, :), w_chrom(1, :));
                
                for i=1:ps
                    [fitness(i, 1), fitness(i, 2)] = Fit2(p_chrom(i, :), m_chrom(i, :), w_chrom(i, :));
                end
                [AS]=pareto(fitness);
                Las=length(AS);
                newobj=zeros(Las,2);
                newfit=zeros(Las,2);
                obj=Finalvalue(fitness); % 适应值归一化结果
                for i=1:Las
                    newobj(i,:)=obj(AS(i),:);
                    newfit(i,:)=fitness(AS(i),:);
                end

                newobj=unique(newobj,'rows');%删除重复行
                newfit=unique(newfit,'rows');%删除重复行
                [Las,~]=size(newobj);
                L_array(iter)=Las;%记录每一次前沿解集的个数
                for cc=1:Las
                    totalPF=[totalPF;newobj(cc,:)];
                    totalPF0=[totalPF0;newfit(cc,:)];
                end

                resPATH = [respath ['res' num2str(iter)] '.txt'];
                fout = fopen(resPATH, 'w');
                fprintf(fout, '%f\t%f\n', fitness(1, 1), fitness(1, 2));%写入适应度
                fprintf(fout, '%d\t', p_chrom(1, :)); % matlab是按照列存储和读取矩阵，则写入文件的时候也是按照列填写，记得要转置存入
                fprintf(fout, '\n');
                fprintf(fout, '%d\t', m_chrom(1, :));
                fprintf(fout, '\n');
                w_chrom_t = w_chrom';
                for i = 1:SH
                    fprintf(fout, '%d\t', w_chrom_t{i}(1, :)); % 将单元数组中的每个第一行元素打印到文件中
                    fprintf(fout, '\n'); % 写入换行符
                end
                fclose(fout);
            end
            fmin   = min(min(totalPF,[],1),zeros(1,2));
            fmax   = max(totalPF,[],1)*1.1;
            current_index=1;
            igd_values = zeros(max_iter, 1);
            for round=1:max_iter
                newobj=[];%取出每一次的PF前沿
                newfit=[];
                endindex=current_index+L_array(round)-1;
                for i=current_index:endindex
                    newobj=[newobj;totalPF(i,:)];
                    newfit=[newfit;totalPF0(i,:)];
                end
                current_index=current_index+L_array(round);
                h_array(round)=myHV(newobj,fmin,fmax);

                % 将 newobj 存储到 totalPF_history 中
                PF{round} = newobj;
                truePF=remove_dominated(totalPF);

                tmp5=newobj';%将求得的前沿解集转置
                tmp6=newfit';%将求得的前沿解集转置

                tmp0='res_PF';
                tmp2=num2str(round);
                tmp3='.txt';
                resPATH=[respath tmp0 tmp2 tmp3];
                fout=fopen(resPATH,'w');
                fprintf(fout,'%5.2f %6.3f\r\n',tmp6);%由于matlab是按照列存储和读取矩阵，则写入文件的时候也是按照列填写，因此要转置存入
                fclose(fout);
            end
            
            sum=0;
            for i=1:max_iter
                sum=sum+h_array(i);
            end
            sum=sum/max_iter;
            best_hv=max(h_array);
            best_index=find(h_array==best_hv);
            L=length(best_index);
            if L>1 %如果不止一个结果则选择点个数最多的
                t=best_index(1);
                round=L_array(t);
                for i=1:L
                    if round<L_array(best_index(i))
                        round=L_array(best_index(i));
                        t=best_index(i);
                    end
                end
            else
                t=best_index;
            end

            fprintf('%s %s\r\n','Finish ',['result' num2str(File)]);

            
        end
