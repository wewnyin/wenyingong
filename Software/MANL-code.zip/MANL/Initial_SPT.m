function [p_chrom, m_chrom, w_chrom] = Initial_SPT(PS)
    global N H SH NM ps M MW Wmax PRO time;

    % 初始化工序码和机器码
    p_chrom = zeros(PS, SH); % 工序码
    m_chrom = zeros(PS, SH); % 机器码
    w_chrom = cell(PS, SH); % 工人码

    %生成工序码
    for i=1:N%将工序按顺序排开
        for j=1:H(i)%假如工件i有j个工序就生成j个i
            k=sum(H(1,1:i))-H(i)+j;
            chrom(k)=i;
        end
    end
    tmp=chrom;
    p_chrom(1,:)=tmp(randperm(length(tmp)));%将工序码打乱
    
    for i=2:PS   
        tmp=p_chrom(i-1,:);
        p_chrom(i,:)=tmp(randperm(length(tmp)));%再根据上一个生成后续的种群个体
    end
    %工序码种群生成完毕

    % 对每个个体应用SPT规则重新排列工序码
    for k = 1:PS
        for i = 1:N
            for j = 1:H(i)
                % 计算工件i的第j道工序的起始索引
                idx = sum(H(1, 1:i - 1)) + j;
                % 获取工件i的第j道工序可选的机器集合
                %available_machines = M{i, j};
                % 获取工序i对应的可选机器数
                num_machines = NM{i, j};
                % 初始化存储机器加工时间的数组
                machine_processing_times = zeros(1,num_machines);
                % 计算每台机器的加工时间
                for m = 1:num_machines
                    machine_processing_times(m) = time{i, j, M{i,j,m}};
                end
                % 找到加工时间最短的机器
                [~, shortest_machine_idx] = min(machine_processing_times);
                % 获取加工时间最短的机器编号
                shortest_machine = M{i,j,shortest_machine_idx};
                % 将加工时间最短的机器存储到机器码中
                m_chrom(k, idx) = shortest_machine;
                % 随机确定不超过机器最大协作人数的工人数
                num_workers = randi(min(Wmax(shortest_machine), length(MW{shortest_machine})));
                % 从机器的可选工人集中选择满足数量的初始加工耗时系数 PRO 较低的工人
                available_workers = MW{shortest_machine};
                [~, sorted_indices] = sort(PRO(available_workers, shortest_machine), 'ascend');
                selected_workers = available_workers(sorted_indices(1:num_workers));
                % 将选定的工人存储到工人码中
                w_chrom{k, idx} = selected_workers;
            end
        end
    end
end
