function [F, p_chrom, m_chrom, w_chrom] = LS(best_solution_indices, good_solution_indices, potential_solution_indices, p_chrom, m_chrom, w_chrom)
    % 初始化子种群
    f_sum = 0;
    f_better = 0;

    % 对最优解集合中的解应用随机的 LS1 到 LS3
    for i = 1:length(best_solution_indices)
        % 对每个索引应用随机的 LS1 到 LS3
        index = best_solution_indices(i);
        ls_func = randi(3); % 随机选择 LS1 到 LS3 中的一个
        [new_pchrom, new_mchrom, new_wchrom, flag] = apply_LS(p_chrom(index, :), m_chrom(index, :), w_chrom(index, :), ls_func);
        if flag == 0 && length(best_solution_indices) > 1
            r = randi(length(best_solution_indices));
            index2 = best_solution_indices(r);
            while i == r % 防止自己与自己交叉
                r = randi(length(best_solution_indices));
                index2 = best_solution_indices(r);
            end
            [new_pchrom, new_mchrom, new_wchrom, ~, ~, ~] = Crossover_new(p_chrom(index, :), m_chrom(index, :), w_chrom(index, :), p_chrom(index2, :), m_chrom(index2, :), w_chrom(index2, :));
        end
        p_chrom(index, :) = new_pchrom;
        m_chrom(index, :) = new_mchrom;
        w_chrom(index, :) = new_wchrom;
        f_sum = f_sum + 1;
        f_better = f_better + flag;
    end

    % 对 good 解和有潜力解随机应用 LS4 或 LS5
    % 对 good 解应用 LS4 或 LS5
    for i = 1:length(good_solution_indices)
        % 对每个索引应用 LS4 或 LS5
        index = good_solution_indices(i);
        % 这里应用随机选择 LS4 或 LS5 的代码
        if rand() < 0.5
            [new_wchrom, flag] = LS4(p_chrom(index, :), m_chrom(index, :), w_chrom(index, :));
        else
            [new_wchrom, flag] = LS5(p_chrom(index, :), m_chrom(index, :), w_chrom(index, :));
        end
        new_pchrom = p_chrom(index, :);
        new_mchrom = m_chrom(index, :);
        if flag == 0 && length(good_solution_indices) > 1
            r = randi(length(good_solution_indices));
            index2 = good_solution_indices(i);
            while i == r % 防止自己与自己交叉
                r = randi(length(good_solution_indices));
                index2 = good_solution_indices(i);
            end
            [new_pchrom, new_mchrom, new_wchrom, ~, ~, ~] = Crossover_new(p_chrom(index, :), m_chrom(index, :), w_chrom(index, :), p_chrom(index2, :), m_chrom(index2, :), w_chrom(index2, :));
        end
        p_chrom(index, :) = new_pchrom;
        m_chrom(index, :) = new_mchrom;
        w_chrom(index, :) = new_wchrom;
        f_sum = f_sum + 1;
        f_better = f_better + flag;
    end

    % 对有潜力解应用 LS4 或 LS5
    for i = 1:length(potential_solution_indices)
        % 对每个索引应用 LS4 或 LS5
        index = potential_solution_indices(i);
        % 这里应用随机选择 LS4 或 LS5 的代码
        if rand() < 0.5
            [new_wchrom, flag] = LS4(p_chrom(index, :), m_chrom(index, :), w_chrom(index, :));
        else
            [new_wchrom, flag] = LS5(p_chrom(index, :), m_chrom(index, :), w_chrom(index, :));
        end
        new_pchrom = p_chrom(index, :);
        new_mchrom = m_chrom(index, :);
        if flag == 0 && length(potential_solution_indices) > 1
            r = randi(length(potential_solution_indices));
            index2 = potential_solution_indices(i);
            while i == r % 防止自己与自己交叉
                r = randi(length(potential_solution_indices));
                index2 = potential_solution_indices(i);
            end
            [new_pchrom, new_mchrom, new_wchrom, ~, ~, ~] = Crossover_new(p_chrom(index, :), m_chrom(index, :), w_chrom(index, :), p_chrom(index2, :), m_chrom(index2, :), w_chrom(index2, :));
        end
        p_chrom(index, :) = new_pchrom;
        m_chrom(index, :) = new_mchrom;
        w_chrom(index, :) = new_wchrom;
        f_sum = f_sum + 1;
        f_better = f_better + flag;
    end

    F = f_better / f_sum;
end

function [new_pchrom, new_mchrom, new_wchrom, flag] = apply_LS(pchrom, mchrom, wchrom, ls_func)
    % 根据 ls_func 应用 LS1 到 LS3 中的一个
    switch ls_func
        case 1
            [new_pchrom, new_mchrom, new_wchrom, flag] = LS1(pchrom, mchrom, wchrom);
        case 2
            [new_mchrom, new_wchrom, flag] = LS2(pchrom, mchrom, wchrom);
            new_pchrom = pchrom;
        case 3
            [new_wchrom, flag] = LS3(pchrom, mchrom, wchrom);
            new_pchrom = pchrom;
            new_mchrom = mchrom;
    end
end
