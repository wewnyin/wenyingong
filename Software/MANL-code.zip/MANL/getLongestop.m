function [worker_id,max_load, Oi, Oj] = getLongestop(pro_m, mac_m, wor_m)
    global N H SH TM time PRO TW Lrate Frate Sim;

    B = 0.8;
    E = 2.718;
    max_skill = 1.1;
    min_skill = 0.75;
    e = 0;
    finish = {};
    
    last_job = zeros(TW, TM, 2);
    
    for worker = 1:TW
        for machine = 1:TM
            last_job(worker, machine, :) = [0, 0];
        end
    end

    for i = 1:N
        for j = 1:H(i)
            finish{i, j} = e;
        end
    end
    
    mt = cell(1, TM);
    for i = 1:TM
        mt{i} = e;
    end
    
    skill = PRO;
    U = zeros(TW, TM);
    Forget = zeros(TW, TM);
    forget_time = zeros(TW, TM);
    Longest_op=zeros(TW,3);%t1 t2 max_time

    s1 = pro_m;
    s2 = zeros(1, SH);
    p = zeros(1, N);
    
    worker_busy = cell(TW, TM);

    for i = 1:SH
        p(s1(i)) = p(s1(i)) + 1;
        s2(i) = p(s1(i));
    end
    
    total = e;
    worker_time = zeros(1, TW);

    for i = 1:SH
        t1 = s1(i);
        t2 = s2(i);
        mm(i) = mac_m(1, sum(H(1, 1:t1 - 1)) + t2);
        machine = mm(i);
        workers = wor_m(sum(H(1, 1:t1 - 1)) + t2);
        num_workers = numel(workers{1});
        worker_time_sum = 0;
        worker_busy_time = zeros(1, num_workers);
        for k = 1:num_workers
            worker = workers{1}(k);
            max_release_time = 0;
            for m = 1:TM
                if worker_busy{worker, m} > max_release_time
                    max_release_time = worker_busy{worker, m};
                end
            end
            worker_busy_time(k) = max_release_time;
        end
        start_time = max(max(worker_busy_time), finish{s1(i), max(1, s2(i) - 1)});

        for k = 1:num_workers
            worker = workers{1}(k);
            for m = 1:TM
                if last_job(worker, m, 1) > 0
                    prev_job = last_job(worker, m, 1);
                    prev_process = last_job(worker, m, 2);
                    forget_time(worker, m) = max(start_time - finish{prev_job, prev_process}, 0);
                    if forget_time(worker, m) > 0 && U(worker, m) > 0
                        exp_ect = ((-Frate(worker) * (1 - Sim(prev_job, s1(i)))) * forget_time(worker, m));
                        Forget(worker, m) = 1 - exp(exp_ect);
                        skill(worker, m) = min((Forget(worker, m) + ((1 - Forget(worker, m)) * U(worker, m)^Lrate(worker))), max_skill);
                    end
                end

            end
        end

        for k = 1:num_workers
            worker = workers{1}(k);
            worker_time_sum = worker_time_sum + 1/(skill(worker, machine) * time{s1(i), s2(i), machine});
            prev_job = last_job(worker, machine,1);
            if prev_job > 0
                U(worker, machine) = U(worker, machine)+Sim(prev_job, s1(i));
                skill(worker, machine) = max(PRO(worker, machine) * ((1 - B) * U(worker, machine)^Lrate(worker)+B), min_skill);
            else
                U(worker, machine) = 1;
            end

        end
        
        actime = num_workers / worker_time_sum;
        for k = 1:num_workers
            worker = workers{1}(k);
            if (actime/ num_workers)>Longest_op(worker,3)
                Longest_op(worker,3)=(actime/ num_workers);
                Longest_op(worker,1)=t1;Longest_op(worker,2)=t2;
            end
            worker_time(worker) = worker_time(worker) + (actime/ num_workers);
        end
        if mt{machine} < start_time
            mt{machine} = start_time + actime;
            finish{s1(i), s2(i)} = mt{machine};
            total = total + actime;
        else
            mt{machine} = mt{machine} + actime;
            finish{s1(i), s2(i)} = mt{machine};
            total = total + actime;
        end

        % 更新工人上一次在该机器上加工的工件和工序
        for k = 1:num_workers
            worker = workers{1}(k);
            last_job(worker, machine, 1) = s1(i);
            last_job(worker, machine, 2) = s2(i);
        end
        
        % 更新工人忙碌状态
        for k = 1:num_workers
            worker = workers{1}(k);
            worker_busy{worker, mm(i)} = finish{s1(i), s2(i)};
        end
    end

    % 找到最大负载的工人
    max_load=max(worker_time) / sum(worker_time); % 计算最大的工人累计加工时间占所有工人加工时间的比重; 
    worker_id = find(worker_time == max(worker_time));
    [Oi]=Longest_op(worker_id,1);
    [Oj]=Longest_op(worker_id,2);
end

