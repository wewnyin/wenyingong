function [p_chrom, m_chrom, w_chrom] = InitializePopulation(PS)
    global N H SH NM ps M MW Wmax PRO time;

    % 初始化工序码、机器码和工人码
    p_chrom = zeros(PS, SH); % 工序码
    m_chrom = zeros(PS, SH); % 机器码
    w_chrom = cell(PS, SH); % 工人码

    % 计算每种初始化函数应该生成的个体数量
    num_MINW = round(PS * 0.2);
    num_MAXW = round(PS * 0.1);
    num_SPT=round(PS * 0.2);
    num_new = PS - num_MINW - num_MAXW-num_SPT;

    % 调用每个初始化函数，生成对应数量的个体
    [p_MINW, m_MINW, w_MINW] = Initial_MINW(num_MINW);
    [p_MAXW, m_MAXW, w_MAXW] = Initial_MAXW(num_MAXW);
    [p_SPT, m_SPT, w_SPT] = Initial_SPT(num_SPT);
    [p_new, m_new, w_new] = Initial_new(num_new);

    % 合并生成的个体
    p_chrom(1:num_MINW, :) = p_MINW;
    m_chrom(1:num_MINW, :) = m_MINW;
    w_chrom(1:num_MINW, :) = w_MINW;

    p_chrom(num_MINW+1:num_MINW+num_MAXW, :) = p_MAXW;
    m_chrom(num_MINW+1:num_MINW+num_MAXW, :) = m_MAXW;
    w_chrom(num_MINW+1:num_MINW+num_MAXW, :) = w_MAXW;

    p_chrom(num_MINW+num_MAXW+1:num_MINW+num_MAXW+num_SPT, :) = p_SPT;
    m_chrom(num_MINW+num_MAXW+1:num_MINW+num_MAXW+num_SPT, :) = m_SPT;
    w_chrom(num_MINW+num_MAXW+1:num_MINW+num_MAXW+num_SPT, :) = w_SPT;

    p_chrom(num_MINW+num_MAXW+num_SPT+1:PS, :) = p_new;
    m_chrom(num_MINW+num_MAXW+num_SPT+1:PS, :) = m_new;
    w_chrom(num_MINW+num_MAXW+num_SPT+1:PS, :) = w_new;
end
