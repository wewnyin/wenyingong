function selected_index = SeqSelection(fitness, num, i)
    all = length(fitness);
    if i <= num
        selected_index = i;
    else
        selected_index =TournamentSelection(fitness, 9);
    end
end
