function [TopPSRank, num_per_layer] = max_crowded(fitness)
    % 初始化
    TopPSRank = {};
    num_per_layer = [];
    L = size(fitness, 1);
    rank = 1;
    F(rank).f = [];  % 记录 Pareto 解集等级为 rank 的个体集合
    individual = struct('n', zeros(1, L), 'p', cell(1, L));
    
    % 确定 Pareto 解集等级为 1 的个体
    for i = 1:L
        for j = 1:L
            dom_less = 0;
            dom_equal = 0;
            dom_more = 0;
            for k = 1:2  % 判断个体 i 和 j 的支配关系
                if fitness(i, k) > fitness(j, k)
                    dom_more = dom_more + 1;
                elseif fitness(i, k) == fitness(j, k)
                    dom_equal = dom_equal + 1;
                else
                    dom_less = dom_less + 1;
                end
            end
            
            if dom_less == 0 && dom_equal ~= 2 % 说明 i 受 j 支配，相应的 n 加 1
                individual(i).n = individual(i).n + 1;
            elseif dom_more == 0 && dom_equal ~= 2 % 说明 i 支配 j，把 j 加入 i 的支配合集中
                individual(i).p = [individual(i).p, j];
            end  
        end
        if individual(i).n == 0 % 个体 i 非支配等级排序最高，属于当前最优解集
            F(rank).f = [F(rank).f, i];
        end
    end
    
    % 给其他个体进行分级
    while ~isempty(F(rank).f)
        Q = [];  % 存放下一个 front 集合
        fL = length(F(rank).f);   
        for i = 1:fL  % 循环当前 Pareto 解集中的个体
            if ~isempty(individual(F(rank).f(i)).p)
                pL = length(individual(F(rank).f(i)).p);
                for j = 1:pL  % 循环个体 i 所支配解集中的个体
                    k = individual(F(rank).f(i)).p(j); % 被 F(rank).f 中个体支配的 j 对应的受支配数减 1
                    individual(k).n = individual(k).n - 1;
                    if individual(k).n == 0
                        Q = [Q, k];
                    end
                end
            end
        end
        rank = rank + 1;
        F(rank).f = Q;
    end
    
    % 计算拥挤度并选择每层拥挤度最大的个体索引
    num_layers = length(F) - 1;  % 计算 Pareto 前沿的层数
    for front = 1:num_layers
        ffL = length(F(front).f);  % 遍历每个支配等级
        num_per_layer(front) = ffL;  % 记录每层的解的个数
        y = fitness(F(front).f, :);
        crowd = zeros(ffL, 1);  % 用于存放目标值的拥挤度
        for i = 1:2  % 每个目标
            [sort_based_on_objective, sort_index] = sort(y(:, i));  % 把一个前沿面的目标值做升序排序
            fmin = sort_based_on_objective(1); % 获取该目标的最小值
            fmax = sort_based_on_objective(ffL); % 获取该目标的最大值
            if ffL == 1 || fmax == fmin  % 对于特殊情况的处理
                crowd(:, i) = ones(ffL, 1);  % 该目标上的拥挤度为 1
            else
                crowd(sort_index(1), i) = -1;  % 首个和末尾个体的拥挤度设为无穷大
                crowd(sort_index(ffL), i) = -1;
                for j = 2:(ffL - 1)  % 计算每个个体该函数目标值的拥挤度
                    crowd(sort_index(j), i) = crowd(sort_index(j), i) + ...
                        (sort_based_on_objective(j + 1) - sort_based_on_objective(j - 1)) / (fmax - fmin);
                end
            end
        end
        crowd = sum(crowd, 2);  % 计算总拥挤度
        max_crowded_indices = find(crowd == max(crowd));  % 找到拥挤度最大的个体索引
            % 将每个索引都添加到TopPSRank中
        for i = 1:length(max_crowded_indices)
            TopPSRank = [TopPSRank, F(front).f(max_crowded_indices(i))];
        end
    end
end
