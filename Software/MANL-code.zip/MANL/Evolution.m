function [p_parent_1, m_parent_1, w_parent_1, p_parent_2, m_parent_2, w_parent_2] = Evolution(pchrom, mchrom, wchrom, indiv)
    global ps SH Pc Pm;

    % 进化由交叉和变异组成
    % 交叉工序码使用POX交叉，机器码使用随机交换突变；工序码变异使用双点交换，机器码变异使用随机机器选择，工人码变异基于协作人数是否变化设计两种变异选择方案
    r = ceil(rand * ps/2);

    while indiv == r % 防止自己与自己交叉
        r = ceil(rand * ps/2);
    end

    if rand <= Pc
        [p_parent_1, m_parent_1, w_parent_1, p_parent_2, m_parent_2, w_parent_2] = Crossover_new(pchrom(indiv,:), mchrom(indiv,:), wchrom(indiv,:), pchrom(r,:), mchrom(r,:), wchrom(r,:));
        %disp('交叉过后w_parent_1'); 
        %disp(w_parent_1);
    else
        p_parent_1 = pchrom(indiv,:);
        m_parent_1 = mchrom(indiv,:);
        w_parent_1 = wchrom(indiv,:);
        
        %disp('未经交叉w_parent_1'); 
        %disp(w_parent_1);

        p_parent_2 = pchrom(r,:);
        m_parent_2 = mchrom(r,:);
        w_parent_2 = wchrom(r,:);
    end

    if rand < Pm
        [p_parent_1, m_parent_1, w_parent_1] = Mutation_new(p_parent_1, m_parent_1, w_parent_1);
        [p_parent_2, m_parent_2, w_parent_2] = Mutation_new(p_parent_2, m_parent_2, w_parent_2);
        %disp('变异过后w_parent_1'); 
        %disp(w_parent_1);
    end
end
