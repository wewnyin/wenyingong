function [dominates] = Comfitness(fit1, fit2)
    % 如果 fit1 在所有目标函数上都不劣于 fit2，并且在至少一个目标函数上更优，则 fit1 支配 fit2
    if all(fit1 <= fit2) && any(fit1 < fit2)
        dominates = 1;
    % 如果 fit2 在所有目标函数上都不劣于 fit1，并且在至少一个目标函数上更优，则 fit2 支配 fit1
    elseif all(fit2 <= fit1) && any(fit2 < fit1)
        dominates = -1;
    else
        dominates = 0; % fit1 和 fit2 互相非支配
    end
end
