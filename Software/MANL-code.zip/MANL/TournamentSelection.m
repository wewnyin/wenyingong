function selected_index = TournamentSelection(fitness, tournament_size)
    % 随机选择竞争个体
    competitors_indices = randperm(length(fitness), tournament_size);
    
    % 找出竞争者中适应度最高的个体索引
    max_index = 1;
    for i = 2:tournament_size
        if dominates(fitness(competitors_indices(i), :), fitness(competitors_indices(max_index), :))
            max_index = i;
        end
    end
    
    % 返回适应度最高的个体的索引
    selected_index = competitors_indices(max_index);
end

function is_dominated = dominates(fitness1, fitness2)
    % 检查fitness1是否支配fitness2
    % 如果fitness1至少在一个目标上优于fitness2，而在其他目标上不劣于fitness2，则返回true
    
    is_dominated = all(fitness1 <= fitness2) && any(fitness1 < fitness2);
end
