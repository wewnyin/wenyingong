function [p_parent_1, m_parent_1, w_parent_1, p_parent_2, m_parent_2, w_parent_2] = Crossover_new(pchrom1, mchrom1, wchrom1, pchrom2, mchrom2, wchrom2)
    global N SH;

    % 工序：POX交叉
    p_parent_1 = pchrom1;
    m_parent_1 = mchrom1;
    w_parent_1 = wchrom1;
    p_parent_2 = pchrom2;
    m_parent_2 = mchrom2;
    w_parent_2 = wchrom2;
    
    J1 = []; % 用于存储工件id的集合，0表示集合Q1，1表示Q2
    c1_p = zeros(1, SH); % 用于标记p1中Q1集合id的位置
    c2_p = zeros(1, SH); % 用于标记p2中Q1集合id的位置

    while isempty(J1)
        J1 = find(round(rand(1, N)) == 1); % 随机产生标记id号的集合
    end

    for j = 1:SH
        if ismember(p_parent_1(j), J1) % 将P1中是J1的元素存储到
            c1_p(j) = p_parent_1(j);
        end
    
        if ~ismember(p_parent_2(j), J1) % 将P2中不是J1的元素存储到c2
            c2_p(j) = p_parent_2(j);
        end
    end
    
    index_1_1 = find(c1_p == 0); % c1中的空位应该填补c2中非0的空位
    index_1_2 = find(c2_p ~= 0);

    index_2_1 = find(c2_p == 0); % c2中的空位应该填补c2中非0的空位
    index_2_2 = find(c1_p ~= 0);
    
    for j = 1:length(index_1_1)
        c1_p(index_1_1(j)) = p_parent_2(index_1_2(j));
    end

    for j = 1:length(index_2_1)
        c2_p(index_2_1(j)) = p_parent_1(index_2_2(j));
    end
    
    p_parent_1 = c1_p;
    p_parent_2 = c2_p;
    
    % 机器和工人码一起UX交叉
    s = round(rand(1, SH)) == 1;
    for i = 1:SH
        if s(i) == 1
            % 交换机器码
            t = m_parent_1(i);
            m_parent_1(i) = m_parent_2(i);
            m_parent_2(i) = t;
            % 交换对应的工人码
            tmp = w_parent_1(i);
            w_parent_1(i) = w_parent_2(i);
            w_parent_2(i) = tmp;
        end
    end
end
