function [pchrom, mchrom, wchrom] = Mutation_new(pchrom, mchrom, wchrom)
    global SH N H NM M PRO MW Wmax;

    % 进行工序变异
    p1 = ceil(rand * SH);   %第一个变异位点
    p2 = ceil(rand * SH);   %第二个变异位点
    while (p1 == p2) || (pchrom(p1) == pchrom(p2))   %确保两个变异位点不同，且所对应的工序号不同
        p2 = ceil(rand * SH);
    end

    t = pchrom(p1);
    pchrom(p1) = pchrom(p2); %将两个工序进行交换
    pchrom(p2) = t;

    %进行机器变异
    s1 = pchrom;
    s2 = zeros(1, SH);
    p = zeros(1, N);
    for i = 1:SH
        p(s1(i)) = p(s1(i)) + 1;
        s2(i) = p(s1(i));
    end

    s3 = mchrom;
    p1 = ceil(rand * SH);       %第一个变异位点
    p2 = ceil(rand * SH);       %第二个变异位点
    while (p1 == p2)
        p2 = ceil(rand * SH);
    end
    n = NM{s1(p1), s2(p1)}; % s1(p1)工件 s2(p1)工件的第几道工序
    m = ceil(rand * n);
    x = M{s1(p1), s2(p1), m};
    %disp(['第一个工序：',strcat(int2str(s1(p1)), strcat('.', int2str(s2(p2))))]);
    %disp(['第二个工序：',strcat(int2str(s1(p2)), strcat('.', int2str(s2(p2))))]);
    %disp(['机器变异点 ', num2str(sum(H(1,1:s1(p1)-1))+s2(p1))]);
    %disp(['原先的机器 ', num2str(s3(p1))]);
    if n > 1
        while (s3(p1) == m)
            m = ceil(rand * n);
            x = M{s1(p1), s2(p1), m};
        end
    end

    mchrom(1, sum(H(1, 1:s1(p1) - 1)) + s2(p1)) = x;
    %disp(['新的机器 ', num2str(mchrom(1,sum(H(1,1:s1(p1)-1))+s2(p1)))]);

    n = NM{s1(p2), s2(p2)};
    m = ceil(rand * n);
    x = M{s1(p2), s2(p2), m};
    %disp(['原先的机器2 ', num2str(s3(p2))]);
    if n > 1
        while (s3(p1) == m)
            m = ceil(rand * n);
            x = M{s1(p2), s2(p2), m};
        end
    end
    mchrom(1, sum(H(1, 1:s1(p2) - 1)) + s2(p2)) = x;
    %disp(['新的机器2 ', num2str(mchrom(1,sum(H(1,1:s1(p2)-1))+s2(p2))))];

    % 进行工人码变异 跟着机器码相同位置变异
    % 随机选择两个不同的变异位点  
    p1 = sum(H(1, 1:s1(p1) - 1)) + s2(p1);       %第一个变异位点
    p2 = sum(H(1, 1:s1(p2) - 1)) + s2(p2);       %第二个变异位点

    % 处理第一个变异位点 p1
    collaborators_p1 = numel(wchrom{p1}); % 当前协作人数
    machine_p1 = mchrom(1, p1); % 对应的机器
    available_workers_p1 = MW{machine_p1}; % 可选工人集合
    % 从新的机器可选工人集中按照工人初始熟练度 PRO 挑选随机个初始加工耗时较低的工人
    new_workers_count_p1 = randi([1, min([numel(available_workers_p1), Wmax(machine_p1)])]);
    [~, sorted_indices_p1] = sort(PRO(available_workers_p1, machine_p1), 'ascend');
    selected_workers_p1 = available_workers_p1(sorted_indices_p1(1:new_workers_count_p1));
    wchrom{p1} = selected_workers_p1;

    % 处理第二个变异位点 p2
    collaborators_p2 = numel(wchrom{p2}); % 当前协作人数
    machine_p2 = mchrom(1, p2); % 对应的机器
    available_workers_p2 = MW{machine_p2}; % 可选工人集合
    % 从新的机器可选工人集中按照工人初始熟练度 PRO 挑选随机个初始加工耗时较低的工人
    new_workers_count_p2 = randi([1, min([numel(available_workers_p2), Wmax(machine_p2)])]);
    [~, sorted_indices_p2] = sort(PRO(available_workers_p2, machine_p2), 'ascend');
    selected_workers_p2 = available_workers_p2(sorted_indices_p2(1:new_workers_count_p2));
    wchrom{p2} = selected_workers_p2;

    %进行工人码自身的变异
    [wchrom] = WorkerMutation(wchrom,mchrom);
end
