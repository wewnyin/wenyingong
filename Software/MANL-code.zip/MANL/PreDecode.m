function [pro_m] = PreDecode(pro_m, mac_m, wor_m)
    global N H SH TM time PRO TW Lrate Frate Sim;
    
    e = 0;
    finish = {}; % 工序完工时间
    
    for i = 1:N % 初始化完成时间矩阵
        for j = 1:H(i)
            finish{i, j} = e;
        end
    end
    
    mt = cell(1, TM);
    for i = 1:TM % 初始化机器最大完成时间数组
        mt{i} = e;
    end
    
    s1 = pro_m;
    s2 = zeros(1, SH);
    p = zeros(1, N);
    
    % 记录工人是否在同一时间段内在其他机器上进行了加工
    worker_busy = cell(TW, TM);

    for i = 1:SH
        p(s1(i)) = p(s1(i)) + 1; % 记录过程是否加工完成，完成一次加一
        s2(i) = p(s1(i)); % 记录加工过程中工件的次数
    end

    % 初始化机器当前统计到自己的第几道工序
    machine_seq = zeros(TM, N);
    % 初始化工人当前统计到自己的第几道工序
    worker_seq = zeros(TW, N);
    % 初始化机器空闲时间矩阵
    machine_idle = cell(TM, N);
    % 初始化工人空闲时间矩阵
    worker_idle = cell(TW, N);
    total = e;
    
    for i = 1:SH
        t1 = s1(i); % 记录当前是哪个工件
        t2 = s2(i); % 记录当前工件是加工到第几次
        mm(i) = mac_m(1, sum(H(1, 1:t1 - 1)) + t2); % 提取该工序该次加工的机器选择
        machine = mm(i);
        workers = wor_m(sum(H(1, 1:t1 - 1)) + t2);% 获取参与加工的工人
        num_workers = numel(workers{1}); % 获取参与加工的工人数量
        worker_time_sum = 0;
        worker_busy_time = zeros(1, num_workers); % 用于记录每个工人的最早释放时间
        for k = 1:num_workers
            worker = workers{1}(k);
            
            % 检查工人在所有机器上的忙碌状态，记录最晚释放时间
            max_release_time = 0; % 初始化为0，表示工人完全空闲
            for m = 1:TM
                if ~isempty(worker_busy{worker, m}) && worker_busy{worker, m} > max_release_time
                    max_release_time = worker_busy{worker, m}; % 找到这些机器中最晚释放的时间
                end
            end
            
            worker_busy_time(k) = max_release_time; % 记录工人的最晚释放时间
        end
        start_time = max(max(worker_busy_time), finish{s1(i), max(1, s2(i) - 1)}); % 取所有工人的最早释放时间中的最大值 和 上工序完成时间 较大者
        worker_end_times = zeros(1, num_workers);
        worker_nextstart_times = zeros(1, num_workers);
        % 检查工人在相应时间段内是否空闲
        %{
        for k = 1:num_workers
            worker = workers{1}(k);
            if ~isempty(worker_busy{worker, machine}) && worker_busy{worker, machine} > start_time
                start_time = worker_busy{worker, machine}; % 如果工人不空闲，更新开始时间
                disp('更新');
            end
        end
        %}
        insert_flag=0;
        actime = time{s1(i), s2(i), mm(i)}; % 实际加工时间
        %{
        if size(machine_idle{machine},2)>3
        for j=2:size(machine_idle{machine},2)-1
            if (numel(machine_idle{machine,j})==5)&&(actime<=machine_idle{machine,j}(5))
                idle_start_time=machine_idle{machine,j}(1);
                idle_start_op=machine_idle{machine,j}(2);
                idle_end_time=machine_idle{machine,j}(3);
                idle_end_op=machine_idle{machine,j}(4);
                % 遍历每个工人
                for k = 1:num_workers
                    worker = workers{1}(k);
                    % 查找工人在 idle_end_op 之前的最近一次工序的加工结束时间
                    for op = 1:size(worker_idle{worker}, 2)-1
                        if (numel(worker_idle{worker,op})==5) && (worker_idle{worker, op}(1)>idle_start_time)
                            worker_end_times(k) = worker_idle{worker, op}(1);
                            worker_nextstart_times(k) = worker_idle{worker, op}(3);
                            break; % 找到后跳出循环
                        end
                    end
                end
                max_end_time = max(worker_end_times,idle_end_op);
                min_start_time = min(worker_nextstart_times,idle_start_op);
                idle_time=min_start_time-max_end_time;
                if idle_time>=actime
                    disp(['工序',num2str(i),'有空闲开始时间',num2str(max_end_time)]);
                    disp(['工序',num2str(i),'有空闲结束时间',num2str(min_start_time)]);
                    if any(s1(idle_end_op:i-1)~=t1)
                        insert_pos=machine_idle{machine,j}(4)-1;
                        disp(['工序',num2str(i),'可插入位置',num2str(insert_pos)]);
                        break;
                    end
                end
            end
        end
        end
        %}
        if size(machine_idle{machine},2)>3
        for j=2:size(machine_idle{machine},2)-1
            if (numel(machine_idle{machine,j})==5)&&(actime<=machine_idle{machine,j}(5))
                    idle_end_op=machine_idle{machine,j}(4);
                    %disp(['工序',num2str(i),'有空闲开始时间',num2str(max_end_time)]);
                    %disp(['工序',num2str(i),'有空闲结束时间',num2str(min_start_time)]);
                    if idle_end_op<i-1&& idle_end_op > 0 && i-1 > 0 && idle_end_op
                        if any(pro_m(idle_end_op:i-1)~=t1) 
                            insert_pos=machine_idle{machine,j}(4)-1;
                            insert_flag=1;
                            machine_idle{machine,j}(4)=insert_pos;
                            machine_idle{machine,j}(3)=machine_idle{machine,j}(3)-actime;
                            machine_idle{machine,j}(5)=machine_idle{machine,j}(5)-actime;
                            %disp(['工序',num2str(i),'插入位置',num2str(insert_pos)]);
                            temp=pro_m(i);pro_m(i)=[];
                            pro_m = [pro_m(1:insert_pos), temp, pro_m(insert_pos+1:end)];
                            break;
                        end
                    end
            end
        end
        end
        % 记录机器对于每个工序的开始时间 从机器的第二道工序开始
        if (machine_seq(mm(i))>0)&&insert_flag~=1
            m_idle=start_time-machine_idle{machine,machine_seq(machine)}(1);
            machine_idle{machine,machine_seq(machine)}=[machine_idle{machine,machine_seq(machine)},start_time,i,m_idle];
        end
        % 记录工人对于每个工序的开始时间 从工人的第二道工序开始
        for k = 1:num_workers
            worker = workers{1}(k);
            if worker_seq(worker)>0&&insert_flag~=1
                w_idle=start_time-worker_idle{worker,worker_seq(worker)}(1);
                worker_idle{worker,worker_seq(worker)}=[worker_idle{worker,worker_seq(worker)},start_time,i,w_idle];
            end
        end
        if insert_flag~=1
            if mt{machine} < start_time % 如果机器最大完成时间小于该工序上一步完成时间
            mt{machine} = start_time + actime; % 机器的完工时间即为开始时间加实际执行时间
            finish{s1(i), s2(i)} = mt{machine}; % 机器的完工时间即为工序/工人组合的完工时间
            total = total + actime;
            else % 如果机器完成时间大于等于该件上一个工序的完成时间
            mt{machine} = mt{machine} + actime;
            finish{s1(i), s2(i)} = mt{machine}; % 更新工人组合的完成时间
            total = total + actime;
            end
            machine_seq(machine)=machine_seq(machine)+1;
            machine_idle{machine,machine_seq(machine)}=[mt{machine},i];
        end

        % 更新工人忙碌状态
        for k = 1:num_workers
            worker = workers{1}(k);
            worker_busy{worker, machine} = finish{s1(i), s2(i)};
            worker_seq(worker)=worker_seq(worker)+1;
            worker_idle{worker,worker_seq(worker)}=[mt{machine},i];
        end
    end

end