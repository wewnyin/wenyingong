function nondominated_PF = remove_dominated(PF)
    num_solutions = size(PF, 1);
    is_dominated = false(num_solutions, 1);

    % 检查每个解是否被其他解支配
    for i = 1:num_solutions
        if ~is_dominated(i)
            for j = 1:num_solutions
                if i ~= j && ~is_dominated(j)
                    % 如果解 j 支配解 i，则将解 i 标记为被支配
                    if all(PF(j,:) <= PF(i,:)) && any(PF(j,:) < PF(i,:))
                        is_dominated(i) = true;
                        break;
                    end
                end
            end
        end
    end

    % 从 PF 中移除被支配的解
    nondominated_PF = PF(~is_dominated, :);
end
