function [worker_load] = getWorkerload(pro_m, mac_m, wor_m,Oi,Oj)
    global N H SH TM time PRO TW Lrate Frate Sim;
    B = 0.8;
    E=2.718;
    max_skill = 1.1; % 最大技能熟练度
    min_skill=0.75;% 最低技能熟练度
    e = 0;
    finish = {}; % 工序完工时间
    
    % 初始化 last_job 为一个大小为 (TW x TM x 2) 的数组
    last_job = zeros(TW, TM, 2);
    
    % 对 last_job 进行初始化
    for worker = 1:TW
        for machine = 1:TM
            % 初始化为 [0, 0]，表示工件和工序信息都为 0
            last_job(worker, machine, :) = [0, 0];
        end
    end

    for i = 1:N % 初始化完成时间矩阵
        for j = 1:H(i)
            finish{i, j} = e;
        end
    end
    
    mt = cell(1, TM);
    for i = 1:TM % 初始化机器最大完成时间数组
        mt{i} = e;
    end
    
    skill = PRO; % 动态熟练度 skill，初始熟练度 PRO
    U = zeros(TW, TM);% 初始化工人对机器的经验矩阵
    Forget = zeros(TW, TM); % 初始化工人对其他机器的遗忘效应
    forget_time = zeros(TW, TM); % 初始化工人对其他机器的遗忘时间
    
    s1 = pro_m;
    s2 = zeros(1, SH);
    p = zeros(1, N);
    
    % 记录工人是否在同一时间段内在其他机器上进行了加工
    worker_busy = cell(TW, TM);

    for i = 1:SH
        %disp(p(s1(i)))
        p(s1(i)) = p(s1(i)) + 1; % 记录过程是否加工完成，完成一次加一
        s2(i) = p(s1(i)); % 记录加工过程中工件的次数
    end
    
    total = e;
    worker_time = zeros(1, TW); % 用于记录每个工人的累计加工时间
    worker_load = zeros(1, TW); % 用于记录每个工人的当前工作负载
    for i = 1:SH
        t1 = s1(i); % 记录当前是哪个工件
        t2 = s2(i); % 记录当前工件是加工到第几次
        mm(i) = mac_m(1, sum(H(1, 1:t1 - 1)) + t2); % 提取该工序该次加工的机器选择
        machine = mm(i);
        workers = wor_m(sum(H(1, 1:t1 - 1)) + t2);% 获取参与加工的工人
        num_workers = numel(workers{1}); % 获取参与加工的工人数量
        worker_time_sum = 0;
        worker_busy_time = zeros(1, num_workers); % 用于记录每个工人的最早释放时间
        for k = 1:num_workers
            worker = workers{1}(k);
            
            % 检查工人在所有机器上的忙碌状态，记录最晚释放时间
            max_release_time = 0; % 初始化为0，表示工人完全空闲
            for m = 1:TM
                %{if (worker_busy{worker, m} > mt{machine}) && (worker_busy{worker, m} > max_release_time) % 工人被其他机器占用
                if (worker_busy{worker, m} > max_release_time) % 获取工人最近一次加工时间      
                    max_release_time = worker_busy{worker, m}; % 找到这些机器中最晚释放的时间
                end
            end
            
            worker_busy_time(k) = max_release_time; % 记录工人的最晚释放时间
            %disp(['被占用工人的最晚释放时间：', num2str(worker_busy_time(k))]);
        end
        start_time = max(max(worker_busy_time), finish{s1(i), max(1, s2(i) - 1)}); % 取所有工人的最早释放时间中的最大值 和 上工序完成时间 较大者

        % 更新工人的遗忘效益
        for k = 1:num_workers
            worker = workers{1}(k);
            for m = 1:TM
                if last_job(worker, m, 1) > 0 % 如果工人在其他机器上有加工记录
                    prev_job = last_job(worker, m, 1); % 工人上一次在该机器上加工的工件
                    prev_process = last_job(worker, m, 2); % 工人上一次在该机器上加工的工序
                    forget_time(worker, m) = max(start_time - finish{prev_job, prev_process}, 0);
                    if forget_time(worker, m)>0 && U(worker, m)>0
                        exp_ect=((-Frate(worker) * (1 - Sim(prev_job, s1(i)))) * forget_time(worker, m));
                        Forget(worker, m) = 1 - exp(exp_ect); % 计算遗忘效应
                        %skill(worker, m)=max(skill(worker, m)*(Forget(worker, m)+((1-Forget(worker, m))*U(worker, m)^Lrate(worker))),min_skill);%更新遗忘效应对技能熟练度的影响
                        skill(worker, m)=min((Forget(worker, m)+((1-Forget(worker, m))*U(worker, m)^Lrate(worker))),max_skill);%更新遗忘效应对技能熟练度的影响
                    end
                end

            end
        end

        for k = 1:num_workers
            worker = workers{1}(k);
            % 计算每个工人的加工时间
            worker_time_sum = worker_time_sum + 1 / (skill(worker, machine) * time{s1(i), s2(i), machine});
            
            % 计算工人对机器的经验U
            prev_job = last_job(worker, machine,1); % 工人上一次在该机器上加工的工件
            if prev_job > 0 % 如果工人不是第一次在该机器上加工
                U(worker, machine) = U(worker, machine)+Sim(prev_job, s1(i)); % 计算经验U
                % 更新工人对机器的技能熟练度
                skill(worker, machine) = max(PRO(worker, machine) * ((1 - B) * U(worker, machine)^Lrate(worker)+B), min_skill);
            else
                U(worker, machine) = 1;
            end

        end
        
        actime = num_workers / worker_time_sum; % 实际加工时间
        current_sum_time=sum(worker_time)+actime;
        for k = 1:num_workers
            worker = workers{1}(k);
            worker_time(worker) = worker_time(worker) + (actime/ num_workers); % 更新每个工人的累计加工时间
            worker_load(worker)=worker_time(worker)/current_sum_time;
        end
        if all(t1 == Oi) && all(t2 == Oj)
            break;
        end
        if mt{machine} < start_time % 如果机器最大完成时间小于该工序上一步完成时间
            mt{machine} = start_time + actime; % 机器的完工时间即为开始时间加实际执行时间
            finish{s1(i), s2(i)} = mt{machine}; % 机器的完工时间即为工序/工人组合的完工时间
            total = total + actime;
        else % 如果机器完成时间大于等于该工件上一个工序的完成时间
            mt{machine} = mt{machine} + actime;
            finish{s1(i), s2(i)} = mt{machine}; % 更新工人组合的完成时间
            total = total + actime;
        end
                
        % 更新工人上一次在该机器上加工的工件和工序
        for k = 1:num_workers
            worker = workers{1}(k);
            last_job(worker, machine, 1) = s1(i); % 更新工件信息
            last_job(worker, machine, 2) = s2(i); % 更新工序信息
        end
        
        % 更新工人忙碌状态
        for k = 1:num_workers
            worker = workers{1}(k);
            worker_busy{worker, mm(i)} = finish{s1(i), s2(i)};
        end
    end
end
