    function [wchrom] = WorkerMutation(wchrom,mchrom)
    global MW Wmax PRO;

    % 随机选择两个位置
    idx1 = randi(numel(wchrom));
    idx2 = randi(numel(wchrom));
    while idx2 == idx1
        idx2 = randi(numel(wchrom));
    end

    % 获取两个位置对应的机器
    machine1 = mchrom(1,idx1);
    machine2 = mchrom(1,idx2);

    % 获取两个位置的可选工人集合
    available_workers1 = MW{machine1};
    available_workers2 = MW{machine2};

    % 变异方式1和变异方式2的选择
    if rand < 0.5 || isempty(setdiff(available_workers1, wchrom{idx1})) || isempty(setdiff(available_workers2, wchrom{idx2}))
        % 变异方式1：保持当前协作人数不变
        new_workers1 = [];
        new_workers2 = [];

        % 位置1的变异
        if numel(available_workers1) > numel(wchrom{idx1})
            unselected_workers1 = setdiff(available_workers1, wchrom{idx1});
            if ~isempty(unselected_workers1)
                new_workers_count1 = min(randi([1, numel(unselected_workers1)]), numel(available_workers1) - numel(wchrom{idx1}));
                new_workers1 = unselected_workers1(randperm(numel(unselected_workers1), new_workers_count1));
            end
        end

        % 位置2的变异
        if numel(available_workers2) > numel(wchrom{idx2})
            unselected_workers2 = setdiff(available_workers2, wchrom{idx2});
            if ~isempty(unselected_workers2)
                new_workers_count2 = min(randi([1, numel(unselected_workers2)]), numel(available_workers2) - numel(wchrom{idx2}));
                new_workers2 = unselected_workers2(randperm(numel(unselected_workers2), new_workers_count2));
            end
        end

        % 更新工人码
        if ~isempty(new_workers1)
           % 如果 new_workers1 是矩阵，则将其转换为行向量
            if size(new_workers1, 1) > 1
                new_workers1 = reshape(new_workers1.', 1, []);
            end
            wchrom{idx1} = [wchrom{idx1}, new_workers1];
        end
        if ~isempty(new_workers2)
            if size(new_workers2, 1) > 1
                new_workers2 = reshape(new_workers2.', 1, []);
            end
            wchrom{idx2} = [wchrom{idx2}, new_workers2];
        end
    else
        % 变异方式2：随机改变协作人数
        collaborators1 = numel(wchrom{idx1});
        collaborators2 = numel(wchrom{idx2});

        % 位置1的变异
        new_collaborators1 = randi([1, min([collaborators1, Wmax(machine1), numel(available_workers1)])]);
        if new_collaborators1 > collaborators1
            if ~isempty(setdiff(available_workers1, wchrom{idx1}))
                [~, sorted_indices] = sort(PRO(available_workers1, machine1), 'ascend');
                additional_workers1 = available_workers1(sorted_indices(1:(new_collaborators1 - collaborators1)));
                wchrom{idx1} = [wchrom{idx1}, additional_workers1];
            end
        elseif new_collaborators1 < collaborators1
            [~, sorted_indices] = sort(PRO(wchrom{idx1}, machine1), 'descend');
            wchrom{idx1} = wchrom{idx1}(sorted_indices(1:new_collaborators1));
        end

        % 位置2的变异
        new_collaborators2 = randi([1, min([collaborators2, Wmax(machine2), numel(available_workers2)])]);
        if new_collaborators2 > collaborators2
            if ~isempty(setdiff(available_workers2, wchrom{idx2}))
                [~, sorted_indices] = sort(PRO(available_workers2, machine2), 'ascend');
                additional_workers2 = available_workers2(sorted_indices(1:(new_collaborators2 - collaborators2)));
                wchrom{idx2} = [wchrom{idx2}, additional_workers2];
            end
        elseif new_collaborators2 < collaborators2
            [~, sorted_indices] = sort(PRO(wchrom{idx2}, machine2), 'descend');
            wchrom{idx2} = wchrom{idx2}(sorted_indices(1:new_collaborators2));
        end
    end
end
