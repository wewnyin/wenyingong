function tFrontNo = tNCDSort(PopObj,PopCon,W,fr)
% theta-non-constrained-dominated sorting

    N  = size(PopObj,1);
    NW = size(W,1);
    
    [z,znad] = deal(min(PopObj),max(PopObj));
    [z_c,znad_c] = deal(min(PopCon),max(PopCon));
    %% Normalization
    [PopObj,PopCon] = Normalization(PopObj,PopCon,z,znad,z_c,znad_c);

    %% Calculate the d1 d2 and d3 values for each solution to each weight
    normP  = sqrt(sum(PopObj.^2,2));
    Cosine = 1 - pdist2(PopObj,W,'cosine');
    d1     = repmat(normP,1,size(W,1)).*Cosine;
    d2     = repmat(normP,1,size(W,1)).*sqrt(1-Cosine.^2);
    d3     = sum(max(0,PopCon),2);
    
    %% Clustering
    [~,class] = min(d2,[],2);
    %d = d1(:,class);
    %% Sort
    theta = zeros(1,NW) + 5;
    theta(sum(W>1e-4,2)==1) = 1e6;
    tFrontNo = zeros(1,N);
    for i = 1 : NW
        C = find(class==i);
        %[~,rank] = sort(d1(C,i)+theta(i)*d2(C,i)+d3(i));
        [~,rank] = sort(d1(C,i)+theta(i)*d2(C,i)+(1-fr)*d3(i));
        %[~,rank] = sort(d1(C,i)+theta(i)*d2(C,i)+(1.5-fr)*d3(i));
        tFrontNo(C(rank)) = 1 : length(C);
    end
end