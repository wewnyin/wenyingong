function CtDEA(Global)
% <algorithm> <A-C>
% CPBI + ��-dominance based evolutionary algorithm

    %% Generate the reference points and random population
    [W,Global.N] = UniformPoint(Global.N,Global.M);
    Population   = Global.Initialization();
    [z,znad]     = deal(min(Population.objs),max(Population.objs));
    [z_c,znad_c] = deal(min(Population.cons),max(Population.cons));

    %% Optimization
    while Global.NotTermination(Population) 
        %MatingPool = TournamentSelection(2,Global.N,tFrontNo,d1);
        MatingPool = randi(Global.N,1,Global.N);
        Offspring  = GA(Population(MatingPool));
        [Population,z,znad,z_c,znad_c] = EnvironmentalSelection([Population,Offspring],W,Global.N,z,znad,z_c,znad_c);
    end
end