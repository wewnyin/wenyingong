function [Population,z,znad,z_c,znad_c] = EnvironmentalSelection(Population,W,N,z,znad,z_c,znad_c)
% The environmental selection of theta-DEA

    %% Non-dominated sorting
    [FrontNo,MaxFNo] = NDSort(Population.objs,Population.cons,N);
    St = find(FrontNo<=MaxFNo);

    %% Normalization
    [PopObj,PopCon,z,znad,z_c,znad_c] = Normalization(Population(St).objs,Population(St).cons,z,znad,z_c,znad_c);
    CV      = sum(max(0,PopCon),2);
    fr      = sum(CV==0)/N;
  
    %% theta-non-dominated sorting
    tFrontNo = tNCDSort(PopObj,PopCon,W,fr);
    MaxFNo    = find(cumsum(hist(tFrontNo,1:max(tFrontNo)))>=N,1);
    LastFront = find(tFrontNo==MaxFNo);
    LastFront = LastFront(randperm(length(LastFront)));
    tFrontNo(LastFront(1:sum(tFrontNo<=MaxFNo)-N)) = inf;
    Next      = St(tFrontNo<=MaxFNo);
    % Population for next generation
    Population = Population(Next);
end