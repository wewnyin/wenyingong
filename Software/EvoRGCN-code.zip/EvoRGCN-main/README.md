# EvoRGCN
“Evolution-Driven Randomized Graph Convolutional Networks”, Under review by TSMCA

## Requirement ##

- torch >= 1.7.0
- torch-geometric >= 1.6.3
- numpy >= 1.19.4
- scikit-learn >= 0.23.1