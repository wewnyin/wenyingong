// BBO_method.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "BBO.h"

void welcome();

int main(int argc, char* argv[])
{
	welcome();

	double seed = 0.0;

	int method;
	int RUN_NUMBER;
	
	printf("method = ");
	method = 1;
	cin>>method;
	
	printf("\nPlease enter the max run number.\n");
	printf("RUN_NUMBER = ");
	RUN_NUMBER = 1;
	cin>>RUN_NUMBER;

	srand((unsigned)time(NULL));

	CBBO *BBO_method;
	for (int i=0;i<RUN_NUMBER;i++)
	{
		int t = output_counter;	
		int k = t*RUN_NUMBER;
		printf("--------- Run no. is %d ---------\n", k+i+1);
		//seed = ((double)(k+i+1))/((double)RUN_NUMBER);
		seed = ((double)(k+i+1))/50.0;		// ............
		if (RUN_NUMBER == 1)
		{
			seed = 0.86564;
		}
		//seed = ((double)(46+1))/50.0;			// test seed
		//seed = (double)(rand()%1000)/1000.0;	// test seed
		if (seed == 0.0)
		{
			seed = 0.001;
		}
		if (seed == 1.0)
		{
			seed = 0.99;
		}

		BBO_method = new CBBO;
		BBO_method->Run_Optimizer(k+i, seed, method);
		delete BBO_method;

		if ((i+1)%100 == 0 && (i+1) != RUN_NUMBER)	// pause
		{
			printf("\nPlease press ENTER key to continue.\n");
			getchar();
		}
	}
	
	return 0;
}

void welcome()
{
	printf("\n");
	printf("***************************************************************\n");
	printf("*             Welcome to use the BBO optimizers.              *\n");
	printf("*        You can select and use the following optimizer.      *\n");
	printf("*                method = 1   for BBO                         *\n");
	printf("*                method = 2   for BBO-DE                      *\n");
	printf("*                method = 3   for BBO-DE1                     *\n");
	printf("*                method = 4   for BBO-EP                      *\n");
	printf("*                method = 5   for BBO-EP1                     *\n");
	printf("*                method = 6   for BBO-EP2                     *\n");
	printf("*                method = 7   for EP                          *\n");
	printf("*                method = 8   for BBO-DE2                     *\n");
	printf("***************************************************************\n");
	printf("\n");
}
