// BBO.cpp: implementation of the CBBO class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "BBO.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

#define PRECISION		1e-8			// ���㾫��
#define out_internal	25				// ������Ƶ��

CBBO::CBBO()
{
	max_iterations = Max_of_NFEs/population_size;
	max_NFFEs = Max_of_NFEs;
	pop_size  = population_size;

	parent_pop = new CIndividual[pop_size+pop_size];
	child_pop  = new CIndividual[2*pop_size];
	upper_bounds = new double[N_of_x];
	lower_bounds = new double[N_of_x];

	// -------------------- only for BBO method --------------------
	flag_prob = 1;			// use the mutation or not
	p_modify = 1.0;
	p_mutate = 0.005;
	elitism_size = 1;
	elite = new CIndividual[pop_size];
	lambdaLower = 0.0;
	lambdaUpper = 1.0;
	dt = 1.0;
	II = 1.0;
	EE = 1.0;

	prob = new double[pop_size];
	lambda = new double[pop_size];
	mu  = new double[pop_size];
	sort_index = new int[2*pop_size];
	ProbDot = new double[pop_size];
	// -------------------- only for BBO method --------------------
}

CBBO::~CBBO()
{
	delete []parent_pop;
	delete []child_pop;
	delete []upper_bounds;
	delete []lower_bounds;

	// -------------------- only for BBO method --------------------
	delete []elite;
	delete []prob;
	delete []lambda;
	delete []mu;
	delete []sort_index;
	delete []ProbDot;
	// -------------------- only for BBO method --------------------
}

void CBBO::init_variables()
{
	int i;
	int n = N_of_x;
	func_flag = index_of_prob;

	switch(func_flag) {
	case 1:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -100.0;
			upper_bounds[i] = 100.0;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 2:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -10.0;
			upper_bounds[i] = 10.0;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 3:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -100.0;
			upper_bounds[i] = 100.0;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 4:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -100.0;
			upper_bounds[i] = 100.0;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 5:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -30.0;
			upper_bounds[i] = 30.0;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 6:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -100.0;
			upper_bounds[i] = 100.0;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 7:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -1.28;
			upper_bounds[i] = 1.28;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 8:// -418.982887272434*D
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -500.0;
			upper_bounds[i] = 500.0;
		}
		known_optimal = -418.982887272433*N_of_x;	// 7.27595761418343e-012
		MINIMIZE = 1;
		break;
	case 9:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -5.12;
			upper_bounds[i] = 5.12;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 10:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -32.0;
			upper_bounds[i] = 32.0;
		}
		known_optimal = 5.88721779659629e-016;
		MINIMIZE = 1;
		break;
	case 11:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -600.0;
			upper_bounds[i] = 600.0;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 12:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -50.0;
			upper_bounds[i] = 50.0;
		}
		known_optimal = 1.57044103551786e-032;
		MINIMIZE = 1;
		break;
	case 13:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -50.0;
			upper_bounds[i] = 50.0;
		}
		known_optimal = 1.34969464963992e-032;
		MINIMIZE = 1;
		break;
	default:
		printf("The function you selected does not exist.\n");
		exit(0);
	}
}

void CBBO::init_pop()
{
	printf("Random based parent_pop initialization method is used.\n");
	init_pop_random();
}

void CBBO::init_pop_random()
{
	int i,j;

	for (i=0;i<pop_size;i++)
	{
		for (j=0;j<N_of_x;j++)
		{
			parent_pop[i].xreal[j] = m_rnd.rndreal(lower_bounds[j],upper_bounds[j]);
		}
	}

	evaluate_pop(parent_pop, pop_size);
}

void CBBO::evaluate_ind(CIndividual &indv)
{
	int i=0;
	func_flag = index_of_prob;
	switch(func_flag) {
	case 1:
		m_func.test_01(indv.xreal,indv.obj,indv.constr);
		break;
	case 2:
		m_func.test_02(indv.xreal,indv.obj,indv.constr);
		break;
	case 3:
		m_func.test_03(indv.xreal,indv.obj,indv.constr);
		break;
	case 4:
		m_func.test_04(indv.xreal,indv.obj,indv.constr);
		break;
	case 5:
		m_func.test_05(indv.xreal,indv.obj,indv.constr);
		break;
	case 6:
		m_func.test_06(indv.xreal,indv.obj,indv.constr);
		break;
	case 7:
		m_func.test_07(indv.xreal,indv.obj,indv.constr);
		break;
	case 8:
		m_func.test_08(indv.xreal,indv.obj,indv.constr);
		break;
	case 9:
		m_func.test_09(indv.xreal,indv.obj,indv.constr);
		break;
	case 10:
		m_func.test_10(indv.xreal,indv.obj,indv.constr);
		break;
	case 11:
		m_func.test_11(indv.xreal,indv.obj,indv.constr);
		break;
	case 12:
		m_func.test_12(indv.xreal,indv.obj,indv.constr);
		break;
	case 13:
		m_func.test_13(indv.xreal,indv.obj,indv.constr);
		break;
	default:
		printf("The function you selected does not exist.\n");
		exit(0);
		break;
	}

	// convert objective function value into fitness
	indv.fitness = MINIMIZE*indv.obj;

	// sum violation of the constrained functions
	if (N_of_constr == 0)
	{
		indv.constr_violation = 0.0;
		indv.feasible = 1;
	}

	evaluations++;		// increase the number of fitness function evaluations
}

void CBBO::evaluate_pop(CIndividual *pop, int size)
{
	for (int i=0;i<size;i++)
	{
		evaluate_ind(pop[i]);
	}
}

int CBBO::compare_ind (CIndividual *indv1, CIndividual *indv2)
{
	if((indv1->feasible==TRUE && indv2->feasible==TRUE))
	{
		if(indv1->fitness < indv2->fitness)
		{
			return 1;
		}
		else if (indv1->fitness > indv2->fitness)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
	else if(indv1->feasible==TRUE && indv2->feasible==FALSE)
	{
		return 1;
	}
	else if (indv1->feasible==FALSE && indv2->feasible==TRUE)
	{
		return -1;
	}
	else
	{
		if(indv1->constr_violation < indv2->constr_violation)
		{
			return 1;
		}
		else if (indv1->constr_violation > indv2->constr_violation)
		{
			return -1;
		}
		else
		{
			//return 0;
			if (indv1->fitness < indv2->fitness)
			{
				return 1;
			}
			else if (indv1->fitness > indv2->fitness)
			{
				return -1;
			}
			else
			{
				return 0;
			}
		}
	}
}

void CBBO::find_best_and_worst_index(CIndividual *pop, int size)
{
	int flag;

	best_index = 0;
	for (int i=1;i<size;i++)
	{
		flag = compare_ind(&pop[i], &pop[best_index]);
		if (flag == 1)
		{
			best_index = i;
		}
	}

	worst_index = 0;
	for (i=1;i<size;i++)
	{
		flag = compare_ind(&pop[i], &pop[worst_index]);
		if (flag == -1)
		{
			worst_index = i;
		}
	}
}

/* -------- other methods used for different algorithms -------- */
void CBBO::random_index(int *array_index, int all_size, int size)
{
	int i,j,krand;
	int *a;
	if ((a = (int *) malloc(all_size*sizeof(int))) == NULL)
	{
		printf("Malloc Error!");
		exit(0);
	}
	for(i = 0;i<all_size;i++)
	{
		a[i] = i;
	}
	for(i=0;i<size;i++)
	{
		j = m_rnd.rndint(i,(all_size-1));
		krand = a[i];
		a[i] = a[j];
		a[j] = krand;
	}	
	for(i=0;i<size;i++)
	{
		array_index[i] = a[i];
	}
	a = NULL;
}

void CBBO::bubble_sort(CIndividual *pop, int *list, int size)
{
	int i,j, temp;
	int dbest;

	for (i=0;i<size-1;i++)
	{
		dbest = list[i];
		for (j=i+1;j<size;j++)
		{
			if (compare_ind(&pop[list[j]], &pop[dbest]) == 1)
			{
				dbest = list[j];
				temp = list[j];
				list[j] = list[i];
				list[i] = temp;
			}
		}
	}
}

void CBBO::shell_sort(CIndividual *pop, int *list, int size)
{
	int done;
	int step, bound, i, j;
	int temp;

	step = size;  // array length
	while (step > 1) 
	{
		step /= 2;	//halve the step size
		do 
		{
			done   = 1;
			bound  = size - step;
			for (j = 0; j < bound; j++) 
			{
				i = j + step + 1;
				if (compare_ind(&pop[list[j]], &pop[list[i-1]]) == -1) 	
				{
					temp      = list[i-1];
					list[i-1] = list[j];
					list[j]   = temp;
					done = 0; // if a swap has been made we are not finished yet
				}  // if
			}  // for
		} while (done == 0);   // while
	} //while (step > 1)
}

void CBBO::display_result(int gen)
{
	if(gen%10==0 || gen == 1)
	{
		//��ǰ��ø����������Ļ
		cout<<setw(5)<<gen;
		cout<<setw(8)<<evaluations;
		//��ʾԼ��������ֵ
		if (N_of_constr != 0)
		{			
			cout<<setw(15)<<best_individual.constr_violation;
		}
		cout.precision(10);					//�����������
		cout<<setw(20)<<MINIMIZE * parent_pop[best_index].fitness;
		cout<<setw(20)<<MINIMIZE * parent_pop[m_rnd.rndint(0, pop_size-1)].fitness;
		cout<<setw(20)<<MINIMIZE * parent_pop[worst_index].fitness<<endl;
	}
}

void CBBO::report_result(int gen, ofstream &file)
{
	if (gen < 100 )
	{
		//��ǰ��ø���������ļ�
		file<<setw(5)<<gen;
		file<<setw(10)<<evaluations;
		file.precision(20);			//�����������
		file<<setw(30)<<MINIMIZE * best_individual.fitness;
		file<<setw(30)<<best_individual.constr_violation<<endl;
	}
	else
	{
		if ((gen % out_internal == 0 ||
			gen >= max_iterations ||
			evaluations >= max_NFFEs) )
		{
			//��ǰ��ø���������ļ�
			file<<setw(5)<<gen;
			file<<setw(10)<<evaluations;
			file.precision(20);			//�����������
			file<<setw(30)<<MINIMIZE * best_individual.fitness;
			file<<setw(30)<<best_individual.constr_violation<<endl;
		}
	}
}

void CBBO::report_diversity(int gen, ofstream &file)
{
	// calculate the diversity of the population
	double x_average[200];
	for (int i=0;i<200;i++)
	{
		x_average[i] = 0.0;
	}

	for (i=0;i<N_of_x;i++)
	{
		for (int j=0;j<pop_size;j++)
		{
			x_average[i] += parent_pop[j].xreal[i];
		}
		x_average[i] = x_average[i]/((double)pop_size);
	}

	double diversity = 0.0;
	for (i=0;i<pop_size;i++)
	{
		double temp = 0.0;
		for (int j=0;j<N_of_x;j++)
		{
			temp += (parent_pop[i].xreal[j]-x_average[j])
				*(parent_pop[i].xreal[j]-x_average[j]);
		}
		diversity += sqrt(temp);
	}
	diversity = diversity/((double)pop_size);

	pop_diversity = diversity;
	
	if (gen < 200 )
	{
		//��ǰ��ø���������ļ�
		file<<setw(5)<<gen;
		file<<setw(10)<<evaluations;
		file.precision(20);			//�����������
		file<<setw(30)<<diversity<<endl;
	}
	else
	{
		if ((gen % out_internal == 0 ||
			gen >= max_iterations ||
			evaluations >= max_NFFEs) )
		{
			//��ǰ��ø���������ļ�
			file<<setw(5)<<gen;
			file<<setw(10)<<evaluations;
			file.precision(20);			//�����������
			file<<setw(30)<<diversity<<endl;
		}
	}
}

void CBBO::Run_Optimizer(int run_no, double seed, int method)
{
	int i = 0; 
	
	method_flag = method;
	rnd_seed = seed;

	ofstream SummaryFile;
	SummaryFile.open(".\\results\\summary.txt",ios::app);

	char f_name1[150];
	sprintf(f_name1,"%s%d%s",".\\results\\process\\process_",run_no+1,".txt");		
	ofstream file_process(f_name1);

	char f_name2[150];
	sprintf(f_name2,"%s%d%s",".\\results\\diversity\\diversity_",run_no+1,".txt");		
	ofstream file_diversity(f_name2);

	clock_t start, finish;
	double time_consume;

	time_consume = 0.0;
	start = clock();						// starts the clock
	
	srand((unsigned)time(0));
	m_rnd.randomize(seed);

	evaluations = 0;						// reset the NFFEs

	init_variables();
	init_pop();								// the population is evaluated here
	find_best_and_worst_index(parent_pop, pop_size);
	best_individual = parent_pop[best_index];

	gen = 1;								// current generation number

	// -------------------- only for BBO method --------------------
	// sort the population from more fit to less fit
	Population_Sort(parent_pop, pop_size);

	// Initialize the species count probability of each habitat
	// Later we might want to initialize probabilities based on cost
	for (i=0;i<pop_size;i++)
	{
		prob[i] = 1.0/pop_size;
	}
	// -------------------- only for BBO method --------------------

	report_result(gen, file_process);
	report_diversity(gen, file_diversity);

	int feasible_flag = 0;					// check to get the feasible individual first
	flag_precision = 0;						// check to arrive the required value
	/* -------- add different optimizer here -------- */
	while ( (evaluations < max_NFFEs) && (gen < max_iterations) )
	{
		finish = clock();					// time consuming of this generation
		time_consume = (double)(finish-start)/1000.0;

		// report the results in the screen
		/* comment the following routines to save the time_consuming */
		//display_result(gen);

		// ADD YOUR OPTIMIZER HERE
		switch(method) {
		case 1:// BBO method
			run_BBO();
			break;
		case 2:// BBO-EP method
			run_BBO_EP();
			break;
		default:
			printf("The method selected does not exist.\n");
			exit(0);
		}

		gen++;

		find_best_and_worst_index(parent_pop, pop_size);
		best_individual = parent_pop[best_index];
		
		report_result(gen, file_process);
		report_diversity(gen, file_diversity);

		if (flag_precision == 0 && MINIMIZE*best_individual.fitness - known_optimal < PRECISION)
		{
			flag_precision = 1;
			ofstream SummaryFile1;
			SummaryFile1.open(".\\results\\evaluations.txt",ios::app);			
			SummaryFile1<<setw(9)<<evaluations<<endl;
			SummaryFile1.close();
		}
		if (N_of_constr != 0 && feasible_flag == 0 && best_individual.feasible == 1)
		{
			feasible_flag = 1;
			ofstream SummaryFile1;
			SummaryFile1.open(".\\results\\feasible_NFFEs.txt",ios::app);
			SummaryFile1<<setw(9)<<evaluations<<endl;
			SummaryFile1.close();
		}
	}
	/* -------- add different optimizer here -------- */
	
	printf("The total running time is %f s.\n", time_consume);
	printf("The routine exits successfully.\n\n");

	SummaryFile.precision(15);
	SummaryFile<<setw(5)<<gen<<setw(9)<<evaluations
		<<setw(25)<<MINIMIZE * best_individual.fitness
		<<setw(8)<<time_consume
		<<setw(25)<<best_individual.constr_violation<<endl;
		
	file_process.close();
	file_diversity.close();
	SummaryFile.close();
	
	return;
}

// -------------------- only for BBO method --------------------
void CBBO::Population_Sort(CIndividual *pop, int size)
{
	for (int i=0;i<size;i++)
	{
		sort_index[i] = i;
	}
	shell_sort(pop, sort_index, size);
}

void CBBO::GetSpeciesCounts(CIndividual *pop, int size)
{
	// Map cost values to species counts.
	// This loop assumes the population is already sorted from most fit to least fit.
	for (int i=0;i<size;i++)
	{
		if (pop[sort_index[i]].fitness < INF)
		{
			pop[sort_index[i]].SpeciesCount = (size-i);
		}
		else
		{
			pop[sort_index[i]].SpeciesCount = 0;
		}
	}
}

void CBBO::GetLambdaMu(CIndividual *pop, int size)
{
	// Compute immigration rate and extinction rate for each species count.
	// lambda(i) is the immigration rate for individual i.
	// mu(i) is the extinction rate for individual i.
	int i;
	double ee = 1.0;
	for (i=0;i<size;i++)
	{
		double temp = (double)pop[sort_index[i]].SpeciesCount/size;
		lambda[i] = II*(1.0-pow(temp, ee));
		mu[i] = EE*(pow(temp, ee));
	}
}

void CBBO::FeasibleFunction(CIndividual *pop, int size)
{
	int i, j;
	for (i=0;i<size;i++)
	{
		for (j=0;j<N_of_x;j++)
		{
			parent_pop[i].xreal[j] = max(parent_pop[i].xreal[j], lower_bounds[j]);
			parent_pop[i].xreal[j] = min(parent_pop[i].xreal[j], upper_bounds[j]);
		}
	}
}

int CBBO::IsEqual(CIndividual &indv1, CIndividual &indv2)
{
	int i;
	int flag = 1;

	for (i=0;i<N_of_x;i++)
	{
		if (fabs(indv1.xreal[i]-indv2.xreal[i]) != 0.0)
		{
			flag = 0;
			break;
		}
	}

	return flag;
}

void CBBO::ClearDups(CIndividual *pop, int size)
{
	int i, j;
	int flag;
	int k;
	for (i=0;i<size-1;i++)
	{
		for (j=i+1;j<size;j++)
		{
			flag = IsEqual(pop[i], pop[j]);
			if (flag == 1)
			{
				k = m_rnd.rndint(0, N_of_x-1);
				pop[j].xreal[k] = lower_bounds[k]+
					(upper_bounds[k]-lower_bounds[k])*m_rnd.rndreal(0.0, 1.0);
			}
		}
	}
}

void CBBO::run_BBO()
{
	int i, j;
	// Save the best habitats in a elite array.
	// Remember: the population is sorted from more fit to less fit
	for (i=0;i<elitism_size;i++)
	{
		elite[i] = parent_pop[sort_index[i]];
	}

	// Map cost values to species counts.
	GetSpeciesCounts(parent_pop, pop_size);

	// Compute immigration rate and emigration rate for each species count.
	GetLambdaMu(parent_pop, pop_size);

	// 1. Modification operator
	// Now use lambda and mu to decide how much information to share between habitats.
	double lambdaMin = lambda[0];
	double lambdaMax = lambda[0];
	for (j=1;j<pop_size;j++)
	{
		if (lambda[j] < lambdaMin)
		{
			lambdaMin = lambda[j];
		}
		if (lambda[j] > lambdaMax)
		{
			lambdaMax = lambda[j];
		}
	}
	double sum_mu = 0.0;
	for (int k=0;k<pop_size;k++)
	{
		sum_mu += mu[k];
	}
	for (i=0;i<pop_size;i++)
	{
		if (m_rnd.rndreal(0,1) > p_modify)
		{
			child_pop[i] = parent_pop[sort_index[i]];
			continue;
		}
		// Normalize the immigration rate.
		double lambdaScale;
		lambdaScale = lambdaLower + 
			(lambdaUpper-lambdaLower)*(lambda[i]-lambdaMin)/(lambdaMax-lambdaMin);
		// Probabilistically input new information into habitat i
		for (j=0;j<N_of_x;j++)
		{
			if (m_rnd.rndreal(0,1) < lambdaScale)
			{
				// Pick a habitat from which to obtain a feature
				double RandomNum;
				RandomNum = m_rnd.rndreal(0,1)*sum_mu;
				double Select;
				int SelectIndex;
				Select = mu[0];
				SelectIndex = 0;
				while ( (RandomNum > Select) && (SelectIndex < pop_size) )
				{
					SelectIndex = SelectIndex + 1;
					Select = Select + mu[SelectIndex];
                }

				// modify the selected habitat (share information)
				child_pop[i].xreal[j] = parent_pop[sort_index[SelectIndex]].xreal[j];
			}
			else
			{
				child_pop[i].xreal[j] = parent_pop[sort_index[i]].xreal[j];
			}
		}
	}

	if (flag_prob == 1)
	{
		// Compute the time derivative of Prob(i) for each habitat i.
		for (j=0;j<pop_size;j++)
		{
			// Compute lambda for one less than the species count of habitat i.
			double lambdaMinus;
			lambdaMinus = II * (1.0 -(double)(parent_pop[sort_index[j]].SpeciesCount - 1)/pop_size);
			// Compute mu for one more than the species count of habitat i.
            double muPlus;
			muPlus = EE * ((double)(parent_pop[sort_index[j]].SpeciesCount + 1)/pop_size);
			// Compute Prob for one less than and one more than the species count of habitat i.
			// Note that species counts are arranged in an order opposite to that presented in
			// MacArthur and Wilson's book - that is, the most fit
			// habitat has index 1, which has the highest species count.
			double ProbMinus, ProbPlus;
			if (j < pop_size-1)
			{
				ProbMinus = prob[j+1];
			}
			else
			{
				ProbMinus = 0.0;
			}
			if (j > 0)
			{
				ProbPlus = prob[j-1];
			}
			else
			{
				ProbPlus = 0;
			}
			ProbDot[j] = -(lambda[j]+mu[j]) * prob[j] + 
				lambdaMinus * ProbMinus + muPlus * ProbPlus;
		}

		// Compute the new probabilities for each species count.
		double temp = 0.0;
		for (j=0;j<pop_size;j++)
		{
			prob[j] = prob[j] + ProbDot[j] * dt;
			prob[j] = max(prob[j], 0);

			temp += prob[j];
		}
		for (j=0;j<pop_size;j++)
		{
			prob[j] = prob[j]/temp;
			//printf("%f\n", prob[j]);
		}//getchar();
	}

	// 2. Mutation operator
	if (flag_prob == 1)
	{
		double Pmax = prob[0];
		for (i=1;i<pop_size;i++)
		{
			if (prob[i] > Pmax)
			{
				Pmax = prob[i];
			}
		}
		double MutationRate[1000];
		for (i=0;i<pop_size;i++)
		{
			MutationRate[i] = p_mutate*(1-prob[i]/Pmax);
		}
		// Mutate
		for (i=0;i<pop_size;i++)
		{
			for (j=0;j<N_of_x;j++)
			{
				if (m_rnd.rndreal(0,1) < MutationRate[i])
				{
					double low = lower_bounds[j];
					double up  = upper_bounds[j];
					child_pop[i].xreal[j] = m_rnd.rndreal(low, up);

					if (child_pop[i].xreal[j] < low || child_pop[i].xreal[j] > up)
					{
						child_pop[i].xreal[j] = m_rnd.rndreal(low, up);
					}
				}
				else
				{
					child_pop[i].xreal[j] = child_pop[i].xreal[j];
				}
			}
		}
	}

	// Replace the habitats with their new versions.
	for (i=0;i<pop_size;i++)
	{
		parent_pop[sort_index[i]] = child_pop[i];
	}

	// Evaluate the population
	evaluate_pop(parent_pop, pop_size);

	// Implement the elitist strategy with the G3 model
	int tmp_index[population_size] = {0};
	int list_index[2*population_size];
	random_index(tmp_index, pop_size, elitism_size);
	// updating plan using G3 model
	for (i=0;i<elitism_size;i++)
	{// add the selected parent individuals in the temporary array
		elite[elitism_size+i] = parent_pop[tmp_index[i]];
	}
	for (i=0;i<2*elitism_size;i++)
	{// initialize the sort index
		list_index[i] = i;
	}
	bubble_sort(elite, list_index, 2*elitism_size);
	for (i=0;i<elitism_size;i++)
	{
		parent_pop[tmp_index[i]] = elite[list_index[i]];
	}

	/* Make sure the population does not have duplicates */
	ClearDups(parent_pop, pop_size);	

	// Sort from best to worst
	Population_Sort(parent_pop, pop_size);
}

void CBBO::run_BBO_EP()
{
	int i, j;
	// Save the best habitats in a elite array.
	// Remember: the population is sorted from more fit to less fit
	for (i=0;i<elitism_size;i++)
	{
		elite[i] = parent_pop[sort_index[i]];
	}

	// Map cost values to species counts.
	GetSpeciesCounts(parent_pop, pop_size);

	// Compute immigration rate and emigration rate for each species count.
	GetLambdaMu(parent_pop, pop_size);

	// 1. Modification operator
	// Now use lambda and mu to decide how much information to share between habitats.
	double lambdaMin = lambda[0];
	double lambdaMax = lambda[0];
	for (j=1;j<pop_size;j++)
	{
		if (lambda[j] < lambdaMin)
		{
			lambdaMin = lambda[j];
		}
		if (lambda[j] > lambdaMax)
		{
			lambdaMax = lambda[j];
		}
	}
	double sum_mu = 0.0;
	for (int k=0;k<pop_size;k++)
	{
		sum_mu += mu[k];
	}
	for (i=0;i<pop_size;i++)
	{
		if (m_rnd.rndreal(0,1) > p_modify)
		{
			child_pop[i] = parent_pop[sort_index[i]];
			continue;
		}
		// Normalize the immigration rate.
		double lambdaScale;
		lambdaScale = lambdaLower + 
			(lambdaUpper-lambdaLower)*(lambda[i]-lambdaMin)/(lambdaMax-lambdaMin);
		// Probabilistically input new information into habitat i
		for (j=0;j<N_of_x;j++)
		{
			if (m_rnd.rndreal(0,1) < lambdaScale)
			{
				// Pick a habitat from which to obtain a feature
				double RandomNum;
				RandomNum = m_rnd.rndreal(0,1)*sum_mu;
				double Select;
				int SelectIndex;
				Select = mu[0];
				SelectIndex = 0;
				while ( (RandomNum > Select) && (SelectIndex < pop_size) )
				{
					SelectIndex = SelectIndex + 1;
					Select = Select + mu[SelectIndex];
                }

				// modify the selected habitat (share information)
				child_pop[i].xreal[j] = parent_pop[sort_index[SelectIndex]].xreal[j];
			}
			else
			{
				child_pop[i].xreal[j] = parent_pop[sort_index[i]].xreal[j];
			}
		}
	}

	if (flag_prob == 1)
	{
		// Compute the time derivative of Prob(i) for each habitat i.
		for (j=0;j<pop_size;j++)
		{
			// Compute lambda for one less than the species count of habitat i.
			double lambdaMinus;
			lambdaMinus = II * (1.0 -(double)(parent_pop[sort_index[j]].SpeciesCount - 1)/pop_size);
			// Compute mu for one more than the species count of habitat i.
            double muPlus;
			muPlus = EE * ((double)(parent_pop[sort_index[j]].SpeciesCount + 1)/pop_size);
			// Compute Prob for one less than and one more than the species count of habitat i.
			// Note that species counts are arranged in an order opposite to that presented in
			// MacArthur and Wilson's book - that is, the most fit
			// habitat has index 1, which has the highest species count.
			double ProbMinus, ProbPlus;
			if (j < pop_size-1)
			{
				ProbMinus = prob[j+1];
			}
			else
			{
				ProbMinus = 0.0;
			}
			if (j > 0)
			{
				ProbPlus = prob[j-1];
			}
			else
			{
				ProbPlus = 0;
			}
			ProbDot[j] = -(lambda[j]+mu[j]) * prob[j] + 
				lambdaMinus * ProbMinus + muPlus * ProbPlus;
		}

		// Compute the new probabilities for each species count.
		double temp = 0.0;
		for (j=0;j<pop_size;j++)
		{
			prob[j] = prob[j] + ProbDot[j] * dt;
			prob[j] = max(prob[j], 0);

			temp += prob[j];
		}
		for (j=0;j<pop_size;j++)
		{
			prob[j] = prob[j]/temp;
		}
	}

	// 2. EP mutation operator
	if (flag_prob == 1)
	{
		double Pmax = prob[0];
		for (i=1;i<pop_size;i++)
		{
			if (prob[i] > Pmax)
			{
				Pmax = prob[i];
			}
		}
		double MutationRate[1000];
		for (i=0;i<pop_size;i++)
		{
			MutationRate[i] = p_mutate*(1-prob[i]/Pmax);
		}
		// Mutate
		for (i=0;i<pop_size;i++)
		{
			for (j=0;j<N_of_x;j++)
			{
				if (m_rnd.rndreal(0,1) < MutationRate[i])
				{
					child_pop[i].xreal[j] = child_pop[i].xreal[j]
						+ m_rnd.noise(0,1);
						//+ m_rnd.cauchy(0,1);
						//+ m_rnd.levy(1);
					double low = lower_bounds[j];
					double up  = upper_bounds[j];
					if (child_pop[i].xreal[j] < low || child_pop[i].xreal[j] > up)
					{
						child_pop[i].xreal[j] = m_rnd.rndreal(low, up);
					}
				}
				else
				{
					child_pop[i].xreal[j] = child_pop[i].xreal[j];
				}
			}
		}
	}

	// Replace the habitats with their new versions.
	for (i=0;i<pop_size;i++)
	{
		parent_pop[sort_index[i]] = child_pop[i];
	}

	// Evaluate the population
	evaluate_pop(parent_pop, pop_size);

	// Implement the elitist strategy with the G3 model
	int tmp_index[population_size] = {0};
	int list_index[2*population_size];
	random_index(tmp_index, pop_size, elitism_size);
	// updating plan using G3 model
	for (i=0;i<elitism_size;i++)
	{// add the selected parent individuals in the temporary array
		elite[elitism_size+i] = parent_pop[tmp_index[i]];
	}
	for (i=0;i<2*elitism_size;i++)
	{// initialize the sort index
		list_index[i] = i;
	}
	bubble_sort(elite, list_index, 2*elitism_size);
	for (i=0;i<elitism_size;i++)
	{
		parent_pop[tmp_index[i]] = elite[list_index[i]];
	}

	/* Make sure the population does not have duplicates */
	ClearDups(parent_pop, pop_size);	

	// Sort from best to worst
	Population_Sort(parent_pop, pop_size);
}
