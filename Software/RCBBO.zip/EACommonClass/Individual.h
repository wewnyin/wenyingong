// Individual.h: interface for the CIndividual class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_INDIVIDUAL_H__A05E59DB_40D8_4282_9D3C_A0201898ACA8__INCLUDED_)
#define AFX_INDIVIDUAL_H__A05E59DB_40D8_4282_9D3C_A0201898ACA8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// global variables (changed with different problems sloved)
#define population_size		100			// size of the population

#define output_counter		0			

#define index_of_prob		1			// the selected problem to be optimized
#define N_of_x				30			// number of the decision variables
#define Max_of_NFEs			150000		// the maximal number of function evaluations
#define N_of_constr			0			// number of the constrained functions

#define flag_of_init_pop	1			// 1: random; 2: orthogonal

class CIndividual  
{
public:
	CIndividual();
	virtual ~CIndividual();

public:
	CIndividual(const CIndividual &);							
	CIndividual &CIndividual::operator=(const CIndividual &);	

public:
	double *xreal;				// Real Coded Decision Variable     
	double obj;					// value of the objective function
	double fitness;				// fitness of the objective function
	double constr_violation;	// parameter for constraint violation
    double *constr;				// defining the constraint values
	int    feasible;			// check the individual is feasible or not (1: feasible; 0: infeasible)
	int    no_of_violation;		// number of the violated constraint functions

	// only for BBO method
	int	   SpeciesCount;
	int	   Modify_flag;
};

#endif // !defined(AFX_INDIVIDUAL_H__A05E59DB_40D8_4282_9D3C_A0201898ACA8__INCLUDED_)
