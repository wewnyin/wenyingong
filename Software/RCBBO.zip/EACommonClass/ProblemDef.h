// ProblemDef.h: interface for the CProblemDef class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_)
#define AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Individual.h"
#include "Rand.h"

// only for unconstrained optimization problems
class CProblemDef  
{
public:
	CProblemDef();
	virtual ~CProblemDef();

	// for unconstrained optimization problems
public:
	double	center[200];
	int		flag_once;
	double	TempValue(double x,int a,int k,int m);

public:
	void test_01(double *xreal,double &obj, double *constr);
	void test_02(double *xreal,double &obj, double *constr);
	void test_03(double *xreal,double &obj, double *constr);
	void test_04(double *xreal,double &obj, double *constr);
	void test_05(double *xreal,double &obj, double *constr);
	void test_06(double *xreal,double &obj, double *constr);
	void test_07(double *xreal,double &obj, double *constr);
	void test_08(double *xreal,double &obj, double *constr);
	void test_09(double *xreal,double &obj, double *constr);
	void test_10(double *xreal,double &obj, double *constr);
	void test_11(double *xreal,double &obj, double *constr);
	void test_12(double *xreal,double &obj, double *constr);
	void test_13(double *xreal,double &obj, double *constr);
	
	// add new test problems here...
};

#endif // !defined(AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_)
