// ProblemDef.cpp: implementation of the CProblemDef class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ProblemDef.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CProblemDef::CProblemDef()
{
	flag_once = 0;
	double c[200] = {-0.7218,0.2966,0.2568,-0.1736,0.9306,0.7528,0.2976,-0.1458,-0.772,0.8638,
			-0.6848,0.4672,0.808,0.1898,-0.0806,0.0116,0.238,-0.2642,0.929,-0.7464,
			0.5252,0.394,0.6492,0.7144,-0.624,0.2602,-0.5962,0.8662,-0.6614,0.7692,
			0.2872,0.7382,0.5548,0.621,-0.689,-0.9764,-0.6014,-0.1244,-0.9528,0.2226,
			-0.3978,0.4172,-0.7128,0.9266,0.933,0.6106,0.4428,-0.4518,-0.5306,0.231,
			-0.206,-0.076,-0.6068,0.163,0.4398,0.0048,0.5108,-0.1546,0.8932,-0.065,
			0.2758,-0.6134,-0.7872,0.3072,-0.7946,0.897,-0.264,0.8604,-0.2176,0.3936,
			0.1496,0.5632,0.0754,0.1784,0.4402,0.9826,0.2974,-0.0948,0.3546,-0.002,
			-0.382,0.4832,-0.2286,-0.324,-0.7596,0.6974,-0.0304,-0.4568,0.843,0.4392,
			0.5342,0.3384,-0.497,0.9298,0.5288,-0.675,-0.4772,-0.4548,-0.6458,-0.3678,
			0.0644,0.676,0.259,-0.5558,-0.5248,-0.3562,-0.0754,-0.8386,-0.8252,-0.5554,
			0.626,0.9792,0.4518,0.1488,0.639,-0.2022,0.2696,0.9012,-0.1744,-0.2394,
			0.845,-0.5038,-0.0594,-0.7888,-0.5306,-0.5262,-0.1372,0.3336,0.5358,0.9036,
			-0.8692,-0.595,-0.653,-0.9458,0.2348,-0.0738,-0.9746,0.7794,0.033,0.4374,
			0.4052,0.3474,-0.46,-0.1664,-0.6324,-0.0926,0.888,0.5788,-0.41,-0.5746,
			0.2462,-0.7596,-0.061,-0.5052,-0.6838,0.1358,-0.5942,-0.8194,0.154,-0.524,
			-0.33,-0.5594,-0.149,-0.7542,-0.1474,-0.054,0.2482,0.2412,0.3468,0.0222,
			0.3256,0.6618,-0.6048,0.0328,-0.969,-0.7104,0.7126,-0.5368,-0.4018,0.971,
			-0.0162,-0.4384,-0.8786,0.631,0.837,0.491,-0.2082,0.4638,-0.552,0.173,
			0.8856,0.2796,-0.3594,0.0956,-0.218,0.545,0.37,-0.27,-0.9858,0.775};
	for (int i=0;i<200;i++)
	{
		center[i] = c[i];
	}
}

CProblemDef::~CProblemDef()
{
}

// only for unconstrained optimization problems
// Ellipsoidal function
void CProblemDef::test_01(double *xreal, double &obj, double *constr)
{
	double x[200];
	for (int j=0;j<N_of_x;j++)
	{
		x[j] = xreal[j]-center[j];
	}
	double fit = 0.0;
	for(int i=0;i<N_of_x;i++)
		fit += ((x[i])*(x[i]));
	obj = fit;
}

// Schwefel's function 2.22
void CProblemDef::test_02(double *xreal, double &obj, double *constr)
{
	double value = 0.0;
	double temp1 = 0.0;
	double temp2 = 1.0;
	double x[200];
	for (int j=0;j<N_of_x;j++)
	{
		x[j] = xreal[j]-center[j];
	}
	for (int i=0;i<N_of_x;i++)
	{
		 temp1 += fabs(x[i]);
		 temp2 *= fabs(x[i]);
	}
	value = temp1+temp2;
	obj = value;
}

// Schwefel's function 1.2
void CProblemDef::test_03(double *xreal, double &obj, double *constr)
{
	double fit = 0.0;
	double sumSCH;
	int i,j;

	double x[200];
	for (j=0;j<N_of_x;j++)
	{
		x[j] = xreal[j]-center[j];
	}
	
	for (i=0;i<N_of_x;i++)
	{
		sumSCH = 0.0;
		for (j=0;j<i+1;j++)
		{
			sumSCH += x[j];
		}
		fit += sumSCH*sumSCH;
	}
	obj = fit;
}

// Schwefel's function 2.21
void CProblemDef::test_04(double *xreal, double &obj, double *constr)
{
	double x[200];
	for (int j=0;j<N_of_x;j++)
	{
		x[j] = xreal[j]-center[j];
	}
	double temp1 = fabs(x[0]);
	for (int i=1;i<N_of_x;i++)
	{
		if (fabs(x[i]) > temp1)
		{
			temp1 = fabs(x[i]);
		}
	}
	obj = temp1;
}

// Rosenbrock's function
void CProblemDef::test_05(double *xreal, double &obj, double *constr)
{
	double x[200];
	for (int j=0;j<N_of_x;j++)
	{
		x[j] = xreal[j]-center[j];
	}
	double fit;
	double t0, tt, t1, d=0;
	t0=x[0];
	for (int i=1; i<N_of_x; i++) 
	{
		t1 = x[i];
		tt = (1.0-t0);
		d += tt*tt;
		tt = t1-t0*t0;
		d += 100*tt*tt;				
		t0 = t1;
	}
	fit = d;

	obj = fit;
}

// step function
void CProblemDef::test_06(double *xreal, double &obj, double *constr)
{
	double x[200];
	for (int j=0;j<N_of_x;j++)
	{
		x[j] = xreal[j]-center[j];
	}
	double temp;
	double value = 0.0;
	for (int i=0;i<N_of_x;i++)
	{
		temp = floor(x[i]+0.5);
		value += temp*temp; 
	}
	obj = value;
}

// Quartic function
void CProblemDef::test_07(double *xreal, double &obj, double *constr)
{
	double x[200];
	for (int j=0;j<N_of_x;j++)
	{
		x[j] = xreal[j]-center[j];
	}
	double value = 0.0;
	for (int i=0;i<N_of_x;i++)
	{
		value += (i+1)*pow(x[i],4.0); 
	}
	CRand rnd;
	obj = value+rnd.randomperc();
}

// Generalized Schwefel's function
void CProblemDef::test_08(double *xreal, double &obj, double *constr)
{
	double x[200];
	for (int j=0;j<N_of_x;j++)
	{
		x[j] = xreal[j]-center[j];
	}
	double value = 0.0;
	for (int i=0;i<N_of_x;i++)
	{
		value += x[i]*sin(sqrt(fabs(x[i]))); 
	}
	obj = -value;	// 418.982887272434*(double)N_of_x modified here
}

// Generalized Rastrigin's function
void CProblemDef::test_09(double *xreal, double &obj, double *constr)
{
	double x[200];
	for (int j=0;j<N_of_x;j++)
	{
		x[j] = xreal[j]-center[j];
	}
	double value = 0.0;
	for (int i=0;i<N_of_x;i++)
	{
		value += x[i]*x[i]-10.0*cos(2.0*PI*x[i])+10.0; 
	}
	obj = value;
}

// Ackley' function
void CProblemDef::test_10(double *xreal, double &obj, double *constr)
{
	double x[200];
	for (int j=0;j<N_of_x;j++)
	{
		x[j] = xreal[j]-center[j];
	}
	double value = 0.0;
	double temp1 = 0.0;
	double temp2 = 0.0;
	for (int i=0;i<N_of_x;i++)
	{
		 temp1 += x[i]*x[i];
		 temp2 += cos(2.0*PI*x[i]);
	}
	obj = -20.0*exp(-0.2*sqrt(temp1/N_of_x))-exp(temp2/N_of_x)+20.0+exp(1.0);
}

// Generalized Griewank function
void CProblemDef::test_11(double *xreal, double &obj, double *constr)
{
	double x[200];
	for (int j=0;j<N_of_x;j++)
	{
		x[j] = xreal[j]-center[j];
	}
	double temp1 = 0.0;
	double temp2 = 1.0;
	for (int i=0;i<N_of_x;i++)
	{
		 temp1 += x[i]*x[i];
		 temp2 *= cos(x[i]/sqrt(i+1));
	}
	obj = temp1/4000.0-temp2+1;
}

double CProblemDef::TempValue(double x,int a,int k,int m)
{
	double temp = 0.0;
	if( x > a)
	{
		temp = k*pow(x-a,m);
	}
	else if( x <= a && x >= -a)
	{
		temp = 0.0;
	}
	else
	{
		temp = k*pow(-x-a,m);
	}
	return temp;
}

// Generalized Penalized function
void CProblemDef::test_12(double *x, double &obj, double *constr)
{
	double *y;	//��ʱ�洢�����еı���

	y=new double[N_of_x];

	for (int i=0;i<N_of_x;i++)
	{
		y[i]=0.0;
	}

	for (i=0;i<N_of_x;i++)
	{
		y[i]=1+(x[i]+1)/4.0;
	}

	double temp1 = 0.0;
	double temp2 = 0.0;
	for (i=0;i<N_of_x-1;i++)
	{
		temp1 += pow(y[i]-1,2.0)*(1.0+10.0*pow(sin(PI*y[i+1]),2.0)); 
	}
	for (i=0;i<N_of_x;i++)
	{
		temp2 += TempValue(x[i],10,100,4);
	}
	obj = (10.0*pow(sin(PI*y[0]),2.0)+temp1+pow(y[N_of_x-1]-1,2))*PI/N_of_x+temp2;
	delete []y;
}

// Generalized Penalized function
void CProblemDef::test_13(double *x, double &obj, double *constr)
{
	double temp1 = 0.0;
	double temp2 = 0.0;
	for (int i=0;i<N_of_x-1;i++)
	{
		temp1 += pow(x[i]-1,2.0)*(1.0+10.0*pow(sin(3*PI*x[i+1]),2.0)); 
	}
	for (i=0;i<N_of_x;i++)
	{
		temp2 += TempValue(x[i],5,100,4);
	}
	obj = (pow(sin(3.0*PI*x[0]),2.0)+temp1+pow(x[N_of_x-1]-1,2.0)
		*(1.0+pow(sin(2.0*PI*x[N_of_x-1]),2.0)))/10.0+temp2;
}
