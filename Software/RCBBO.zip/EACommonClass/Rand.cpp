// Rand.cpp: implementation of the CRand class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Rand.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

int    CRand::jrand = 0;
double CRand::oldrand[55] = {0};
double CRand::rndx1 = 0;
double CRand::rndx2 = 0;
int    CRand::rndcalcflag = 1;

CRand::CRand()
{
}

CRand::~CRand()
{
}

// Get seed number for random and start it up
void CRand::randomize(double seed)
{
	int j1;
	for(j1=0; j1<=54; j1++)
    {
        oldrand[j1] = 0.0;
    }
	jrand=0;
	warmup_random (seed);
    return;
}

// Get randomize off and running
void CRand::warmup_random (double seed)
{
    int j1, ii;
    double new_random, prev_random;
    oldrand[54] = seed;
    new_random = 0.000000001;
    prev_random = seed;
    for(j1=1; j1<=54; j1++)
    {
        ii = (21*j1)%54;
        oldrand[ii] = new_random;
        new_random = prev_random-new_random;
        if(new_random<0.0)
        {
            new_random += 1.0;
        }
        prev_random = oldrand[ii];
    }
    advance_random ();
    advance_random ();
    advance_random ();
    jrand = 0;
    return;
}

// Create next batch of 55 random numbers
void CRand::advance_random ()
{
    int j1;
    double new_random;
    for(j1=0; j1<24; j1++)
    {
        new_random = oldrand[j1]-oldrand[j1+31];
        if(new_random<0.0)
        {
            new_random = new_random+1.0;
        }
        oldrand[j1] = new_random;
    }
    for(j1=24; j1<55; j1++)
    {
        new_random = oldrand[j1]-oldrand[j1-24];
        if(new_random<0.0)
        {
            new_random = new_random+1.0;
        }
        oldrand[j1] = new_random;
    }
}

// Fetch a single random number between 0.0 and 1.0
double CRand::randomperc()
{
	jrand++;
	if(jrand>=55)
    {
        jrand = 1;
        advance_random();
    }
    return((double)oldrand[jrand]);
}

// Fetch a single random integer between low and high including the bounds
int CRand::rndint (int low, int high)
{
    int res;
    if (low >= high)
    {
        res = low;
    }
    else
    {
        res = low + (int)(randomperc()*(high-low+1));
        if (res > high)
        {
            res = high;
        }
    }
    return (res);
}

// Fetch a single random real number between low and high including the bounds
double CRand::rndreal (double low, double high)
{
    return (low + (high-low)*randomperc());
}

void CRand::initrandomnormaldeviate()
{
	rndcalcflag = 1;
}

double CRand::randomnormaldeviate()
{
	double t; 
 
    if(rndcalcflag) 
    { 
        rndx1 = sqrt(- 2.0*log((double) randomperc())); 
        t = 6.2831853072 * (double) randomperc(); 
        rndx2 = sin(t); 
        rndcalcflag = 0; 
        return(rndx1 * cos(t)); 
    } 
    else 
    { 
        rndcalcflag = 1; 
        return(rndx1 * rndx2); 
    }
}

double CRand::noise(double mu,double sigma)
{
	return((randomnormaldeviate()*sigma) + mu); 
}

double CRand::cauchy(double median, double formFactor)
{
	assert( formFactor > 0. ); 
	double u, v; 
	do { 
			double U1 = (double) randomperc();
			double U2 = (double) randomperc();
			u = 2.0 * U1 - 1.0; 
			v = 2.0 * U2 - 1.0; 
		}while (u*u+v*v>1.0 ||(u==0.0&&v==0.0)); 

	if (u!=0) 
		return (median + formFactor * (v/u)); 
	else 
		return(median);
}

double CRand::gaussian(double median, double stdev)
{
	assert( stdev > 0. ); 
	double u,v,x; 
	do { 
			double U1 = (double) randomperc();
			double U2 = (double) randomperc();
			u = 2.0 * U1 - 1.0; 
			v = 2.0 * U2 - 1.0; 
			x = u * u + v * v; 
		}while ( x >= 1.0 || x == 0 ); 
	return median + stdev * u * sqrt( -2. * log( x ) / x );
}

double CRand::levy(int n)
{
	double x,y,v,w;
	double alpha,alpha1;
	
	switch(n)
	{
	case 1:
		alpha=0.8;
		alpha1=1.0/alpha;
		x=gaussian(0,1.13999);
		y=gaussian(0,1);
		v=x/pow(fabs(y),alpha1);    
		w=((0.793112-1.0)*exp(-fabs(v)/2.483)+1.0)*v;
		break;
	case 2:
		alpha=1.4;
		alpha1=1.0/alpha;
		x=gaussian(0,0.759679);
		y=gaussian(0,1);
		v=x/pow(fabs(y),alpha1);
		w=(0.44647*exp(-fabs(v)/2.8315)+1.0)*v;
		break;
	case 3:
		alpha=1.5;
		alpha1=1.0/alpha;
		x=gaussian(0,0.696575);
		y=gaussian(0,1);
		v=x/pow(fabs(y),alpha1);
		w=(0.59922*exp(-fabs(v)/2.737)+1.0)*v;
		break;
	case 4:
		alpha=1.6;
		alpha1=1.0/alpha;
		x=gaussian(0,0.628231);
		y=gaussian(0,1);
		v=x/pow(fabs(y),alpha1);
		w=(0.79361*exp(-fabs(v)/2.6125)+1.0)*v;
		break;
	case 5:
		alpha=1.2;
		alpha1=1.0/alpha;
		x=gaussian(0,0.878829);
		y=gaussian(0,1);
		v=x/pow(fabs(y),alpha1);
		w=(0.20519*exp(-fabs(v)/2.941)+1.0)*v;
		break;
	case 6:
		alpha=1.8;
		alpha1=1.0/alpha;
		x=gaussian(0,0.458638);
		y=gaussian(0,1);
		v=x/pow(fabs(y),alpha1);
		w=(1.50147*exp(-fabs(v)/2.206)+1.0)*v;
		break;
	default:
		break;
	}
  
	return w;
}

int CRand::flip(double p)
{
	if (randomperc() <= p)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}