function [ LB,UB,Dim ] = Parameter_29_s( type )
%PARAMETER �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    if type==1  || type==2 || type==3  || type==4 
%         Dim=5;
%         UB=zeros(1,Dim);  %�ϱ߽�
%         UB(1) = 1;
%         UB(2) = 1e-6;
%         UB(3) = 0.5;
%         UB(4) = 100;
%         UB(5) = 2;
%         LB=zeros(1,Dim); %�±߽�
%         LB(5) = 1;
    elseif type==5 || type==6 || type==7  || type==8 || type==9 || type==20 || type==21 || type==22  % Multi-crystalline (KC200GT)		

         % single
        Dim=5;
        UB=zeros(1,Dim);  %�ϱ߽�
        if type==5       % 25, 200w/m
            UB(1) = 3.284;  
        elseif type==6   % 25, 400w/m
            UB(1) = 6.568;
        elseif type==7   % 25, 600w/m
            UB(1) = 9.852;
        elseif type==8   % 25, 800w/m
            UB(1) = 13.136;
        elseif type==9   % 25, 1000w/m
            UB(1) = 16.42;
        elseif type==20   % 1000w/m, 75, 
            UB(1) = 16.738;
        elseif type==21   % 1000w/m, 50, 
            UB(1) = 16.5790;
        elseif type==22   % 1000w/m, 25, 
            UB(1) = 16.42;
        end

        UB(2) = 100e-6;
        UB(3) = 2;
        UB(4) = 5000;
        UB(5) = 4;
        LB=zeros(1,Dim); %�±߽�
        LB(5) = 1;
       
        
        % double
%         Dim=7;
%         UB=zeros(1,Dim);  %�ϱ߽�
%         if type==5       % 25, 200w/m
%             UB(1) = 3.284;
%         elseif type==6   % 25, 400w/m
%             UB(1) = 6.568;
%         elseif type==7   % 25, 600w/m
%             UB(1) = 9.852;
%         elseif type==8   % 25, 800w/m
%             UB(1) = 13.136;
%         elseif type==9   % 25, 1000w/m
%             UB(1) = 16.42;
%         elseif type==20   % 1000w/m, 75,
%             UB(1) = 16.738;
%         elseif type==21   % 1000w/m, 50,
%             UB(1) = 16.5790;
%         elseif type==22   % 1000w/m, 25,
%             UB(1) = 16.42;
%         end
%         UB(2) = 100e-6;
%         UB(3) = 2;
%         UB(4) = 5000;
%         UB(5) = 4;
%         UB(6) = 100e-6;
%         UB(7) = 4;
%         LB=zeros(1,Dim); %�±߽�
%         LB(5) = 1;
%         LB(7) = 1;
        
    elseif type==10 || type==11 || type==12  || type==13 || type==14 || type==27 || type==28 || type==29  % Mono-crystalline SM55
        
        % single
        Dim=5;
        UB=zeros(1,Dim);  %�ϱ߽�
        if type==10       % 25, 200w/m
            UB(1) = 1.36;  
        elseif type==11   % 25, 400w/m
            UB(1) = 2.72;
        elseif type==12   % 25, 600w/m
            UB(1) = 4.08;
        elseif type==13   % 25, 800w/m
            UB(1) = 5.44;
        elseif type==14   % 25, 1000w/m
            UB(1) = 6.80;
        elseif type==27   % 1000w/m, 60, 
            UB(1) = 6.898;
        elseif type==28   % 1000w/m, 40, 
            UB(1) = 6.8042;
        elseif type==29   % 1000w/m, 25, 
            UB(1) = 6.80;
        end

        UB(2) = 100e-6;
        UB(3) = 2;
        UB(4) = 5000;
        UB(5) = 4;
        LB=zeros(1,Dim); %�±߽�
        LB(5) = 1;
       
        
        % double
%         Dim=7;
%         UB=zeros(1,Dim);  %�ϱ߽�
%         if type==10       % 25, 200w/m
%             UB(1) = 1.36;  
%         elseif type==11   % 25, 400w/m
%             UB(1) = 2.72;
%         elseif type==12   % 25, 600w/m
%             UB(1) = 4.08;
%         elseif type==13   % 25, 800w/m
%             UB(1) = 5.44;
%         elseif type==14   % 25, 1000w/m
%             UB(1) = 6.80;
%         elseif type==27   % 1000w/m, 60, 
%             UB(1) = 6.898;
%         elseif type==28   % 1000w/m, 40, 
%             UB(1) = 6.8042;
%         elseif type==29   % 1000w/m, 25, 
%             UB(1) = 6.80;
%         end
%         UB(2) = 100e-6;
%         UB(3) = 2;
%         UB(4) = 5000;
%         UB(5) = 4;
%         UB(6) = 100e-6;
%         UB(7) = 4;
%         LB=zeros(1,Dim); %�±߽�
%         LB(5) = 1;
%         LB(7) = 1;
    elseif type==15 || type==16 || type==17  || type==18 || type==19 || type==23 || type==24 || type==25 || type==26 % Thin-film ST40	
        Dim=5;
        UB=zeros(1,Dim);  %�ϱ߽�
        
        if type==15       % 25, 200w/m
            UB(1) = 1.072;  
        elseif type==16   % 25, 400w/m
            UB(1) = 2.144;
        elseif type==17   % 25, 600w/m
            UB(1) = 3.216;
        elseif type==18   % 25, 800w/m
            UB(1) = 4.288;
        elseif type==19   % 25, 1000w/m
            UB(1) = 5.36;
        elseif type==23   % 1000w/m, 70, 
            UB(1) = 5.3915;
        elseif type==24   % 1000w/m, 55, 
            UB(1) = 5.3810;
        elseif type==25   % 1000w/m, 40, 
            UB(1) = 5.3705;
        elseif type==26   % 1000w/m, 25
            UB(1) = 5.36;
        end
        
        UB(2) = 100e-6;
        UB(3) = 2;
        UB(4) = 5000;
        UB(5) = 4;
        LB=zeros(1,Dim); %�±߽�
        LB(5) = 1;
        
        
%         Dim=7;
%         UB=zeros(1,Dim);  %�ϱ߽�
%         if type==15       % 25, 200w/m
%             UB(1) = 1.072;
%         elseif type==16   % 25, 400w/m
%             UB(1) = 2.144;
%         elseif type==17   % 25, 600w/m
%             UB(1) = 3.216;
%         elseif type==18   % 25, 800w/m
%             UB(1) = 4.288;
%         elseif type==19   % 25, 1000w/m
%             UB(1) = 5.36;
%         elseif type==23   % 1000w/m, 70,
%             UB(1) = 5.3915;
%         elseif type==24   % 1000w/m, 55,
%             UB(1) = 5.3810;
%         elseif type==25   % 1000w/m, 40,
%             UB(1) = 5.3705;
%         elseif type==26   % 1000w/m, 25
%              UB(1) = 5.36;
%         end
%         UB(2) = 100e-6;
%         UB(3) = 2;
%         UB(4) = 5000;
%         UB(5) = 4;
%         UB(6) = 100e-6;
%         UB(7) = 4;
%         LB=zeros(1,Dim); %�±߽�
%         LB(5) = 1;
%         LB(7) = 1;
       
    end
    

end

