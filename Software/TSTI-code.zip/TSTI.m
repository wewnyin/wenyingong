classdef TSTI < ALGORITHM
%<many> <real/binary/permutation> <constrained/none>


	methods
        function main(Algorithm,Problem)

			[Epsilon0,row] = Algorithm.ParameterSet(0.05,1.01);
			Population = Problem.Initialization();
			[fpr,fcd] = Estimation(Population.objs,1/Problem.N^(1/Problem.M));
			fcv = Calculate_fcv(Population); 
			Epsilon = Epsilon0;
			PopObj_1 = [fpr,fcd]; 
			[fm,~] = NDSort(PopObj_1,Problem.N);
			PopObj = [fm' + Epsilon * fcv,fcv];
			[frank,~] = NDSort(PopObj,Problem.N);
			fitness = frank' + fcv./(fcv+1);
			

			%% Optimization
			while Algorithm.NotTerminated(Population)
				if Problem.FE<=0.4*Problem.maxFE
					MatingPool = TournamentSelection(2,Problem.N,fitness);
					Offspring  = OperatorGA(Population(MatingPool));
					[fpr,fcd] = Estimation(Offspring.objs,1/Problem.N^(1/Problem.M));
					fcv = Calculate_fcv(Offspring); 
					OffObj_1 = [fpr,fcd]; 
					[fm,~] =NDSort(OffObj_1,Problem.N);
					OffObj = [fm' + Epsilon * fcv,fcv];
					[Population,fitness] = EnvironmentalSelectionStageI([Population,Offspring],PopObj,OffObj,Problem.N);
					[fpr,fcd] = Estimation(Population.objs,1/Problem.N^(1/Problem.M));
					fcv = Calculate_fcv(Population);
					PopObj_1 = [fpr,fcd]; 
					[fm,~] =NDSort(PopObj_1,Problem.N);
					PopObj = [fm' + Epsilon * fcv,fcv];
					Epsilon = row * Epsilon;
				else
					[Population,fit2] = EnvironmentalSelectionStageII(Population,Problem.N);
					MatingPool = TournamentSelection(2,Problem.N,fit2);
					Offspring  = OperatorGA(Population(MatingPool));
					[Population,fit2] = EnvironmentalSelectionStageII([Population,Offspring],Problem.N);

				end
					
				end
			end
		end
	end
