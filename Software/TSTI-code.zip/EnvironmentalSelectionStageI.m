function [Population,fitness] = EnvironmentalSelection(Population,PopObj,OffObj,N)
% The environmental selection of TiGE_1


% Population：子代和父代合并后的种群
% PopObj：N*2，fm'和fc（父代种群的）
% OffObj：子代种群的


%------------------------------- Copyright --------------------------------
% Copyright (c) 2018-2019 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------
    % 将父代、子代的fm'和fc合并后，再进行非支配排序
	[FrontNo,~] = NDSort([PopObj;OffObj],N);
	
	% 父代子代混合种群的cv值
    fcv = Calculate_fcv(Population); % CV of hybrid population
    fitness = FrontNo' + fcv./(fcv+1);
    [~,index] = sort(fitness);
    Population = Population(index(1:N));
    fitness = fitness(index(1:N));
end