clc;
clear;

%所有的txt文件
namelist = dir('dataset\*.txt');

%%%遍历所有txt文件
file_index = 1;
len = length(namelist);
while (file_index <= len)
    %打开文件
    fid = fopen(['dataset\', namelist(file_index).name]);
    file = fscanf(fid, '%d');

    %前3行为工件数、机器数、工厂数
    data = [];
    d = [];
    n = file(1);
    m = file(2);
    f = file(3);
    
    %读取数据
    for i = 4:length(file)
        if mod(i, 2) == 1
            d = [d, file(i)];
        end
    end
    d = reshape(d, [m, n]);
    d = d';
    data = [data, d];
    d =[];

    %关闭文件
    fclose(fid);
    
    %将其他工厂的数据并入
    count = 1;
    while (count < f)
        file_index = file_index + 1;
        count = count + 1;
        
        %打开文件
        fid = fopen(['dataset\', namelist(file_index).name]);
        file = fscanf(fid, '%d');
        
        %读取数据
        for i = 4:length(file)
            if mod(i, 2) == 1
                d = [d, file(i)];
            end
        end
        d = reshape(d, [m, n]);
        d = d';
        data = [data, d];
        d =[];
        
    end
    
    cell_str = strsplit(namelist(file_index).name, '_');
    filename = ['dataset\', cell_str{2}, '_', cell_str{3}, '_', cell_str{4}, '.xlsx'];
    filename = strrep(filename, ' ', '');
    xlswrite(filename, data);
    
    file_index = file_index + 1;

    
end