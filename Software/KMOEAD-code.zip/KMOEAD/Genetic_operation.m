function [new_schedule, new_factory] = Genetic_operation(s1, s2, f1, f2)    %进行遗传操作产生新解
global N M F P G T O MU CR;

%可能出现不会进行交叉和变异的时候
if rand > 0.5
    new_schedule = s1;
    new_factory = f1;
else
    new_schedule = s2;
    new_factory = f2;
end

%交叉操作，随机选取两个工件进行交换
if rand < CR
    s1 = s1(1:N);
    s2 = s2(1:N);
    f1 = f1(1:N);
    f2 = f2(1:N);

    r1 = ceil(rand * N);
    r2 = ceil(rand * N);
    while r1 == r2
        r2 = ceil(rand * N);
    end

    new_schedule = [];
    new_factory = [];
    judge = round(rand);
    if judge == 1
        %交换工件码
        temp = s1(r1);
        s1(r1) = s1(r2);
        s1(r2) = temp;

%         %交换工厂码
%         temp = f1(r1);
%         f1(r1) = f1(r2);
%         f1(r2) = temp;

        for i = 1:M
            new_schedule = [new_schedule, s1];
        end

        for i = 1:M
            new_factory = [new_factory, f1];
        end
    else
        %交换工件码
        temp = s2(r1);
        s2(r1) = s2(r2);
        s2(r2) = temp;

%         %交换工厂码
%         temp = f2(r1);
%         f2(r1) = f2(r2);
%         f2(r2) = temp;

        for i = 1:M
            new_schedule = [new_schedule, s2];
        end

        for i = 1:M
            new_factory = [new_factory, f2];
        end 
    end
end


%变异操作，随机选取一个工厂码进行变异
if rand < MU
    judge = tabulate(new_factory(1:N));     %确保每个工厂至少有两个工件加工
    if all(judge(:, 2) > 2)
        pos = ceil(rand * N);
        choice = ceil(rand * F);
        while choice == new_factory(pos)
            choice = ceil(rand * F);
        end
        for i = 1:M
            new_factory(pos + (i - 1) * N) = choice;
        end
    end
end


end