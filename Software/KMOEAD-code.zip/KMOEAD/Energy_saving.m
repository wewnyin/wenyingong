function [start_time, end_time] = Energy_saving(start_time, end_time)       %节能策略
%%%start_time和end_time的格式为行：工件数，列：机器数
global N M F P G T O MU;

row = size(start_time, 1);
col = size(start_time, 2);
processing_time = end_time - start_time;

for c = col:-1:1
    %如果是最后一列，则代表是最后一个机器，直接右移;
    %否则只能移到min(该工件下一个工序的开始时间，该工件所在机器的下一个工序的开始时间)
    if c == col
        for r = (row - 1):-1:1
            end_time(r, c) = start_time(r + 1, c);
            start_time(r, c) = end_time(r, c) - processing_time(r, c);
        end
    else
        for r = (row - 1):-1:1
            end_time(r, c) = min(start_time(r, c + 1), start_time(r + 1, c));
            start_time(r, c) = end_time(r, c) - processing_time(r, c);
        end
    end
end


end