function neighbor_index = Get_neighbor(reference_vector)    %寻找最近的T个邻居的索引值
global N M F P G T O MU;

neighbor_index = [];
for i = 1:P
    distance = [];
    for j = 1:P
        if (i == j)
            distance = [distance, 10];
        else
            dis = sqrt((reference_vector(i, 1) - reference_vector(j, 1)) ^ 2 + (reference_vector(i, 2) - reference_vector(j, 2)) ^ 2);
            distance = [distance, dis];
        end
    end
    [distance, index] = sort(distance);
    neighbor_index = [neighbor_index; index(1:T)];
end
end