%%%造数据，data_n_m_f表示n个工件、m个机器、f个工厂的数据
n = [20, 50, 80, 100];  %工件数量集
m = [5, 10, 20];    %机器数量集
f = [2, 3, 4];  %工厂数量集

%数据格式为n*(m*f),数据范围为1~10
data = [];
for i = 1:4
    for j = 1:3
        for k = 1:3
            n_t = n(i);     %工件数量
            m_t = m(j);     %机器数量
            f_t = f(k);     %工厂数量
            m_f = m_t * f_t;    %数据的列数
            
            for t = 1:n_t               
                array = ceil(rand(1, m_f) * 10);
                data = [data; array];
            end
            format = 'data_%d_%d_%d.xlsx';
            filename = sprintf(format, n_t, m_t, f_t)
            xlswrite(filename, data);
            data = [];
        end
    end
end
            
