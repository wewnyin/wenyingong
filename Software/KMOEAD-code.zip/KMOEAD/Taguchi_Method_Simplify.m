clc;
clear;

global N M F P G T O MU CR;

P_array = [40, 60, 80, 100];
T_array = [5, 10, 15, 20];
CR_array = [0.7, 0.8, 0.9, 1.0];
MU_array = [0.1, 0.2, 0.3, 0.4];

%设计正交表
L16 = sortrows(rowexch(4, 16, 'l', 'cat', 1:4, 'levels', 4*ones([1, 4]), 'tries', 100));
xlswrite('Orthogonal_table.xlsx', L16);

for row = 1:16
    
    %机器的能量消耗：第一个为机器的启动关闭能量消耗量，第二个为机器工作时的能量消耗功率，第三个为机器空闲时的能量消耗功率
    Energy_consumption_power = [35, 3, 1.125;
                                40, 2.875, 1.25;
                                45, 2.75, 1.375;
                                50, 2.625, 1.5;
                                55, 2.5, 1.625;
                                60, 2.375, 1.75;
                                65, 2.25, 1.875;
                                70, 2.125, 2];      
     
                            
    N = 100;     %工件数，使用不同的数据集工件数不同
    M = 20;      %机器数，使用不同的数据集机器数不同
    F = 8;      %工厂数，使用不同的数据集工厂数不同

    P = P_array(L16(row, 1));    %种群大小
    G = 200;    %迭代次数

    T = T_array(L16(row, 2));     %每一个权重向量的邻居个数
    O = 2;     %优化目标个数
    CR = CR_array(L16(row, 3));   	%交叉概率
    MU = MU_array(L16(row, 4));   	%变异概率
         
    %创建文件夹
    dirname = ['Taguchi_Simplify\', num2str(P), '_', num2str(T), '_', num2str(CR), '_', num2str(MU)];
    mkdir(dirname);

    % processing_time = xlsread('data\data_20_5_2.xlsx');      %读取工件的加工时间
    processing_time = xlsread('dataset\100_20_8.xlsx');      %读取工件的加工时间
   


    for run = 1:20       %独立运行run次
        fprintf('**********P=%d,T=%d,CR=%.2f,MU=%.2f: N=%d,M=%d,F=%d: 第%d次独立运行**********\n', P, T, CR, MU, N, M, F, run);

        PF = [];    %存储非支配解
        %[schedule, factory, reference_vector] = Initial_randomn(run);      %初始化工件码、工厂码、参考向量                                                                                                                                                                                             
        [schedule, factory, reference_vector] = Initial_NEH(processing_time, Energy_consumption_power, run);      %初始化工件码、工厂码、参考向量                                                                                                                                                                                             

        %寻找最近的T个邻居的索引值
        neighbor_index = Get_neighbor(reference_vector);        

        %计算目标值
        %objective_value = Calculate_objective_value(schedule, factory, processing_time, Energy_consumption_power);        %计算目标值(第一个值为最大完工时间，第二个值为总能量消耗)
        objective_value = Calculate_objective_value_ES(schedule, factory, processing_time, Energy_consumption_power);        %计算目标值(第一个值为最大完工时间，第二个值为总能量消耗)

         %初始化参考点
        for i = 1:2
            reference_point(i) = min(objective_value(:, i));        
        end

        %计算切比雪夫值
        tchebycheff = Calculate_Tchebycheff(objective_value, reference_vector, reference_point);    
        fitness = [objective_value, tchebycheff];       %前两个值为最大完工时间和总能量消耗，最后一个值为Tchebycheff值

        PF = Nondominated_solution(objective_value);
        
        %迭代循环
        for i = 1:G
            gen = i;
            fprintf('第%d次迭代\n', i);
            for j = 1:P
                %遗传操作产生新解
                index = randperm(T);
                index1 = neighbor_index(j, index(1));
                index2 = neighbor_index(j, index(2));

                %遗传操作
                %[new_schedule, new_factory] = Genetic_operation(schedule(index1, :), schedule(index2, :), factory(index1, :), factory(index2, :));
                [new_schedule, new_factory] = Genetic_operation_improvement(schedule(index1, :), schedule(index2, :), factory(index1, :), factory(index2, :));

                %%%局部搜索
                [critical_factory, ~] = Calculate_makespan(new_schedule, new_factory, processing_time);
                [new_schedule, new_factory] = Local_search(critical_factory, new_schedule, new_factory);

                %求目标值
                %new_objective_value = Calculate_objective_value(new_schedule, new_factory, processing_time, Energy_consumption_power);
                new_objective_value = Calculate_objective_value_ES(new_schedule, new_factory, processing_time, Energy_consumption_power);

                %如果新生成的解比原来解好就更新邻域
                temp_objective_value = Calculate_objective_value(schedule(j, :), factory(j, :), processing_time, Energy_consumption_power);
                if (Nondominated_judge(temp_objective_value, new_objective_value) == 0)
                    schedule(j, :) = new_schedule;
                    factory(j, :) = new_factory;
                    objective_value(j, :) = temp_objective_value;
                    temp_tchebycheff = Calculate_Tchebycheff(temp_objective_value, reference_vector, reference_point);
                    fit(j, :) = [temp_objective_value, temp_tchebycheff];
                end
                
                %更新参考点
                for i = 1:2
                    reference_point(i) = min(new_objective_value(i), reference_point(i));        %更新参考点
                end

                %更新邻域解
                [schedule, factory, objective_value, fitness] = Update_neighbor_solution(schedule, factory, objective_value, fitness, neighbor_index(j, :), reference_vector(j, :), reference_point, new_schedule, new_factory, new_objective_value);
            
                %更新非支配解
                PF = Update_PF(PF, new_objective_value);
            end
                 
        end
%         %得到非支配解
%         PF = Nondominated_solution(objective_value);
%         solutions = [objective_value, zeros(size(objective_value, 1), 1)];
%         for i = 1:size(PF, 1)
%             for j = 1:size(objective_value, 1)
%                 if PF(i, :) == objective_value(j, :)
%                     solutions(j, 3) = 1;
%                 end
%             end
%         end
                        
        %存储数据
        filename = ['Taguchi_Simplify\', num2str(P), '_', num2str(T), '_', num2str(CR), '_', num2str(MU), '\', num2str(run), '.xlsx'];
        xlswrite(filename, PF);
        
    end
                            

    
end







