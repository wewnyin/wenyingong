function [PF, PF_schedule, PF_factory] = Collaborative_local_search(PF, PF_schedule, PF_factory, processing_time, Energy_consumption_power)
global N M F P G T O MU;

len = size(PF_schedule, 1);
for i = 1:len
    [critical_factory, ~] = Calculate_makespan(PF_schedule(i, :), PF_factory(i, :), processing_time);
    
    %%%LS1：从关键工厂中提取随机提取一个工件，将其插入该关键工厂中的一个随机位置
    schedule_temp = PF_schedule(i, 1:N);
    factory_temp = PF_factory(i, 1:N);
    
    index = find(factory_temp == critical_factory);
    schedule_segment = schedule_temp(index);
    factory_segment = factory_temp(index);

    %如果插入位置与待插入工件位置相同，则重新选择
    ext_pos = ceil(rand * length(schedule_segment));
    ins_pos = ceil(rand * length(schedule_segment));
    while ins_pos == ext_pos
        ins_pos = ceil(rand * length(schedule_segment));
    end

    %插入工件
    [schedule_segment, factory_segment] = Insert_operator(schedule_segment, factory_segment, ext_pos, ins_pos);
    schedule_temp(index) = schedule_segment;
    factory_temp(index) = factory_segment;
    new_schedule = Expand(schedule_temp);
    new_factory = Expand(factory_temp);
    new_objective_value = Calculate_objective_value_ES(new_schedule, new_factory, processing_time, Energy_consumption_power);
    if all(new_objective_value(1, :) <= PF(i, :)) && any(new_objective_value(1, :) < PF(i, :))
        PF(i, :) = new_objective_value(1, :);
        PF_schedule(i, :) = new_schedule;
        PF_factory(i, :) = new_factory;
        [critical_factory, ~] = Calculate_makespan(PF_schedule(i, :), PF_factory(i, :), processing_time);
    end
        
    
    
    %%%LS2：从关键工厂中随机提取一个工件，将其随机插入到非关键工厂中的一个随机位置
    schedule_temp = PF_schedule(i, 1:N);
    factory_temp = PF_factory(i, 1:N);

    %随机提取关键工厂中的工件
    index = find(factory_temp == critical_factory);

    %确保关键工厂中必须至少有两个工件加工
    if length(index) > 2
        idx = ceil(rand * length(index));
        ext_job = schedule_temp(index(idx));

        %将其插入随机的非关键工厂
        noncritical_factory = ceil(rand * F);
        while noncritical_factory == critical_factory
            noncritical_factory = ceil(rand * F);
        end
        factory_temp(index(idx)) = noncritical_factory;

        %提取需要进行插入操作的工件码段和工厂码段
        index = find(factory_temp == noncritical_factory);
        schedule_segment = schedule_temp(index);
        factory_segment = factory_temp(index);

        %如果插入位置与待插入工件位置相同，则重新选择
        ext_pos = find(schedule_segment == ext_job);
        ins_pos = ceil(rand * length(schedule_segment));

        if ins_pos == ext_pos
            %经过变异操作后可能存在非关键工厂上只有0个或1个工件的情况
        else
            %插入工件
            [schedule_segment, factory_segment] = Insert_operator(schedule_segment, factory_segment, ext_pos, ins_pos);
        end

        schedule_temp(index) = schedule_segment;
        factory_temp(index) = factory_segment;
        new_schedule = Expand(schedule_temp);
        new_factory = Expand(factory_temp);
        new_objective_value = Calculate_objective_value_ES(new_schedule, new_factory, processing_time, Energy_consumption_power);
        if all(new_objective_value(1, :) <= PF(i, :)) && any(new_objective_value(1, :) < PF(i, :))
            PF(i, :) = new_objective_value(1, :);
            PF_schedule(i, :) = new_schedule;
            PF_factory(i, :) = new_factory;
            [critical_factory, ~] = Calculate_makespan(PF_schedule(i, :), PF_factory(i, :), processing_time);
        end
    end
    
    
    
    %%%LS3：随机互换关键工厂中的两个工件
    schedule_temp = PF_schedule(i, 1:N);
    factory_temp = PF_factory(i, 1:N);

    index = find(factory_temp == critical_factory);

    % 随机选取关键工厂中的两个工件
    idx1 = ceil(rand * length(index));
    idx2 = ceil(rand * length(index));
    while idx1 == idx2
        idx2 = ceil(rand * length(index));
    end

    % 互换两个工件
    temp1 = schedule_temp(index(idx1));
    %temp2 = factory_temp(index(idx1));
    schedule_temp(index(idx1)) = schedule_temp(index(idx2));
    %factory_temp(index(idx1)) = factory_temp(index(idx2));
    schedule_temp(index(idx2)) = temp1;
    %factory_temp(index(idx2)) = temp2;
    new_schedule = Expand(schedule_temp);
    new_factory = Expand(factory_temp);
    new_objective_value = Calculate_objective_value_ES(new_schedule, new_factory, processing_time, Energy_consumption_power);
    if all(new_objective_value(1, :) <= PF(i, :)) && any(new_objective_value(1, :) < PF(i, :))
        PF(i, :) = new_objective_value(1, :);
        PF_schedule(i, :) = new_schedule;
        PF_factory(i, :) = new_factory;
        [critical_factory, ~] = Calculate_makespan(PF_schedule(i, :), PF_factory(i, :), processing_time);
    end


    
    %%%LS4：随机互换关键工厂和非关键工厂的两个工件
    schedule_temp = PF_schedule(i, 1:N);
    factory_temp = PF_factory(i, 1:N);

    critical_index = find(factory_temp == critical_factory);

    %随机选取一个非关键工厂,但是该非关键工厂必须有工件在加工
    noncritical_factory = ceil(rand * F);
    while noncritical_factory == critical_factory | length(find(factory_temp == noncritical_factory)) == 0
        noncritical_factory = ceil(rand * F);
    end
    noncritical_index = find(factory_temp == noncritical_factory);

    %随机选取一个关键工厂工件和非关键工厂工件
    critical_idx = ceil(rand * length(critical_index));
    noncritical_idx = ceil(rand * length(noncritical_index));

    %互换两个工件(待考察！！！！！！！)
    temp1 = schedule_temp(critical_index(critical_idx));
    %temp2 = factory_temp(critical_index(critical_idx));
    schedule_temp(critical_index(critical_idx)) = schedule_temp(noncritical_index(noncritical_idx));
    %factory_temp(critical_index(critical_idx)) = factory_temp(noncritical_index(noncritical_idx));
    schedule_temp(noncritical_index(noncritical_idx)) = temp1;
    %factory_temp(noncritical_index(noncritical_idx)) = temp2;
    new_schedule = Expand(schedule_temp);
    new_factory = Expand(factory_temp);
    new_objective_value = Calculate_objective_value_ES(new_schedule, new_factory, processing_time, Energy_consumption_power);
    if all(new_objective_value(1, :) <= PF(i, :)) && any(new_objective_value(1, :) < PF(i, :))
        PF(i, :) = new_objective_value(1, :);
        PF_schedule(i, :) = new_schedule;
        PF_factory(i, :) = new_factory;
        [critical_factory, ~] = Calculate_makespan(PF_schedule(i, :), PF_factory(i, :), processing_time);
    end
    
    
    
    energy_critical_factory = Energy_critical_factory_ES(PF_schedule(i, :), PF_factory(i, :), processing_time, Energy_consumption_power);
    %%%LS5：从最大能量消耗工厂中提取随机提取一个工件，将其插入该最大能量消耗工厂中的一个随机位置
    schedule_temp = PF_schedule(i, 1:N);
    factory_temp = PF_factory(i, 1:N);
    index = find(factory_temp == energy_critical_factory);
    schedule_segment = schedule_temp(index);
    factory_segment = factory_temp(index);

    %如果插入位置与待插入工件位置相同，则重新选择
    ext_pos = ceil(rand * length(schedule_segment));
    ins_pos = ceil(rand * length(schedule_segment));
    while ins_pos == ext_pos
        ins_pos = ceil(rand * length(schedule_segment));
    end

    %插入工件
    [schedule_segment, factory_segment] = Insert_operator(schedule_segment, factory_segment, ext_pos, ins_pos);
    schedule_temp(index) = schedule_segment;
    factory_temp(index) = factory_segment;
    new_schedule = Expand(schedule_temp);
    new_factory = Expand(factory_temp);
    new_objective_value = Calculate_objective_value_ES(new_schedule, new_factory, processing_time, Energy_consumption_power);
    if all(new_objective_value(1, :) <= PF(i, :)) && any(new_objective_value(1, :) < PF(i, :))
        PF(i, :) = new_objective_value(1, :);
        PF_schedule(i, :) = new_schedule;
        PF_factory(i, :) = new_factory;
        energy_critical_factory = Energy_critical_factory_ES(PF_schedule(i, :), PF_factory(i, :), processing_time, Energy_consumption_power);
    end
    
    
    
    %%%LS6：从最大能量消耗工厂中随机提取一个工件，将其随机插入到非最大能量消耗工厂中的一个随机位置
    schedule_temp = PF_schedule(i, 1:N);
    factory_temp = PF_factory(i, 1:N);

    %随机提取关键工厂中的工件
    index = find(factory_temp == energy_critical_factory);

    %确保关键工厂中必须至少有两个工件加工
    if length(index) > 2
        idx = ceil(rand * length(index));
        ext_job = schedule_temp(index(idx));

        %将其插入随机的非关键工厂
        noncritical_factory = ceil(rand * F);
        while noncritical_factory == energy_critical_factory
            noncritical_factory = ceil(rand * F);
        end
        factory_temp(index(idx)) = noncritical_factory;

        %提取需要进行插入操作的工件码段和工厂码段
        index = find(factory_temp == noncritical_factory);
        schedule_segment = schedule_temp(index);
        factory_segment = factory_temp(index);

        %如果插入位置与待插入工件位置相同，则重新选择
        ext_pos = find(schedule_segment == ext_job);
        ins_pos = ceil(rand * length(schedule_segment));

        if ins_pos == ext_pos
            %经过变异操作后可能存在非关键工厂上只有0个或1个工件的情况
        else
            %插入工件
            [schedule_segment, factory_segment] = Insert_operator(schedule_segment, factory_segment, ext_pos, ins_pos);
        end

        schedule_temp(index) = schedule_segment;
        factory_temp(index) = factory_segment;
        new_schedule = Expand(schedule_temp);
        new_factory = Expand(factory_temp);
        new_objective_value = Calculate_objective_value_ES(new_schedule, new_factory, processing_time, Energy_consumption_power);
        if all(new_objective_value(1, :) <= PF(i, :)) && any(new_objective_value(1, :) < PF(i, :))
            PF(i, :) = new_objective_value(1, :);
            PF_schedule(i, :) = new_schedule;
            PF_factory(i, :) = new_factory;
            energy_critical_factory = Energy_critical_factory_ES(PF_schedule(i, :), PF_factory(i, :), processing_time, Energy_consumption_power);
        end
    end
    
    
    
    %%%LS7：随机互换最大能量消耗工厂中的两个工件
    schedule_temp = PF_schedule(i, 1:N);
    factory_temp = PF_factory(i, 1:N);
    index = find(factory_temp == energy_critical_factory);

    %随机选取关键工厂中的两个工件
    idx1 = ceil(rand * length(index));
    idx2 = ceil(rand * length(index));
    while idx1 == idx2
        idx2 = ceil(rand * length(index));
    end

    %互换两个工件
    temp1 = schedule_temp(index(idx1));
    %temp2 = factory_temp(index(idx1));
    schedule_temp(index(idx1)) = schedule_temp(index(idx2));
    %factory_temp(index(idx1)) = factory_temp(index(idx2));
    schedule_temp(index(idx2)) = temp1;
    %factory_temp(index(idx2)) = temp2;
    new_schedule = Expand(schedule_temp);
    new_factory = Expand(factory_temp);
    new_objective_value = Calculate_objective_value_ES(new_schedule, new_factory, processing_time, Energy_consumption_power);
    if all(new_objective_value(1, :) <= PF(i, :)) && any(new_objective_value(1, :) < PF(i, :))
        PF(i, :) = new_objective_value(1, :);
        PF_schedule(i, :) = new_schedule;
        PF_factory(i, :) = new_factory;
        energy_critical_factory = Energy_critical_factory_ES(PF_schedule(i, :), PF_factory(i, :), processing_time, Energy_consumption_power);
    end
    
    
    
    %%%LS8：随机互换最大能量消耗工厂和非最大能量消耗工厂的两个工件
    schedule_temp = PF_schedule(i, 1:N);
    factory_temp = PF_factory(i, 1:N);

    critical_index = find(factory_temp == energy_critical_factory);

    %随机选取一个非关键工厂,但是该非关键工厂必须有工件在加工
    noncritical_factory = ceil(rand * F);
    while noncritical_factory == energy_critical_factory | length(find(factory_temp == noncritical_factory)) == 0
        noncritical_factory = ceil(rand * F);
    end
    noncritical_index = find(factory_temp == noncritical_factory);

    %随机选取一个关键工厂工件和非关键工厂工件
    critical_idx = ceil(rand * length(critical_index));
    noncritical_idx = ceil(rand * length(noncritical_index));

    %互换两个工件(待考察！！！！！！！)
    temp1 = schedule_temp(critical_index(critical_idx));
    %temp2 = factory_temp(critical_index(critical_idx));
    schedule_temp(critical_index(critical_idx)) = schedule_temp(noncritical_index(noncritical_idx));
    %factory_temp(critical_index(critical_idx)) = factory_temp(noncritical_index(noncritical_idx));
    schedule_temp(noncritical_index(noncritical_idx)) = temp1;
    %factory_temp(noncritical_index(noncritical_idx)) = temp2;
    new_schedule = Expand(schedule_temp);
    new_factory = Expand(factory_temp);
    new_objective_value = Calculate_objective_value_ES(new_schedule, new_factory, processing_time, Energy_consumption_power);
    if all(new_objective_value(1, :) <= PF(i, :)) && any(new_objective_value(1, :) < PF(i, :))
        PF(i, :) = new_objective_value(1, :);
        PF_schedule(i, :) = new_schedule;
        PF_factory(i, :) = new_factory;
        energy_critical_factory = Energy_critical_factory_ES(PF_schedule(i, :), PF_factory(i, :), processing_time, Energy_consumption_power);
    end



end

dominated = zeros(1, len);
for i = 1:len
    for j = 1:len
        if all(PF(i, :) >= PF(j, :)) && any(PF(i, :) > PF(j, :))
            dominated(i) = 1;
            break;
        end
    end
end    

index = find(dominated == 0);
PF = PF(index, :);
PF_schedule = PF_schedule(index, :);
PF_factory = PF_factory(index, :);

end