function [true_pareto, max_and_min] = Pareto(solutions)    %%求得真实帕累托前沿面

true_pareto = {};
max_and_min = {};
for i = 1:length(solutions{1})
    data = [];
    for j = 1:length(solutions)
        for k = 1:length(solutions{j}{i})
            data = [data; solutions{j}{i}{k}];
        end
    end
    
    data = unique(data(:, 1:2), 'rows');
    len = size(data, 1);
    dominated = zeros(1, len);
    for j = 1:len
        for k = 1:len
            if all(data(j, :) >= data(k, :)) && any(data(j, :) > data(k, :))
                dominated(j) = 1;
                break;
            end
        end
    end 

    index = find(dominated == 0);
    true_pareto{end + 1} = data(index, :);
    
    %找出每一列的最大最小值，方便之后归一化
    max_array = max(data, [], 1);
    min_array = min(data, [], 1);
    array = [max_array; min_array];
    max_and_min{end + 1} = array;
    
    
end


end