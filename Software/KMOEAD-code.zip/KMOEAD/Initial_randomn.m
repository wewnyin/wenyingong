function [schedule, factory, reference_vector] = Initial_randomn(run)    %随机初始化
global N M F P G T O MU;
schedule = [];
factory = [];

%生成随机数种子，控制随机数的生成
%rng(6);

%随机初始化工件码、工厂码
for i = 1:P
    %随机初始化工件码
    s_temp = [];
    f_temp = [];
    s = [];
    f = [];
    s = randperm(N);
    for j = 1:M
        s_temp = [s_temp, s];
    end
    schedule = [schedule; s_temp];
        

    %随机初始化工厂码
    f = ceil(F * rand(1, N));
    t = 1:F;
    judge = tabulate(f);
    while ~all(ismember(t, f)) || any(judge(:, 2) < 2)
        f = ceil(F * rand(1, N));   %确保每个工厂都有两个工件加工
        judge = tabulate(f);
    end
    for j = 1:M
        f_temp = [f_temp, f];
    end
    factory = [factory; f_temp];
end

%随机初始化参考向量
vector = (0:P) / P;
for i = 1:(P+1)
    reference_vector(i, 1) = vector(i);
    reference_vector(i, 2) = 1 - vector(i);
    
    if reference_vector(i, 1) == 0
        reference_vector(i, 1) = 0.00001;
    end
    if reference_vector(i, 2) == 0
        reference_vector(i, 2) = 0.00001;
    end
    
end
len = size(reference_vector, 1);
index = randperm(len);
index = sort(index(1:P));
reference_vector = reference_vector(index, :);


end

