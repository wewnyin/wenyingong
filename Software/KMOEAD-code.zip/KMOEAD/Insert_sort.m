function [s_result, f_result] = Insert_sort(s, f, processing_time, Energy_consumption_power)    %插入排序，选择最小完工时间的序列
global N M F P G T O MU;
s_result = s;
f_result = f;

s_expand = Expand(s);
f_expand = Expand(f);
objective_value = Calculate_objective_value_ES(s_expand, f_expand, processing_time, Energy_consumption_power);

%进行插入排序
ins_pos = length(s) - 1;    %插入位置
while ins_pos > 0
    s_temp = s;
    f_temp = f;
    s_number = s(end);
    f_number = f(end);
    
    for i = length(s):-1:(ins_pos + 1)
        s_temp(i) = s_temp(i - 1);
        f_temp(i) = f_temp(i - 1);
    end
    s_temp(ins_pos) = s_number;
    f_temp(ins_pos) = f_number;
    
    s_expand = Expand(s_temp);
    f_expand = Expand(f_temp);
    objective_value_temp = Calculate_objective_value_ES(s_expand, f_expand, processing_time, Energy_consumption_power);

    %比较目标值
    %judge = Nondominated_judge(objective_value_temp, objective_value);
    judge = (objective_value_temp(1) < objective_value(1));   
    
    if judge == 1
        s_result = s_temp;
        f_result = f_temp;
    end
    
    ins_pos = ins_pos - 1;
end


end