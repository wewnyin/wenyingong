function tchebycheff = Calculate_Tchebycheff(objective_value, reference_vector, reference_point)       %计算每个个体的Tchebycheff值
tchebycheff = [];
for i = 1:size(objective_value, 1)
    value1 = reference_vector(i, 1) * abs(objective_value(i, 1) - reference_point(1, 1));
    value2 = reference_vector(i, 2) * abs(objective_value(i, 2) - reference_point(1, 2));
    value = max(value1, value2);
    tchebycheff = [tchebycheff; value];
end

end