function value = HV(pareto, max_and_min)   %计算HV值，默认都是按照x的值排好序的

%将非支配解集归一化
if size(pareto, 1) > 1
    max_value_x = max_and_min(1, 1);
    min_value_x = max_and_min(2, 1);
    max_value_y = max_and_min(1, 2);
    min_value_y = max_and_min(2, 2);
    for i = 1:size(pareto, 1)
        pareto(i, 1) = (pareto(i, 1) - min_value_x) / (max_value_x - min_value_x);
        pareto(i, 2) = (pareto(i, 2) - min_value_y) / (max_value_y - min_value_y);
    end
else
    pareto(1, 1) = 1;
    pareto(1, 2) = 1;
end

%计算面积，参考点为（1.01，1.01）
value = 0;
for i = 1:(size(pareto, 1) - 1)
    value = value + (pareto(i + 1, 1) - pareto(i, 1)) * (1.01 - pareto(i, 2));
end
value = value + (1.01 - pareto(size(pareto, 1), 1)) * (1.01 - pareto(size(pareto, 1), 2));

end