clc;
clear;


global N M F P G T O MU CR;

%机器的能量消耗：第一个为机器的启动关闭能量消耗量，第二个为机器工作时的能量消耗功率，第三个为机器空闲时的能量消耗功率
Energy_consumption_power = [35, 3, 1.125;
                            40, 2.875, 1.25;
                            45, 2.75, 1.375;
                            50, 2.625, 1.5;
                            55, 2.5, 1.625;
                            60, 2.375, 1.75;
                            65, 2.25, 1.875;
                            70, 2.125, 2];      

% n = [8, 12, 16, 20, 24; 100, 200, 500];  %工件数量集
% m = [2, 3, 4, 5; 5, 10, 20];    %机器数量集
% f = [2, 3, 4; 4, 6, 8];  %工厂数量集
N = 20;     %工件数，使用不同的数据集工件数不同
M = 5;      %机器数，使用不同的数据集机器数不同
F = 4;      %工厂数，使用不同的数据集工厂数不同

P = 100;    %种群大小
G = 200;    %迭代次数
    
T = 15;     %每一个权重向量的邻居个数
O = 2;     %优化目标个数
CR = 0.7;   	%交叉概率
MU = 0.1;   	%变异概率


% processing_time = xlsread('data\data_20_5_2.xlsx');      %读取工件的加工时间
processing_time = xlsread('dataset\20_5_4.xlsx');      %读取工件的加工时间
PF = [];    %存储非支配解


for run = 1:1       %独立运行run次
    %[schedule, factory, reference_vector] = Initial_randomn(run);      %初始化工件码、工厂码、参考向量                                                                                                                                                                                             
    [schedule, factory, reference_vector] = Initial_NEH(processing_time, Energy_consumption_power, run);      %初始化工件码、工厂码、参考向量                                                                                                                                                                                             

    %寻找最近的T个邻居的索引值
    neighbor_index = Get_neighbor(reference_vector);        
    
    %计算目标值
    objective_value = Calculate_objective_value(schedule, factory, processing_time, Energy_consumption_power);        %计算目标值(第一个值为最大完工时间，第二个值为总能量消耗)
    %objective_value = Calculate_objective_value_ES(schedule, factory, processing_time, Energy_consumption_power);        %计算目标值(第一个值为最大完工时间，第二个值为总能量消耗)
    
    %初始化参考点
    for i = 1:2
        reference_point(i) = min(objective_value(:, i));        
    end
    
    %计算切比雪夫值
    tchebycheff = Calculate_Tchebycheff(objective_value, reference_vector, reference_point);    
    fitness = [objective_value, tchebycheff];       %前两个值为最大完工时间和总能量消耗，最后一个值为Tchebycheff值
    
    [PF, PF_index] = Nondominated_solution(objective_value);
    PF_schedule = schedule(PF_index, :);
    PF_factory = factory(PF_index, :);
    
    %迭代循环
    for i = 1:G
        gen = i;
        fprintf('第%d次迭代\n', i);
        for j = 1:P
            %遗传操作产生新解
%             rng(1);
            index = randperm(T);
            index1 = neighbor_index(j, index(1));
            index2 = neighbor_index(j, index(2));
            
            %遗传操作
            [new_schedule, new_factory] = Genetic_operation(schedule(index1, :), schedule(index2, :), factory(index1, :), factory(index2, :));
            %[new_schedule, new_factory] = Genetic_operation_improvement(schedule(index1, :), schedule(index2, :), factory(index1, :), factory(index2, :));
            
            %%%局部搜索
            [critical_factory, ~] = Calculate_makespan(new_schedule, new_factory, processing_time);
            [new_schedule, new_factory] = Local_search(critical_factory, new_schedule, new_factory, 48);
            
            %求目标值
            new_objective_value = Calculate_objective_value(new_schedule, new_factory, processing_time, Energy_consumption_power);
            %new_objective_value = Calculate_objective_value_ES(new_schedule, new_factory, processing_time, Energy_consumption_power);
            
            %如果新生成的解比原来解好就更新邻域
            if (Nondominated_judge(objective_value(j, :), new_objective_value) == -1)
                schedule(j, :) = new_schedule;
                factory(j, :) = new_factory;
                objective_value(j, :) = new_objective_value;
                new_tchebycheff = Calculate_Tchebycheff(new_objective_value, reference_vector, reference_point);
                fitness(j, :) = [new_objective_value, new_tchebycheff];
            elseif (Nondominated_judge(objective_value(j, :), new_objective_value) == 0)
%                 PF = [PF; new_objective_value];
                [PF, PF_schedule, PF_factory] = Update_PF(PF, new_objective_value, new_schedule, new_factory, PF_schedule, PF_factory);
            end
            
            %更新参考点
            for i = 1:2
                reference_point(i) = min(new_objective_value(i), reference_point(i));        %更新参考点
            end

            %更新邻域解
            [schedule, factory, objective_value, fitness] = Update_neighbor_solution(schedule, factory, objective_value, fitness, neighbor_index(j, :), reference_vector(j, :), reference_point, schedule(j, :), factory(j, :), objective_value(j, :));

            %更新非支配解
            [PF, PF_schedule, PF_factory] = Update_PF(PF, new_objective_value, new_schedule, new_factory, PF_schedule, PF_factory);
            
        end
        
        [PF, PF_schedule, PF_factory] = Collaborative_local_search(PF, PF_schedule, PF_factory, processing_time, Energy_consumption_power);  
        
        %画出非支配解
%         PF = Nondominated_solution(objective_value);
        clf
        %scatter(PF(:, 1), PF(:, 2));
        [~, index] = sort(PF(:, 1));
        PF = PF(index, :);
        PF_schedule = PF_schedule(index, :);
        PF_factory = PF_factory(index, :);
        plot(PF(:, 1), PF(:, 2), '-o');
        title(['KMOEA/D: Iteration ', num2str(gen)]);
        xlabel('Makespan');
        ylabel('TEC');
        hold on
        scatter(objective_value(:, 1), objective_value(:, 2));
        drawnow
        
 
    end
    
    
end



% delete('KMOEAD.xlsx');
% xlswrite('KMOEAD.xlsx', PF);


