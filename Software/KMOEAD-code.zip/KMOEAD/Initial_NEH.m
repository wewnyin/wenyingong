function [schedule, factory, reference_vector] = Initial_NEH(processing_time, Energy_consumption_power, run)    %随机初始化
global N M F P G T O MU;

rng(run);

schedule = [];
factory = [];


%随机初始化工件码、工厂码
for i = 1:P
    %随机初始化工件码
    s_temp = [];
    f_temp = [];
    s = [];
    f = [];
    s = randperm(N);
    for j = 1:M
        s_temp = [s_temp, s];
    end
    schedule = [schedule; s_temp];
        
    %随机初始化工厂码
    f = ceil(F * rand(1, N));
    t = 1:F;
    judge = tabulate(f);
    while ~all(ismember(t, f)) || any(judge(:, 2) < 2)
        f = ceil(F * rand(1, N));   %确保每个工厂都有两个工件加工
        judge = tabulate(f);
    end
    for j = 1:M
        f_temp = [f_temp, f];
    end
    factory = [factory; f_temp];
end


%使用NEH算法初始化工件码、工厂码
for i = 1:P
    total_processing_time = [];
    for j = 1:N
        f_index = factory(i, j);    %确定工件所在的工厂
        start_index = (f_index - 1) * M + 1;    %确定processing_time中所处理数据的起始列
        end_index = start_index + M - 1;    %确定processing_time中所处理数据的终止列
        time = sum(processing_time(j, start_index:end_index));
        total_processing_time = [total_processing_time, time];
    end
    
    %非增顺寻排序
    [~, order] = sort(total_processing_time, 'descend');
    
    %选取最小完工时间的序列
    s_temp = [schedule(i, order(1)), schedule(i, order(2))];
    f_temp = [factory(i, order(1)), factory(i, order(2))];
       
    [s_temp, f_temp] = Insert_sort(s_temp, f_temp, processing_time, Energy_consumption_power); 
    
    for j = 3:length(order)
        s_temp = [s_temp, schedule(i, order(j))];
        f_temp = [f_temp, factory(i, order(j))];
        [s_temp, f_temp] = Insert_sort(s_temp, f_temp, processing_time, Energy_consumption_power);
    end
    
    s_expand = Expand(s_temp);
    f_expand = Expand(f_temp);
    
    schedule(i, :) = s_expand;
    factory(i, :) = f_expand;
    fprintf('第%d个个体采用NEH\n', i);
end


%随机初始化参考向量
vector = (0:P) / P;
for i = 1:(P+1)
    reference_vector(i, 1) = vector(i);
    reference_vector(i, 2) = 1 - vector(i);
    
    if reference_vector(i, 1) == 0
        reference_vector(i, 1) = 0.00001;
    end
    if reference_vector(i, 2) == 0
        reference_vector(i, 2) = 0.00001;
    end
    
end
len = size(reference_vector, 1);
index = randperm(len);
index = sort(index(1:P));
reference_vector = reference_vector(index, :);


end

