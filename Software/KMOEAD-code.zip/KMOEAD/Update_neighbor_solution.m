function [schedule, factory, objective_value, fitness] = Update_neighbor_solution(schedule, factory, objective_value, fitness, neighbor_index, reference_vector, reference_point, new_schedule, new_factory, new_objective_value)  
f2 = Calculate_Tchebycheff(new_objective_value, reference_vector, reference_point);

%更新邻域解
for i = 1:size(neighbor_index)     
    f1 = fitness(neighbor_index(i), 3);
    if f2 < f1
        schedule(neighbor_index(i), :) = new_schedule;
        factory(neighbor_index(i), :) = new_factory;
        objective_value(neighbor_index(i), :) = new_objective_value;
        temp = [new_objective_value, f2];
        fitness(neighbor_index(i), :) = temp;
    end

end