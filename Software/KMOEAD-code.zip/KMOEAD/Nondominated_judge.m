function judge = Nondominated_judge(o1, o2)     %判断哪个值最好，o1好则返回1，一样好则返回0，否则返回-1

if all(o1(1, :) <= o2(1, :)) && any(o1(1, :) < o2(1, :))
    judge = 1;
elseif all(o1(1, :) >= o2(1, :)) && any(o1(1, :) > o2(1, :))
    judge = -1;
else
    judge = 0;
end

end