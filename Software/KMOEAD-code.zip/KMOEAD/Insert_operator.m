function [schedule_segment, factory_segment] = Insert_operator(schedule_segment, factory_segment, ext_pos, ins_pos);
%插入操作

if ext_pos - ins_pos > 0
    t1 = schedule_segment(ext_pos);
    t2 = factory_segment(ext_pos);
    for i = ext_pos:-1:(ins_pos + 1)
        schedule_segment(i) = schedule_segment(i - 1);
        factory_segment(i) = factory_segment(i - 1);
    end
    schedule_segment(ins_pos) = t1;
    factory_segment(ins_pos) = t2;
else
    t1 = schedule_segment(ext_pos);
    t2 = factory_segment(ext_pos);
    for i = ext_pos:(ins_pos - 1)
        schedule_segment(i) = schedule_segment(i + 1);
        factory_segment(i) = factory_segment(i + 1);
    end
    schedule_segment(ins_pos) = t1;
    factory_segment(ins_pos) = t2;
end


end