// JADE_method.cpp: implementation of the CJADE_method class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "JADE_method.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CJADE_method::CJADE_method()
{
	max_iterations = Max_of_NFEs/population_size;
	max_NFFEs      = Max_of_NFEs;
	pop_size       = population_size;

	parent_pop   = new CIndividual[2*pop_size];
	child_pop    = new CIndividual[2*pop_size];
	child_pop1   = new CIndividual[2*pop_size];
	upper_bounds = new double[N_of_x];
	lower_bounds = new double[N_of_x];
	sort_index   = new int[2*pop_size];

	/* -------------------- only for DE method -------------------- */
	m_F        = 0.5;
	m_CR       = 0.9;

	/* ------------------- only for JADE method ------------------- */
	mu_CR  = 0.5;
	mu_FF  = 0.5;
	std_CR = 1.0/6;
	std_FF = 1.0/6;

	S_CR = new double[pop_size];
	S_FF = new double[pop_size];

	JADE_c = 0.1;
	if (pop_size <= 50)
	{
		JADE_p = 0.2;	// 0.05 ~ 0.2
	}
	else
	{
		JADE_p = 0.05;	// 0.05 ~ 0.2
	}

	JADE_alpha         = 1;
	archive_size       = 0;
	extended_size      = 0;
	total_archive_size = JADE_alpha*pop_size;
	archive_pop        = new CIndividual[total_archive_size];

	/* ---- only for my proposed new strategy adaptation method ---- */
	mu_strategy = 0.5;
	S_strategy  = new double[pop_size];

	for (int i=0;i<10;i++)
	{
		mu_CR1[i] = 0.5;
		mu_FF1[i] = 0.5;
	}
}

CJADE_method::~CJADE_method()
{
	delete []parent_pop;
	delete []child_pop;
	delete []child_pop1;
	delete []upper_bounds;
	delete []lower_bounds;
	delete []sort_index;

	/* ------------------- only for JADE method ------------------- */
	delete []S_CR;
	delete []S_FF;
	delete []archive_pop;

	/* ---- only for my proposed new strategy adaptation method ---- */
	delete []S_strategy;
}

void CJADE_method::init_variables()
{
	if ((index_of_normal) == 0)
	{
		printf("Are you kiding me?\nThere is no function to be optimized.\n");
		exit(0);
	}

	if (index_of_normal != 0)
	{
		init_normal_variables();
	}

	max_interval = 0;
	double temp;
	for (int i=0;i<N_of_x;i++)
	{
		temp = upper_bounds[i]-lower_bounds[i];
		max_interval += temp*temp;
	}
	max_interval = sqrt(max_interval);
}

void CJADE_method::init_normal_variables()
{
	int i;
	int n = N_of_x;
	func_flag = index_of_normal;

	switch(func_flag) {
	case 1:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -100.0;
			upper_bounds[i] = 100.0;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	case 2:
		for (i=0;i<N_of_x;i++)
		{
			lower_bounds[i] = -10.0;
			upper_bounds[i] = 10.0;
		}
		known_optimal = 0.0;
		MINIMIZE = 1;
		break;
	default:
		printf("The function you selected does not exist.\n");
		exit(0);
	}
}

void CJADE_method::init_pop()
{
	printf("Random based parent_pop initialization method is used.\n");
	init_pop_random();

	// initialize the F and CR of DE
	for (int i=0;i<pop_size;i++)
	{
		parent_pop[i].F        = m_rnd.rndreal(0.1, 1.0);
		parent_pop[i].CR       = m_rnd.rndreal(0.0, 1.0);
		parent_pop[i].accepted = 0;
		parent_pop[i].strategy = m_rnd.rndreal(0.0, 1.0);
	}
}

void CJADE_method::init_pop_random()
{
	for (int i=0;i<pop_size;i++)
	{
		for (int j=0;j<N_of_x;j++)
		{
			parent_pop[i].xreal[j] = m_rnd.rndreal(lower_bounds[j],upper_bounds[j]);
		}
	}
}

void CJADE_method::evaluate_ind(CIndividual &indv)
{
	if ((index_of_normal) == 0)
	{
		printf("Are you kinding me?\nThere is no function to be optimized.\n");
		exit(0);
	}

	if (index_of_normal != 0)
	{
		evaluate_normal_ind(indv);
	}

	// convert objective function value into fitness
	indv.fitness = MINIMIZE*indv.obj;

	// sum violation of the constrained functions
	if (N_of_constr == 0)
	{
		indv.constr_violation = 0.0;
		indv.feasible = 1;
	}
}

void CJADE_method::evaluate_normal_ind(CIndividual &indv)
{
	func_flag = index_of_normal;

	m_func.evaluate_normal_fitness(indv.xreal,indv.obj,indv.constr,
		func_flag, evaluations);
}

void CJADE_method::evaluate_pop(CIndividual *pop, int size)
{
	for (int i=0;i<size;i++)
	{
		evaluate_ind(pop[i]);
	}
}

int CJADE_method::compare_ind (CIndividual *indv1, CIndividual *indv2)
{
	if((indv1->feasible==TRUE && indv2->feasible==TRUE))
	{
		if(indv1->fitness < indv2->fitness)
		{
			return 1;
		}
		else if (indv1->fitness > indv2->fitness)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
	else if(indv1->feasible==TRUE && indv2->feasible==FALSE)
	{
		return 1;
	}
	else if (indv1->feasible==FALSE && indv2->feasible==TRUE)
	{
		return -1;
	}
	else
	{
		if(indv1->constr_violation < indv2->constr_violation)
		{
			return 1;
		}
		else if (indv1->constr_violation > indv2->constr_violation)
		{
			return -1;
		}
		else
		{
			//return 0;
			if (indv1->fitness < indv2->fitness)
			{
				return 1;
			}
			else if (indv1->fitness > indv2->fitness)
			{
				return -1;
			}
			else
			{
				return 0;
			}
		}
	}
}

void CJADE_method::find_best_index(CIndividual *pop, int size)
{
	int flag;

	best_index = 0;
	for (int i=1;i<size;i++)
	{
		flag = compare_ind(&pop[i], &pop[best_index]);
		if (flag == 1)
		{
			best_index = i;
		}
	}

	worst_index = 0;
	for (i=1;i<size;i++)
	{
		flag = compare_ind(&pop[i], &pop[worst_index]);
		if (flag == -1)
		{
			worst_index = i;
		}
	}
}

void CJADE_method::random_index(int *array_index, int all_size, int size)
{
	int i,j,krand;
	int *a;
	a = new int[all_size];

	for(i = 0;i<all_size;i++)
	{
		a[i] = i;
	}
	for(i=0;i<size;i++)
	{
		j = m_rnd.rndint(i,(all_size-1));
		krand = a[i];
		a[i] = a[j];
		a[j] = krand;
	}	
	for(i=0;i<size;i++)
	{
		array_index[i] = a[i];
	}
	a = NULL;

	delete []a;
}

void CJADE_method::shell_sort(CIndividual *pop, int *list, int size)
{
	int done;
	int step, bound, i, j;
	int temp;

	step = size;  // array length
	while (step > 1) 
	{
		step /= 2;	//halve the step size
		do 
		{
			done   = 1;
			bound  = size - step;
			for (j = 0; j < bound; j++) 
			{
				i = j + step + 1;
				if (compare_ind(&pop[list[j]], &pop[list[i-1]]) == -1) 	
				{
					temp      = list[i-1];
					list[i-1] = list[j];
					list[j]   = temp;
					done = 0; // if a swap has been made we are not finished yet
				}  // if
			}  // for
		} while (done == 0);   // while
	} //while (step > 1)
}

void CJADE_method::shell_sort_array(double *array, int *list, int size)
{
	int done;
	int step, bound, i, j;
	int temp;

	step = size;  // array length
	while (step > 1) 
	{
		step /= 2;	//halve the step size
		do 
		{
			done   = 1;
			bound  = size - step;
			for (j = 0; j < bound; j++) 
			{
				i = j + step + 1;
				if (array[list[j]] < array[list[i-1]]) 	
				{
					temp      = list[i-1];
					list[i-1] = list[j];
					list[j]   = temp;
					done = 0; // if a swap has been made we are not finished yet
				}  // if
			}  // for
		} while (done == 0);   // while
	} //while (step > 1)
}

double CJADE_method::median(double *array, int size)
{
	double value = 0.0;

	int list[2000];
	for (int i=0;i<2000;i++)
	{
		list[i] = i;
	}
	shell_sort_array(array, list, size);
	
	if (size%2 == 1)
	{// the size of the array is odd.
		int media_index;
		media_index = size/2;
		value = array[list[media_index]];
	}
	else
	{// the size of the array is even.
		int a = (size-1)/2;
		int b = size/2;
		value = (array[list[a]]+array[list[b]])/2.0;
	}

	return value;
}

void CJADE_method::statistic_pop_fitness(CIndividual *pop, int size)
{
	int i;
	
	min_fitness = best_individual.fitness;
	max_fitness = parent_pop[worst_index].fitness;

	avg_fitness = 0.0;
	for (i=0;i<size;i++)
	{
		avg_fitness += pop[i].fitness;
	}
	avg_fitness = avg_fitness/(double)size;

	double value = 0.0;
	for (i=0;i<size;i++)
	{
		value += fabs(pop[i].fitness-avg_fitness);
	}
	std_fitness = value/(double)size;

	double array[population_size];
	for (i=0;i<size;i++)
	{
		array[i] = pop[i].fitness;
	}
	media_fitness = median(array, size);
}

void CJADE_method::display_result(int gen)
{
	if(gen%10==0 || gen == 1)
	{
		//��ǰ��ø����������Ļ
		cout<<setw(5)<<gen;
		cout<<setw(8)<<evaluations;
		//��ʾԼ��������ֵ
		if (N_of_constr != 0)
		{			
			cout<<setw(15)<<best_individual.constr_violation;
		}
		cout.precision(10);					//�����������
		cout<<setw(20)<<MINIMIZE * parent_pop[best_index].fitness;
		cout<<setw(20)<<MINIMIZE * parent_pop[m_rnd.rndint(0, pop_size-1)].fitness;
		cout<<setw(20)<<MINIMIZE * parent_pop[worst_index].fitness<<endl;
	}
}

void CJADE_method::report_result(int gen, ofstream &file)
{
	if (gen < 100 )
	{
		//��ǰ��ø���������ļ�
		file<<setw(5)<<gen;
		file<<setw(10)<<evaluations;
		file.precision(20);			//�����������
		file<<setw(30)<<MINIMIZE * best_individual.fitness;
		file<<setw(30)<<best_individual.constr_violation;
		//file<<setw(30)<<best_individual.CR;
		file<<endl;
	}
	else
	{
		if ((gen % out_internal == 0 ||
			gen >= max_iterations ||
			evaluations >= max_NFFEs) )
		{
			//��ǰ��ø���������ļ�
			file<<setw(5)<<gen;
			file<<setw(10)<<evaluations;
			file.precision(20);			//�����������
			file<<setw(30)<<MINIMIZE * best_individual.fitness;
			file<<setw(30)<<best_individual.constr_violation;
			//file<<setw(30)<<best_individual.CR;
			file<<endl;
		}
	}
}

void CJADE_method::report_diversity(int gen, ofstream &file)
{
	// calculate the diversity of the population
	double x_average[2000];
	for (int i=0;i<2000;i++)
	{
		x_average[i] = 0.0;
	}

	for (i=0;i<N_of_x;i++)
	{
		for (int j=0;j<pop_size;j++)
		{
			x_average[i] += parent_pop[j].xreal[i];
		}
		x_average[i] = x_average[i]/((double)pop_size);
	}

	double diversity = 0.0;
	for (i=0;i<pop_size;i++)
	{
		double temp = 0.0;
		double x;
		for (int j=0;j<N_of_x;j++)
		{
			x = parent_pop[i].xreal[j];
			temp += (x-x_average[j])*(x-x_average[j]);
		}
		diversity += sqrt(temp);
	}
	diversity = diversity/(((double)pop_size)*max_interval);

	pop_diversity = diversity;
	
	if (gen < 100 )
	{
		//��ǰ��ø���������ļ�
		file<<setw(5)<<gen;
		file<<setw(10)<<evaluations;
		file.precision(20);			//�����������
		file<<setw(30)<<diversity<<endl;
	}
	else
	{
		if ((gen % out_internal == 0 ||
			gen >= max_iterations ||
			evaluations >= max_NFFEs) )
		{
			//��ǰ��ø���������ļ�
			file<<setw(5)<<gen;
			file<<setw(10)<<evaluations;
			file.precision(20);			//�����������
			file<<setw(30)<<diversity<<endl;
		}
	}
}

void CJADE_method::report_parameter(int gen, ofstream &file)
{
	int counter = max_iterations/20;
	if (method_flag != 1)
	{
		if (gen==1 || gen%counter == 0)//gen < 100 )
		{
			//��ǰ��ø���������ļ�
			file<<setw(5)<<gen;
			file<<setw(10)<<evaluations;
			file.precision(20);			//�����������

			file<<setw(30)<<mu_CR;
			file<<setw(30)<<mu_FF;
			file<<setw(30)<<mu_strategy;
			//file<<setw(30)<<best_individual.strategy;

			file<<endl;
		}
		/*else
		{
			if ((gen % out_internal == 0 ||
				gen >= max_iterations ||
				evaluations >= max_NFFEs) )
			{
				//��ǰ��ø���������ļ�
				file<<setw(5)<<gen;
				file<<setw(10)<<evaluations;
				file.precision(20);			//�����������

				file<<setw(30)<<mu_CR;
				file<<setw(30)<<mu_FF;
				file<<setw(30)<<mu_strategy;

				file<<endl;
			}
		}*/
	}
	else
	{
		if (gen%counter == 0)//gen < 100 )
		{
			//��ǰ��ø���������ļ�
			file<<setw(5)<<gen;
			file<<setw(10)<<evaluations;
			file.precision(20);			//�����������

			file<<setw(30)<<best_individual.CR;
			file<<setw(30)<<best_individual.F;
			file<<setw(30)<<best_individual.strategy;

			file<<endl;
		}
		/*else
		{
			if ((gen % out_internal == 0 ||
				gen >= max_iterations ||
				evaluations >= max_NFFEs) )
			{
				//��ǰ��ø���������ļ�
				file<<setw(5)<<gen;
				file<<setw(10)<<evaluations;
				file.precision(20);			//�����������

				file<<setw(30)<<best_individual.CR;
				file<<setw(30)<<best_individual.F;
				file<<setw(30)<<best_individual.strategy;

				file<<endl;
			}
		}*/
	}
	
//	int counter = max_iterations/20;
//	if (gen%counter == 0)
//	{
//		//��ǰ��ø���������ļ�
//		file<<setw(5)<<gen;
//		file<<setw(10)<<evaluations;
//		file.precision(20);			//�����������
//		file<<setw(30)<<best_individual.CR;
//		file<<setw(30)<<best_individual.F;
//		file<<setw(30)<<best_individual.migration_rate;
//		file<<endl;
//	}
	
//	else
//	{
//		if ((gen % 10 == 0 ||
//			gen >= max_iterations ||
//			evaluations >= max_NFFEs) )
//		{
//			//��ǰ��ø���������ļ�
//			file<<setw(5)<<gen;
//			file<<setw(10)<<evaluations;
//			file.precision(20);			//�����������
//			file<<setw(30)<<best_individual.CR;
//			file<<setw(30)<<best_individual.F;
//			file<<setw(30)<<best_individual.migration_rate;
//			file<<endl;
//		}
//	}
}

void CJADE_method::sort_pop(CIndividual *pop, int size)
{
	for (int i=0;i<size;i++)
	{
		sort_index[i] = i;
	}
	shell_sort(pop, sort_index, size);
}

void CJADE_method::Run_Optimizer(int run_no, double seed, int method, int restart_flag)
{

	int i = 0; 
	
	method_flag = method;
	rnd_seed = seed;

	ofstream SummaryFile;
	SummaryFile.open(".\\results\\summary.txt",ios::app);

	char f_name1[150];
	sprintf(f_name1,"%s%d%s",".\\results\\process\\process_",run_no+1,".txt");		
	ofstream file_process(f_name1);

	char f_name2[150];
	sprintf(f_name2,"%s%d%s",".\\results\\diversity\\diversity_",run_no+1,".txt");		
	ofstream file_diversity(f_name2);

	char f_name3[150];
	sprintf(f_name3,"%s%d%s",".\\results\\migration\\migration_",run_no+1,".txt");		
	ofstream file_migration(f_name3);

	clock_t start, finish;
	double time_consume;

	time_consume = 0.0;
	start = clock();						// starts the clock
	
	srand((unsigned)time(0));
	m_rnd.randomize(seed);

	evaluations = 0;						// reset the NFFEs

	init_variables();
	init_pop();
	evaluate_pop(parent_pop, pop_size);
	find_best_index(parent_pop, pop_size);
	best_individual = parent_pop[best_index];

	gen = 1;								// current generation number
	int counter=0;							// only for restarting the population

	statistic_pop_fitness(parent_pop, pop_size);

	report_result(gen, file_process);
	report_diversity(gen, file_diversity);
	report_parameter(gen, file_migration);

	int feasible_flag = 0;					// check to get the feasible individual first
	flag_precision = 0;						// check to arrive the required value
	double diversity_max = pop_diversity;
	double delta = 1.0;						// only for elitist learning
	/* -------- add different optimizer here -------- */
	while ( (evaluations < max_NFFEs) && (gen < max_iterations) )
	{
		finish = clock();					// time consuming of this generation
		time_consume = (double)(finish-start)/1000.0;

		// report the results in the screen
		/* comment the following routines to save the time_consuming */
		//display_result(gen);
		
		// ADD YOUR OPTIMIZER HERE
		switch(method) {
		case 1:// JADE with my proposed strategy adaptation
			strategy_adaptation_type = 1;	// 0: uniform; 1: method1;
			run_my_SaJADE_method();
			break;
		default:
			printf("The method selected does not exist.\n");
			exit(0);
		}

		gen++;

		find_best_index(parent_pop, pop_size);
		
		if (compare_ind(&parent_pop[best_index], &best_individual) != -1)
		{
			best_individual = parent_pop[best_index];
		}

		statistic_pop_fitness(parent_pop, pop_size);
		
		report_result(gen, file_process);
		report_diversity(gen, file_diversity);
		report_parameter(gen, file_migration);

		if (flag_precision == 0 && 
			MINIMIZE*best_individual.fitness - known_optimal < PRECISION
			&& best_individual.feasible == 1)
		{
			flag_precision = 1;
			ofstream SummaryFile1;
			SummaryFile1.open(".\\results\\evaluations.txt",ios::app);			
			SummaryFile1<<setw(9)<<evaluations<<endl;
			SummaryFile1.close();
			//break;		// ������һ���ľ���ͳ����Ӧֵ���۴���ʱʹ��
		}
		if (N_of_constr != 0 && feasible_flag == 0 && best_individual.feasible == 1)
		{
			feasible_flag = 1;
			ofstream SummaryFile1;
			SummaryFile1.open(".\\results\\feasible_NFFEs.txt",ios::app);
			SummaryFile1<<setw(9)<<evaluations<<endl;
			SummaryFile1.close();
		}
	}
	/* -------- add different optimizer here -------- */
	
	printf("The total running time is %f s.\n", time_consume);
	printf("The routine exits successfully.\n\n");

	SummaryFile.precision(15);
	SummaryFile<<setw(5)<<gen<<setw(9)<<evaluations
		<<setw(25)<<MINIMIZE * best_individual.fitness
		<<setw(8)<<time_consume
		<<setw(25)<<best_individual.constr_violation<<endl;

		
	file_process.close();
	file_diversity.close();
	file_migration.close();
	SummaryFile.close();
	
	return;
}


/* ---- only for my proposed new strategy adaptation method ---- */
void CJADE_method::run_my_SaJADE_method()
{
	int    i, j;
	int    r1, r2, r3;	
	int    j_rand;
	double low, up;

	int    archive_index;	// if r3 is chosen from archive archive_index=1, else =0
	int    p_index;
	int    SS_size = 0;

	sort_pop(parent_pop, pop_size);

	num_of_strategy = 4;
	
	int    strategy_index[population_size];

	for (i=0;i<pop_size;i++)
	{
		do {
			r1 = m_rnd.rndint(0, pop_size-1);
		} while(r1 == i);
		do {
			r2 = m_rnd.rndint(0, pop_size-1);
		} while(r2 == r1 || r2 == i);
		
		///////////////////////////////////////////////////////////
		// 1. generate the strategy
		switch(strategy_adaptation_type) {
		case 0:// uniform
			child_pop[i].strategy = m_rnd.rndreal(0.0, 1.0);
			strategy_index[i] = (int)floor(child_pop[i].strategy*num_of_strategy)+1;
			break;
		case 1:// similar to JADE 
			if (gen == 1)
			{
				child_pop[i].strategy = m_rnd.gaussian(mu_strategy, 1.0/6);
				//child_pop[i].strategy = m_rnd.rndreal(0.0, 1.0);
			}
			else
			{
				child_pop[i].strategy = m_rnd.gaussian(mu_strategy, 0.1);
			}
			if (child_pop[i].strategy > 1 || child_pop[i].strategy < 0)	
			{
				child_pop[i].strategy = m_rnd.rndreal(0.0, 1.0);
			}
			strategy_index[i] = (int)floor(child_pop[i].strategy*num_of_strategy)+1;
			break;
		default:
			printf("The type of the strategy adaptation does not exist.\n");
			exit(0);
		}
		///////////////////////////////////////////////////////////

		// 2. generate the CR and F for each offspring
		child_pop[i].CR = m_rnd.gaussian(mu_CR, 0.1);
		if (child_pop[i].CR > 1 || child_pop[i].CR < 0)	
		{
			child_pop[i].CR = m_rnd.rndreal(0.0, 1.0);
		}
		if (strategy_adaptation_type == 0)
		{
			do {
				child_pop[i].F  = m_rnd.cauchy(mu_FF, 0.1);
			} while(child_pop[i].F <= 0);
			if (child_pop[i].F > 1)
			{
				child_pop[i].F = 1;
			}
		}
		else
		{
		///////////////////////////////////////////////////////////////////////
		if (strategy_index[i]==1 || strategy_index[i]==3 || N_of_x>100)
		{// for DE/current-to-pbest mutation
			do {
				child_pop[i].F  = m_rnd.cauchy(mu_FF, 0.1);
			} while(child_pop[i].F <= 0);
			if (child_pop[i].F > 1)
			{
				child_pop[i].F = 1;
			}
		}
		else// if (strategy_index[i]==2 || strategy_index[i]==4)
		{// for DE/rand-to-pbest mutation
			do {
				child_pop[i].F  = m_rnd.gaussian(mu_FF, 0.1);
			} while(child_pop[i].F <= 0);
			if (child_pop[i].F > 1)
			{
				child_pop[i].F = 1;
			}
		}
		///////////////////////////////////////////////////////////////////////
		}
		m_CR = child_pop[i].CR;
		m_F  = child_pop[i].F;

		// 3. randomly choose the p_best individual
		p_index = m_rnd.rndint(0, int(JADE_p*pop_size)-1);
		p_index = sort_index[p_index];

		// ------------------------------------------------------------- //
		// 4. choose r3

		if (strategy_index[i] <= num_of_strategy/2)
		{// without archive
			// choose r3 only from the parent population
			do {
				r3 = m_rnd.rndint(0, pop_size-1);
			} while(r3 == r2 || r3 == r1 || r3 == i);
			r3 = sort_index[r3];
		}
		else
		{// with archive	
			// choose r3 from the union of parent population and the archive
			archive_index = 0;
			int k = pop_size+archive_size;
			r3 = m_rnd.rndint(0, k-1);
			if (r3 < pop_size)
			{// r3 is chosen from the parent population
				while(r3 == r2 || r3 == r1 || r3 == i)
				{
					r3 = m_rnd.rndint(0, pop_size-1);
				}
				r3 = sort_index[r3];
			}
			else
			{// r3 is chosen from the archive
				archive_index = 1;
				r3 = r3-pop_size;
			}
		}
		r1 = sort_index[r1];
		r2 = sort_index[r2];
		// ------------------------------------------------------------- //

		// 5. generate the offspring
		j_rand = m_rnd.rndint(0, N_of_x-1);
		for (j=0;j<N_of_x;j++)
		{
			low = lower_bounds[j];
			up  = upper_bounds[j];

			if (m_rnd.rndreal(0,1) < m_CR || j == j_rand)
			{
				switch(strategy_index[i]) {
				// without archive
				case 1:// DE/current-to-pbest mutation
					child_pop[i].xreal[j] = parent_pop[sort_index[i]].xreal[j] +
						m_F*(parent_pop[p_index].xreal[j]-parent_pop[sort_index[i]].xreal[j]) +
						m_F*(parent_pop[r2].xreal[j]-parent_pop[r3].xreal[j]);
					break;
				case 2:// DE/rand-to-pbest mutation
					child_pop[i].xreal[j] = parent_pop[r1].xreal[j] +
						m_F*(parent_pop[p_index].xreal[j]-parent_pop[r1].xreal[j]) +
						m_F*(parent_pop[r2].xreal[j]-parent_pop[r3].xreal[j]);
					break;
				// with archive
				case 3:// DE/current-to-pbest mutation
					if (archive_index==0)
					{
						child_pop[i].xreal[j] = parent_pop[sort_index[i]].xreal[j] +
							m_F*(parent_pop[p_index].xreal[j]-parent_pop[sort_index[i]].xreal[j]) +
							m_F*(parent_pop[r2].xreal[j]-parent_pop[r3].xreal[j]);
					}
					else
					{
						child_pop[i].xreal[j] = parent_pop[sort_index[i]].xreal[j] +
							m_F*(parent_pop[p_index].xreal[j]-parent_pop[sort_index[i]].xreal[j]) +
							m_F*(parent_pop[r2].xreal[j]-archive_pop[r3].xreal[j]);
					}
					break;
				case 4:// DE/rand-to-pbest mutation
					if (archive_index==0)
					{
						child_pop[i].xreal[j] = parent_pop[r1].xreal[j] +
							m_F*(parent_pop[p_index].xreal[j]-parent_pop[r1].xreal[j]) +
							m_F*(parent_pop[r2].xreal[j]-parent_pop[r3].xreal[j]);
					}
					else
					{
						child_pop[i].xreal[j] = parent_pop[r1].xreal[j] +
							m_F*(parent_pop[p_index].xreal[j]-parent_pop[r1].xreal[j]) +
							m_F*(parent_pop[r2].xreal[j]-archive_pop[r3].xreal[j]);
					}
					break;
				default:
					printf("The selected strategy does not exist.\n");
					exit(0);
				}

				if (child_pop[i].xreal[j] < low || child_pop[i].xreal[j] > up)
				{
					child_pop[i].xreal[j] = m_rnd.rndreal(low, up);
				}
			}
			else
			{
				child_pop[i].xreal[j] = parent_pop[sort_index[i]].xreal[j];
			}
		}
	}
	
	// 6. evaluate the offspring
	evaluate_pop(child_pop, pop_size);

	// 7. obtain the next parent population
	//    and save the successful CR, F, and strategy 
	for (i=0;i<pop_size;i++)
	{
		int flag = compare_ind(&child_pop[i], &parent_pop[sort_index[i]]);
		if (flag != -1)
		{
			// save the inferior parent into the archive
			if (archive_size < total_archive_size)
			{
				archive_pop[archive_size] = parent_pop[sort_index[i]];
				archive_size++;
			}
			else
			{
				archive_size = total_archive_size;
				
				int ii = m_rnd.rndint(0, archive_size-1);

				archive_pop[ii] = parent_pop[sort_index[i]];
			}

			// replace the inferior parent with the better offspring
			parent_pop[sort_index[i]] = child_pop[i];

			// save the successful strategy
			S_strategy[SS_size] = child_pop[i].strategy;
			
			// save the successful CR and F
			S_CR[SS_size] = child_pop[i].CR;
			S_FF[SS_size] = child_pop[i].F;
			SS_size++;

			parent_pop[sort_index[i]].accepted = 1;
		}
		else
		{
			parent_pop[sort_index[i]].accepted = 0;
		}
	}

	// 8. update mu_CR, mu_F, and mu_strategy based on the successful CRs and Fs
	if (SS_size != 0)
	{
		// update mu_CR
		double mean_cr = 0.0;
		for (i=0;i<SS_size;i++)
		{
			mean_cr += S_CR[i];
		}
		mean_cr = mean_cr/SS_size;
		mu_CR = (1-JADE_c)*mu_CR + JADE_c*mean_cr;

		// update mu_F
		double mean_ff = 0.0;
		double t1 = 0.0;
		double t2 = 0.0;
		for (i=0;i<SS_size;i++)
		{
			t1 += S_FF[i]*S_FF[i];
			t2 += S_FF[i];
		}
		mean_ff = t1/t2;
		mu_FF = (1-JADE_c)*mu_FF + JADE_c*mean_ff;

		// update mu_strategy
		double mean_strategy = 0.0;
		for (i=0;i<SS_size;i++)
		{
			mean_strategy += S_strategy[i];
		}
		mean_strategy = mean_strategy/SS_size;
		mu_strategy = (1-JADE_c)*mu_strategy + JADE_c*mean_strategy;
	}
}


