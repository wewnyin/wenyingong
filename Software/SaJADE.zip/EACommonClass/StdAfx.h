// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__4C3B4F23_7BD6_4DC5_BB97_4EF09DAE7B68__INCLUDED_)
#define AFX_STDAFX_H__4C3B4F23_7BD6_4DC5_BB97_4EF09DAE7B68__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// TODO: reference additional headers your program requires here
// --------------------include files--------------------
#include <iostream.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <windows.h>
#include <fstream.h>
#include <iomanip.h>
#include <string.h>
#include <stdio.h>
#include <assert.h>

// --------------------Global variables--------------------
#define E	2.71828182845905
#define PI	3.14159265358979
#define INF	1.0e14
#define EPS 1.0e-14		// the precision of the constraints

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__4C3B4F23_7BD6_4DC5_BB97_4EF09DAE7B68__INCLUDED_)
