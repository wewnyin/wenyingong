// ProblemDef.h: interface for the CProblemDef class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_)
#define AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Individual.h"
#include "Rand.h"

// only for unconstrained optimization problems
class CProblemDef  
{
public:
	CProblemDef();
	virtual ~CProblemDef();

	// for unconstrained optimization problems
public:
	double	center[200];
	int		flag_once;
	double	TempValue(double x,int a,int k,int m);

	void	evaluate_normal_fitness(double *xreal,double &obj, 
		double *constr, int func_flag, long int &evaluations);

public:
	void test_01(double *xreal,double &obj, double *constr);
	void test_02(double *xreal,double &obj, double *constr);
	void test_03(double *xreal,double &obj, double *constr);
	void test_04(double *xreal,double &obj, double *constr);
	void test_05(double *xreal,double &obj, double *constr);
	void test_06(double *xreal,double &obj, double *constr);
	void test_07(double *xreal,double &obj, double *constr);
	void test_08(double *xreal,double &obj, double *constr);
	void test_09(double *xreal,double &obj, double *constr);
	void test_10(double *xreal,double &obj, double *constr);
	void test_11(double *xreal,double &obj, double *constr);
	void test_12(double *xreal,double &obj, double *constr);
	void test_13(double *xreal,double &obj, double *constr);
	void test_14(double *xreal,double &obj, double *constr);
	void test_15(double *xreal,double &obj, double *constr);
	void test_16(double *xreal,double &obj, double *constr);
	void test_17(double *xreal,double &obj, double *constr);
	void test_18(double *xreal,double &obj, double *constr);

	// add new test problems here...
	// unconstrained application problems
	void Chebychev_Polynomial(double *xreal, double &obj, double *constr);	// 27
	void FMSoundWave(double *xreal, double &obj, double *constr);			// 28
	// only for Lennard-Jones
	double y0[200];
	void Lennard_Jones(double *xreal, double &obj, double *constr);			// 29
	// only for Spread Spectrum Radar
	double Phi[4*N_of_x-1];	// Phi[0] is not used here
	double x[N_of_x+1];		// x[0] is not used here
	void SpreadSpectrumRadar(double *xreal, double &obj, double *constr);	// 30
	// only for Linear Equations System
	double A[10][10];
	double B[10];
	void LinearEquationsSystem(double *xreal, double &obj, double *constr);	// 31
};

#endif // !defined(AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_)
