// ProblemDef.h: interface for the CProblemDef class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_)
#define AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../global.h"
#include "Individual.h"
#include "Rand.h"


// only for unconstrained optimization problems
class CProblemDef  
{
public:
	CProblemDef();
	virtual ~CProblemDef();

	// for unconstrained optimization problems
public:
	int		flag_once;
	int		m_function;
	CRand	m_rnd;

	void	evaluate_normal_fitness(double *xreal,tFitness &obj, 
				double *constr, int func_flag, long int &evaluations);

public:
	tFitness	actual_V_data[5000], actual_I_data[5000], model_V_data[5000], model_I_data[5000];
	int			data_len, data_column, num_of_cells;
	/************************************************************************/
	/* only for the SOFC problem                                    */
	/************************************************************************/
	// Ref: J. Yang, et al, Parameter optimization for tubular solid oxide fuel cell stack based on the dynamic model and an improved genetic algorithm,
	//      International Journal of Hydrogen Energy 36 (2011) 6160 - 6174
	tFitness	calculate_SOFC_model(double *x, double i, double T);				// 1
	tFitness	calculate_SOFC_model1(double *x, double i, double T);				// 2
	tFitness	calculate_SOFC_fitness(double *x, double i, double T);				// 3
	tFitness	calculate_SOFC_fitness_T(double *x, double i, double T);			// 4
	tFitness	calculate_SOFC_fitness_in(double *x, double i, double T);			// 5
	
	void		SOFC_model_fitness(double *x, tFitness &obj, double *constr);				

};

#endif // !defined(AFX_PROBLEMDEF_H__C8A8E61F_A57B_4F2A_A52A_0956308C172C__INCLUDED_)
