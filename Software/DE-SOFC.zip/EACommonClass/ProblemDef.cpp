// ProblemDef.cpp: implementation of the CProblemDef class.
//
//////////////////////////////////////////////////////////////////////


#include "ProblemDef.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CProblemDef::CProblemDef()
{
	flag_once = 0;
}

CProblemDef::~CProblemDef()
{
}

void CProblemDef::evaluate_normal_fitness(double *xreal, tFitness &obj, double *constr, 
										  int func_flag, long int &evaluations)
{
	m_function = func_flag;

	SOFC_model_fitness(xreal, obj, constr);

	evaluations++;
}

/************************************************************************/
/*  Tabular SOFC 1
    # of real variables = 7
    # of objectives     = 1
    # of constraints    = 0                                             */
/************************************************************************/
tFitness CProblemDef::calculate_SOFC_model(double *x, double i, double T)
{
	tFitness	results;

	double	Z   = (double)num_of_cells;		
	double	E0  = x[0];
	double	A   = x[1];
	double	i_n = x[2];
	double	i_0 = x[3];
	double	r   = x[4];
	double	m   = x[5];
	double	n   = x[6];
	double	k1	= 0;//x[7];
	double	k2	= 0;//x[8];

	//assert(i>0 && i_0>0);

	double	V_con, V_act, V_ohm;
	
	V_ohm = i*r;
	V_act = k1+k2*T + A*log( (i+i_n)/i_0 );
	V_con = m*exp(n*i);

	results = Z * ( E0 - V_ohm - V_act - V_con );

	return results;
}

/************************************************************************/
/*  Tabular SOFC 2
    # of real variables = 6
    # of objectives     = 1
    # of constraints    = 0                                             */
/************************************************************************/
tFitness CProblemDef::calculate_SOFC_model1(double *x, double i, double T)
{
	tFitness	results;

	double	Z   = (double)num_of_cells;		
	double	E0  = x[0];
	double	A   = x[1];
	double	i_0 = x[2];
	double	r   = x[3];
	double	m   = x[4];
	double	n   = x[5];
	double	k1	= 0;//x[6];
	double	k2	= 0;//x[7];

	//assert(i>0 && i_0>0);

	double	V_con, V_act, V_ohm;
	double	u = (i)/(2*i_0);

	V_ohm = i*r;

	V_act = k1+k2*T + A*log( u + sqrt(1.0 + u*u) );

	V_con = m*exp(n*i);

	results = Z * ( E0 - V_ohm - V_act - V_con );

	return results;
}

/************************************************************************/
/*  Tabular SOFC 3
    # of real variables = 6
    # of objectives     = 1
    # of constraints    = 0                                             */
/************************************************************************/
tFitness CProblemDef::calculate_SOFC_fitness(double *x, double i, double T)
{
	tFitness	results;

	double	Z   = (double)num_of_cells;		
	double	E0  = x[0];
	double	A   = x[1];
	double	i_0 = x[2];
	double	r   = x[3];
	double	m   = x[4];
	double	n   = x[5];		// i_L

	double	V_con, V_act, V_ohm;
	double	u = (i)/(2*i_0);

	if (i != 0.0)
	{////////////////////////////////////////////////////// modified in 2013-03-25
		V_ohm = i*r;
		V_act = A*log( u + sqrt(1.0 + u*u) );
		V_con = -m*log(1.0 - i/n);
	}
	else
	{		
		V_ohm = 0.0;
		V_act = 0.0;
		V_con = 0.0;
	}

	results = Z * ( E0 - V_con - V_act - V_ohm );

	return results;
}

/************************************************************************/
/*  Tabular SOFC 4
    # of real variables = 9
    # of objectives     = 1
    # of constraints    = 0                                             */
/************************************************************************/
tFitness CProblemDef::calculate_SOFC_fitness_T(double *x, double i, double T)
{
	tFitness	results;

	double	Z   = (double)num_of_cells;		
	double	E0, V_con, V_act, V_ohm, u;

	E0		= x[0] * T + x[9];

	V_ohm	= i * (x[1] * exp(x[2]*(1/x[3]-1/T)));

	u		= i / (2*x[5]*T*exp(-x[6]/T));
	V_act	= x[4] * T * log( u + sqrt(1.0 + u*u) );

	V_con	= -x[7]*T*log(1.0 - i/x[8]);

	results = Z * ( E0 - V_con - V_act - V_ohm );

	return results;
}

/************************************************************************/
/*  Tabular SOFC 5
    # of real variables = 7
    # of objectives     = 1
    # of constraints    = 0                                             */
/************************************************************************/
tFitness CProblemDef::calculate_SOFC_fitness_in(double *x, double i, double T)
{
	tFitness	results;

	double	Z   = (double)num_of_cells;		
	double	E0  = x[0];
	double	A   = x[1];
	double	i_0 = x[2];
	double	r   = x[3];
	double	m   = x[4];
	double	n   = x[5];		// i_L
	double	i_n = x[6];		// i_n

//  	i = (i+i_n);			// add i_n

	double	V_con, V_act, V_ohm;
	double	u	= (i)/(2*i_0);
	double	u1	= (i)/(2*i_n);

	if (i != 0.0)
	{////////////////////////////////////////////////////// modified in 2013-03-25
		V_ohm = (i)*r;
		V_act = A*log( u + sqrt(1.0 + u*u) ) + A*log( u1 + sqrt(1.0 + u1*u1) );
		V_con = -m*log(1.0 - (i)/n);
	}
	else
	{		
		V_ohm = 0.0;
		V_act = 0.0;
		V_con = 0.0;
	}

	results = Z * ( E0 - V_con - V_act - V_ohm );

	return results;
}

void CProblemDef::SOFC_model_fitness(double *x,tFitness &obj, double *constr)
{
	int		i, j;
	double  T    = 1073.0;
	double	area = 1000.0;		//1000.0;	

	if (flag_once == 0) 
	{
		flag_once = 1;
		printf("The data is initialized only once.\n");

		//********************************************************************
		// get data from the file                                             
		FILE *fpt;
		fpt          = fopen("data/SOFC1073.txt","r");		// ASC-SOFC/utilization-2
		num_of_cells = 96; 
		if (fpt==NULL)
		{
			printf("The file does not exist!\n");
			exit(0);
		}
		
		fscanf(fpt,"%d",&data_len);
		assert(data_len<=5000);
		
		for(i=0;i<data_len;i++)
		{
			fscanf(fpt,"%Lf%Lf", &actual_I_data[i], &actual_V_data[i]);
		}

		fclose(fpt);
		//********************************************************************
	}

	// calculate the model data
	double current;
	for (i=0;i<data_len;i++)
	{
		current = actual_I_data[i]*1000.0/area;				// for simulated data,  area = 1600.0 for default
//		current = actual_I_data[i]*1000.0;					// for real-data
		if (m_function == 1)
		{
			if ( (current+x[2]) <= 4*x[3] )
			{
				obj = INF;
				return;
			}

			if (0)//current==0.0)
			{
				model_V_data[i] = actual_V_data[i];
			}
			else
			{
				model_V_data[i] = calculate_SOFC_model(x, current, T);
			}
		}
		else if (m_function == 2)
		{
			if (0)//current==0.0)
			{
				model_V_data[i] = actual_V_data[i];
			}
			else
			{
				model_V_data[i] = calculate_SOFC_model1(x, current, T);
			}
		}
		else if (m_function == 3)
		{
			if ( (current - x[5] >= 1e-13) )
			{
				obj = INF;
				return;
			}

			if (0)//current==0.0)
			{
				model_V_data[i] = actual_V_data[i];
			}
			else
			{
				model_V_data[i] = calculate_SOFC_fitness(x, current, T);
			}			
		}
		else if (m_function == 4)
		{
			if ( current - x[8] >= 1e-13 )
			{
				obj = INF;
				return;
			}

			if (0)//current==0.0)
			{
				model_V_data[i] = actual_V_data[i];
			}
			else
			{
				model_V_data[i] = calculate_SOFC_fitness_T(x, current, T);
			}			
		}
		else if (m_function == 5)
		{
			//if ( (current+x[6] - x[5] >= 1e-13) )
			if ( (x[2]>x[6]) || (current- x[5] >= 1e-13) )
			{
				obj = INF;
				return;
			}

			if (0)//current==0.0)
			{
				model_V_data[i] = actual_V_data[i];
			}
			else
			{
				model_V_data[i] = calculate_SOFC_fitness_in(x, current, T);
			}			
		}
	}

	// calculate the fitness value
	tFitness fitness;
	fitness = 0.0;
	for (j=0;j<data_len;j++)
	{
		fitness += (model_V_data[j]-actual_V_data[j])*(model_V_data[j]-actual_V_data[j]);
	}
	fitness = (fitness)/(double)data_len;

	obj = fitness;
}


