function data_MFEA = RLMFEA(Tasks,pop,gen,selection_process,p_il)
    clc    
    tic       
    if mod(pop,2) ~= 0
        pop = pop + 1;
    end   
    no_of_tasks=length(Tasks);
    if no_of_tasks <= 1
        error('At least 2 tasks required for MFEA');
    end
    D=zeros(1,no_of_tasks);
    for i=1:no_of_tasks
        D(i)=Tasks(i).dims;
    end
    D_multitask=max(D);
    options = optimoptions(@fminunc,'Display','off','Algorithm','quasi-newton','MaxIter',5); 
    
    fnceval_calls = 0;
    calls_per_individual=zeros(1,pop);
    EvBestFitness = zeros(no_of_tasks,gen);
    TotalEvaluations=zeros(1,gen);
    bestobj=inf*(ones(1,no_of_tasks));
        
    for i = 1 : pop
        population(i) = Chromosome();
        population(i) = initialize(population(i),D_multitask);
        population(i).skill_factor=0;
    end
    parfor i = 1 : pop
        [population(i),calls_per_individual(i)] = evaluate(population(i),Tasks,p_il,no_of_tasks,options);
    end
    
    fnceval_calls=fnceval_calls + sum(calls_per_individual);
    TotalEvaluations(1)=fnceval_calls;
    
    %%%%������������
    factorial_cost=zeros(1,pop);
    for i = 1:no_of_tasks
        for j = 1:pop
            factorial_cost(j)=population(j).factorial_costs(i);
        end
        [xxx,y]=sort(factorial_cost);
        population=population(y);
        for j=1:pop
            population(j).factorial_ranks(i)=j; 
        end
        bestobj(i)=population(1).factorial_costs(i);
        EvBestFitness(i,1)=bestobj(i);
        bestInd_data(i)=population(1);
    end
    %%%���������������似������
    for i=1:pop
        [xxx,yyy]=min(population(i).factorial_ranks);
        x=find(population(i).factorial_ranks == xxx);
        equivalent_skills=length(x);
        if equivalent_skills>1
            population(i).skill_factor=x(1+round((equivalent_skills-1)*rand(1)));
            tmp=population(i).factorial_costs(population(i).skill_factor);
            population(i).factorial_costs(1:no_of_tasks)=inf;
            population(i).factorial_costs(population(i).skill_factor)=tmp;
        else
            population(i).skill_factor=yyy;
            tmp=population(i).factorial_costs(population(i).skill_factor);
            population(i).factorial_costs(1:no_of_tasks)=inf;
            population(i).factorial_costs(population(i).skill_factor)=tmp;
        end
    end
        
%     mu = 10; % Index of Simulated Binary Crossover (tunable)
%     sigma = 0.02; % standard deviation of Gaussian Mutation model (tunable)
    mu = 2;     % Index of Simulated Binary Crossover (tunable)
    sigma = 5;    % Index of polynomial mutation
    
    generation=1;
    
    %%%% ǿ��ѧϰ����
    num_state = 3; %%��Ӧ1,2,3����״̬
    num_action = 7; %%%��Ӧrmp7��ȡֵ����0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7��
    Q_table_population1 = zeros(num_state,num_action);
    Q_table_population2 = zeros(num_state,num_action);
    alp=0.1; %Q-learing rate
    gamma = 0.9; 
    reward = [0,5,10];
    
    %%%%%%�տ�ʼ���ȡһ��״̬
    state1 = randi(num_state);
    state2 = randi(num_state);
    %action = randi(num_action);
    %rmp = action/10;
    
    while generation <= gen      
        generation = generation + 1;
        %populationT1 = [];
        countT1 = 0;
        countT2 = 0;
        %populationT2 = [];
        %child = [];  
        Temp_Q1 = Q_table_population1(state1,:);
        Temp_Q2 = Q_table_population2(state2,:);
        temp1=exp(Temp_Q1);
        temp2=exp(Temp_Q2);
        %%%�������̶�
%         aaa = cumsum(temp1);
%         bbb = cumsum(temp2);
%         ratio1 = aaa/sum(temp1); %softmax�������
%         ratio2 = bbb/sum(temp2); %softmax�������
%         jtemp1=find(rand(1)<ratio1);
%         jtemp2=find(rand(1)<ratio2);
%         pop1_action=jtemp1(1);         %ѡ��action:F ����
%         pop2_action=jtemp2(1);
%         %����action
%         pop1_rmp = pop1_action/10;
%         pop2_rmp = pop2_action/10;
        
        
        pro1 = temp1/sum(temp1);
        pro2 = temp2/sum(temp2);
        %%%%�˴����õ�̰�Ĳ��ԣ�û�������̶ĵķ���
        maxQ1 = max(pro1);
        maxQ2 = max(pro2);
        index1 = find(pro1==maxQ1);
        index2 = find(pro2==maxQ2);
        len_index1 = length(index1);
        len_index2 = length(index2);
        if len_index1>1
            r1 = randi(len_index1);
            pop1_action = index1(r1);
            pop1_rmp = pop1_action/10;
        else
            pop1_action = index1(1);
            pop1_rmp = pop1_action/10;
        end
        if len_index2>1
            r2 = randi(len_index2);
            pop2_action = index2(r2);
            pop2_rmp = pop2_action/10;
        else
            pop2_action = index2(1);
            pop2_rmp = pop2_action/10;
        end
            
        %%%%�ֳ�������Ⱥ 
        for i = 1:pop
           %population_temp = Chromosome();
           if  population(i).skill_factor==1
               populationT1(countT1+1) = population(i);
               countT1 = countT1+1;
           else
               populationT2(countT2+1) = population(i);
               countT2 = countT2+1;
           end
        end
        
        %%%%
        rmp1(generation) = pop1_rmp;
        rmp2(generation) = pop2_rmp;
%         childpopution1 = GAEA(populationT1(1:countT1),populationT2(1:countT2),countT1,D_multitask,mu,sigma,pop1_rmp);
%         childpopution2 = GAEA(populationT2(1:countT2),populationT1(1:countT1),countT2,D_multitask,mu,sigma,pop2_rmp);
%         childpopution1 = DEEA(populationT1(1:countT1),populationT2(1:countT2),countT1,D_multitask,pop1_rmp);
%         childpopution2 = DEEA(populationT2(1:countT2),populationT1(1:countT1),countT2,D_multitask,pop2_rmp);
       
        
        if countT1<2
            %��˵����Ⱥ�еĸ��嶼���ڽ���ڶ������񣬾ͽ���T2����
            childpopution1 = DEEA(populationT1(1:countT1),populationT2(1:countT2),countTT1,D_multitask,0);
%             childpopution2 = EA(populationT2(1:countT2),populationT1(1:countT1),countTT2,D_multitask,mu,sigma,0);
             disp('000000000000000000000000000000000000000000000000');
        elseif 2<=countT1 && countT1<pop-2
            if rand<0.5
                childpopution1 = GAEA(populationT1(1:countT1),populationT2(1:countT2),countT1,D_multitask,mu,sigma,pop1_rmp);
                childpopution2 = DEEA(populationT2(1:countT2),populationT1(1:countT1),countT2,D_multitask,pop2_rmp);
            else
                
                childpopution1 = DEEA(populationT1(1:countT1),populationT2(1:countT2),countT1,D_multitask,pop1_rmp);
                childpopution2 = GAEA(populationT2(1:countT2),populationT1(1:countT1),countT2,D_multitask,mu,sigma,pop2_rmp);
            end
                    %%%%��Ⱥ1ר�Ž���T1���񣬽���T2����������
%             childpopution1 = EA(populationT1(1:countT1),populationT2(1:countT2),countTT1,D_multitask,mu,sigma,0.3);
%             childpopution2 = DEEA(populationT2(1:countT2),populationT1(1:countT1),countTT2,D_multitask,0.3);
        else %%%ֻ����T1������
            childpopution2 = EA(populationT2(1:countT2),populationT1(1:countT1),countTT2,D_multitask,mu,sigma,0);
%             childpopution1 = DEEA(populationT1(1:countT1),populationT2(1:countT2),countTT1,D_multitask,0);
            disp('11111111111111111111111111111111111111111111111111');
        end
        
        len1 = length(childpopution1);
        len2 = length(childpopution2);
        for i = 1:len1
            childpopution1(i).IsOK = 1;
        end
        for i = 1:len2
            childpopution2(i).IsOK = 2;
        end
        child(1:len1) = childpopution1;
        child(len1+1:len1+len2) = childpopution2;
        lenchild = length(child);
  
        parfor i = 1 : lenchild          
            [child(i),calls_per_individual(i)] = evaluate(child(i),Tasks,p_il,no_of_tasks,options);     
        end             
        fnceval_calls=fnceval_calls + sum(calls_per_individual);
        TotalEvaluations(generation)=fnceval_calls;
        %%%%%%%%����������Ⱥ
        
        intpopulation(1:pop)=population;
        intpopulation(pop+1:pop+lenchild)=child;
        total_pop = pop+lenchild;
        factorial_cost=zeros(1,total_pop);
        for i = 1:no_of_tasks
            for j = 1:total_pop
                factorial_cost(j)=intpopulation(j).factorial_costs(i);
            end
            [xxx,y]=sort(factorial_cost);
            intpopulation=intpopulation(y);
            for j=1:total_pop
                intpopulation(j).factorial_ranks(i)=j;
            end
            if intpopulation(1).factorial_costs(i)<=bestobj(i)
                bestobj(i)=intpopulation(1).factorial_costs(i);
                bestInd_data(i)=intpopulation(1);
            end
            EvBestFitness(i,generation)=bestobj(i);            
        end
        for i=1:total_pop
            [xxx,yyy]=min(intpopulation(i).factorial_ranks);
            intpopulation(i).skill_factor=yyy;
            
            intpopulation(i).scalar_fitness=1/xxx;
        end   
        
        if strcmp(selection_process,'elitist')
            [xxx,y]=sort(-[intpopulation.scalar_fitness]);
            intpopulation=intpopulation(y);
            population=intpopulation(1:pop); 
            %%%%%%������Ӧֵ������״̬
            if EvBestFitness(1,generation-1)<EvBestFitness(1,generation)
                reward1 = reward(1);
                next_state1 = 1;
            elseif EvBestFitness(1,generation-1)==EvBestFitness(1,generation)
                reward1 = reward(2);
                next_state1 = 2;
            else
                reward1 = reward(3);
                next_state1 = 3;
            end
            
            if EvBestFitness(2,generation-1)<EvBestFitness(2,generation)
                reward2 = reward(1);
                next_state2 = 1;
            elseif EvBestFitness(2,generation-1)==EvBestFitness(2,generation)
                reward2 = reward(2);
                next_state2 = 2;
            else
                reward2 = reward(3);
                next_state2 = 3;
            end
            
            
            
            %%%% ͳ����һ����������Ⱥ���Ӵ����ĸ���������״̬
%             count_pop1 = 0;
%             count_pop2 = 0;
%             for i = 1:pop
%                if  population(i).IsOK == 0
%                     
%                elseif population(i).IsOK == 1
%                    count_pop1 = count_pop1+1;
%                elseif population(i).IsOK == 2
%                     count_pop2 = count_pop2+1;
%                 end 
%             end
%             if count_pop1<1
%                 reward1 = reward(1);
%                 next_state1 = 1;
%             elseif (countT1/3)<=count_pop1 && count_pop1<countT1/2
%                 reward1 = reward(2);
%                 next_state1 = 2;
%             else
%                 reward1 = reward(3);
%                 next_state1 = 3;
%             end
%             if count_pop2<1
%                 reward2 = reward(1);
%                 next_state2 = 1;
%             elseif (countT2/3)<=count_pop2 && count_pop2<countT2/2
%                 reward2 = reward(2);
%                 next_state2 = 2;
%             else
%                 reward2 = reward(3);
%                 next_state2 = 3;
%             end
        elseif strcmp(selection_process,'roulette wheel')
            for i=1:no_of_tasks
                skill_group(i).individuals=intpopulation([intpopulation.skill_factor]==i);
            end
            count=0;
            while count<pop
                count=count+1;
                skill=mod(count,no_of_tasks)+1;
                population(count)=skill_group(skill).individuals(RouletteWheelSelection([skill_group(skill).individuals.scalar_fitness]));
            end
        end
        
        %%%%%����Q��
        pop1_tempMAX = max(Q_table_population1(next_state1,:));
        pop2_tempMAX = max(Q_table_population2(next_state2,:));
        Q_table_population1(state1,pop1_action) = Q_table_population1(state1,pop1_action)+alp*(reward1+gamma*pop1_tempMAX-Q_table_population1(state1,pop1_action));
        Q_table_population2(state2,pop2_action) = Q_table_population2(state2,pop2_action)+alp*(reward2+gamma*pop2_tempMAX-Q_table_population2(state2,pop2_action));
        
        state1 = next_state1;
        state2 = next_state2;
        
%         for i = 1:pop
%             population(i).IsOK = 0;
%         end
        
%         disp(['MFEA Generation = ', num2str(generation), ' best factorial costs = ', num2str(bestobj)]);
    end 
%     disp(['MFEA Generation = ', num2str(generation), ' best factorial costs = ', num2str(bestobj)]);
    data_MFEA.wall_clock_time=toc;
    data_MFEA.EvBestFitness=EvBestFitness;
    data_MFEA.bestInd_data=bestInd_data;
    data_MFEA.TotalEvaluations=TotalEvaluations;
%     save('data_MFEA0','data_MFEA');
%     for i=1:no_of_tasks
%         figure(i)
%         hold on
%         plot(EvBestFitness(i,:),'r:','LineWidth',3);
%         xlabel('GENERATIONS')
%         ylabel(['TASK ', num2str(i), ' OBJECTIVE'])
%         legend('MFEA')
%     end
end