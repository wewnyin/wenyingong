% This MATLAB R2014b code is for EVOLUTIONARY MULTITASKING across minimization problems. 
% For maximization problems, multiply objective function by -1.

% Settings of simulated binary crossover (SBX) in this code is Pc = 1, 
% and probability of variable sawpping = 0. 

% For suggestions please contact: Abhishek Gupta (Email: abhishekg@ntu.edu.sg or
% agup839@aucklanduni.ac.nz or abhi.nitr2010@gmail.com)

clear all
%%%%%% �ҵ�ʵ�鸴��
% F1��{��30R,none��,(30R,30S),(30R,30A),(30R,20S)}
% n=30; 
% Tasks(1).dims=n;
% M=orth(randn(n,n)); %%%���ؾ����������
% Tasks(1).fnc=@(x)Rastrigin(x,M); 
% Tasks(1).Lb=-50*ones(1,n);
% Tasks(1).Ub=50*ones(1,n); 
% 
% % Sphere function definition
% n=30;
% Tasks(2).dims=n;
% M=eye(n,n);
% Tasks(2).fnc=@(x)Sphere(x,M);
% Tasks(2).Lb=-50*ones(1,n);
% Tasks(2).Ub=50*ones(1,n);

% Ackley function definition
% n=20;
% Tasks(2).dims=n;
% M=orth(randn(n,n));
% Tasks(2).fnc=@(x)Ackley(x,M);
% Tasks(2).Lb=-50*ones(1,n);
% Tasks(2).Ub=50*ones(1,n);




%% Example 1 - (40-D Rastrigin, 30-D Ackley)
% Rastrigin function definition
% n=40;
% Tasks(1).dims=n;
% M=orth(randn(n,n));
% Tasks(1).fnc=@(x)Rastrigin(x,M);
% Tasks(1).Lb=-5*ones(1,n);
% Tasks(1).Ub=5*ones(1,n);
% % Ackley function definition
% n=30;
% Tasks(2).dims=n;
% M=orth(randn(n,n));
% Tasks(2).fnc=@(x)Ackley(x,M);
% Tasks(2).Lb=-32*ones(1,n);
% Tasks(2).Ub=32*ones(1,n);

%% Example 2 - (50-D Sphere, 30-D Weierstrass)
% % Sphere function definition
% n=50;
% Tasks(1).dims=n;
% M=eye(n,n);
% Tasks(1).fnc=@(x)Sphere(x,M);
% Tasks(1).Lb=-100*ones(1,n);
% Tasks(1).Ub=100*ones(1,n);
% % Weierstrass function definition
% n=30;
% Tasks(2).dims=n;
% M=orth(randn(n,n));
% Tasks(2).fnc=@(x)Weierstrass(x,M);
% Tasks(2).Lb=-0.5*ones(1,n);
% Tasks(2).Ub=0.5*ones(1,n);

%% Example 3 - (40-D Rastrigin, 50-D Ackley, 20-D Sphere)
% % Rastrigin function definition
% n=40;
% Tasks(1).dims=n;
% M=orth(randn(n,n));
% Tasks(1).fnc=@(x)Rastrigin(x,M);
% Tasks(1).Lb=-5*ones(1,n);
% Tasks(1).Ub=5*ones(1,n);
% % Ackley function definition
% n=50;
% Tasks(2).dims=n;
% M=orth(randn(n,n));
% Tasks(2).fnc=@(x)Ackley(x,M);
% Tasks(2).Lb=-32*ones(1,n);
% Tasks(2).Ub=32*ones(1,n);
% % Sphere function definition
% n=20;
% Tasks(3).dims=n;
% M=eye(n,n);
% Tasks(3).fnc=@(x)Sphere(x,M);
% Tasks(3).Lb=-100*ones(1,n);
% Tasks(3).Ub=100*ones(1,n);

%% Example 5 - Mirror Functions - (30-D Rastrigin, 30-D Rastrigin)
% % Rastrigin function definition
% n=30;
% Tasks(1).dims=n;
% M=orth(randn(n,n));
% Tasks(1).fnc=@(x)Rastrigin(x,M);
% Tasks(1).Lb=-5*ones(1,n);
% Tasks(1).Ub=5*ones(1,n);
% Tasks(2) = Tasks(1);

%% Example 6 - Mirror Functions - (30-D Ackley, 30-D Ackley)
% % Ackley function definition
% n=30;
% Tasks(1).dims=n; 
% M=orth(randn(n,n));
% Tasks(1).fnc=@(x)Ackley(x,M);
% Tasks(1).Lb=-32*ones(1,n);
% Tasks(1).Ub=32*ones(1,n);
% Tasks(2)=Tasks(1);

%% Calling the solvers
% For large population sizes, consider using the Parallel Computing Toolbox
% of MATLAB.
% Else, program can be slow.


pop=100; % population size
gen=1000; % generation count
selection_pressure = 'elitist'; % choose either 'elitist' or 'roulette wheel'
p_il = 0; % probability of individual learning (BFGA quasi-Newton Algorithm) --> Indiviudal Learning is an IMPORTANT component of the MFEA.
% rmp=0; % random mating probability

% rmp = 0:0.1:1.0;

% len = length(rmp);
% for i = 1:len
%     rmp1 = rmp(i);
%     data_MFEA=MFEA(Tasks,pop,gen,selection_pressure,rmp1,p_il);
%     M = strcat('data_MFEA',char(num2str(i-1)));
%     save(M,'data_MFEA');
%     
% end

rep = 20;
tic
for index = 1:9
    Tasks = benchmark(index);
    for i =1:rep
        data_MFEA(i)=RLMFEA(Tasks,pop,gen,selection_pressure,p_il);
        T1(i) = data_MFEA(i).EvBestFitness(1,end); 
        T2(i) = data_MFEA(i).EvBestFitness(2,end);
        fprintf('%d time of the Task has been finished\n',i);
%         disp(['The ', num2str(i),'-th time of the Task ', num2str(index) ' has been finished']);
    end
    charr = strcat('data_MFEA',num2str(index));
    save(charr,'data_MFEA');
    minT1 = min(T1);
    meanT1 = mean(T1);
    stdT1 = std(T1);
    minT2 = min(T2);
    meanT2 = mean(T2);
    stdT2 = std(T2);
    disp(['minT1 = ', num2str(minT1),' meanT1 = ', num2str(meanT1), ' stdT1 = ', num2str(stdT1)]);
    disp(['minT2 = ', num2str(minT2),' meanT2 = ', num2str(meanT2), ' stdT2 = ', num2str(stdT2)]);
    pp(index,:) = [minT1,meanT1,stdT1,minT2,meanT2,stdT2];
end
toc





% "task_for_comparison_with_SOO" compares performance of corresponding task in MFO with SOO.
% For Instance, In EXAMPLE 1 ...
% "task_for_comparison_with_SOO" = 1 --> compares 40-D Rastrin in MFO with 40-D
% Rastrigin in SOO.
% "task_for_comparison_with_SOO" = 2 --> compares 30D Ackley in MFO with
% 30D Ackley in SOO.
% task_for_comparison_with_SOO = 1;
% data_SOO=SOO(Tasks(task_for_comparison_with_SOO),task_for_comparison_with_SOO,pop,gen,selection_pressure,p_il);  

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% DE-SOO
% pop=50; % population size
% gen=1000; % generation count
% selection_pressure = 'elitist'; % choose either 'elitist' or 'roulette wheel'
% p_il = 0; % probability of individual learning (BFGA quasi-Newton Algorithm) --> Indiviudal Learning is an IMPORTANT component of the MFEA.
% rep = 20;
% tic
% for index = 1:9
%     Tasks = benchmark(index);
%     task_for_comparison_with_SOO1 = 1;
%     task_for_comparison_with_SOO2 = 2;
%     data_SOO1(index)=SOEA(Tasks(task_for_comparison_with_SOO1),pop,gen,selection_pressure,p_il,rep); 
%     data_SOO2(index)=SOEA(Tasks(task_for_comparison_with_SOO2),pop,gen,selection_pressure,p_il,rep); 
%     meanss1 = data_SOO1(index).EvBestFitness(:,end);
%     meanss2 = data_SOO2(index).EvBestFitness(:,end);
%     
%     pp(index,:) = [min(meanss1),mean(meanss1),std(meanss1),min(meanss2),mean(meanss2),std(meanss2)];
% %     fprintf('%d time of the Task has been finished\n',i);  
% end
% save('DEdata_SOO1','data_SOO1');
% save('DEdata_SOO2','data_SOO2');
% save('DESOOpp50','pp');
% toc
