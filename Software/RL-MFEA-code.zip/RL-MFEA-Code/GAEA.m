function [ child ] = GAEA(population1,population2,countT1,D_multitask,mu,sigma,rmp)
%EA �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
%         indorder = randperm(pop);
%         rmp = 0.3;
        if mod(countT1,2) ~= 0
            countT1 = countT1-1;
        end
        count=1;
        len1 = length(population1);
        len2 = length(population2);
        indorder1 = randperm(len1);
        indorder2 = randperm(len2);
        for i = 1 : countT1/2   
%             indorder1 = randperm(len1);
%             indorder2 = randperm(len2);
            p1 = indorder1(i);
            if rand<rmp 
                if i<=len2
                    p2 = indorder2(i);
                else
                    p2 = indorder2(1);
                end
                populationp2 = population2(p2);
            else
                p2 = indorder1(i+countT1/2);
                populationp2 = population1(p2);
            end
            child(count)=Chromosome();
            child(count+1)=Chromosome();
            
            if rand>0.1          
                u = rand(1,D_multitask);
                cf = zeros(1,D_multitask);
                cf(u<=0.5)=(2*u(u<=0.5)).^(1/(mu+1));
                cf(u>0.5)=(2*(1-u(u>0.5))).^(-1/(mu+1));
                child(count) = crossover(child(count),population1(p1),populationp2,cf);
                child(count+1) = crossover(child(count+1),populationp2,population1(p1),cf);
% % % % % % % %                 if rand(1) < 0.1 
% % % % % % % %                     child(count)=mutate(child(count),child(count),D,sigma/2);
% % % % % % % %                     child(count+1)=mutate(child(count+1),child(count+1),D,sigma/2);
% % % % % % % %                 end        
                sf1=1+round(rand(1));
                sf2=1+round(rand(1));
                if sf1 == 1
                    child(count).skill_factor=population1(p1).skill_factor;
                else
                    child(count).skill_factor=populationp2.skill_factor;
                end
                if sf2 == 1
                    child(count+1).skill_factor=population1(p1).skill_factor;
                else
                    child(count+1).skill_factor=populationp2.skill_factor;
                end
            else
                child(count)=mutate(child(count),population1(p1),D_multitask,sigma);
                child(count).skill_factor=population1(p1).skill_factor;
                child(count+1)=mutate(child(count+1),populationp2,D_multitask,sigma);
                child(count+1).skill_factor=populationp2.skill_factor;
            end
            count=count+2;
        end 
%          for i = 1 : countT1/2    
%             p1 = indorder(i);
%             p2 = indorder(i+(pop/2));
%             child(count)=Chromosome();
%             child(count+1)=Chromosome();
%             if (population(p1).skill_factor == population(p2).skill_factor) || (rand(1)<rmp)            
%                 u = rand(1,D_multitask);
%                 cf = zeros(1,D_multitask);
%                 cf(u<=0.5)=(2*u(u<=0.5)).^(1/(mu+1));
%                 cf(u>0.5)=(2*(1-u(u>0.5))).^(-1/(mu+1));
%                 child(count) = crossover(child(count),population(p1),population(p2),cf);
%                 child(count+1) = crossover(child(count+1),population(p2),population(p1),cf);
% % % % % % % % %                 if rand(1) < 0.1 
% % % % % % % % %                     child(count)=mutate(child(count),child(count),D,sigma/2);
% % % % % % % % %                     child(count+1)=mutate(child(count+1),child(count+1),D,sigma/2);
% % % % % % % % %                 end        
%                 sf1=1+round(rand(1));
%                 sf2=1+round(rand(1));
%                 if sf1 == 1
%                     child(count).skill_factor=population(p1).skill_factor;
%                 else
%                     child(count).skill_factor=population(p2).skill_factor;
%                 end
%                 if sf2 == 1
%                     child(count+1).skill_factor=population(p1).skill_factor;
%                 else
%                     child(count+1).skill_factor=population(p2).skill_factor;
%                 end
%             else
%                 child(count)=mutate(child(count),population(p1),D_multitask,sigma);
%                 child(count).skill_factor=population(p1).skill_factor;
%                 child(count+1)=mutate(child(count+1),population(p2),D_multitask,sigma);
%                 child(count+1).skill_factor=population(p2).skill_factor;
%             end
%             count=count+2;
%         end
end

