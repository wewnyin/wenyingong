function [recRMSE,bestP,optValue]=AGDE_PV_demo(mType,Max_NFEs,NP)


    addpath('../CauchyFunction');
    addpath('../');

    %%��ʼ��
    [ UB,LB,Dim ] = Parameter(mType);
    G=1;%���õ���������ǰ����������
    index=mType;%���Ժ�������
    pNum=round(0.1*NP);
    eps=0.01;
    

    UB=(repmat((UB),NP,1));
    LB=repmat((LB),NP,1);
    P=(UB-LB).*rand(NP,Dim)+LB;%���������ʼ��Ⱥ����
    
%     if index==1
%         P=load('..\convergence-curve\InitPoPdata\model1pop.mat','Pinit');
%     elseif index==2
%         P=load('..\convergence-curve\InitPoPdata\model2pop.mat','Pinit');
%     elseif index==3
%         P=load('..\convergence-curve\InitPoPdata\model3pop.mat','Pinit');
%     elseif index==4
%         P=load('..\convergence-curve\InitPoPdata\model4pop.mat','Pinit');
%     elseif index==5
%         P=load('..\convergence-curve\InitPoPdata\model5pop.mat','Pinit');
%     end
%     P=double(P.Pinit);
    
    for i=1:NP
        fitnessP(i)=PV_TestFunction(index,P(i,:));%������Ⱥ������Ӧֵ
    end
    NFEs=NP;%��¼��Ӧ�Ⱥ������ô���
    [fitnessBestP,indexBestP]=min(fitnessP);
    bestP=P(indexBestP,:);
    recRMSE(1:NP)=fitnessP;
    
    %%�����ѭ��
    while NFEs<Max_NFEs
        
        ns1=0;
        nf1=0;
        ns2=0;
        nf2=0;
        
        F=0.1+0.9*rand;

        %%�������+�������
        for i=1:NP   
            
            urnd=rand;
            if G==1
                pro1=0.5;
            end
            if urnd<=pro1
                CR(i)=0.05+0.1*rand;
                flag=1;
            else
                CR(i)=0.9+0.1*rand;
                flag=2;
            end
            
            %�ӵ�ǰ��ȺP�����ѡ��P1��P2��P3
            [~,indexsortP]=sort(fitnessP);
            k0=randi([1,pNum]); %pBest
            P1=P(indexsortP(k0),:);
            
            k1=randi([pNum+1,NP-pNum]); %middle
            P2=P(indexsortP(k1),:);
            
            k2=randi([NP-pNum+1,NP]); %pWorst
            P3=P(indexsortP(k2),:);

            V(i,:)=P2+F.*(P1-P3);   
       
            %%�߽紦��
            for j=1:Dim
              if (V(i,j)>UB(i,j))
                 V(i,j)=2*UB(i,j)-V(i,j);
              end
              if (V(i,j)<LB(i,j))
                 V(i,j)=2*LB(i,j)-V(i,j);
              end
           end
           
            %%�������
            jrand=randi([1,Dim]); 
            for j=1:Dim
                k3=rand;
                if(k3<=CR(i)||j==jrand)
                    U(i,j)=V(i,j);
                else
                    U(i,j)=P(i,j);
                end
            end
            fitnessU(i)=PV_TestFunction(index,U(i,:));
            NFEs=NFEs+1;
            
            %%ѡ�����
            if(fitnessU(i)<fitnessP(i))
                P(i,:)=U(i,:);
                fitnessP(i)=fitnessU(i);
                if flag==1
                    ns1=ns1+1;
                elseif flag==2
                    ns2=ns2+1;
                end
                
                if(fitnessU(i)<fitnessBestP)
                   fitnessBestP=fitnessU(i);
                   bestP=U(i,:);
                end
            else
                if flag==1
                    nf1=nf1+1;
                elseif flag==2
                    nf2=nf2+1;
                end
            end
            
            recRMSE(NFEs)=fitnessP(i);
        end
        
         if ns1+nf1==0 || ns2+nf2==0
            pro1=0.5;
        else
            s1=ns1/(ns1+nf1)+eps;
            s2=ns2/(ns2+nf2)+eps;
            ps1=s1/(s1+s2);
            pro1=((G-1)*pro1+ps1)/G;
        end

        G=G+1;
        
    end

    optValue=fitnessBestP;
    

end
