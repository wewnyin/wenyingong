clear all

format long;
format compact;
warning('off');

runtime=50;

tic()


termin=9.861e-4;

maxNFEs=30000;

PVindex = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16];

NP=50;

for k =1:length(PVindex)
    for j=1:runtime
        [bestP(j,:),bestValue(j),bestNFEs(j)]=AGDE_PV_demo(PVindex(k),PVindex(k),termin,maxNFEs,NP);
    end
    
    
    fprintf('��%d�����ݼ������\n',PVindex(k));
    
    %%%%
    ppp(k,:) = [std(bestValue),mean(bestValue)];
    
end


toc()

