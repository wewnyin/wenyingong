function [ UB,LB,Dim ] = Parameter_16( type )
%PARAMETER �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    if type==1  || type==2 || type==3  || type==4 || type==5  || type==11 || type==12 || type==13% Multi-crystalline (KC200GT)		
        % double
        Dim=7;
        UB=zeros(1,Dim);  %�ϱ߽�
        if type==1       % 25, 200w/m
            UB(1) = 3.284;
        elseif type==2   % 25, 400w/m
            UB(1) = 6.568;
        elseif type==3   % 25, 600w/m
            UB(1) = 9.852;
        elseif type==4   % 25, 800w/m
            UB(1) = 13.136;
        elseif type==5   % 25, 1000w/m
            UB(1) = 16.42;
        elseif type==11   % 1000w/m, 75,
            UB(1) = 16.738;
        elseif type==12   % 1000w/m, 50,
            UB(1) = 16.5790;
        elseif type==13   % 1000w/m, 25,
            UB(1) = 16.42;
        end
        UB(2) = 100e-6;
        UB(3) = 2;
        UB(4) = 5000;
        UB(5) = 4;
        UB(6) = 100e-6;
        UB(7) = 4;
        LB=zeros(1,Dim); %�±߽�
        LB(5) = 1;
        LB(7) = 1;
    elseif type==6 || type==7  || type==8 || type==9 || type==10  || type==14 || type==15 || type==16% Mono-crystalline SM55
        
        % double
        Dim=7;
        UB=zeros(1,Dim);  %�ϱ߽�
        if type==10       % 25, 200w/m
            UB(1) = 1.36;  
        elseif type==11   % 25, 400w/m
            UB(1) = 2.72;
        elseif type==12   % 25, 600w/m
            UB(1) = 4.08;
        elseif type==13   % 25, 800w/m
            UB(1) = 5.44;
        elseif type==14   % 25, 1000w/m
            UB(1) = 6.80;
        elseif type==27   % 1000w/m, 60, 
            UB(1) = 6.898;
        elseif type==28   % 1000w/m, 40, 
            UB(1) = 6.8042;
        elseif type==29   % 1000w/m, 25, 
            UB(1) = 6.80;
        end
        UB(2) = 100e-6;
        UB(3) = 2;
        UB(4) = 5000;
        UB(5) = 4;
        UB(6) = 100e-6;
        UB(7) = 4;
        LB=zeros(1,Dim); %�±߽�
        LB(5) = 1;
        LB(7) = 1;
        
          
    end
    
end

