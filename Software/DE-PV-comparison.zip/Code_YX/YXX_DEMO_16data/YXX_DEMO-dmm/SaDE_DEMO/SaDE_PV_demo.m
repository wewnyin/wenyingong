function [bestP,optValue,endNFEs]=SaDE_PV_demo(fType,pType,TerminCri,Max_NFEs,NP)

    addpath('../CauchyFunction');
    
     addpath('../');
    %%��ʼ��
    [ UB,LB,Dim ] = Parameter_16(pType);
    NP=50;%��Ⱥ��ģ
    G=0;%���õ���������ǰ����������
    index=fType;%���Ժ�������
    pStr=0.5; %ʹ��rand/1/bin�ĸ��ʣ�Str1����current-to-best/2/bin ��Ϊ Str2
    ns1=0; %�ɹ�Ӧ��Str1�ĸ�����
    nf1=0; %ʧ��Ӧ��Str1�ĸ�����
    ns2=0; %�ɹ�Ӧ��Str2�ĸ�����
    nf2=0; %ʧ��Ӧ��Str2�ĸ�����
    CRm=0.5; %��ʼCRm
    numSCR=0; %��¼sCR������Ԫ�ظ���
    endNFEs=0;
    
    MaMi=(repmat((UB-LB),NP,1));
    MiLB=repmat((LB),NP,1);
    P=MaMi.*rand(NP,Dim)+MiLB;%���������ʼ��Ⱥ����

%     if index==1
%         P=load('..\convergence-curve\InitPoPdata\model1pop.mat','Pinit');
%     elseif index==2
%         P=load('..\convergence-curve\InitPoPdata\model2pop.mat','Pinit');
%     elseif index==3
%         P=load('..\convergence-curve\InitPoPdata\model3pop.mat','Pinit');
%     elseif index==4
%         P=load('..\convergence-curve\InitPoPdata\model4pop.mat','Pinit');
%     elseif index==5
%         P=load('..\convergence-curve\InitPoPdata\model5pop.mat','Pinit');
%     end
%     P=double(P.Pinit);
    
    for i=1:NP
        fitnessP(i)=PV_TestFunction_16(index,P(i,:));%������Ⱥ������Ӧֵ
    end
    NFEs=NP;%��¼��Ӧ�Ⱥ������ô���

    [fitnessBestP,indexBestP]=min(fitnessP);
    bestP=P(indexBestP,:);
%     recRMSE(1:50)=fitnessP;
    
    
    %%�����ѭ��
    while NFEs<Max_NFEs

        if (mod(G,5)==0||G==0)
            for i=1:NP  
                CR(i)=normrnd(CRm,0.1);%������̬�ֲ�
                while (CR(i)<=0||CR(i)>=1)
                    CR(i)=normrnd(CRm,0.1);
                end  
            end
        end
        
        for i=1:NP
            F(i)=normrnd(0.5,0.3);
            while (F(i)<=0||F(i)>2)
                F(i)=normrnd(0.5,0.3);
            end
        end
        
        
        %%�������+�������
        for i=1:NP   
            
            %%������� 
            k0=randi([1,NP]);
            while(k0==i)
                k0=randi([1,NP]);   
            end
            P1=P(k0,:);
            k1=randi([1,NP]);
            while(k1==i||k1==k0)
                k1=randi([1,NP]);
            end
            P2=P(k1,:);
            k2=randi([1,NP]); 
            
            randj=rand;
            if randj<=pStr
                %rand/1/bin
                while(k2==i||k2==k1||k2==k0)
                    k2=randi([1,NP]);
                end
                P3=P(k2,:);
                V(i,:)=P1+F(i).*(P2-P3);   
                flag(i)=1;
            else
                %current-to-best/2/bin
                V(i,:)=P(i,:)+F(i).*(bestP-P(i,:))+F(i).*(P1-P2);
                flag(i)=2;
            end
            
    
            %%�߽紦��
            for j=1:Dim
              if (V(i,j)>UB(j)||V(i,j)<LB(j))
                 V(i,j)=LB(j)+rand*(UB(j)-LB(j));
              end
            end
           
           
            %%�������
            jrand=randi([1,Dim]); 
            for j=1:Dim
                k3=rand;
                if(k3<=CR(i)||j==jrand)
                    U(i,j)=V(i,j);
                else
                    U(i,j)=P(i,j);
                end
            end
            fitnessU(i)=PV_TestFunction_16(index,U(i,:));
            NFEs=NFEs+1;
            
            %%ѡ�����
            if(fitnessU(i)<fitnessP(i))
                P(i,:)=U(i,:);
                fitnessP(i)=fitnessU(i);
                numSCR=numSCR+1;
                sCR(numSCR)=CR(i);
                
                if flag(i)==1
                    ns1=ns1+1;
                elseif flag(i)==2
                    ns2=ns2+1;
                end
 
                if(fitnessU(i)<fitnessBestP)
                   fitnessBestP=fitnessU(i);
                   bestP=U(i,:);
                end
                
            else
                if flag(i)==1
                    nf1=nf1+1;
                elseif flag(i)==2
                    nf2=nf2+1;
                end
                
            end
            
%             recRMSE(NFEs)=fitnessP(i);
        end
        
        if mod(G,50)==0
            pStr=ns1*(ns2+nf2)/(ns2*(ns1+nf1)+ns1*(ns2+nf2));
            ns1=0; %����
            nf1=0;
            ns2=0;
            nf2=0;
        end
        
        if mod(G,25)==0
            if numSCR>0
                CRm=mean(sCR);
                sCR=[]; %����
                numSCR=0;
            end 
        end
        
        G=G+1;
%         bestfitnessG(G)=fitnessBestP;
        
    end

    endNFEs=NFEs;
    optValue=fitnessBestP;
    

end
