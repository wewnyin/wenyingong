function [bestP,optValue,endNFEs]=CODE_PV_demo(fType,pType,TerminCri,Max_NFEs,NP)


        addpath('../CauchyFunction');
    
     addpath('../');

    %%��ʼ��
    [ UB,LB,Dim ] = Parameter_16(pType);
    G=1;%���õ���������ǰ����������
    index=fType;%���Ժ�������


    MaMi=(repmat((UB-LB),NP,1));
    MiLB=repmat((LB),NP,1);
    P=MaMi.*rand(NP,Dim)+MiLB;%���������ʼ��Ⱥ����
    
%     if index==1
%         P=load('..\convergence-curve\InitPoPdata\model1pop.mat','Pinit');
%     elseif index==2
%         P=load('..\convergence-curve\InitPoPdata\model2pop.mat','Pinit');
%     elseif index==3
%         P=load('..\convergence-curve\InitPoPdata\model3pop.mat','Pinit');
%     elseif index==4
%         P=load('..\convergence-curve\InitPoPdata\model4pop.mat','Pinit');
%     elseif index==5
%         P=load('..\convergence-curve\InitPoPdata\model5pop.mat','Pinit');
%     end
%     P=double(P.Pinit);
    
    for i=1:NP
        fitnessP(i)=PV_TestFunction_16(index,P(i,:));%������Ⱥ������Ӧֵ
    end
    NFEs=NP;%��¼��Ӧ�Ⱥ������ô���
    [fitnessBestP,indexBestP]=min(fitnessP);
    bestP=P(indexBestP,:);
%     recRMSE(1:50)=fitnessP;
    
    %%�����ѭ��
    while NFEs<Max_NFEs
        

        %%�������+�������
        for i=1:NP   
            
            indexPara=randperm(3);
            F=[1 1 0.8];
            CR=[0.1 0.9 0.2];
            
            %�ӵ�ǰ��ȺP�����ѡ��P1��P2��P3,P4,P5
            k0=randi([1,NP]);
            while(k0==i)
                k0=randi([1,NP]);   
            end
            P1=P(k0,:);
            k1=randi([1,NP]);
            while(k1==i||k1==k0)
                k1=randi([1,NP]);
            end
            P2=P(k1,:);
            k2=randi([1,NP]);
            while(k2==i||k2==k1||k2==k0)
                k2=randi([1,NP]);
            end
            P3=P(k2,:);
            k3=randi([1,NP]);
            while(k3==i||k3==k1||k3==k0||k3==k2)
                k3=randi([1,NP]);
            end
            P4=P(k3,:);
            k4=randi([1,NP]);
            while(k4==i||k4==k1||k4==k0||k4==k2||k4==k3)
                k4=randi([1,NP]);
            end
            P5=P(k4,:);

            %�������
            V1(i,:)=P1+F(indexPara(1)).*(P2-P3);  %rand/1/bin
            V2(i,:)=P1+rand.*(P2-P3)+F(indexPara(2)).*(P4-P5); %rand/2/bin
            V3(i,:)=P(i,:)+rand.*(P1-P(i,:))+F(indexPara(3)).*(P2-P3); %current-to-rand/1

           
%             %%�������
%             jrand=randi([1,Dim]); 
%             for j=1:Dim
%                 kn1=rand;
%                 kn2=rand;
%                 if(kn1<=CR(indexPara(1))||j==jrand)
%                     U1(i,j)=V1(i,j);
%                 else
%                     U1(i,j)=P(i,j);  
%                 end
%                 if(kn2<=CR(indexPara(2))||j==jrand)
%                     U2(i,j)=V2(i,j);
%                 else
%                     U2(i,j)=P(i,j);  
%                 end
%                 U3(i,j)=P(i,j)+rand.*(V3(i,j)-P(i,j));
%             end

            % ���� �õ�ʵ������u��������������Էֿ�Ч������
            jrand1 = randi(Dim);
            for j=1:Dim
                if j==jrand1 || rand<CR(indexPara(1))
                    U1(i,j) = V1(i,j);
                else
                    U1(i,j) = P(i,j);
                end
            end

            jrand2 = randi(Dim);
            for j=1:Dim
                if j==jrand2 || rand<CR(indexPara(2))
                    U2(i,j) = V2(i,j);
                else
                    U2(i,j) = P(i,j);
                end
            end
            
            U3(i,:)=P(i,:)+rand.*(V3(i,:)-P(i,:));

            %%�߽紦��
            for j=1:Dim
                if (U1(i,j)>UB(j)||U1(i,j)<LB(j))
                    U1(i,j)=LB(j)+rand*(UB(j)-LB(j));
                end
                if (U2(i,j)>UB(j)||U2(i,j)<LB(j))
                    U2(i,j)=LB(j)+rand*(UB(j)-LB(j));
                end
                if (U3(i,j)>UB(j)||U3(i,j)<LB(j))
                    U3(i,j)=LB(j)+rand*(UB(j)-LB(j));
                end
            end
            
            test(1)=PV_TestFunction_16(index,U1(i,:));
            test(2)=PV_TestFunction_16(index,U2(i,:));
            test(3)=PV_TestFunction_16(index,U3(i,:));
            [fitnessU(i),indexU]=min(test);

%             recRMSE(NFEs+1:NFEs+3)=test;
            NFEs=NFEs+3;
            
            if indexU==1
                U(i,:)=U1(i,:);
            elseif indexU==2
                U(i,:)=U2(i,:);
            elseif indexU==3
                U(i,:)=U3(i,:);
            end
            
            %%ѡ�����
            if(fitnessU(i)<fitnessP(i))
                P(i,:)=U(i,:);
                fitnessP(i)=fitnessU(i);

                if(fitnessU(i)<fitnessBestP)
                   fitnessBestP=fitnessU(i);
                   bestP=U(i,:);
                end
            end

        end
        
       
        G=G+1;
%         bestfitnessG(G)=fitnessBestP;
        
    end
    
    endNFEs=NFEs;
    optValue=fitnessBestP;
    

end
