clear all
clc

format long;
format compact;
warning('off');

type=input('Input the type of model:');

inputNum=xlsread('fiveresults.xlsx');

if type==1
    x=inputNum(11,1:5);
elseif type==2
    x=inputNum(26,1:7);
elseif type==3
    x=inputNum(41,1:5);
elseif type==4
    x=inputNum(56,1:5);
elseif type==5
    x=inputNum(71,1:5);
end


[V_L,I_Lm,I_result,IAE,SIAE]=calculate_I(type,x);

if type==1
%plot
%single
hold off;
hold on;
figure(1);
subplot(1,2,1);
plot(V_L,I_Lm,'bo',V_L,I_result,'r');
xlim([-0.3,0.6]);
set(gca,'xtick',[-0.3:0.1:0.6]);
ylim([-0.4,1]);
xlabel('Voltage (V)');
ylabel('Current (A)');
legend('measured','simulated');
legend('measured','simulated','Location','SouthWest');
grid on;
end

if type==2
hold on;
figure(1);
subplot(1,2,2);
plot(V_L,I_Lm,'bo',V_L,I_result,'r');
xlim([-0.3,0.6]);
set(gca,'xtick',[-0.3:0.1:0.6]);
ylim([-0.4,1]);
xlabel('Voltage (V)');
ylabel('Current (A)');
legend('measured','simulated','Location','SouthWest');
grid on;

end


if type==3
hold off;
hold on;
figure(2);
subplot(1,3,1);
plot(V_L,I_Lm,'bo',V_L,I_result,'r');
xlim([0,18]);
set(gca,'xtick',[0:2:18]);
ylim([-0.4,1.2]);
xlabel('Voltage (V)');
ylabel('Current (A)');
legend('measured','simulated','Location','SouthWest');
grid on;
end

if type==4
hold on;
figure(2);
subplot(1,3,2);
plot(V_L,I_Lm,'bo',V_L,I_result,'r');
xlim([0,22]);
set(gca,'xtick',[0:2:22]);
ylim([0,1.8]);
xlabel('Voltage (V)');
ylabel('Current (A)');
legend('measured','simulated','Location','SouthWest');
grid on;
end

if type==5
hold on;
figure(2);
subplot(1,3,3);
plot(V_L,I_Lm,'bo',V_L,I_result,'r');
xlim([0,20]);
set(gca,'xtick',[0:2:20]);
ylim([0,8]);
xlabel('Voltage (V)');
ylabel('Current (A)');
legend('measured','simulated','Location','SouthWest');
grid on;
end

function [V_L,I_Lm,I_cal,IAE,SIAE]=calculate_I(type, x)

    q = 1.60217646e-19;
    k = 1.3806503e-23;
    
    
    if type==1  %single_diode_model
        
        T = 273.15+33.0;
        
        V_t  = k*T/q;
        
        I_ph = x(1);
        I_sd = x(2)*10^(-6);
        R_s = x(4);
        R_sh  = x(5);
        a = x(3);
        
        V_L = [-0.2057, -0.1291,-0.0588, 0.0057,0.0646,0.1185,0.1678,0.2132,0.2545,0.2924,0.3269,0.3585,0.3873,0.4137,0.4373,0.4590,0.4784,0.4960,...
            0.5119,0.5265,0.5398,0.5521,0.5633,0.5736,0.5833,0.5900];
        I_Lm = [ 0.7640,0.7620,0.7605,0.7605,0.7600 ,0.7590 ,0.7570 ,0.7570 ,0.7555 ,0.7540 ,0.7505 ,0.7465 , 0.7385 , 0.7280 , 0.7065 , 0.6755 ,...
            0.6320 ,0.5730 ,0.4990 , 0.4130 ,0.3165 , 0.2120 ,0.1035 , -0.0100, -0.1230 , -0.2100 ];
        
        len=26;
        
        I_L=sym('I_L',[1 len]);
        
        for i=1:len
            res1 = I_ph-I_sd*(exp((V_L(i)+I_L(i)*R_s)/(a*V_t))-1)-(V_L(i)+I_L(i)*R_s)/R_sh-I_L(i);
            I_L(i)=(vpasolve(res1,I_L(i)));
        end
   
    elseif type==2  %double_diode_model
        
        T = 273.15+33.0;
    
        V_t  = k*T/q;

        I_ph = x(1);
        I_sd1 = x(2)*10^(-6);
        R_s = x(6);
        R_sh  = x(7);
        a1 = x(4);
        I_sd2 = x(3)*10^(-6);
        a2 = x(5);
        
        V_L = [-0.2057, -0.1291,-0.0588, 0.0057,0.0646,0.1185,0.1678,0.2132,0.2545,0.2924,0.3269,0.3585,0.3873,0.4137,0.4373,0.4590,0.4784,0.4960,...
            0.5119,0.5265,0.5398,0.5521,0.5633,0.5736,0.5833,0.5900];
      I_Lm = [ 0.7640,0.7620,0.7605,0.7605,0.7600 ,0.7590 ,0.7570 ,0.7570 ,0.7555 ,0.7540 ,0.7505 ,0.7465 , 0.7385 , 0.7280 , 0.7065 , 0.6755 ,...
            0.6320 ,0.5730 ,0.4990 , 0.4130 ,0.3165 , 0.2120 ,0.1035 , -0.0100, -0.1230 , -0.2100 ];
        
        len=26;
        
        I_L=sym('I_L',[1 len]);
        
        for i=1:len
            res1 = I_ph-I_sd1*(exp((V_L(i)+I_L(i)*R_s)/(a1*V_t))-1)-I_sd2*(exp((V_L(i)+I_L(i)*R_s)/(a2*V_t))-1)-(V_L(i)+I_L(i)*R_s)/R_sh-I_L(i);
            I_L(i)=(vpasolve(res1,I_L(i)));
        end

    
    elseif type==3  %single_diode_PV_module
        
        T = 273.15+45.0;
    
        V_t  = k*T/q;

       I_ph = x(1);
        I_sd = x(2)*10^(-6);
        R_s = x(4);
        R_sh  = x(5);
        a = x(3);
        Ns = 1;
        
        V_L = [0.1248 , 1.8093,3.3511,4.7622,6.0538 ,7.2364,8.3189,9.3097,10.2163,11.0449,11.8018,12.4929,13.1231,13.6983,14.2221,14.6995,15.1346,15.5311,...
            15.8929,16.2229,16.5241,16.7987,17.0499,17.2793,17.4885];
        I_Lm = [ 1.0315,1.0300,1.0260,1.0220,1.0180 ,1.0155 ,1.0140 ,1.0100 ,1.0035 ,0.9880 ,0.9630 ,0.9255 , 0.8725 , 0.8075 , 0.7265 , 0.6345 ,...
            0.5345 ,0.4275 ,0.3185 , 0.2085 ,0.1010 , -0.0080 ,-0.1110 ,-0.2090, -0.3030];
        
        len=25;
        
        I_L=sym('I_L',[1 len]);
        
        for i=1:len
            res1 = I_ph-I_sd*(exp((V_L(i)+I_L(i)*R_s)/(a*Ns*V_t))-1)-(V_L(i)+I_L(i)*R_s)/R_sh-I_L(i);
            I_L(i)=(vpasolve(res1,I_L(i)));
        end

        
    elseif type==4 %�����裬T=51
        
        T = 273.15+51.0;
        V_t  = k*T/q;
        
       I_ph = x(1);
        I_sd = x(2)*10^(-6);
        R_s = x(4);
        R_sh  = x(5);
        a = x(3);
        Ns = 36;
        
        V_L = [0,0.118 , 2.237,5.434,7.26,9.68 ,11.59,12.6,13.37,14.09,14.88,15.59,16.4,16.71,16.98,17.13,17.32,17.91,19.08,21.02];
        I_Lm = [1.663, 1.663,1.661,1.653,1.65,1.645 ,1.64 ,1.636 ,1.629 ,1.619 ,1.597 ,1.581 ,1.542 , 1.524 , 1.5 , 1.485 , 1.465 ,1.388,1.118,0];
        
        len=20;
        
        I_L=sym('I_L',[1 len]);
        
        for i=1:len
            res1 = I_ph-I_sd*(exp((V_L(i)+Ns*I_L(i)*R_s)/(a*Ns*V_t))-1)-(V_L(i)+Ns*I_L(i)*R_s)/(Ns*R_sh)-I_L(i);
            I_L(i)=(vpasolve(res1,I_L(i)));
        end

        
    elseif type==5 %�ྦྷ�裬T=55
        
        T = 273.15+55.0;
        V_t  = k*T/q;
        
        I_ph = x(1);
        I_sd = x(2)*10^(-6);
        R_s = x(4);
        R_sh  = x(5);
        a = x(3);
        Ns = 36;
        
        V_L=[0, 9.06, 9.74, 10.32, 11.17, 11.81, 12.36, 12.74, 13.16, 13.59, 14.17, 14.58, 14.93, 15.39, 15.71, 16.08, 16.34, 16.76, 16.9, 17.1, 17.25, 17.41, 17.65, 19.21];
        I_Lm=[7.48, 7.45, 7.42, 7.44, 7.41, 7.38, 7.37, 7.34, 7.29, 7.23, 7.10, 6.97, 6.83, 6.58, 6.36, 6.00, 5.75, 5.27, 5.27, 4.79, 4.56, 4.29, 3.83, 0];
        
        len=24;
        
        I_L=sym('I_L',[1 len]);
        
        for i=1:len
            res1 = I_ph-I_sd*(exp((V_L(i)+Ns*I_L(i)*R_s)/(a*Ns*V_t))-1)-(V_L(i)+Ns*I_L(i)*R_s)/(Ns*R_sh)-I_L(i);
            I_L(i)=(vpasolve(res1,I_L(i)));
        end

        
    end
     I_cal=double(I_L)';
     IAE=double(abs(I_Lm-I_L))';
     SIAE=double(sum(abs(I_Lm-I_L),2));   
end