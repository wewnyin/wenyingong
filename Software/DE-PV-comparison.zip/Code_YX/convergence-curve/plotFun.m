clear all
clc


format long;
format compact;
warning('off');

type=input('Input the type of model:');

NP=50;

if type==1
    Max_NFEs = 10000;
elseif type==2
    Max_NFEs = 20000;
elseif type==3
    Max_NFEs = 10000;
elseif type==4
    Max_NFEs = 30000;
elseif type==5
    Max_NFEs = 30000;
end

% plot
%     figure(2);
%     subplot(1,3,3);
%     
%     xNFEs=1:Max_NFEs;
%     yy1=load('methodOFVdata\DE5.mat');
%     yyDouble1=sort(double(yy1.plotRMSE),'descend');
%     yRMSE=yyDouble1(1:Max_NFEs);
%     semilogy(1:Max_NFEs,yRMSE(1:Max_NFEs),'-', 'LineWidth', 2);
%     
%     
%     hold on
%     yy1=load('methodOFVdata\CoDE5.mat');
%     yyDouble1=sort(double(yy1.plotRMSE),'descend');
%     yRMSE=yyDouble1(1:Max_NFEs);
%     semilogy(1:Max_NFEs,yRMSE(1:Max_NFEs),'-', 'LineWidth', 2);
% 
%     
%     hold on
%     yy1=load('methodOFVdata\jDE5.mat');
%     yyDouble1=sort(double(yy1.plotRMSE),'descend');
%     yRMSE=yyDouble1(1:Max_NFEs);
%     semilogy(1:Max_NFEs,yRMSE(1:Max_NFEs),'-', 'LineWidth', 2);
% 
%     
%     hold on
%     yy1=load('methodOFVdata\SaDE5.mat');
%     yyDouble1=sort(double(yy1.plotRMSE),'descend');
%     yRMSE=yyDouble1(1:Max_NFEs);
%     semilogy(1:Max_NFEs,yRMSE(1:Max_NFEs),'-', 'LineWidth', 2);
% 
%     
%     hold on
%     yy1=load('methodOFVdata\IDE5.mat');
%     yyDouble1=sort(double(yy1.plotRMSE),'descend');
%     yRMSE=yyDouble1(1:Max_NFEs);
%     semilogy(1:Max_NFEs,yRMSE(1:Max_NFEs),'-', 'LineWidth', 2);
% 
%     
%     hold on
%     yy1=load('methodOFVdata\AGDE5.mat');
%     yyDouble1=sort(double(yy1.plotRMSE),'descend');
%     yRMSE=yyDouble1(1:Max_NFEs);
%     semilogy(1:Max_NFEs,yRMSE(1:Max_NFEs),'-', 'LineWidth', 2);
% 
%     
%     hold on
%     yy1=load('methodOFVdata\JADE5.mat');
%     yyDouble1=sort(double(yy1.plotRMSE),'descend');
%     yRMSE=yyDouble1(1:Max_NFEs);
%     semilogy(1:Max_NFEs,yRMSE(1:Max_NFEs),'-', 'LineWidth', 2);
% 
%     
%     hold on
%     yy1=load('methodOFVdata\RcrIJADE5.mat');
%     yyDouble1=sort(double(yy1.plotRMSE),'descend');
%     yRMSE=yyDouble1(1:Max_NFEs);
%     semilogy(1:Max_NFEs,yRMSE(1:Max_NFEs),'-', 'LineWidth', 2);
% 
%     
%     hold on
%     yy1=load('methodOFVdata\SHADE5.mat');
%     yyDouble1=sort(double(yy1.plotRMSE),'descend');
%     yRMSE=yyDouble1(1:Max_NFEs);
%     semilogy(1:Max_NFEs,yRMSE(1:Max_NFEs),'-', 'LineWidth', 2);
% 
%     
%     hold on
%     yy1=load('methodOFVdata\LSHADE5.mat');
%     yyDouble1=sort(double(yy1.plotRMSE),'descend');
%     yRMSE=yyDouble1(1:Max_NFEs);
%     semilogy(1:Max_NFEs,yRMSE(1:Max_NFEs),'-', 'LineWidth', 2);
% 
%     
%     hold on
%     yy1=load('methodOFVdata\SDE5.mat');
%     yyDouble1=sort(double(yy1.plotRMSE),'descend');
%     yRMSE=yyDouble1(1:Max_NFEs);
%     semilogy(1:Max_NFEs,yRMSE(1:Max_NFEs),'-', 'LineWidth', 2);
%     axis([0 Max_NFEs 10e-5 10e2]);
%     
%     
%     
%     
%     xlabel('NFEs');
%     ylabel('RMSE(log)');
%     ax = gca;
%     ax.XAxis.Exponent = 4;
%     grid on;
%     legend('DE','CoDE','jDE','SaDE','IDE','AGDE','JADE','Rcr-IJADE','SHADE','L-SHADE','SDE');
%     
    
    figure(1);
    
    xNFEs=1:Max_NFEs;
    yy1=load('methodOFVdata\RcrIJADE5.mat');
    yyDouble1=sort(double(yy1.plotRMSE),'descend');
    yRMSE=yyDouble1(1:Max_NFEs);
    semilogy(1:Max_NFEs,yRMSE(1:Max_NFEs),'-', 'LineWidth', 2);
    
    hold on
    yy1=load('methodOFVdata\ORcr-IJADE_0.1_5.mat');
    yyDouble1=sort(double(yy1.plotRMSE),'descend');
    yRMSE=yyDouble1(1:Max_NFEs);
    semilogy(1:Max_NFEs,yRMSE(1:Max_NFEs),'-', 'LineWidth', 2);
    axis([0 Max_NFEs 10e-5 10e2]);
    
    
    
    
    xlabel('NFEs');
    ylabel('RMSE(log)');
    ax = gca;
    ax.XAxis.Exponent = 4;
    grid on;
    legend('Rcr-IJADE','ORcr-IJADE');
    title('STP');
    
