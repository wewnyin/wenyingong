clear all
clc

format long;
format compact;
warning('off');

NP=50;

type=input('Input the type of model:');


%%��ʼ��
[ UB,LB,Dim ] = Parameter(type);
MaMi=(repmat((UB-LB),NP,1));
MiLB=repmat((LB),NP,1);
Pinit=MaMi.*rand(NP,Dim)+MiLB;%���������ʼ��Ⱥ����

% if type==1
%     P=load('..\convergence-curve\InitPoPdata\model1pop.mat','Pinit');
% elseif type==2
%     P=load('..\convergence-curve\InitPoPdata\model2pop.mat','Pinit');
% elseif type==3
%     P=load('..\convergence-curve\InitPoPdata\model3pop.mat','Pinit');
% elseif type==4
%     P=load('..\convergence-curve\InitPoPdata\model4pop.mat','Pinit');
% elseif type==5
%     P=load('..\convergence-curve\InitPoPdata\model5pop.mat','Pinit');
% end
% P=double(P.Pinit);

for i=1:NP
        OFV(i)=PV_TestFunction(type,Pinit(i,:));%������Ⱥ������Ӧֵ
end



