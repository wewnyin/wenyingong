function [GD]=convergence(obj,ref_point)%�����Ѿ���һ����Ŀ��ֵ�Ͳο���
    [obj_size,~]=size(obj);
    [ref_size,~]=size(ref_point);
    distance=zeros(obj_size,ref_size);
    GD=0;
    for i=1:obj_size
        for j=1:ref_size
            distance(i,j)=(obj(i,1)-ref_point(j,1))^2+(obj(i,2)-ref_point(j,2))^2;
            distance(i,j)=sqrt(distance(i,j));
        end
        GD=GD+min(distance(i,:));
    end
    GD=GD/obj_size;
    
end