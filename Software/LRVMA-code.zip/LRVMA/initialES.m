function [p_chrom,m_chrom] = initialES()
global ps refpoint;
[p_chrom,m_chrom]=initial();

fitness=cell(ps/2,2);
    for i=1:ps/2
        [fitness{i,1},fitness{i,2}]=fit(p_chrom(i,:),m_chrom(i,:));
    end
    obj=finalvalue(fitness);
    [refpoint,~]=min(obj);   

for i=1:ps/2
   [p_chrom(i,:),m_chrom(i,:),fitness(i,:)]=EnergySave(p_chrom(i,:),m_chrom(i,:),fitness(i,:)); 
end

end