function DeleteRpeat()
global Archive_PF;
[m,~]=size(Archive_PF);
for i=1:m
    if i>m
        break;
    end
    F=Archive_PF(i,:);
    j=i+1;
    while j<m
        if Archive_PF(j,1)==F(1,1)&&Archive_PF(j,2)==F(1,2)           
            Archive_PF(j,:)=[];           
            j=j-1;
            m=m-1;
        end
        j=j+1;
    end
end
end