classdef BDCR < ALGORITHM
% <multi> <real/binary/permutation> <constrained>

%------------------------------- Reference --------------------------------
% Q. Zhu, Q. Zhang, and Q. Lin, A constrained multi-objective evolutionary
% algorithm with detect-and-escape strategy, IEEE Transactions on
% Evolutionary Computation, 2020, 24(5): 938-947.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2022 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    methods
        function main(Algorithm,Problem)
            %% Generate the weight vectors
            [delta,~] = Algorithm.ParameterSet(0.9,2);
            [W,Problem.N] = UniformPoint(Problem.N,Problem.M);
            % Size of neighborhood
            T = ceil(Problem.N/5);

            %% Detect the neighbours of each solution
            B = pdist2(W,W);
            [~,B] = sort(B,2);
            B = B(:,1:T);
            
            Population1 = Problem.Initialization();
            Z           = min(Population1.objs,[],1);

            %% Evaluate the Population
            Tc               = 0.9 * ceil(Problem.maxFE/Problem.N)/2;
            last_gen         = 20;
            change_threshold = 1e-1;
            search_stage     = 1; % 1 for push stage,otherwise,it is in pull stage.
            max_change       = 1;
            epsilon_k        = 0;
            epsilon_0        = 0;
            cp               = 2;
            alpha            = 0.95;
            tao              = 0.05;
            ideal_points     = zeros(ceil(Problem.maxFE/Problem.N),Problem.M);
            nadir_points     = zeros(ceil(Problem.maxFE/Problem.N),Problem.M);

            %% Generate random population
            Population2  = Problem.Initialization();
            Z           = min([Z;Population2.objs],[],1);
            Pi          = ones(Problem.N,1);
            avg_fit1     = sum(max(abs((Population1.objs-repmat(Z,Problem.N,1)).*W),[],2))/Problem.N;%种群聚合函数平均值
            avg_fit2     = sum(max(abs((Population2.objs-repmat(Z,Problem.N,1)).*W),[],2))/Problem.N;%种群聚合函数平均值
            epsilon2_max = max(sum(max(Population2.cons,0),2));%种群中最大约束违反度
            epsilon2     = epsilon2_max*size(Population2.cons,2);
            sigma_min2   = 1-(1/(epsilon2+1.0e-10))^(3/ceil(Problem.maxFE/Problem.N));
            A     = ArchiveUpdate(Population2,Problem.N);%环境选择时只要非支配排序序号为1的个体
            gen2   = 0;   
            gen    = 1;
            CV2    = sum(max(Population2.cons,0),2);%所有个体的约束违反度
            fr2    = length(find(CV2<=0))/Problem.N;%种群可行率
            sigma2 = max(sigma_min2,fr2);

            %% Optimization
            while Algorithm.NotTerminated(A)%把存档作为图像
                Q = [];
                w = [];
                pop_cons   = Population1.cons;
                cv         = overall_cv(pop_cons);
                population = [Population1.decs,Population1.objs,cv];
                fr1         = sum(cv <= 1e-6) / Problem.N;
                ideal_points(gen,:) = Z;
                nadir_points(gen,:) = max(population(:,Problem.D + 1 : Problem.D + Problem.M),[],1);
                if gen >= last_gen
                    max_change = calc_maxchange(ideal_points,nadir_points,gen,last_gen);
                end
                % The value of e(k) and the search strategy are set.
                if gen < Tc
                    if max_change <= change_threshold && search_stage == 1
                        search_stage = -1;
                        epsilon_0 = max(population(:,end),[],1);
                        epsilon_k = epsilon_0;
                    end
                    if search_stage == -1
                        epsilon_k =  update_epsilon(tao,epsilon_k,epsilon_0,fr1,alpha,gen,Tc,cp);
                    end
                else
                    epsilon_k = 0;
                end
                
                for subgeneration = 1 : 5
                        % Choose the parents
                        Bounday = find(sum(W<1e-3,2)==Problem.M-1)';%最两侧的向量序号
                        mid=50;
                        I = [Bounday,mid,TournamentSelection(10,floor(Problem.N/5)-length(Bounday)-1,-Pi)];%除了两侧之外挑选18个父代（共计20个）
                        for j = 1 : length(I)
                            i = I(j);
                            if rand < delta
                                P2 = B(i,randperm(size(B,2)));
                                P1 = B(i,randperm(size(B,2)));
                            else
                                P2 = randperm(Problem.N);
                                P1 = randperm(Problem.N);
                            end
                            Offspring2 = OperatorGAhalf(Problem,Population2(P2(1:2)));
                            Offspring1 = OperatorDE(Problem,Population1(i),Population1(P1(1)),Population1(P1(2)));
                            Z = min([Z;Offspring2.objs;Offspring1.objs],[],1);
                     
                          %在pps的评判标准下进行比较
                           g_i1= max(abs(Offspring1.obj-Z).*W(i,:),[],2);
                           g_i2= max(abs(Offspring2.obj-Z).*W(i,:),[],2);
                           cv_i1=overall_cv(Offspring1.con);
                           cv_i2=overall_cv(Offspring2.con);
                           if search_stage == 1 % Push Stage
                               if(g_i1<=g_i2)
                                   Population1 = UpdatePpsP(Population1,P1,Offspring1,epsilon_k,Z,W,search_stage,avg_fit1,Pi);
                               else
                                   Population1 = UpdatePpsP(Population1,P1,Offspring2,epsilon_k,Z,W,search_stage,avg_fit1,Pi);
                               end
                           else  % Pull Stage  &&  An improved epsilon constraint-handling is employed to deal with constraints
                               if(cv_i1 <= epsilon_k&&cv_i2 <= epsilon_k||cv_i1==cv_i2)
                                   if(g_i1<=g_i2)
                                       Population1 = UpdatePpsP(Population1,P1,Offspring1,epsilon_k,Z,W,search_stage,avg_fit1,Pi);
                                   else
                                       Population1 = UpdatePpsP(Population1,P1,Offspring2,epsilon_k,Z,W,search_stage,avg_fit1,Pi);
                                   end 
                               else
                                  if(cv_i1<cv_i2)
                                     Population1 = UpdatePpsP(Population1,P1,Offspring1,epsilon_k,Z,W,search_stage,avg_fit1,Pi);
                                  else
                                      Population1 = UpdatePpsP(Population1,P1,Offspring2,epsilon_k,Z,W,search_stage,avg_fit1,Pi);
                                  end
                               end
                           end
                        %在DAE标准下进行比较
                           if(cv_i1 <= epsilon2&&cv_i2 <= epsilon2||cv_i1==cv_i2)
                               if(g_i1<=g_i2)
                                    [Population2,Pi] = UpdatePop(Population2,P2,Offspring1,epsilon2,Z,W,sigma2,Pi,avg_fit2);
                               else
                                    [Population2,Pi] = UpdatePop(Population2,P2,Offspring2,epsilon2,Z,W,sigma2,Pi,avg_fit2);
                               end 
                           else
                              if(cv_i1<cv_i2)
                                   [Population2,Pi] = UpdatePop(Population2,P2,Offspring1,epsilon2,Z,W,sigma2,Pi,avg_fit2);
                              else
                                   [Population2,Pi] = UpdatePop(Population2,P2,Offspring2,epsilon2,Z,W,sigma2,Pi,avg_fit2);
                              end
                           end
                       
                           if sum(max(Offspring2.cons,0),2) == 0
                              Q = [Q Offspring2];
                           end 
                           if sum(max(Offspring1.cons,0),2) == 0
                              w =[w Offspring1];
                           end
                       end
                         
                end
   
                gen2   = gen2+1;
                gen   = gen+1;
                CV2    = sum(max(Population2.cons,0),2);
                fr2    = length(find(CV2<=0))/Problem.N;
                sigma2 = max(sigma_min2,fr2);
                if fr2 < 0.95
                    epsilon2 = (1-sigma2)*epsilon2;
                else
                    epsilon2   = epsilon2_max;
                    sigma_min2 = 1-(1/(epsilon2+1.0e-10))^(3/ceil(Problem.maxFE/(2*Problem.N)));
                end 
                if mod(gen,10) == 0
                    avg_fit2 = sum(max(abs((Population2.objs-repmat(Z,Problem.N,1)).*W),[],2))/Problem.N;
                     avg_fit1 = sum(max(abs((Population1.objs-repmat(Z,Problem.N,1)).*W),[],2))/Problem.N;
                end
               
                if size(Q,2) > 0
                   A = ArchiveUpdate([A Q],Problem.N);
                end
                A=ArchiveUpdate([A w],Problem.N);
                
            end
        end
    end
end
% The Overall Constraint Violation
function result = overall_cv(cv)
    cv(cv <= 0) = 0;cv = abs(cv);
    result = sum(cv,2);
end

% Calculate the Maximum Rate of Change
function max_change = calc_maxchange(ideal_points,nadir_points,gen,last_gen)
    delta_value = 1e-6 * ones(1,size(ideal_points,2));
    rz = abs((ideal_points(gen,:) - ideal_points(gen - last_gen + 1,:)) ./ max(ideal_points(gen - last_gen + 1,:),delta_value));
    nrz = abs((nadir_points(gen,:) - nadir_points(gen - last_gen + 1,:)) ./ max(nadir_points(gen - last_gen + 1,:),delta_value));
    max_change = max([rz, nrz]);
end

function result = update_epsilon(tao,epsilon_k,epsilon_0,rf,alpha,gen,Tc,cp)
    if rf < alpha
        result = (1 - tao) * epsilon_k;
    else
        result = epsilon_0 * ((1 - (gen / Tc)) ^ cp);
    end
end