function [PS_Archive, PF_Archive, startEndTime_Archive] = Update_Archive(PS, PF, startEndTime, PS_Archive, PF_Archive, startEndTime_Archive)
%%%更新档案集

%%%合并种群
PS_Archive = cat(1, PS_Archive, PS);
PF_Archive = cat(1, PF_Archive, PF);
startEndTime_Archive = cat(2, startEndTime_Archive, startEndTime);

%%%删除重复解
[~, resIdx, ~] = unique(PS_Archive, 'rows');          
PS_Archive = PS_Archive(resIdx, :);
PF_Archive = PF_Archive(resIdx, :);
startEndTime_Archive = startEndTime_Archive(resIdx);

%%%找出非支配解作为存档集
array = (1:size(PF_Archive, 1))';
nonIdx = Find_Nondominated_Solutions(PF_Archive, array);
PS_Archive = PS_Archive(nonIdx, :);
PF_Archive = PF_Archive(nonIdx, :);
startEndTime_Archive = startEndTime_Archive(nonIdx);


end