function SchedSeqOff = LS2(p_chrom, m_chrom, s_chrom, criticalPathBlock)
%%%LS2：采用N8邻域结构

global N H SH;

s1 = p_chrom;
s2 = zeros(1, SH);
p = zeros(1, N);
for j = 1:SH
    p(s1(j)) = p(s1(j)) + 1;    %记录过程是否加工完成，完成一次加一
    s2(j) = p(s1(j));     %记录加工过程中，工件的次数
end

for j = 1:SH
    t1 = s1(j);   %记录到当前是哪个工件
    t2 = s2(j);   %记录当前工件是加工到第几次
    mm(j) = m_chrom(sum(H(1:t1-1)) + t2);   %提取该工序该次加工的机器选择，因为机器码的排列表示该工件第几次加工所选的机器，是一段表示一个工件
end

idxMap = 1:SH;      %下标映射

for i = 1:length(criticalPathBlock)
    %%%调整关键路径块内部的工序
    machNo = mm(criticalPathBlock{i}(1));       %关键块的机器号
    opSegIdx = find(mm == machNo);        %关键块上的所有工序下标
    frontIdx = criticalPathBlock{i}(1);       %关键路径块第一个工序的下标
    rearIdx = criticalPathBlock{i}(end);       %关键路径块最后一个工序的下标
    len = length(criticalPathBlock{i});
    if len > 2
        %%关键块上的工序数大于2时，才执行块内工序的插入操作
        insIdx = criticalPathBlock{i}(randi([2, len-1]));      %待插入的索引值
        if rand > 0.5
            %%向前插入
            insPos = randi(frontIdx);
        else
            %%向后插入
            insPos = randi([rearIdx, SH]);
        end
        idxMap(find(idxMap == insIdx)) = [];
        idxMap = [idxMap(1:insPos-1), insIdx, idxMap(insPos:end)];
    end
    
    
    %%%调整关键路径块的首部工序
    if rearIdx < opSegIdx(end)
        %%关键路径块最后一个工序之后存在工序才执行N8邻域结构，否则执行N7邻域结构
        idx = find(opSegIdx == rearIdx);
        insPos = randi([opSegIdx(idx+1), SH]);
        idxMap(find(idxMap == frontIdx)) = [];
        idxMap = [idxMap(1:insPos-1), frontIdx, idxMap(insPos:end)];   
    elseif len >= 3
        %%关键块上的工序数大于等于3时，才执行N7邻域结构
        insPos = randi([frontIdx+1, rearIdx-1]);
        idxMap(find(idxMap == frontIdx)) = [];
        idxMap = [idxMap(1:insPos-1), frontIdx, idxMap(insPos:end)];
    end
    
    
    %%%调整关键路径块的尾部工序
    if frontIdx > opSegIdx(1)
        %%关键路径块第一个工序之前存在工序才执行N8邻域结构，否则执行N7邻域结构
        idx = find(opSegIdx == frontIdx);
        insPos = randi(opSegIdx(idx-1));
        idxMap(find(idxMap == rearIdx)) = [];
        idxMap = [idxMap(1:insPos-1), rearIdx, idxMap(insPos:end)];        
    elseif len >= 3
        %%关键块上的工序数大于等于3时，才执行N7邻域结构
        insPos = randi([frontIdx+1, rearIdx-1]);
        idxMap(find(idxMap == rearIdx)) = [];
        idxMap = [idxMap(1:insPos-1), rearIdx, idxMap(insPos:end)];
    end
    
end

p_chrom = p_chrom(idxMap);

SchedSeqOff = [p_chrom, m_chrom, s_chrom];


end