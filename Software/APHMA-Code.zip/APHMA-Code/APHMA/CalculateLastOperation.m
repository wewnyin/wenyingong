function value = CalculateLastOperation(s1, s2, mm, ss, digraph, last, VELTime, procTime)

Index = last;
e = 0;
t1 = e;
t2 = e;
if digraph(Index, 3) ~= 0
    zlast = digraph(Index, 3);
    if isempty(VELTime{zlast, 1})          
        VELTime{zlast, 1} = CalculateLastOperation(s1, s2, mm, ss, digraph, zlast, VELTime, procTime);
    end
    t1 = procTime{s1(zlast)}(s2(zlast), mm(zlast)) / ss(zlast) + VELTime{zlast, 1};
end

if digraph(Index, 4) ~= 0
    zlast = digraph(Index, 4);
    if isempty(VELTime{zlast, 1})  
        VELTime{zlast, 1} = CalculateLastOperation(s1, s2, mm, ss, digraph, zlast, VELTime, procTime);
    end
    t2 = procTime{s1(zlast)}(s2(zlast), mm(zlast)) / ss(zlast) + VELTime{zlast, 1};
end   

if t1 > t2      %如果t1大于t2则
    VELTime{Index, 1} = t1;
else
    VELTime{Index, 1} = t2;
end
value = VELTime{Index, 1};
    
end