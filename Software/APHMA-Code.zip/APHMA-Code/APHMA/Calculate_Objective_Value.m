function [objValue, startEndTime] = Calculate_Objective_Value(schedSeq, procTime, startupShutdownPower, procPower, idlePower) 

global N M H SH;

%%%将调度序列进行拆分，拆分为OS+MS+SS
OS = schedSeq(:, 1:SH);
MS = schedSeq(:, SH+1:2*SH);
SS = schedSeq(:, 2*SH+1:3*SH);

objValue = [];    %存储目标函数值
startEndTime = {};      %存储种群中每个工序的开始加工时间和结束加工时间
len = size(OS, 1);

for i = 1:len
    totEnergyConsumption = 0;       %总的能量消耗
    machAvlTime = zeros(1, M);     %机器最早可用时间
    
    %%%startEnd{1}(1, 1)表示工件1的第1道工序的开始加工时间，startEnd{1}(1, 2)表示工件1的第1道工序的结束加工时间
    startEnd = {};      
    for j = 1:N
        array = zeros(size(procTime{j}, 1), 2);
        startEnd{j, 1} = array;
    end
    
    s1 = OS(i, :);     %s1用来存放种群中的每个工序码
    s2 = zeros(1, SH);      %s2用来存放每个工件的是第几个工序
    p = zeros(1, N);
    
    for t = 1:SH
        p(s1(t)) = p(s1(t)) + 1;
        s2(t) = p(s1(t));
    end
    
    for j = 1:SH
        
        if (s2(j) == 1)
            jobNo = s1(j);      %工件号
            machNo = MS(i, sum(H(1:(jobNo - 1)))+ 1);    %机器号
            machLvl = SS(i, sum(H(1:(jobNo - 1)))+ 1);     %机器速度等级
            time = procTime{jobNo}(1, machNo) / machLvl;      %工序的实际加工时间
            totEnergyConsumption = totEnergyConsumption + time * (machLvl + log(machLvl)) * procPower(machNo);      %计算加工功率，更新总能量消耗

            startEnd{jobNo}(1, 1) = machAvlTime(machNo);    %记录工序的开始加工时间
            startEnd{jobNo}(1, 2) = startEnd{jobNo}(1, 1) + time;    %记录工序的结束加工时间
            machAvlTime(machNo) = startEnd{jobNo}(1, 2);
      
        else
            jobNo = s1(j);      %工件号
            machNo = MS(i, sum(H(1:(jobNo - 1)))+ s2(j));    %机器号
            machLvl = SS(i, sum(H(1:(jobNo - 1)))+ s2(j));     %机器速度等级
            time = procTime{jobNo}(s2(j), machNo) / machLvl;      %工序的实际加工时间
            totEnergyConsumption = totEnergyConsumption + time * (machLvl + log(machLvl)) * procPower(machNo);      %计算加工功率，更新总能量消耗

            startEnd{jobNo}(s2(j), 1) = max(machAvlTime(machNo), startEnd{jobNo}(s2(j) - 1, 2));    %记录工序的开始加工时间
            
            %%%计算空闲功率，更新总能量消耗
            idleTime = startEnd{jobNo}(s2(j) - 1, 2) - machAvlTime(machNo);
            if idleTime > 0
                totEnergyConsumption = totEnergyConsumption + idleTime * (machLvl + log(machLvl)) * idlePower(machNo);      %计算空闲功率，更新总能量消耗
            end
                
            startEnd{jobNo}(s2(j), 2) = startEnd{jobNo}(s2(j), 1) + time;    %记录工序的结束加工时间
            machAvlTime(machNo) = startEnd{jobNo}(s2(j), 2);

        end
        
    end
    
    makespan = max(machAvlTime);       %最大完工时间
    
    %%%计算开机/关机功率，更新总能量消耗
    for k = 1:M
        totEnergyConsumption = totEnergyConsumption + 2 * startupShutdownPower(k);
    end
    
    objValue = cat(1, objValue, [makespan, totEnergyConsumption]);
    startEndTime{i} = startEnd;
    
end


end