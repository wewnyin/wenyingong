function SchedSeqSel = Tournament_Selection(SchedSeq, objValue)
%%%根据目标值进行选择

global P;

SchedSeqSel = [];

for i = 1:(P / 2)
    index1 = ceil(rand * P);
    index2 = ceil(rand * P);
    while index1 == index2
        index2 = ceil(rand * P);    %防止两个相同个体
    end
    
    if all(objValue(index1, :) <= objValue(index2, :)) && any(objValue(index1, :) < objValue(index2, :))
        index = index1;
    elseif all(objValue(index2, :) <= objValue(index1, :)) && any(objValue(index2, :) < objValue(index1, :))
        index = index2;
    else
        if rand > 0.5
            index = index1;
        else
            index = index2;
        end
    end
    
    SchedSeqSel = cat(1, SchedSeqSel, SchedSeq(index, :));
       
end


end