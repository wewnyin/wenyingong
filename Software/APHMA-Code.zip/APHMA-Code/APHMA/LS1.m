function SchedSeqOff = LS1(p_chrom, m_chrom, s_chrom, criticalOperation, criticalPath, procTime)
%%%LS1：随机选取处于多条关键路径上的工序，将其随机插入到候选机器集中；若不存在这样的工序，则随机选取关键路径

global N H SH;

s1 = p_chrom;
s2 = zeros(1, SH);
p = zeros(1, N);
for i = 1:SH
    p(s1(i)) = p(s1(i)) + 1;    %记录过程是否加工完成，完成一次加一
    s2(i) = p(s1(i));     %记录加工过程中，工件的次数
end

crucialOperation = criticalOperation;     %保存处于多条关键路径上的工序

if length(criticalPath) > 1
    %%存在多条关键路径，随机选取处于多条关键路径上的工序，将其随机插入到候选机器集中
    crucialOperation = criticalPath{1};
    for i = 2:length(criticalPath)
        crucialOperation = intersect(crucialOperation, criticalPath{i});
    end
    if isempty(crucialOperation)
        crucialOperation = criticalOperation;
    end
end

%%只存在一条关键路径，随机选取关键工序，将其随机插入到候选机器集中
delIdx = [];
for i = 1:length(crucialOperation)
    idx = crucialOperation(i);
    if length(find(procTime{s1(idx)}(s2(idx), :) > 0)) == 1
        %%如果候选机器集只有1台机器，则排除这个工序
        delIdx = cat(2, delIdx, i);
    end
end
crucialOperation(delIdx) = [];
if ~isempty(crucialOperation)
    idx = crucialOperation(randi(length(crucialOperation)));
    machSet = procTime{s1(idx)}(s2(idx), :);
    machNo = m_chrom(sum(H(1:(s1(idx) - 1)))+ s2(idx));    %机器号
    machSet(machNo) = 0;
    avlMachSet = find(machSet ~= 0);
    adjMachNo = avlMachSet(randi(length(avlMachSet)));
    
    %%调整工序的机器号
    m_chrom(sum(H(1:(s1(idx) - 1)))+ s2(idx)) = adjMachNo;
    
    %%调整工序序列，否则调整机器号的工序会处于一个相对固定的位置
    insPos = randi(SH);     %插入的位置
    insOp = p_chrom(idx);   %插入的工序
    p_chrom(idx) = [];
    p_chrom = [p_chrom(1:insPos-1), insOp, p_chrom(insPos:end)];
end

SchedSeqOff = [p_chrom, m_chrom, s_chrom];


end