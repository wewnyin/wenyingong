function allPaths = Find_All_Paths(G, startNode, endNode)
    % 初始化存储所有路径的变量
    allPaths = {};
    
    % 从起始节点开始进行深度优先搜索
    dfs(G, startNode, endNode, []);
    
    % 深度优先搜索函数
    function dfs(G, currentNode, endNode, currentPath)
        % 将当前节点添加到当前路径中
        currentPath = [currentPath, currentNode];
        
        % 如果当前节点是结束节点，则将当前路径添加到所有路径中
        if currentNode == endNode
            allPaths = [allPaths; {currentPath}];
            return;
        end
        
        % 获取当前节点的邻居节点
        neighbors = successors(G, currentNode);
        
        % 遍历邻居节点
        for i = 1:length(neighbors)
            neighbor = neighbors(i);
            % 如果邻居节点不在当前路径中，则递归调用DFS
            if ~ismember(neighbor, currentPath)
                dfs(G, neighbor, endNode, currentPath);
            end
        end
    end
end
