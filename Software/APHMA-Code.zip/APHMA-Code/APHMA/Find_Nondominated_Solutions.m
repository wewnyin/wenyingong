function nonIdx = Find_Nondominated_Solutions(objValue, idxArray)
%%%寻找非支配解

% [~, resIdx, ~] = unique(schedSeq, 'rows');          %删除重复解
% PS = schedSeq(resIdx, :);
% PF = objValue(resIdx, :);
% startEnd = startEndTime(resIdx);

len = size(objValue, 1);
nondominated = ones(1, len);
for i = 1:len
    for j = 1:len
        if all(objValue(j, :) <= objValue(i, :)) && any(objValue(j, :) < objValue(i, :))
            nondominated(i) = 0;
        end
    end
end
idx = find(nondominated == 1);
nonIdx = idxArray(idx);


end