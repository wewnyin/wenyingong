function [exemplar, exemplarBelong, X] = RF_AP_Clustering(schedSeq, objValue)
%%%基于RF的AP聚类，先用RF进行特征选择，再用AP进行聚类
global SH;

featureNum = ceil(sqrt(SH / 3));        %提取的特征数量，为了减缓维度灾难对欧式距离的影响
lam = 0.5;          %设置阻尼系数，防止某些情况下出现的数据振荡

%%%归一化决策空间和目标空间
X = (schedSeq - min(schedSeq(:))) / (max(schedSeq(:)) - min(schedSeq(:)));
normObj = mapminmax(objValue', 0, 1)';
Y = 0.5 * normObj(:, 1) + 0.5 * normObj(:, 2);

%%%建立RF，并进行特征选择
rf = TreeBagger(100, X, Y, 'Method', 'regression', 'OOBPredictorImportance', 'on');
featureScore = rf.OOBPermutedPredictorDeltaError;
[~, sortedIdx] = sort(featureScore, 'descend');       %将特征根据其重要性排序
featureSel = sortedIdx(1:featureNum);           %提取出的特征
X = X(:, featureSel);           %归一化且特征提取后的决策空间

%%%建立相似度矩阵
len = size(X, 1);
S = -Inf * ones(len, len);           %-Inf负无穷大，定义S为len*len的相似度矩阵，初始化每个值为负无穷大
tmp = [];           %存储相似度值
for i = 1:len
    for j = 1:len
        S(i, j) = -pdist2(X(i, :), X(j, :), 'euclidean');        %计算欧式距离
        if i ~= j
            tmp = cat(1, tmp, S(i, j));
        end
    end
end
pref = median(tmp);            %p为所有相似度值的中位数，用中位数作为preference,将获得数量合适的簇的个数
for i = 1:len
    S(i, i) = pref;
end

dS = diag(S);       %列向量，存放S中对角线元素信息
R = zeros(len, len);        %吸引矩阵
A = zeros(len, len);        %归属矩阵
maxIter = 500;         %设置迭代最大次数为500次
convits = 50;         %设置迭代不变次数为50
iterInfo = zeros(len, convits);         %info循环地记录50次迭代信息
judge = 1;          %judge = 0作为一个循环结束信号
iter = 0;           %iter用来记录循环次数
while judge
    iter = iter + 1;
    
    %%%更新吸引矩阵
    Rold = R;           %用Rold记下更新前的R
    AS = A + S;         %A(i,j) + S(i,j)
    [Y, I] = max(AS, [], 2);            %获得AS中每行的最大值存放到列向量Y中，每个最大值在AS中的列数存放到列向量I中
    for k = 1:len
        AS(k, I(k)) = -realmax;         %将AS中每行的最大值置为负的最大浮点数，以便于下面寻找每行的第二大值
    end
    [Y2, ~] = max(AS, [], 2);           %存放原AS中每行的第二大值的信息
    R = S - repmat(Y, [1, len]);          %更新R, R(i,k)=S(i,k)-max{A(i,k')+S(i,k')}, k'~=k, 即计算出各点作为i点的簇中心的适合程度
    
    for k = 1:len                               %eg:第一行中AS(1,2)最大,AS(1,3)第二大，
        R(k, I(k)) = S(k, I(k)) - Y2(k);        %so R(1,1)=S(1,1)-AS(1,2); R(1,2)=S(1,2)-AS(1,3); R(1,3)=S(1,3)-AS(1,2).............
    end                                         %这样更新R后，R的值便表示k多么适合作为i 的簇中心，若k是最适合i的点，则R(i,k)的值为正
    R = (1 - lam) * R + lam * Rold;
    
    %%%更新归属矩阵
    Aold = A;
    Rp = max(R,0);          %除R(k,k)外，将R中的负数变为0，忽略不适和的点的不适合程度信息
    for k = 1:len
        Rp(k, k) = R(k, k);
    end
    A = repmat(sum(Rp, 1), [len, 1]) - Rp;      %更新A(i,k),先将每列大于零的都加起来，因为i~=k,所以要减去多加的Rp(i,k)
    
    dA = diag(A);
    A = min(A, 0);               %除A(k,k)以外，其他的大于0的A值都置为0
    for k = 1:len
        A(k, k) = dA(k);
    end
    A = (1 - lam) * A + lam * Aold;
    
    %%%判断是否收敛
    E = ((diag(A) + diag(R)) > 0);
    iterInfo(:, mod(iter - 1, convits) + 1) = E;     %将循环计算结果列向量E放入矩阵iterInfo中，注意是循环存放结果，即第一次循环得出的E放到len*50的iterInfo矩阵的第一列，第51次的结果又放到第一列
    K = sum(E);         %大于0确保一定存在聚类中心
    if iter >= convits || iter >= maxIter       %判断循环是否终止
        se = sum(iterInfo, 2);          %se为列向量，E的convits次迭代结果和
        converged = (sum((se == convits) + (se == 0)) == len);  %所有的点要么迭代50次都满足A+R>0，要么一直都小于零，不可以作为簇中心
        if (converged && (K > 0))||(iter == maxIter)   %迭代50次不变，且有簇中心产生或超过最大循环次数时循环终止。
            judge = 0;
        end
    end
end

exemplar = find(diag(A + R) > 0);           %聚类中心
K = length(exemplar);      %Identify exemplars
[~, c] = max(S(:, exemplar), [], 2);       %取出S中的第二，四列；求出2，4列的每行的最大值，如果第一行第二列的值大于第一行第四列的值，则说明第一个点是第二个点是归属点
c(exemplar) = 1:K;     %Identify clusters，c(2)=1,c(4)=2(第2个点为第一个簇中心，第4个点为第2个簇中心)
% Refine the final set of exemplars and clusters and return results
for k = 1:K
    idx = find(c == k);          %k=1时，发现第1，2，3个点为都属于第一个簇
    [~, I] = max(sum(S(idx, idx), 1));         %k=1时 提取出S中1，2，3行和1，2，3列组成的3*3的矩阵，分别算出3列之和取最大值，y记录最大值，j记录最大值所在的列
    exemplar(k) = idx(I(1));            %I=[2;4]
end
[~, c] = max(S(:, exemplar), [], 2);         %tmp为2，4列中每行最大数组成的列向量，c为每个最大数在S（：，I）中的位置，即表示各点到那个簇中心最近
c(exemplar) = 1:K;          %c(2)=1;c(4)=2;
exemplarBelong = exemplar(c);           %每个个体的聚类归属
%(tmpidx-1)*N+(1:N)'                                       %一个列向量分别表示S(1,2),S(2,2),S(3,2),S(4,4),S(5,4),S(6,4)是S矩阵的第几个元素
%sum(S((tmpidx-1)*N+(1:N)'))                        %求S中S(1,2)+S(2,2)+S(3,2)+S(4,4)+S(5,4)+S(6,4)的和
%tmpnetsim=sum(S((tmpidx-1)*N+(1:N)'));   %将各点到簇中心的一个表示距离的负值的和来衡量这次聚类的适合度


end


