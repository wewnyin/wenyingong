function [] = Parallel_Main_Built_in(run)

global N M H SH P G CR MU BETA SIGMA;

startupShutdownPower = [16.21, 18.11, 19.73, 15.90, 19.01, 16.05, 16.92, 19.19, 15.97, 16.61, 19.24, 16.18, 15.13, 18.61, 18.77]; %机器开机/关机功率
procPower = [6.08, 5.89, 9.85, 8.68, 7.41, 6.51, 5.41, 9.88, 8.35, 9.86, 8.81, 8.86, 5.38, 6.78, 6.06];    %机器的基础加工功率，共有5个Level
idlePower = [0.96, 1.65, 2.98, 3.61, 1.98, 4.51, 0.77, 2.76, 2.50, 4.34, 4.69, 0.38, 0.90, 3.12, 2.70];   %机器的基础空闲功率，共有5个Level

%%%文件路径，win和mac保持一致
fileName = dir('Data_Set/*.txt');

for count = 1:length(fileName)
    
    %%%文件路径，win和mac保持一致
    [N, M, H, procTime] = Load_Data(['Data_Set/', fileName(count).name]);    %加载工件数，机器数，每个工件的工序数量，加工时间
    
    SH = sum(H);
    
    P = 100;    %种群大小
    G = 250;    %迭代次数
    
    CR = 1.0;   	%交叉概率
    MU = 0.2;   	%变异概率
    
    BETA = 20;       %聚类阈值参数
    SIGMA = 0.3;       %小生镜参数
    
    PS_Archive = [];     %存储PS
    PF_Archive = [];     %存储PF
    startEndTime_Archive = {};   %存储非支配解的工序开始加工时间和完工时间
    
    fprintf('**********%s: 第%d次独立运行**********\n', fileName(count).name(1:4), run);
    
    %%%混合初始化工序码、机器码、机器速度码
    schedSeq = Hybrid_Initialization(procTime);
    
    %%%计算最大完工时间和总能量消耗
    [objValue, startEndTime] = Calculate_Objective_Value(schedSeq, procTime, startupShutdownPower, procPower, idlePower);
    
    %%%迭代循环
    for gen = 1:G
        fprintf('第%d次迭代\n', gen);
        
        %%%采用竞标赛选择出P/2个个体，进行交叉、变异操作，产生大约P个个体
        schedSeqSel = Tournament_Selection(schedSeq, objValue);
        schedSeqOff = Genetic_Operation(schedSeqSel, procTime);
        [objValueOff, startEndTimeOff] = Calculate_Objective_Value(schedSeqOff, procTime, startupShutdownPower, procPower, idlePower);
        
        %%%合并父代和子代
        schedSeq = cat(1, schedSeq, schedSeqOff);
        objValue = cat(1, objValue, objValueOff);
        startEndTime = cat(2, startEndTime, startEndTimeOff);
        
        
        %%%采用基于层次选取的方法选用P/4个个体进行变邻域搜索
        [schedSeqSel, ~, ~] = Hierarchy_Environmental_Selection(schedSeq, objValue, startEndTime, procTime, startupShutdownPower, procPower, idlePower, 2);
        
        %%%局部搜索
        schedSeqOff = Local_Search(schedSeqSel, procTime, startupShutdownPower, procPower, idlePower);
        [objValueOff, startEndTimeOff] = Calculate_Objective_Value(schedSeqOff, procTime, startupShutdownPower, procPower, idlePower);
        
        %%%合并父代和子代
        schedSeq = cat(1, schedSeq, schedSeqOff);
        objValue = cat(1, objValue, objValueOff);
        startEndTime = cat(2, startEndTime, startEndTimeOff);
        
        
        %%%执行基于层次的环境选择策略
        [schedSeq, objValue, startEndTime] = Hierarchy_Environmental_Selection(schedSeq, objValue, startEndTime, procTime, startupShutdownPower, procPower, idlePower, 1);
        
        %%%找出非支配个体
        array = (1:size(objValue, 1))';
        nonIdx = Find_Nondominated_Solutions(objValue, array);
        nonSchedSeq = schedSeq(nonIdx, :);
        nonObjValue = objValue(nonIdx, :);
        nonStartEndTime = startEndTime(nonIdx);
        
        
        %%%更新档案集
        [PS_Archive, PF_Archive, startEndTime_Archive] = Update_Archive(nonSchedSeq, nonObjValue, nonStartEndTime, PS_Archive, PF_Archive, startEndTime_Archive);
        
    end
    
    
    %%%节能策略
    popSize = size(PF_Archive, 1);
    
    for i = 1:popSize
        %%%%%使用右移策略，在不增加最大完工时间的基础上减小总能量消耗
        startEndTime_ES = Energy_Saving_Strategy(PS_Archive(i, :), startEndTime_Archive{i});
        
        %%%更新总能量消耗
        PF_Update = Update_TEC(PS_Archive(i, :), startEndTime_ES, startupShutdownPower, procPower, idlePower);
        PF_Archive(i, 2) = min(PF_Archive(i, 2), PF_Update);
    end
    

    array = (1:popSize)';
    nonIdx = Find_Nondominated_Solutions(PF_Archive, array);
    PS_Archive = PS_Archive(nonIdx, :);
    PF_Archive = PF_Archive(nonIdx, :);
    resResult = cat(2, PS_Archive, PF_Archive);         %前一部分PS，后一部分PF
    
    %%%文件路径，win和mac保持一致
    dirName = ['Results/', fileName(count).name(1:4)];
    if ~exist(dirName, 'dir')
        mkdir(dirName);
    end
    if run < 10
        fn = [dirName, '/0', num2str(run), '.xlsx'];
    else
        fn = [dirName, '/', num2str(run), '.xlsx'];
    end
    %%%版本太老不建议使用，改用writematrix
    % xlswrite(fn, resResult);
    writematrix(resResult, fn);
    
end


end