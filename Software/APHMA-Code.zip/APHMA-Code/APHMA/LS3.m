function SchedSeqOff = LS3(p_chrom, m_chrom, s_chrom, criticalOperation, procTime)
%%%VNS3：随机选取关键路径上的一个最后完工工序，将其分配给最小加工时间机器

global N H SH;

s1 = p_chrom;
s2 = zeros(1, SH);
p = zeros(1, N);
for i = 1:SH
    p(s1(i)) = p(s1(i)) + 1;    %记录过程是否加工完成，完成一次加一
    s2(i) = p(s1(i));     %记录加工过程中，工件的次数
end

avlOpIdx = [];      %存储关键路径上最后完工工序的下标

for i = 1:length(criticalOperation)
    opIdx = criticalOperation(i);
    job = s1(opIdx);
    op = s2(opIdx);
    if H(job) == op
        avlOpIdx = cat(2, avlOpIdx, opIdx);
    end
end

opIdx = avlOpIdx(randi(length(avlOpIdx)));
machSet = procTime{s1(opIdx)}(s2(opIdx), :);
machSet(find(machSet == 0)) = Inf;
[~, avlMachSet] = min(machSet);
adjMachNo = avlMachSet(randi(length(avlMachSet)));

%%调整工序的机器号
m_chrom(sum(H(1:(s1(opIdx) - 1)))+ s2(opIdx)) = adjMachNo;

%%调整工序序列，否则调整机器号的工序会处于一个相对固定的位置
insPos = randi(SH);     %插入的位置
insOp = p_chrom(opIdx);   %插入的工序
p_chrom(opIdx) = [];
p_chrom = [p_chrom(1:insPos-1), insOp, p_chrom(insPos:end)];

SchedSeqOff = [p_chrom, m_chrom, s_chrom];


end