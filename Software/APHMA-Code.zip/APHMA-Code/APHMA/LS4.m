function SchedSeqOff = LS4(p_chrom, m_chrom, s_chrom, criticalOperation)
%%%LS4：随机选取非关键路径上的一个工序，降低其机器的加工速度

global N H SH;

s1 = p_chrom;
s2 = zeros(1, SH);
p = zeros(1, N);
for i = 1:SH
    p(s1(i)) = p(s1(i)) + 1;    %记录过程是否加工完成，完成一次加一
    s2(i) = p(s1(i));     %记录加工过程中，工件的次数
end

noncriticalOp= 1:SH;    %存储非关键工序
noncriticalOp(criticalOperation) = [];
idx = noncriticalOp(randi(length(noncriticalOp)));      %选取工序索引

machSpd = s_chrom(sum(H(1:(s1(idx) - 1)))+ s2(idx));    %加工机器的加工速度
if machSpd ~= 1
    adjMachSpd = randi(machSpd - 1);
    %%降低加工机器的加工速度
    s_chrom(sum(H(1:(s1(idx) - 1)))+ s2(idx)) = adjMachSpd;
end

SchedSeqOff = [p_chrom, m_chrom, s_chrom];


end