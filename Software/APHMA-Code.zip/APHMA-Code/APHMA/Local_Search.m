function SchedSeqOff = Local_Search(SchedSeqSel, procTime, startupShutdownPower, procPower, idlePower)
global N P SH;

SchedSeqOff = [];
OS = SchedSeqSel(:, 1:SH);
MS = SchedSeqSel(:, SH+1:2*SH);
SS = SchedSeqSel(:, 2*SH+1:3*SH);

for i = 1:P/4
    p_chrom = OS(i, :);
    m_chrom = MS(i, :);
    s_chrom = SS(i, :);

    %%%找出关键工序、关键路径块和关键路径
    [criticalOperation, criticalPathBlock, criticalPath] = Find_Critical_Path(p_chrom, m_chrom, s_chrom, procTime);

    % s1 = p_chrom;
    % s2 = zeros(1, SH);
    % p = zeros(1, N);
    % for i = 1:SH
    %     p(s1(i)) = p(s1(i)) + 1;    %记录过程是否加工完成，完成一次加一
    %     s2(i) = p(s1(i));     %记录加工过程中，工件的次数
    % end
    
    
    %%%LS1：随机选取处于多条关键路径上的工序，将其随机插入到候选机器集中；若不存在这样的工序，则随机选取关键路径
    SchedSeqOff1 = LS1(p_chrom, m_chrom, s_chrom, criticalOperation, criticalPath, procTime);
    SchedSeqOff = cat(1, SchedSeqOff, SchedSeqOff1);
    
    
    %%%LS2：采用N8邻域结构
    SchedSeqOff2 = LS2(p_chrom, m_chrom, s_chrom, criticalPathBlock);
    SchedSeqOff = cat(1, SchedSeqOff, SchedSeqOff2);
    
    
    %%%LS3：随机选取关键路径上的一个最后完工工序，将其分配给最小加工时间机器
    SchedSeqOff3 = LS3(p_chrom, m_chrom, s_chrom, criticalOperation, procTime);
    SchedSeqOff = cat(1, SchedSeqOff, SchedSeqOff3);
    
    
    %%%LS4：随机选取非关键路径上的一个工序，降低其机器的加工速度
    SchedSeqOff4 = LS4(p_chrom, m_chrom, s_chrom, criticalOperation);
    SchedSeqOff = cat(1, SchedSeqOff, SchedSeqOff4);

end


end