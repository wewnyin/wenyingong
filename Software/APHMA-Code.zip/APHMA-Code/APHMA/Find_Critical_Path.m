function [criticalOperation, criticalPathBlock, criticalPath] = Find_Critical_Path(p_chrom, m_chrom, s_chrom, procTime)

global N H SH;

%将工序码构建成有向图的结构，有向图中包含节点集，即所有工序
%包含边集，即两个节点之间是否含有有向边
%每个节点包含一个加工时间。每个工件的第一个工序作为开始节点的下一个节点。最多只有N个路径，N为工件个数。每个工序的最后一个工序作为结束节点的上一个工序。
%由于柔性车间调度的特殊性，导致有向图中每个节点只有两条出度两条入度。即当前工件的下一个工序，和当前机器的下一个工序。
%在这个有向图中求出，从开始节点到结束节点的最大完工时间的关键路径。
%采用的数据结构为数组加链表。数据用来存储每个工序的下标。每个数据元素后第一个元素为当前工件工序的下一个工序，第二个元素为当前机器工序的下一个工序。
%这两个元素都采用双向链表连接在数据的元素后面。实际为SH*4的矩阵。
%遍历每个工件的第一个工序，从第一个工序开始，广度遍历第二列求出一条路径，再深度遍历第三列求出一条路径。每条路径的结束标准都是，最后工序的下一列的值为0.


%%%每一列分布表示：当前工件工序下一个工序的索引，当前工序所在机器的下一个工序索引，当前工序工件的上一个工序的索引，当前工序所在机器的上一个工序的索引
directedGraph = zeros(SH, 4);    %由于矩阵自身的行号本身就可以表示索引值，所以省略一列
dflag = zeros(SH, 4);  %用于标记该点是否找到

%%%先完成解码标记每个工序的工件和工序号
s1 = p_chrom;
s2 = zeros(1, SH);
p = zeros(1, N);
    
for i = 1:SH
    p(s1(i)) = p(s1(i)) + 1;    %记录过程是否加工完成，完成一次加一
    s2(i) = p(s1(i));     %记录加工过程中，工件的次数
end
    
for i = 1:SH
    t1 = s1(i);   %记录到当前是哪个工件
    t2 = s2(i);   %记录当前工件是加工到第几次
    mm(i) = m_chrom(sum(H(1:t1-1)) + t2);   %提取该工序该次加工的机器选择，因为机器码的排列表示该工件第几次加工所选的机器，是一段表示一个工件
    ss(i) = s_chrom(sum(H(1:t1-1)) + t2);   %提取该工序该次加工的机器速度选择
end

%%%构建有向图
for i = 1:SH
    to = s1(i);
    tm = mm(i);
    for j= i+1:SH
        %%%找当前工件工序的下一个工序
        if to == s1(j) && dflag(i, 1) == 0
            directedGraph(i, 1)=j;
            dflag(i, 1) = 1;    %下指针已经找到
            directedGraph(j, 3) = i;
            dflag(j, 3) = 1;    %上指针已经找到
        end
        %%%找当前机器工序的下一个工序
        if tm == mm(j) && dflag(i, 2) == 0
            directedGraph(i, 2) = j;
            dflag(i, 2) = 1;
            directedGraph(j, 4) = i;
            dflag(j, 4) = 1;
        end
        
        %%%全部都找完跳出当前循环，或者如果当前工序当前工件的是最后一个工序
        if (dflag(i, 1) == 1 || s2(i) == H(s1(i))) && dflag(i,2) == 1
            break;
        end
           
    end
end

VELTime = cell(SH, 2);     %每个工序的最早开始时间和最晚开始时间
e = 0;



%%%采用广度遍历更新每个顶点的最早开始时间和最晚开始时间,如果不采用广度优先遍历，则会在更新后续层的时候，出现前序结点来不及计算，而导致计算错误。
%%%广度优先遍历的顺序是，先算所有工件的第一个工序，再是所有工件的第二个工序。
level = zeros(1, SH);
len = 1;
L = 1;
while len <= SH
    for i = 1:SH
        if s2(i) == L
            level(len) = i;
            len = len + 1;
        end
    end
    L = L + 1;
end


%%%计算最早开始时间
LastNode = e;
for i = 1:SH
    Index = level(i);
%     VELTime{Index, 1} = e;      %VELTime{Index,2}=e; 
    t1 = e;
    t2 = e;
    if directedGraph(Index, 3) ~= 0
        last = directedGraph(Index, 3);
        t1 = procTime{s1(last)}(s2(last), mm(last)) / ss(last) + VELTime{last, 1};
    end
       
    if directedGraph(Index, 4) ~= 0
        last = directedGraph(Index, 4);
        if isempty(VELTime{last, 1})     
            VELTime{last, 1} = CalculateLastOperation(s1, s2, mm, ss, directedGraph, last, VELTime, procTime);
        end
        t2 = procTime{s1(last)}(s2(last), mm(last)) / ss(last) + VELTime{last, 1};
    end
    
    if t1 > t2       %如果t1大于t2则
        VELTime{Index, 1} = t1;
    else
        VELTime{Index, 1} = t2;
    end
       
    %%%如果是工件的最后一个工序则说明下一个节点是LastNode虚拟结束节点, 则虚拟节点的上一个节点是所有工件的最后一个工序
    if directedGraph(Index, 1) == 0 
        t1 = procTime{s1(Index)}(s2(Index), mm(Index)) / ss(Index) + VELTime{Index, 1};%选最大的作为最后的虚拟节点
        if t1 > LastNode
            LastNode = t1;
        end
    end
    
end


%%%计算最晚开始时间
for i = SH:-1:1
    Index = level(i); 
%     if digraph(Index, 1) == 0 && digraph(Index, 2) == 0     %该工件既没有后续工序，所在机器上又没有后续机器
%         VELTime{Index, 2} = LastNode - procTime{s1(Index)}(s2(Index), mm(Index)) / ss(Index); %最后一个拓扑有序的结点的工序的最晚开始时间等于最早开始时间
%         continue;
%     end
% 
%     VELTime{Index, 2} = LastNode - procTime{s1(Index)}(s2(Index), mm(Index)) / ss(Index); %最后一个拓扑有序的结点的工序的最晚开始时间等于最早开始时间
    t1 = LastNode - procTime{s1(Index)}(s2(Index), mm(Index)) / ss(Index);
    t2 = LastNode - procTime{s1(Index)}(s2(Index), mm(Index)) / ss(Index);
    
    if directedGraph(Index, 1) ~= 0
        next = directedGraph(Index, 1);
        t1 = VELTime{next, 2} - procTime{s1(Index)}(s2(Index), mm(Index)) / ss(Index);%下一个节点减当前这条边的时间，但是时间在节点上所有减当前节点是时间                       
    end
       
    if directedGraph(Index,2) ~= 0
        next = directedGraph(Index, 2);
        if isempty(VELTime{next, 2})
            VELTime{next, 2} = CalculateNextOperation(s1, s2, mm, ss, directedGraph, next, VELTime, procTime, LastNode);  
        end
        t2 = VELTime{next, 2} - procTime{s1(Index)}(s2(Index), mm(Index)) / ss(Index); 
    end
        
    if t1 > t2      %选最小的
        VELTime{Index, 2} = t2;
    else
        VELTime{Index, 2} = t1;
    end

end


%%%用最晚开始时间减最早开始时间，剩余时间最小的结点，则为关键路径上的结点。
idleTime = cell(SH, 1);
for i = 1:SH
    idleTime{i, 1} = VELTime{i, 2} - VELTime{i, 1};
    if idleTime{i, 1} < 1e-5    %Matlab的浮点数运算会造成精度损失
        idleTime{i, 1} = 0;
    end
end


%%%找到松弛时间最小的工序则为关键路径上的工序
criticalOperation = find(cell2mat(idleTime) == 0)';



%%%寻找关键路径块
len = length(criticalOperation);
block = 1;
% criticalPathBlock = {};
criticalPathBlock{block} = criticalOperation(1);
machCmp = mm(criticalOperation(1));
for i = 2:len
    mach = mm(criticalOperation(i));
    if machCmp == mach
        %对于关键工序来说，在同一机器上的工序必定相邻，构成关键路径块
        criticalPathBlock{block} = cat(2, criticalPathBlock{block}, criticalOperation(i));
    else
        block = block + 1;
        criticalPathBlock{block} = criticalOperation(i);
        machCmp = mm(criticalOperation(i));
    end
end



%%%构造邻接矩阵，寻找所有的关键路径
%%第一行为起始节点，第2-（length(criticalOperation)+1）为所有的关键工序，最后一行为终止节点
adjMat = zeros(len + 2, len + 2);
startNode = [];     %存放起始节点所连接的工序
for i = 1:len
    opIdx = criticalOperation(i);
    
    if directedGraph(opIdx, 1) ~= 0
        %存在后置工序，更新邻接表，第一行为起始节点所以需要加1
        idx = find(criticalOperation == directedGraph(opIdx, 1));
        adjMat(i + 1, idx + 1) = procTime{s1(opIdx)}(s2(opIdx), mm(opIdx)) / ss(opIdx);
    end
    
    if directedGraph(opIdx, 2) ~= 0
        %机器上存在后置工序，更新邻接表，第一行为起始节点所以需要加1
        idx = find(criticalOperation == directedGraph(opIdx, 2));
        adjMat(i + 1, idx + 1) = procTime{s1(opIdx)}(s2(opIdx), mm(opIdx)) / ss(opIdx);
    end
    
    if directedGraph(opIdx, 1) == 0 && directedGraph(opIdx, 2) == 0
        %没有后置工序且该机器上没有后置工序，后面直接连接终止节点，第一行为起始节点所以需要加1
        adjMat(i + 1, end) = procTime{s1(opIdx)}(s2(opIdx), mm(opIdx)) / ss(opIdx);
    end
    
    if directedGraph(opIdx, 3) == 0 && directedGraph(opIdx, 4) == 0
        %没有前置工序且该机器上没有前置工序，前面直接连着起始节点，第一行为起始节点所以需要加1
        startNode = cat(2, startNode, i + 1);
    end
    
end

%更新邻接表的第一行，起始节点到第一个工序的权重值为1
adjMat(1, startNode) = 1;

% 找出起始节点到终止节点之间的所有路径
G = digraph(adjMat);
allPaths = Find_All_Paths(G, 1, size(adjMat, 1));
criticalPath = {};
for i = 1:length(allPaths)
    %%筛选出关键路径，关键路径的长度为LastNode + 1
    criticalLen = 0;
    for j = 1:(length(allPaths{i}) - 1)
        criticalLen = criticalLen + adjMat(allPaths{i}(j), allPaths{i}(j + 1));
        if abs(criticalLen - LastNode - 1) < 1e-5    %Matlab的浮点数运算会造成精度损失
            %%删除起始节点和终止节点，整体再减1映射到criticalOperation中
            array = allPaths{i};
            array(1) = [];
            array(end) = [];
            array = array - 1;
            criticalPath = cat(1, criticalPath, criticalOperation(array));
        end
    end
end


end