function [schedSeqElite, objValueElite, startEndTimeElite] = Hierarchy_Environmental_Selection(schedSeq, objValue, startEndTime, procTime, startupShutdownPower, procPower, idlePower, judge)
%%%保留第一层的PF（全局PS）
%%%基于RF的AP聚类，选出聚类后解个数大于BETA的类别，保留PF（局部PS）
%%%删除全局PS和局部PS中，其决策空间小于SIGMA的解
%%%不断循环直到满足条件

global N M H P SH BETA SIGMA;

schedSeqElite = [];
objValueElite = [];
startEndTimeElite = [];

if judge == 1
    popSize = P;
else
    popSize = P / 4;
end

while size(schedSeqElite, 1) < popSize && ~isempty(schedSeq)
    len = size(schedSeq, 1);
    resIdx = [];        %需要保留的全局PS和局部PS的索引
    delIdx = [];        %需要删除的个体索引
    
    %%%保留第一层的PF（全局PS）
    array = (1:size(objValue, 1))';
    nonIdx = Find_Nondominated_Solutions(objValue, array);
    resIdx = cat(1, resIdx, nonIdx);
    
    %%%基于RF的AP聚类，选出聚类后解个数大于BETA的类别，保留PF（局部PS）
    [exemplar, exemplarBelong, decisionSpace] = RF_AP_Clustering(schedSeq, objValue);
    for i = 1:length(exemplar)
        idx = find(exemplarBelong == exemplar(i));
        if length(idx) < BETA
            continue;
        else
            nonIdx = Find_Nondominated_Solutions(objValue(idx, :), idx);
            resIdx = cat(1, resIdx, nonIdx);
        end
    end
    resIdx = unique(resIdx);
    
    %%%删除离全局PS和局部PS距离小于SIGMA的个体
    for i = 1:length(resIdx)
        for j = 1:len
            if i ~= j && pdist2(decisionSpace(resIdx(i), :), decisionSpace(j, :), 'euclidean') < SIGMA
                delIdx = cat(1, delIdx, j);
            end
        end
    end
    
    %%%保留精英解
    if size(schedSeqElite, 1) + length(resIdx) <= popSize
        schedSeqElite = cat(1, schedSeqElite, schedSeq(resIdx, :));
        objValueElite = cat(1, objValueElite, objValue(resIdx, :));
        startEndTimeElite = cat(2, startEndTimeElite, startEndTime(resIdx));
    else
        resNum = popSize - size(schedSeqElite, 1);
        resIdx = resIdx(randperm(numel(resIdx), resNum));
        schedSeqElite = cat(1, schedSeqElite, schedSeq(resIdx, :));
        objValueElite = cat(1, objValueElite, objValue(resIdx, :));
        startEndTimeElite = cat(2, startEndTimeElite, startEndTime(resIdx));
        break;
    end
    
    %%%更新种群
    delIdx = cat(1, delIdx, resIdx);
    delIdx = unique(delIdx);
    schedSeq(delIdx, :) = [];
    objValue(delIdx, :) = [];
    startEndTime(delIdx) = [];
    
end



%%%如果选取出的精英种群个数小于popSize，则用初始化策略补充
%%%以下是初始化策略代码
if size(schedSeqElite, 1) < popSize
    num = popSize - size(schedSeqElite, 1);
    schedSeqSply = [];
    
    %%%OS的基础序列按照1 1 1 2 2 3 3...排列，后续通过打乱这个初始序列来生成种群
    basicSeq = [];
    
    for i = 1:N
        seq = ones(1, H(i)) * i;
        basicSeq = cat(2, basicSeq, seq);
    end
    
    %%%随机初始化工序码、机器速度码和机器码
    for i = 1:num
        
        %随机初始化工序码
        index = randperm(SH);
        OS = basicSeq(index);
        
        %随机初始化机器速度码，速度等级为1-5
        SS = round(rand(1, SH) * 4 + 1);
        
        %%%机器码初始化遵循以下5个准则: 最小机器负载准则(0.15), 最早可用机器准则(0.15)，
        %%%最小加工时间准则(0.15)，降低机器速度准则(0.15)，随机初始化准则(0.4)
        MS = zeros(1, SH);   %机器码
        s1 = OS;
        s2 = zeros(1, SH);
        p = zeros(1, N);
        for j = 1:SH
            p(s1(j)) = p(s1(j)) + 1;    %记录过程是否加工完成，完成一次加一
            s2(j) = p(s1(j));     %记录加工过程中，工件的次数
        end
        
        probability = rand;
        
        if probability <= 0.15  %选择最小负载的机器，若机器不止一个则从中随机选取
            machWorkload = zeros(1, M);  %存储各个机器的机器负载
            for j = 1:SH
                job = s1(j);     %待加工工件
                avlMach = find(procTime{job}(s2(j), :) > 0);   %可用机器号
                
                machOpts = Inf(1, M);
                machOpts(avlMach) = machWorkload(avlMach);   %可供选择的机器集，根据总机器负载选择，inf表示不可选
                machSel = find(machOpts == min(machOpts));     %可选机器集
                machNum = machSel(randperm(length(machSel), 1));  %选出机器(可能会出现多个最小值的情况)
                
                MS(sum(H(1:job - 1)) + s2(j)) = machNum;       %将机器号加入机器码
                machWorkload(machNum) = machWorkload(machNum) + procTime{job}(s2(j), machNum) / SS(sum(H(1:job - 1)) + s2(j));   %更新机器负载，加工时间为标准加工时间/机器速度
            end
            
        elseif probability <= 0.3  %选择最早可用机器，若机器不止一个则从中随机选取
            machAvlTm = zeros(1, M);      %存储各个机器的最早可用时间
            opCpltTm = zeros(1, N);     %存储前一个工序的完工时间
            for j = 1:SH
                job = s1(j);     %待加工工件
                avlMach = find(procTime{job}(s2(j), :) > 0);   %可用机器号
                
                machOpts = Inf(1, M);
                machOpts(avlMach) = machAvlTm(avlMach);   %可供选择的机器集，根据总机器负载选择，inf表示不可选
                machSel = find(machOpts == min(machOpts));     %可选机器集
                machNum = machSel(randperm(length(machSel), 1));  %选出机器(可能会出现多个最小值的情况)
                
                MS(sum(H(1:job - 1)) + s2(j)) = machNum;       %将机器号加入机器码
                machAvlTm(machNum) = max(machAvlTm(machNum), opCpltTm(job)) + procTime{job}(s2(j), machNum) / SS(sum(H(1:job - 1)) + s2(j));   %更新机器最早可用时间，加工时间为标准加工时间/机器速度
                opCpltTm(job) = machAvlTm(machNum);     %更新前一个工序的完工时间
            end
            
        elseif probability <= 0.45  %选择标准加工时间最小的机器，若机器不止一个则从中随机选取
            
            for j = 1:SH
                job = s1(j);     %待加工工件
                avlMach = find(procTime{job}(s2(j), :) > 0);   %可用机器号
                
                machOpts = Inf(1, M);
                machOpts(avlMach) = procTime{job}(s2(j), avlMach);   %可供选择的机器集，根据加工时间选择，inf表示不可选
                machSel = find(machOpts == min(machOpts));     %可选机器集
                machNum = machSel(randperm(length(machSel), 1));  %选出机器
                
                MS(sum(H(1:job - 1)) + s2(j)) = machNum;       %将机器号加入机器码
            end
            
        elseif probability <= 0.6   %机器随机选择，降低一档机器的加工速度，若机器加工速度为1则保持不变
            
            for j = 1:SH
                job = s1(j);     %待加工工件
                avlMach = find(procTime{job}(s2(j), :) > 0);   %可用机器号
                
                machNum = avlMach(randperm(length(avlMach), 1));  %选出机器
                
                MS(sum(H(1:job - 1)) + s2(j)) = machNum;       %将机器号加入机器码
                
                if SS(sum(H(1:job - 1)) + s2(j)) > 1     %机器速度降低一个level
                    SS(sum(H(1:job - 1)) + s2(j)) = SS(sum(H(1:job - 1)) + s2(j)) - 1;
                end
            end
            
        else
            
            for j = 1:SH
                job = s1(j);     %待加工工件
                avlMach = find(procTime{job}(s2(j), :) > 0);   %可用机器号
                
                machNum = avlMach(randperm(length(avlMach), 1));  %选出机器
                
                MS(sum(H(1:job - 1)) + s2(j)) = machNum;       %将机器号加入机器码
            end
            
        end
        
        schedSeqSply = cat(1, schedSeqSply, [OS, MS, SS]);
        
    end
    [objValueSply, startEndTimeSply] = Calculate_Objective_Value(schedSeqSply, procTime, startupShutdownPower, procPower, idlePower);
    schedSeqElite = cat(1, schedSeqElite, schedSeqSply);
    objValueElite = cat(1, objValueElite, objValueSply);
    startEndTimeElite = cat(2, startEndTimeElite, startEndTimeSply);
end


end