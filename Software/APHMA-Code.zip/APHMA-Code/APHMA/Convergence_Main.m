clc;
clear;
tic;

global N M H SH P G CR MU BETA SIGMA;

%%%数据中最多有15台机器
% startupShutdownPower = [85.84, 88.63, 80.31, 99.68, 83.34, 82.12, 87.45, 83.96, 89.79, 86.79, 99.03, 98.41, 81.05, 94.76, 85.38]; %机器开机/关机功率
% procPower = [31.21, 49.06, 57.00;
%                    35.90, 48.80, 56.39;
%                    32.26, 48.18, 50.34;
%                    33.85, 42.61, 50.69;
%                    35.83, 45.94, 53.20;
%                    32.52, 40.23, 55.31;
%                    32.90, 44.25, 56.54;
%                    36.17, 43.13, 54.08;
%                    32.65, 41.61, 58.20;
%                    38.24, 41.79, 57.18;
%                    39.83, 44.23, 59.69;
%                    37.30, 40.94, 55.31;
%                    33.44, 45.99, 53.25;
%                    35.84, 44.71, 51.06;
%                    31.08, 46.96, 56.11];    %机器的加工功率，共有3个Level
% idlePower = [6.76, 19.16, 26.07;
%              2.89, 10.01, 21.92;
%              6.72, 14.62, 27.38;
%              6.95, 14.24, 22.43;
%              1.68, 14.61, 29.17;
%              2.55, 17.70, 22.69;
%              2.24, 13.22, 27.66;
%              6.68, 17.85, 21.89;
%              8.44, 14.71, 22.87;
%              3.44, 10.36, 20.91;
%              7.81, 11.76, 25.76;
%              6.75, 17.22, 26.83;
%              5.67, 14.73, 27.47;
%              6.02, 11.53, 24.26;
%              3.87, 13.41, 26.66];   %机器的空闲功率，共有3个Level

% startupShutdownPower = [16.21, 18.11, 19.73, 15.90, 19.01, 16.05, 16.92, 19.19, 15.97, 16.61, 19.24, 16.18, 15.13, 18.61, 18.77]; %机器开机/关机功率
% procPower = [5.624, 6.374, 7.573, 8.630, 9.493;
%              5.611, 6.503, 7.245, 8.741, 9.629;
%              5.573, 6.545, 7.920, 8.162, 9.272;
%              5.562, 6.415, 7.062, 8.809, 9.665;
%              5.164, 6.076, 7.518, 8.108, 9.825;
%              5.747, 6.169, 7.003, 8.278, 9.470;
%              5.311, 6.407, 7.464, 8.562, 9.449;
%              5.510, 6.963, 7.565, 8.672, 9.630;
%              5.705, 6.273, 7.069, 8.231, 9.446;
%              5.226, 6.455, 7.236, 8.513, 9.795;
%              5.017, 6.230, 7.400, 8.930, 9.960;
%              5.200, 6.452, 7.609, 8.487, 9.320;
%              5.219, 6.795, 7.897, 8.448, 9.453;
%              5.055, 6.153, 7.710, 8.065, 9.288;
%              5.363, 6.267, 7.252, 8.365, 9.181];    %机器的加工功率，共有5个Level
% idlePower = [0.665, 1.546, 2.353, 3.964, 4.774;
%              0.527, 1.483, 2.281, 3.527, 4.565;
%              0.390, 1.492, 2.565, 3.667, 4.208;
%              0.460, 1.429, 2.551, 3.108, 4.930;
%              0.356, 1.947, 2.305, 3.775, 4.684;
%              0.554, 1.153, 2.358, 3.063, 4.409;
%              0.229, 1.378, 2.939, 3.944, 4.857;
%              0.432, 1.430, 2.999, 3.241, 4.701;
%              0.484, 1.500, 2.104, 3.948, 4.113;
%              0.121, 1.359, 2.954, 3.358, 4.084;
%              0.637, 1.721, 2.056, 3.619, 4.608;
%              0.932, 1.564, 2.438, 3.602, 4.313;
%              0.041, 1.280, 2.076, 3.222, 4.566;
%              0.432, 1.008, 2.963, 3.677, 4.998;
%              0.301, 1.047, 2.986, 3.928, 4.734];   %机器的空闲功率，共有5个Level

startupShutdownPower = [16.21, 18.11, 19.73, 15.90, 19.01, 16.05, 16.92, 19.19, 15.97, 16.61, 19.24, 16.18, 15.13, 18.61, 18.77]; %机器开机/关机功率
procPower = [6.08, 5.89, 9.85, 8.68, 7.41, 6.51, 5.41, 9.88, 8.35, 9.86, 8.81, 8.86, 5.38, 6.78, 6.06];    %机器的基础加工功率，共有5个Level
idlePower = [0.96, 1.65, 2.98, 3.61, 1.98, 4.51, 0.77, 2.76, 2.50, 4.34, 4.69, 0.38, 0.90, 3.12, 2.70];   %机器的基础空闲功率，共有5个Level


%%%文件路径，win和mac保持一致
fileName = 'Data_Set/Mk10.txt';
% fileName = 'Data_Set/DP03.txt';

[N, M, H, procTime] = Load_Data(fileName);    %加载工件数，机器数，每个工件的工序数量，加工时间
SH = sum(H);

P = 100;    %种群大小
G = 250;    %迭代次数

CR = 1.0;   	%交叉概率
MU = 0.2;   	%变异概率

BETA = 20;       %聚类阈值参数
SIGMA = 0.3;       %小生镜参数

PS_Archive = [];     %存储PS
PF_Archive = [];     %存储PF
startEndTime_Archive = {};   %存储非支配解的工序开始加工时间和完工时间

count = 0;      %记录点的个数

for run = 1:1        %独立运行run次

    %%%混合初始化工序码、机器码、机器速度码
    schedSeq = Hybrid_Initialization(procTime);

    %%%计算最大完工时间和总能量消耗
    [objValue, startEndTime] = Calculate_Objective_Value(schedSeq, procTime, startupShutdownPower, procPower, idlePower);


    %%%初始化之后迭代0次，需要保存初始化的结果
    array = (1:size(objValue, 1))';
    nonIdx = Find_Nondominated_Solutions(objValue, array);
    nonSchedSeq = schedSeq(nonIdx, :);
    nonObjValue = objValue(nonIdx, :);
    resResult = cat(2, nonSchedSeq, nonObjValue);         %前一部分PS，后一部分PF

    %%%文件路径，win和mac保持一致
    dirName = 'Convergence/';
    mkdir(dirName);
    fn = [dirName, '/0', num2str(count), '.xlsx'];
    writematrix(resResult, fn);
    count = count + 1;


    %%%迭代循环
    for gen = 1:G
        fprintf('第%d次迭代\n', gen);

        %%%采用竞标赛选择出P/2个个体，进行交叉、变异操作，产生大约P个个体
        schedSeqSel = Tournament_Selection(schedSeq, objValue);
        schedSeqOff = Genetic_Operation(schedSeqSel, procTime);
        [objValueOff, startEndTimeOff] = Calculate_Objective_Value(schedSeqOff, procTime, startupShutdownPower, procPower, idlePower);

        %%%合并父代和子代
        schedSeq = cat(1, schedSeq, schedSeqOff);
        objValue = cat(1, objValue, objValueOff);
        startEndTime = cat(2, startEndTime, startEndTimeOff);


        %%%采用基于层次选取的方法选用P/4个个体进行变邻域搜索
        [schedSeqSel, ~, ~] = Hierarchy_Environmental_Selection(schedSeq, objValue, startEndTime, procTime, startupShutdownPower, procPower, idlePower, 2);

        %%%局部搜索
        schedSeqOff = Local_Search(schedSeqSel, procTime, startupShutdownPower, procPower, idlePower);
        [objValueOff, startEndTimeOff] = Calculate_Objective_Value(schedSeqOff, procTime, startupShutdownPower, procPower, idlePower);

        %%%合并父代和子代
        schedSeq = cat(1, schedSeq, schedSeqOff);
        objValue = cat(1, objValue, objValueOff);
        startEndTime = cat(2, startEndTime, startEndTimeOff);


        %%%执行基于层次的环境选择策略
        [schedSeq, objValue, startEndTime] = Hierarchy_Environmental_Selection(schedSeq, objValue, startEndTime, procTime, startupShutdownPower, procPower, idlePower, 1);

        %%%找出非支配个体
        array = (1:size(objValue, 1))';
        nonIdx = Find_Nondominated_Solutions(objValue, array);
        nonSchedSeq = schedSeq(nonIdx, :);
        nonObjValue = objValue(nonIdx, :);
        nonStartEndTime = startEndTime(nonIdx);


        %%%更新档案集
        [PS_Archive, PF_Archive, startEndTime_Archive] = Update_Archive(nonSchedSeq, nonObjValue, nonStartEndTime, PS_Archive, PF_Archive, startEndTime_Archive);



        %%%保存收敛结果
        if mod(gen, 13) == 0
            resResult = cat(2, PS_Archive, PF_Archive);
            if count < 10
                fn = [dirName, '/0', num2str(count), '.xlsx'];
            else
                fn = [dirName, '/', num2str(count), '.xlsx'];
            end
            writematrix(resResult, fn);
            count = count + 1;
        end

    end



    %%%节能策略
    popSize = size(PF_Archive, 1);

    for i = 1:popSize
        %%%%%使用右移策略，在不增加最大完工时间的基础上减小总能量消耗
        startEndTime_ES = Energy_Saving_Strategy(PS_Archive(i, :), startEndTime_Archive{i});

        %%%更新总能量消耗
        PF_Update = Update_TEC(PS_Archive(i, :), startEndTime_ES, startupShutdownPower, procPower, idlePower);
        PF_Archive(i, 2) = min(PF_Archive(i, 2), PF_Update);
    end

    array = (1:popSize)';
    nonIdx = Find_Nondominated_Solutions(PF_Archive, array);
    PS_Archive = PS_Archive(nonIdx, :);
    PF_Archive = PF_Archive(nonIdx, :);
    resResult = cat(2, PS_Archive, PF_Archive);         %前一部分PS，后一部分PF

    fn = [dirName, '/', num2str(count), '.xlsx'];
    writematrix(resResult, fn);
    count = count + 1;

    toc

end




