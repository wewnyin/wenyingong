function [jobNum, machineNum, operationNum, processingTime] = Load_Data(filename)

%%%读取数据
fidin=fopen(filename);
x = fscanf(fidin,'%f');

%%%获取工件数量、机器数量、每个工件的工序数量
jobNum = x(1);
machineNum = x(2);
operationNum = [];

%%%存储加工时间,ProcessingTime{1}(i, j)表示工件1的第i道工序在第j台机器上的加工时间，0表示不可加工
processingTime = cell(jobNum, 1);

%%%处理数据
index = 4;      %开始读取数据的下标

for i = 1:jobNum
    operationNumber = x(index);    %工序数量
    index = index + 1;
    timeArray = zeros(operationNumber, machineNum);    %存储工件i的加工时间
    
    for j = 1:operationNumber
        processingMachineNum = x(index);    %处理工序Oij的机器数量，后续有k对数据
        index = index + 1;
        
        for k = 1:processingMachineNum
            machineIndex = x(index);    %加工机器的机器号
            index = index + 1;
            time = x(index);    %加工时间
            index = index + 1;
%             timeArray(j, machineIndex) = time;
            timeArray(j, machineIndex) = time * 5;  %加工时间翻5倍，因为实际加工时间为该时间除以机器速度，便于整除
        end
        
    end
    
    processingTime{i} = timeArray;
    operationNum = cat(1, operationNum, operationNumber);
    
end

end