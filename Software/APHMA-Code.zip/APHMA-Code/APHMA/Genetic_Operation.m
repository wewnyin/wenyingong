function SchedSeqOff = Genetic_Operation(SchedSeqSel, procTime)
%%%交叉操作：OS采用IPOX交叉算子，MS和SS采用MPX(Multi-point Crossover)交叉算子
%%%变异操作：OS和SS采用IM变异算子(Inversion Mutation)，MS采用MPM变异算子(Multi-point Mutation)

global N H SH MU CR;

%%%将调度序列进行拆分，拆分为OS+MS+SS
OS_Sel = SchedSeqSel(:, 1:SH);
MS_Sel = SchedSeqSel(:, SH+1:2*SH);
SS_Sel = SchedSeqSel(:, 2*SH+1:3*SH);
SchedSeqOff = [];
len = size(SchedSeqSel, 1);

%%%找出各个工序的可用机器
avlMach = {};
count = 1;
for i = 1:N
    for j = 1:H(i)
        machSet = find(procTime{i}(j, :) > 0);
        avlMach{count} = machSet;
        count = count + 1;
    end
end

%%%交叉操作，OS采用IPOX交叉算子；MS和SS采用MPX(Multi-point Crossover)交叉算子
for i = 1:len
    if rand < CR
        %%工序码采用IPOX交叉算子
        index1 = ceil(rand * len);
        index2 = ceil(rand * len);
        while index1 == index2
            index2 = ceil(rand * len);
        end
        OS1 = OS_Sel(index1, :);
        OS2 = OS_Sel(index2, :);
        
        set1 = randperm(N, ceil(rand * (N - 1)));       %o1保留的工件
        set2 = [];                     %o2保留的工件
        for j = 1:N
            if ~ismember(j, set1)
                set2 = cat(2, set2, j);
            end
        end
        
        OS1_off = zeros(1, SH);   %存储子代1
        OS2_off = zeros(1, SH);   %存储子代2
        
        %复制OS1包含在set1的工件到OS1_off，并保留它们的位置
        for j = 1:length(set1)
            index = find(OS1 == set1(j));
            OS1_off(index) = OS1(index);
        end
        
        %复制OS2包含在set2的工件到OS2_off，并保留它们的位置
        for j = 1:length(set2)
            index = find(OS2 == set2(j));
            OS2_off(index) = OS2(index);
        end
        
        %复制OS1包含在set1的工件到OS2_off，复制OS2包含在set2的工件到OS1_off，保留它们的顺序
        saveSeq1 = OS1_off(find(OS1_off > 0));
        saveSeq2 = OS2_off(find(OS2_off > 0));
        
        OS2_off(find(OS2_off == 0)) = saveSeq1;
        OS1_off(find(OS1_off == 0)) = saveSeq2;
        
        
        %%机器码采用MPX交叉算子
        MS1 = MS_Sel(index1, :);
        MS2 = MS_Sel(index2, :);
        exchange = round(rand(1, SH));
        index = find(exchange == 1);
        temp = MS1(index);
        MS1(index) = MS2(index);
        MS2(index) = temp;       
        
        
        %%机器速度码采用MPX交叉算子
        SS1 = SS_Sel(index1, :);
        SS2 = SS_Sel(index2, :);
        exchange = round(rand(1, SH));
        index = find(exchange == 1);
        temp = SS1(index);
        SS1(index) = SS2(index);
        SS2(index) = temp;
        
        
        %%%将生成的子代加入SchedSeqOff中
        SchedSeqOff = cat(1, SchedSeqOff, [OS1_off, MS1, SS1]);
        SchedSeqOff = cat(1, SchedSeqOff, [OS2_off, MS2, SS2]);

    end
    
end



%%%变异操作，OS采用IM变异算子(Inversion Mutation)，MS和SS采用MPM变异算子(Multi-point Mutation)
%%%选择交叉后的子代进行变异操作
OS_Sel = SchedSeqOff(:, 1:SH);
MS_Sel = SchedSeqOff(:, SH+1:2*SH);
SS_Sel = SchedSeqOff(:, 2*SH+1:3*SH);
len = size(SchedSeqOff, 1);
for i = 1:len
    if rand < MU      %进行变异操作
        %%工序码采用IM变异算子
        OS = OS_Sel(i, :);
        pos1 = ceil(rand * SH);
        pos2 = ceil(rand * SH);
        while pos1 == pos2
            pos2 = ceil(rand * SH);
        end
        minPos = min(pos1, pos2);
        maxPos = max(pos1, pos2);
        OS(minPos:maxPos) = flip(OS(minPos:maxPos));
        
        
        %%机器码采用MPM变异算子
        MS = MS_Sel(i, :);
        exgJdg = round(rand(1, SH));
        exgIdx = find(exgJdg == 1);
        for j = 1:length(exgIdx)
            machSetLen = length(avlMach{exgIdx(j)});
            if machSetLen > 1
                machine = avlMach{exgIdx(j)}(ceil(rand * machSetLen));
                while MS(exgIdx(j)) == machine
                    machine = avlMach{exgIdx(j)}(ceil(rand * machSetLen));     %确保一定变异!!!
                end
                MS(exgIdx(j)) = machine;
            end
        end
        
        
        %%机器速度码采用MPM变异算子
        SS = SS_Sel(i, :);
        exgJdg = round(rand(1, SH));
        exgIdx = find(exgJdg == 1);
        for j = 1:length(exgIdx)
            spd = ceil(rand * 5);    
            while SS(exgIdx(j)) == spd
                spd = ceil(rand * 5);     %确保一定变异!!!
            end
            SS(exgIdx(j)) = spd;
        end

        
        %%%将生成的子代加入SchedSeqOff中
        SchedSeqOff = cat(1, SchedSeqOff, [OS, MS, SS]);

    end
    
end


end