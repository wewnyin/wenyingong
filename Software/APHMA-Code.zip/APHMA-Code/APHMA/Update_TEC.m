function TEC = Update_TEC(PS, startEndTime, startupShutdownPower, procPower, idlePower)
%%%更新TEC，TEC可能会增加，因为空闲能耗与机器速度有关，右移之后会存在有些本没有空闲时间的工序产生空闲时间
%%%虽然总的空闲时间会减少，但右移后产生空闲时间的工序，其机器速度可能会增加，进而增加空闲能耗

global N M H SH;    

%%%将调度序列进行拆分，拆分为OS+MS+SS
p_chrom = PS(:, 1:SH);
m_chrom = PS(:, SH+1:2*SH);
s_chrom = PS(:, 2*SH+1:3*SH);

%%%先完成解码标记每个工序的工件和工序号
s1 = p_chrom;
s2 = zeros(1, SH);
p = zeros(1, N);
    
for i = 1:SH
    p(s1(i)) = p(s1(i)) + 1;    %记录过程是否加工完成，完成一次加一
    s2(i) = p(s1(i));     %记录加工过程中，工件的次数
end
    
for i = 1:SH
    t1 = s1(i);   %记录到当前是哪个工件
    t2 = s2(i);   %记录当前工件是加工到第几次
    mm(i) = m_chrom(sum(H(1:t1-1)) + t2);   %提取该工序该次加工的机器选择，因为机器码的排列表示该工件第几次加工所选的机器，是一段表示一个工件
    ss(i) = s_chrom(sum(H(1:t1-1)) + t2);   %提取该工序该次加工的机器速度选择
end

TEC = 0;
machAvlTime = zeros(1, M);     %机器最早可用时间

%%%更新机器最早可用时间
for i = 1:M
    index = find(mm == i);
    if ~isempty(index)
        job = s1(index(1));
        op = s2(index(1));
        machAvlTime(i) = startEndTime{job}(op, 1);
    end
end

for i = 1:SH
    job = s1(i);
    op = s2(i);
    mach = mm(i);
    spd = ss(i);
    
    time = startEndTime{job}(op, 2) - startEndTime{job}(op, 1);     %加工时间
    idleTime = startEndTime{job}(op, 1) - machAvlTime(mach);        %空闲时间
    machAvlTime(mach) = startEndTime{job}(op, 2);   %更新机器最早可用时间
    TEC = TEC + time * (spd + log(spd)) * procPower(mach);     %更新TEC
    TEC = TEC + idleTime * (spd + log(spd)) * idlePower(mach);   %更新TEC

end

%%%计算开机/关机功率，更新总能量消耗
for i = 1:M
    TEC = TEC + 2 * startupShutdownPower(i);        %（开机/关机一共2s）
end


end