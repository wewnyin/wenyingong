function value = CalculateNextOperation(s1, s2, mm, ss, digraph, next, VELTime, procTime, LastNode)

Index = next;
% l = LastNode - processingTime{s1(Index)}(s2(Index), mm(Index)) / ss(Index);
% t1 = l;     %t1,t2是什么值无所谓，后面都会被覆盖
% t2 = l;     %t1,t2是什么值无所谓，后面都会被覆盖

if digraph(Index, 1) == 0
    t1 = LastNode - procTime{s1(Index)}(s2(Index), mm(Index)) / ss(Index);
else
    znext = digraph(Index, 1);
    if isempty(VELTime{znext, 2})
        VELTime{znext, 2} = CalculateNextOperation(s1, s2, mm, ss, digraph, znext, VELTime, procTime, LastNode);
    end
    t1 = VELTime{znext, 2} - procTime{s1(Index)}(s2(Index), mm(Index)) / ss(Index);
end
    

if digraph(Index, 2) == 0
    t2 = LastNode - procTime{s1(Index)}(s2(Index), mm(Index)) / ss(Index);
else
    znext = digraph(Index, 2);
    if isempty(VELTime{znext, 2})
        VELTime{znext, 2} = CalculateNextOperation(s1, s2, mm, ss, digraph, znext, VELTime, procTime, LastNode);
    end
    t2 = VELTime{znext, 2} - procTime{s1(Index)}(s2(Index), mm(Index)) / ss(Index);
end

if t1 > t2   %如果t1大于t2则
    VELTime{Index, 2} = t2;
else
    VELTime{Index, 2} = t1;
end
value = VELTime{Index, 2}; 

end
