# coding:utf-8
#f= open("../DATASET/J10M5O5.txt", "r",encoding='utf-8')
import numpy as np
import sys

def DataReadDHHJSP(Filepath):
    data = []
    enter='\n'
    # for example "../DATASET/J10M5O5.txt"
    with open(Filepath, "r",encoding='utf-8') as f1:
        for line in f1:
            temp=line.split(' ');
            l=len(temp)
            for i in range(l):
                if temp[i] != enter:
                    data.append(int(temp[i]))
    N=data[0]
    TS=data[1]
    F=data[2]
    NS = np.zeros(TS, dtype=int)
    p=3
    for s in range(TS):
        NS[s] = data[p];
        p = p + 1;
    p = p + 1;
    time = np.zeros(shape=(F, TS, N))
    for f in range(F):
        for s in range(TS):
            for i in range(N):
                time[f][s][i]=data[p]
                p = p + 1;
        p = p + 1;

    p = p - 1;
    JP = np.zeros(N, dtype=int)
    JDD = np.zeros(N)
    for i in range(N):
        JP[i] = data[p];
        p = p + 1;

    for i in range(N):
        JDD[i] = data[p];
        p = p + 1;
    f1.close()

    return N,TS,F,NS,time,JP,JDD
'''
data = f.read()
N=int(data[1])
TM=int(data[3])
H=np.zeros(1,N)
print(N)
print(TM)'''
