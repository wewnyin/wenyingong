# coding:utf-8
import numpy as np

def mymin(arr):
    index=[]
    l=len(arr)
    if l>1:
        minvalue=min(arr)
        for i in range(l):
            if arr[i]==minvalue:
                index.append(i)
    else:
        index.append(0)
    return index

def mylistRound(arr):
    l=len(arr)
    for i in range(l):
        arr[i]=round(arr[i])
    return arr

def find_all_index(arr, item):
    return [i for i, a in enumerate(arr) if a == item]

def find_all_index_not(arr, item):
    l=len(arr)
    flag=np.zeros(l)
    index=find_all_index(arr,item)
    flag[index]=1
    not_index=find_all_index(flag,0)
    return not_index

def NDS(fit1,fit2):
    v=0
    dom_less = 0;
    dom_equal = 0;
    dom_more = 0;
    for k in range(2):
        if fit1[k] > fit2[k]:
            dom_more = dom_more + 1;
        elif fit1[k] == fit2[k]:
            dom_equal = dom_equal + 1;
        else:
            dom_less = dom_less + 1;

    if dom_less == 0 and dom_equal != 2:
        v = 2
    if dom_more == 0 and dom_equal != 2:
        v = 1
    return v

def Ismemeber(item,list):
    l=len(list)
    flag=0
    for i in range(l):
        if list[i]==item:
            flag=1
            break
    return flag

def DeleteReapt(QP,QF,QFit,ps):
    row=np.size(QFit,0)
    i=0
    while i<row:
        if i>=row:
            #print('break 1')
            break

        F=QFit[i,:]
        j=i+1
        while j<row:
            if QFit[j][0]==F[0] and QFit[j][1]==F[1]:
                QP = np.delete(QP, j, axis=0)
                QF = np.delete(QF, j, axis=0)
                QFit = np.delete(QFit, j, axis=0)
                j=j-1
                row=row-1
                if row<2*ps+1:
                    break
            j=j+1
        i=i+1
        if row < 2 * ps + 1:
            #print('break 2')
            break
    return QP,QF,QFit

def DeleteReaptE(QP,QF,QFit): #for elite strategy
    row=np.size(QFit,0)
    i=0
    while i<row:
        if i>=row:
            #print('break 1')
            break

        F=QFit[i,:]
        j=i+1
        while j<row:
            if QFit[j][0]==F[0] and QFit[j][1]==F[1]:
                QP = np.delete(QP, j, axis=0)
                QF = np.delete(QF, j, axis=0)
                QFit = np.delete(QFit, j, axis=0)
                j=j-1
                row=row-1
            j=j+1
        i=i+1

    return QP,QF,QFit

def DeleteReaptACOMOEAD(QP,QF,QFit,QT): #for elite strategy
    row=np.size(QFit,0)
    i=0
    while i<row:
        if i>=row:
            #print('break 1')
            break

        F=QFit[i,:]
        j=i+1
        while j<row:
            if QFit[j][0]==F[0] and QFit[j][1]==F[1]:
                QP = np.delete(QP, j, axis=0)
                QF = np.delete(QF, j, axis=0)
                QFit = np.delete(QFit, j, axis=0)
                QT = np.delete(QT, j, axis=0)
                j=j-1
                row=row-1
            j=j+1
        i=i+1

    return QP,QF,QFit,QT

def DeleteReaptE2(QP,QF,QFit,Fnum): #for elite strategy
    row=np.size(QFit,0)
    i=0
    while i<row:
        if i>=row:
            #print('break 1')
            break

        F=QFit[i,:]
        j=i+1
        while j<row:
            if QFit[j][0]==F[0] and QFit[j][1]==F[1]:
                QP = np.delete(QP, j, axis=0)
                QF = np.delete(QF, j, axis=0)
                QFit = np.delete(QFit, j, axis=0)
                j=j-1
                row=row-1
            f_num = np.zeros(Fnum, dtype=int);
            for f in range(Fnum):
                f_num[f] = len(find_all_index(QF[j,:], f));
            for f in range(Fnum):
                if f_num[f] == 0:
                    QP = np.delete(QP, j, axis=0)
                    QF = np.delete(QF, j, axis=0)
                    QFit = np.delete(QFit, j, axis=0)
                    j = j - 1
                    row = row - 1
            j=j+1
        i=i+1

    return QP,QF,QFit

def pareto(fitness):
    PF=[]
    L=np.size(fitness,axis=0)
    pn=np.zeros(L,dtype=int)
    for i in range(L):
        for j in range(L):
            dom_less = 0;
            dom_equal = 0;
            dom_more = 0;
            for k in range(2):#number of objectives
                if (fitness[i][k] > fitness[j][k]):
                    dom_more = dom_more + 1
                elif(fitness[i][k] == fitness[j][k]):
                    dom_equal = dom_equal + 1
                else:
                    dom_less = dom_less + 1

            if dom_less == 0 and dom_equal != 2: # i is dominated by j
                pn[i] = pn[i] + 1;
        if pn[i] == 0: # add i into pareto front
            PF.append(i)
    return PF