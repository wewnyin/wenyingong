# coding:utf-8
import numpy as np

import numpy as np
import math
import random
from Tool import *
import copy
from  FastNDSort import *
from CalFitness import *
def TSelection(p_chrom,f_chrom,fitness,ps,N):
    #mating selection pool
    pool_size=ps
    P_pool = np.zeros(shape=(ps, N), dtype=int)
    F_pool = np.zeros(shape=(ps, N), dtype=int) #fitness of pool solutions
    # compeitor number
    tour=2
    # tournament selection
    for i in range(pool_size):
        index1=int(math.floor(random.random()*ps))
        index2 = int(math.floor(random.random() * ps))
        while index1==index2:
            index2 = int(math.floor(random.random() * ps))
        f1=fitness[index1,0:2]
        f2=fitness[index2,0:2]
        if (NDS(f1, f2) == 1):
            P_pool[i,:]=p_chrom[index1,:]
            F_pool[i,:]=f_chrom[index1,:]
        elif(NDS(f1, f2) == 2):
            P_pool[i, :] = p_chrom[index2, :]
            F_pool[i, :] = f_chrom[index2, :]
        else:
            if random.random() <= 0.5:
                P_pool[i, :] = p_chrom[index1, :]
                F_pool[i, :] = f_chrom[index1, :]
            else:
                P_pool[i, :] = p_chrom[index2, :]
                F_pool[i, :] = f_chrom[index2, :]
    return P_pool,F_pool

def POX(P1,P2,N):
    #inital offerspring
    NP1=P1;
    NP2=P2;
    #index of each operation in P1 and P2
    ci1=np.zeros(N,dtype=int)
    ci2 = np.zeros(N, dtype=int)
    # store some jobs in J1
    temp=[random.random() for _ in range(N) ]
    temp=mylistRound(temp)
    J1=find_all_index(temp,1)#find the index where value equal to 1
    for j in range(N):
        if Ismemeber(P1[j], J1)==1: #if is in job set J
            ci1[j] = P1[j]+1

        if Ismemeber(P2[j], J1)==0: #if is not in job set J
            ci2[j] = P2[j]+1
    index_1_1 = find_all_index(ci1,0) # find the empty positions in ci1
    index_1_2 = find_all_index_not(ci2,0) # find the positions in ci2 which is not zero

    index_2_1 = find_all_index(ci2,0)
    index_2_2 = find_all_index_not(ci1,0)
    l1=len(index_1_1);l2=len(index_2_1)
    for j in range(l1):
        ci1[index_1_1[j]] = NP2[index_1_2[j]]
    for j in range(l2):
        ci2[index_2_1[j]] = NP1[index_2_2[j]]
    l1 = len(index_2_2);l2 = len(index_1_2)
    for j in range(l1):
        ci1[index_2_2[j]] = ci1[index_2_2[j]]-1
    for j in range(l2):
        ci2[index_1_2[j]] = ci2[index_1_2[j]] - 1
    NP1=ci1
    NP2 =ci2
    return NP1,NP2

def PMX(P1,P2,N):
    #partially matching crossover operator (PMX) 1985
    #inital offerspring
    pos1 = math.floor(N/2-N/4)
    pos2 = math.floor(N-pos1)
    pos2=int(pos2)
    L = min(pos1, pos2)
    U = max(pos1, pos2)
    np1 = np.zeros(N,dtype=int)
    np2 = np.zeros(N,dtype=int)
    part1 = P1[L:U]

    part2 = P2[L:U]
    np1 = copy.copy(P1)
    np2 = copy.copy(P2)
    np1[L:U]=copy.copy(part2)
    try:
        np2[L:U]=copy.copy(part1)
    except:
        print('something wrong')
    tot=sum(i for i in range(N))
    for j in range(N):
        if j<L or j>U-1:
            x=find_all_index(part2,np1[j])
            if len(x)!=0:
                np1[j]=part1[x]
                x = find_all_index(part2, np1[j])
                while len(x)!=0:
                    np1[j] = part1[x]
                    x = find_all_index(part2, np1[j])

            x2 = find_all_index(part1, np2[j])
            if len(x2) != 0:
                np2[j] = part2[x2]
                x2 = find_all_index(part1, np2[j])
                while len(x2) != 0:
                    np2[j] = part2[x2]
                    x2 = find_all_index(part1, np2[j])
    return np1,np2

def UX_F(F1,F2,N,F):
    nf1 = copy.copy(F1);nf2 = copy.copy(F2);
    #s = [random.random() for _ in range(N)]
    #s = mylistRound(s)
    for i in range(N):
        s=round(random.random()*1)
        if (s == 1):
            temp = copy.copy(nf1[i]);
            nf1[i] = copy.copy(nf2[i]);
            nf2[i] = copy.copy(temp);
    f_num = np.zeros(F,dtype=int);
    for f in range(F):
        f_num[f]= len(find_all_index(nf1, f));
    for f in range(F):
        if f_num[f]==0:
            FC = np.zeros(N, dtype=int)
            # generate operation sequence randomly
            for i in range(N):
                FC[i] = i % F
            tmp2 = copy.copy(FC)
            random.shuffle(tmp2)
            nf1 = copy.copy(tmp2)

    f_num = np.zeros(F, dtype=int);
    for f in range(F):
        f_num[f] = len(find_all_index(nf2, f));
    for f in range(F):
        if f_num[f] == 0:
            FC = np.zeros(N, dtype=int)
            # generate operation sequence randomly
            for i in range(N):
                FC[i] = i % F
            tmp2 = copy.copy(FC)
            random.shuffle(tmp2)
            nf2= copy.copy(tmp2)
    return nf1,nf2

def mutation_p(p_chrom,N):
    #swap for operation sequence as mutation operator
    SH=N
    p1=math.floor(random.random()*N)
    p2 = math.floor(random.random() * N)
    while p1==p2:
        p2 = math.floor(random.random() * N)
    t = copy.copy(p_chrom[p1])
    p_chrom[p1] = copy.copy(p_chrom[p2])
    p_chrom[p2] = copy.copy(t);


    return p_chrom

def mutation_f(f_chrom,N,F):
    #swap for operation sequence as mutation operator
    pos1=int(np.floor(random.random()*N))
    cf=f_chrom[pos1]
    f=math.floor(random.random()*F)
    while cf==f:
        f=np.floor(random.random()*F)
        f=int(f)
        f_chrom[pos1]=f
    f_num = np.zeros(F, dtype=int);
    for f in range(F):
        f_num[f] = len(find_all_index(f_chrom, f));
    for f in range(F):
        if f_num[f] == 0:
            FC = np.zeros(N, dtype=int)
            # generate operation sequence randomly
            for i in range(N):
                FC[i] = i % F
            tmp2 = FC
            random.shuffle(tmp2)
            f_chrom= copy.copy(tmp2)

    return f_chrom

def NSGA2(p_chrom,f_chrom,fitness,Pc,Pm,ps,N,time,F,TS,NS, JP,JDD):
    Pool_P, Pool_F = TSelection(p_chrom, f_chrom, fitness,ps,N);
    CP = [];CF = [];CFit = []
    for i in range(ps):
        if random.random() < Pc:
            index = math.floor(random.random() * ps)
            P1 = Pool_P[index, :]
            F1 = Pool_F[index, :]
            [np1, np2] = PMX(p_chrom[i, :], P1, N)
            [nf1, nf2] = UX_F(f_chrom[i, :], F1, N,F)
            if random.random() < Pm:
                np1 = mutation_p(np1,N)
                nf1 = mutation_f(nf1,N,F)
            if random.random() < Pm:
                np2 = mutation_p(np2, N)
                nf2 = mutation_f(nf2, N, F)
        f1=np.zeros(3);f2=np.zeros(3);
        f1[0],f1[1],f1[2] = FitDHHFSP(np1, nf1,N,time,F,TS,NS, JP, JDD)
        f2[0],f2[1],f2[2] = FitDHHFSP(np2, nf2,N,time,F,TS,NS, JP, JDD)
        if len(CP) == 0:
            CP.append(np1);CFit.append(f1);CF.append(nf1)
            CP = np.vstack((CP, np2));CFit = np.vstack((CFit, f2));CF=np.vstack((CF, nf2))
        else:
            CP = np.vstack((CP, np1));CP = np.vstack((CP, np2));
            CF = np.vstack((CF, nf1));CF = np.vstack((CF, nf2));
            CFit = np.vstack((CFit, f1));CFit = np.vstack((CFit, f2))
    QP = np.vstack((p_chrom, CP))
    QF = np.vstack((f_chrom, CF))
    QFit = np.vstack((fitness, CFit))
    QP,QF, QFit = DeleteReapt(QP,QF,QFit,ps)
    TopRank = FastNDS(QFit, ps)
    p_chrom = QP[TopRank, :];
    f_chrom = QF[TopRank, :];
    fitness = QFit[TopRank, :]

    return p_chrom,f_chrom,fitness

def NSGA2POX(p_chrom,f_chrom,fitness,Pc,Pm,ps,N,time,F,TS,NS, JP,JDD):
    Pool_P, Pool_F = TSelection(p_chrom, f_chrom, fitness,ps,N);
    CP = [];CF = [];CFit = []
    for i in range(ps):
        if random.random() < Pc:
            index = math.floor(random.random() * ps)
            P1 = Pool_P[index, :]
            F1 = Pool_F[index, :]
            [np1, np2] = POX(p_chrom[i, :], P1, N)
            [nf1, nf2] = UX_F(f_chrom[i, :], F1, N,F)
            if random.random() < Pm:
                np1 = mutation_p(np1,N)
                nf1 = mutation_f(nf1,N,F)
            if random.random() < Pm:
                np2 = mutation_p(np2, N)
                nf2 = mutation_f(nf2, N, F)
        f1=np.zeros(3);f2=np.zeros(3);
        f1[0],f1[1],f1[2] = FitDHHFSP(np1, nf1,N,time,F,TS,NS, JP, JDD)
        f2[0],f2[1],f2[2] = FitDHHFSP(np2, nf2,N,time,F,TS,NS, JP, JDD)
        if len(CP) == 0:
            CP.append(np1);CFit.append(f1);CF.append(nf1)
            CP = np.vstack((CP, np2));CFit = np.vstack((CFit, f2));CF=np.vstack((CF, nf2))
        else:
            CP = np.vstack((CP, np1));CP = np.vstack((CP, np2));
            CF = np.vstack((CF, nf1));CF = np.vstack((CF, nf2));
            CFit = np.vstack((CFit, f1));CFit = np.vstack((CFit, f2))
    QP = np.vstack((p_chrom, CP))
    QF = np.vstack((f_chrom, CF))
    QFit = np.vstack((fitness, CFit))
    QP,QF, QFit = DeleteReapt(QP,QF,QFit,ps)
    TopRank = FastNDS(QFit, ps)
    p_chrom = QP[TopRank, :];
    f_chrom = QF[TopRank, :];
    fitness = QFit[TopRank, :]

    return p_chrom,f_chrom,fitness

def NSGA2POXES(p_chrom,f_chrom,fitness,Pc,Pm,ps,N,time,F,TS,NS, JP,JDD):
    Pool_P, Pool_F = TSelection(p_chrom, f_chrom, fitness,ps,N);
    CP = [];CF = [];CFit = []
    for i in range(ps):
        index = math.floor(random.random() * ps)
        P1 = Pool_P[index, :]
        F1 = Pool_F[index, :]
        np1=copy.copy(p_chrom[i, :]);np2=copy.copy(P1);
        nf1 = copy.copy(f_chrom[i, :]);nf2 = copy.copy(F1);
        if random.random() < Pc:
            [np1, np2] = POX(p_chrom[i, :], P1, N)
            [nf1, nf2] = UX_F(f_chrom[i, :], F1, N,F)
            if random.random() < Pm:
                np1 = mutation_p(np1,N)
                nf1 = mutation_f(nf1,N,F)
            if random.random() < Pm:
                np2 = mutation_p(np2, N)
                nf2 = mutation_f(nf2, N, F)
        f1=np.zeros(3);f2=np.zeros(3);
        f1[0],f1[1],f1[2] = EnergySave_DHHFSP(np1, nf1,N,time,F,TS,NS, JP, JDD)
        f2[0],f2[1],f2[2] = EnergySave_DHHFSP(np2, nf2,N,time,F,TS,NS, JP, JDD)
        if len(CP) == 0:
            CP.append(np1);CFit.append(f1);CF.append(nf1)
            CP = np.vstack((CP, np2));CFit = np.vstack((CFit, f2));CF=np.vstack((CF, nf2))
        else:
            CP = np.vstack((CP, np1));CP = np.vstack((CP, np2));
            CF = np.vstack((CF, nf1));CF = np.vstack((CF, nf2));
            CFit = np.vstack((CFit, f1));CFit = np.vstack((CFit, f2))
    QP = np.vstack((p_chrom, CP))
    QF = np.vstack((f_chrom, CF))
    QFit = np.vstack((fitness, CFit))
    QP,QF, QFit = DeleteReapt(QP,QF,QFit,ps)
    TopRank = FastNDS(QFit, ps)
    p_chrom = QP[TopRank, :];
    f_chrom = QF[TopRank, :];
    fitness = QFit[TopRank, :]

    return p_chrom,f_chrom,fitness

def NSGA2PMXES(p_chrom,f_chrom,fitness,Pc,Pm,ps,N,time,F,TS,NS, JP,JDD):
    Pool_P, Pool_F = TSelection(p_chrom, f_chrom, fitness,ps,N);
    CP = [];CF = [];CFit = []
    for i in range(ps):
        if random.random() < Pc:
            index = math.floor(random.random() * ps)
            P1 = Pool_P[index, :]
            F1 = Pool_F[index, :]
            [np1, np2] = PMX(p_chrom[i, :], P1, N)
            [nf1, nf2] = UX_F(f_chrom[i, :], F1, N,F)
            if random.random() < Pm:
                np1 = mutation_p(np1,N)
                nf1 = mutation_f(nf1,N,F)
            if random.random() < Pm:
                np2 = mutation_p(np2, N)
                nf2 = mutation_f(nf2, N, F)
        f1=np.zeros(3);f2=np.zeros(3);
        f1[0],f1[1],f1[2] = EnergySave_DHHFSP(np1, nf1,N,time,F,TS,NS, JP, JDD)
        f2[0],f2[1],f2[2] = EnergySave_DHHFSP(np2, nf2,N,time,F,TS,NS, JP, JDD)
        if len(CP) == 0:
            CP.append(np1);CFit.append(f1);CF.append(nf1)
            CP = np.vstack((CP, np2));CFit = np.vstack((CFit, f2));CF=np.vstack((CF, nf2))
        else:
            CP = np.vstack((CP, np1));CP = np.vstack((CP, np2));
            CF = np.vstack((CF, nf1));CF = np.vstack((CF, nf2));
            CFit = np.vstack((CFit, f1));CFit = np.vstack((CFit, f2))
    QP = np.vstack((p_chrom, CP))
    QF = np.vstack((f_chrom, CF))
    QFit = np.vstack((fitness, CFit))
    QP,QF, QFit = DeleteReapt(QP,QF,QFit,ps)
    TopRank = FastNDS(QFit, ps)
    p_chrom = QP[TopRank, :];
    f_chrom = QF[TopRank, :];
    fitness = QFit[TopRank, :]

    return p_chrom,f_chrom,fitness


def NSGA2MOX(p_chrom,f_chrom,fitness,Pc,Pm,ps,N,time,F,TS,NS, JP,JDD):
    Pool_P, Pool_F = TSelection(p_chrom, f_chrom, fitness,ps,N);
    CP = [];CF = [];CFit = []
    for i in range(ps):
        if random.random() < Pc:
            index = math.floor(random.random() * ps)
            P1 = Pool_P[index, :]
            F1 = Pool_F[index, :]
            if random.random()<0.5:
                [np1, np2] = POX(p_chrom[i, :], P1, N)
            else:
                [np1, np2] = PMX(p_chrom[i, :], P1, N)
            [nf1, nf2] = UX_F(f_chrom[i, :], F1, N,F)
            if random.random() < Pm:
                np1 = mutation_p(np1,N)
                nf1 = mutation_f(nf1,N,F)
            if random.random() < Pm:
                np2 = mutation_p(np2, N)
                nf2 = mutation_f(nf2, N, F)
        f1=np.zeros(3);f2=np.zeros(3);
        f1[0],f1[1],f1[2] = FitDHHFSP(np1, nf1,N,time,F,TS,NS, JP, JDD)
        f2[0],f2[1],f2[2] = FitDHHFSP(np2, nf2,N,time,F,TS,NS, JP, JDD)
        if len(CP) == 0:
            CP.append(np1);CFit.append(f1);CF.append(nf1)
            CP = np.vstack((CP, np2));CFit = np.vstack((CFit, f2));CF=np.vstack((CF, nf2))
        else:
            CP = np.vstack((CP, np1));CP = np.vstack((CP, np2));
            CF = np.vstack((CF, nf1));CF = np.vstack((CF, nf2));
            CFit = np.vstack((CFit, f1));CFit = np.vstack((CFit, f2))
    QP = np.vstack((p_chrom, CP))
    QF = np.vstack((f_chrom, CF))
    QFit = np.vstack((fitness, CFit))
    QP,QF, QFit = DeleteReapt(QP,QF,QFit,ps)
    TopRank = FastNDS(QFit, ps)
    p_chrom = QP[TopRank, :];
    f_chrom = QF[TopRank, :];
    fitness = QFit[TopRank, :]

    return p_chrom,f_chrom,fitness

def MOEADPOX(p_chrom,f_chrom,index,T,neighbour,Pc,Pm,N,time,F,TS,NS, JP,JDD):
    nei = neighbour[index, :]
    R1 = math.floor(random.random() * T)
    R1 = nei[R1]
    R2 = math.floor(random.random() * T)
    R2 = nei[R2]

    np1 = copy.copy(p_chrom[R1, :])
    np2 = copy.copy(p_chrom[R2, :])
    nf1 = copy.copy(f_chrom[R1, :])
    nf2= copy.copy(f_chrom[R2, :])
    while R1 == R2:
        R2 = math.floor(random.random() * T)
        R2 = nei[R2]
    if random.random() < Pc:
        [np1, np2] = POX(p_chrom[R1, :], p_chrom[R2, :], N)
        [nf1, nf2] = UX_F(f_chrom[R1, :], f_chrom[R2, :], N, F)
        if random.random() < Pm:
            np1 = mutation_p(np1, N)
            nf1 = mutation_f(nf1, N, F)
        if random.random() < Pm:
            np2 = mutation_p(np2, N)
            nf2 = mutation_f(nf2, N, F)

        f1=np.zeros(3);f2=np.zeros(3);
        f1[0],f1[1],f1[2] = FitDHHFSP(np1, nf1,N,time,F,TS,NS, JP, JDD)
        f2[0],f2[1],f2[2] = FitDHHFSP(np2, nf2,N,time,F,TS,NS, JP, JDD)

    return np1,nf1,f1,np2,nf2,f2