function [ Xr1 ,Xr2 ] = selectR( P,A,i )
%SELECTR �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    [m,n] = size(P);
    [p,q] = size(A);
    % PUA
    C = [P;A];
    r1 = randi(m);
    while i==r1
        r1 = randi(m);
    end
    
    r2 = randi(m+p);
    while i==r2 || r1==r2
        r2 = randi(m+p);
    end
    
    Xr1 = P(r1,:);
    Xr2 = C(r2,:);
    
end

