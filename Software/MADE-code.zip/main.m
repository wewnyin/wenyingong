clear all
close all

rehash

format long g

warning ('off'); 

ss=[];
tic()
runtimes = 30;
for type=1:1
    if type==1
        Max_NEF = 4500;
        VTR = 0.005;
    elseif type==2
        Max_NEF = 9500;
        VTR = 0.005;
    elseif type==3
        Max_NEF = 4500;
        VTR = 0.005;
    elseif type==4
        Max_NEF = 6500;
        VTR = 0.01;
    elseif type==5
        Max_NEF = 6500;
        VTR = 1;
    elseif type==6
        Max_NEF = 9000;
    end
    
    if type==2
%         runtimes = 100;
        runtimes = 30;
    else
        runtimes =30;
    end
    
    [LB,UB,D] = Parameter(type);
    
    pp=[];
    count = 0;
    
    for i=1:runtimes
        [FinalSolution ,FinalValue,FinalNFE] = SHADE(type,@ModelFunction,Max_NEF,VTR,LB,UB,D);
        s = 0;
        for j=1:D
            if FinalSolution(j)<LB(j) || FinalSolution(j)>UB(j)
                s = s+1;
            end
        end
        if s==0
            count = count+1;
            pp(count,:)=[FinalValue, FinalSolution ,FinalNFE];
        end
    end

    ss{type}=pp;
    minr = ss{type}(:,1);
    WW{type} = [min(minr),max(minr),mean(minr),std(minr)];
    
end
toc()