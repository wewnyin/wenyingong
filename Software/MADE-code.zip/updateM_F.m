function [ Mk ] = updateM_F( deta_f,Sf)
%UPDATEM_CR_F �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    x = 0;
    y = 0;
    count = length(Sf);
    if 1<=count
        for k=1:count
            wk = deta_f(k)/(sum(deta_f));
            x = x+wk*(Sf(k)^2);
            y = y+wk*Sf(k);
        end
        
        Mk = x/y;
        
    else
        fprintf('deta_f and Sf are not the same size');
    end

end

