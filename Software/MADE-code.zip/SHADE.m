 function [ Solution ,Value ,NFEs ] = SHADE( type,ObjectionFunc ,Max_NFE,kesi,LB,UB,D)
%JADE �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
%     [LB,UB,kesi,bestValue,Max_NFE,VTR] = Parameters(type,D);
    more off
    
%     [LB,UB,D] = Parameter(type);
    addpath('./CauchyFunction');
    
    if type==1
        fun_name = 'single_diode';
    elseif type==2
        fun_name = 'double_diode';
    elseif type==3
        fun_name = 'PV_diode';
    elseif type==4
        fun_name = 'STM6_40_36';
    elseif type==5
        fun_name = 'STP6_120_36';
    elseif type==6
        fun_name = 'KC200GT';
    end
    
    NP =20; 
    Gm = Max_NFE/NP;  
    NFE = 0;
    
    pmin = 2/NP;
    pmax = 0.2;
    A = [];
    k = 1;
    H = 100;
    M_CR = 0.5*ones(1,H);
    M_F = 0.5*ones(1,H);
    w1 = 0.2;
    w2 = 0.6;
       
     X = zeros(NP,D);
     for i=1:NP
         for j=1:D
             X(i,j) = LB(j)+rand*(UB(j)-LB(j));
         end
     end
     
     OFV = zeros(1,NP);
     
     for i=1:NP
         OFV(i) = ObjectionFunc(type,X(i,:));
     end   
     NFE = NFE+NP;
     
     [sorted,indices] = sort(OFV);
     
      Solution = X(indices(1),:);
      Value = sorted(1);
     
     for g=1:Gm-1
        
        [mm,nn] = size(A);
        Num_A = mm+1; 
        Sf = [];
        Scr = [];
        count = 1;
        deta_f = [];
     
        [sorted,indices] = sort(OFV);
        X = X(indices,:);
        OFV = sorted;
        for i=1:NP
            % select ri
            ri = randi(H);
            % generate CR(i)
             CR(i)=normrnd(M_CR(ri),0.1);
            if CR(i)<0
                 CR(i) = 0;
            end
            if CR(i)>1
                CR(i) = 1;
            end
            % generate F(i)
            F(i)=cauchyrnd(M_F(ri),0.1);
            while F(i)<=0
                F(i)=cauchyrnd(M_F(ri),0.1);
            end
              
            if F(i)>1
               F(i) = 1;
            end
            % select Xpbest
%             [sorted,indices] = sort(OFV);
%             X = X(indices,:);
%             OFV = sorted;
           
            p = pmin+rand()*(pmax-pmin);
            pid = floor(NP*p);
            pbestid = randi(pid);
            Xpbest = X(pbestid,:);
            
            % select r1��r2
            [Xr1,Xr2] = selectR(X,A,i);
            % mutation
            v(i,:) = X(i,:)+F(i).*(Xpbest-X(i,:))+F(i).*(Xr1-Xr2);
            
            jrand = randi(D);
            
            % deal bound
%             for j=1:D
%                 if v(i,j)<LB(j)
%                     v(i,j) = (LB(j)+X(i,j))/2;
%                 end
%                 
%                 if v(i,j)>UB(j)
%                     v(i,j) = (UB(j)+X(i,j))/2;
%                 end 
%             end
            
            % crossover
            for j=1:D
                if j==jrand || rand()<CR(i)
                    u(i,j) = v(i,j);
                else
                    u(i,j) = X(i,j);
                end
            end
            
            % 
            for j=1:D
                if u(i,j)<LB(j)
                    u(i,j) = LB(j)+rand()*(UB(j)-LB(j));
                end
                
                if u(i,j)>UB(j)
                    u(i,j) = LB(j)+rand()*(UB(j)-LB(j));
                end 
            end
            
            % 
            New_OFV(i) = ObjectionFunc(type,u(i,:));
            NFE = NFE+1;
        end
        
        for i=1:NP
            
            % selection
            
            if New_OFV(i)<OFV(i)
                A(Num_A,:) = X(i,:);
                Sf(count) = F(i);
                Scr(count) = CR(i);
                deta_f(count) = abs(New_OFV(i)-OFV(i));
                count = count+1;
                Num_A = Num_A+1;
            end
            
            if New_OFV(i)<=OFV(i)
                X(i,:) = u(i,:);
                OFV(i) = New_OFV(i);
            else
                X(i,:) = X(i,:);
            end
            
            
        end
        
        % update A
        A = updateA(A,NP);
        
        % update M_CR and M_F
        if count<=1
            M_CR = M_CR;
            M_F = M_F;
        else
%             fprintf('%d %d\n',length(Scr),length(deta_f));
            M_CR(k) = updateM_CR(deta_f,Scr);
            M_F(k) = updateM_F(deta_f,Sf);
            k = k+1;
            if k>H
                k = 1;
            end
        end
        [sorted,indices] = sort(OFV);
         OFV = sorted;
         X = X(indices,:);
         if OFV(1)<kesi
             [x,fval,exitflag,output] = fminsearch(fun_name,X(1,:));
             NFE =  NFE+output.funcCount;
             output.funcCount;
             if fval<OFV(1)
                 X(1,:) = x;
                 OFV(1) = fval;
             end
         end
          if NFE>=Max_NFE
                 break;
          end
          

     end
     [sorted,indices] = sort(OFV);
     Solution = X(indices(1),:);
     Value = sorted(1);
     NFEs = NFE;
                
               
end

