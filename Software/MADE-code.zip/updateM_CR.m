function [ Mk ] = updateM_CR( deta_f,Scr)
%UPDATEM_CR_F �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    summ = 0;
    count = length(Scr);
    if 1<=count
        for k=1:count
            wk = deta_f(k)/(sum(deta_f));
            summ = summ+wk*Scr(k);
        end
        
        Mk = summ;
        
    else
       fprintf('deta_f and Scr are not the same size');
    end

end

