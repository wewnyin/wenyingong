# Multiobjective Multitask Optimization with Multiple Knowledge and Transfer Adaptation (MTDE-MKTA)

**Email: <int_lyc@cug.edu.cn>**

## Reference

```
@Article{Li2024MTDE-MKTA,
  title    = {Multiobjective Multitask Optimization with Multiple Knowledge and Transfer Adaptation},
  author   = {Li, Yanchi and Gong, Wenyin},
  journal  = {IEEE Transactions on Evolutionary Computation},
  year     = {2024},
} 
```

## Note

The MTO-Platform (MToP) has incorporated the relevant algorithm and provides convenient utility functions. We highly recommend using it for code running. [https://github.com/intLyc/MTO-Platform](https://github.com/intLyc/MTO-Platform)

The real-world applications covered in the paper have also been uploaded to the MToP.
