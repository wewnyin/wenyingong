function CTAEA2(Global)
% <algorithm> <A-C>
% Two-archive evolutionary algorithm for constrained MOPs for better versatility

            %% Generate random population
            Population = Global.Initialization();
            CA = Population; DA = Population;
            
            %% Optimization
            while Global.NotTermination(CA)
                %% mating selection and offspring generation
                MatingPool1 = MatingSelection(CA,ceil(Global.N/2),2);
                MatingPool2 = MatingSelection(DA,Global.N-length(MatingPool1),1);
                Offspring1  = GA(CA(MatingPool1));
                Offspring2  = GA(DA(MatingPool2));
                Offspring = [Offspring1,Offspring2];
%                 Archive = [CA,DA];
%                 MatingPool = MatingSelection(Archive,Problem.N);
                %MatingPool = randi(Problem.N,1,Problem.N);
                %Offspring  = OperatorGA(Archive(MatingPool));
                %% update CA and DA
                CA = UpdateCA(CA,[DA,Offspring],Global.N);
                DA = UpdateDA(CA,DA,Offspring,Global.N);
                %% environmental selection
                %Population = EnvironmentalSelection([CA,DA],Problem.N);
%                 CAObjs = CA.objs;
%                 DAObjs = DA.objs;
%                 scatter3(CAObjs(:,1),CAObjs(:,2),CAObjs(:,3),'red');
%                 hold on;
%                 scatter3(DAObjs(:,1),DAObjs(:,2),DAObjs(:,3),'blue');
%                 hold off;
            end
end