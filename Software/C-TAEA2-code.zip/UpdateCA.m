function UpdatedCA=UpdateCA(CA,Population,N)
% Update CA

        P = [CA,Population];
        CV = sum(max(0,P.cons),2);
        UpdatedCA = P(CV==0);
        if length(UpdatedCA) < N
            P = setdiff(P,UpdatedCA);
            CV = sum(max(0,P.cons),2);
            [~,index] = sort(CV,'ascend');
            remain_size = N-length(UpdatedCA);
            Remain = P(index(1:remain_size));
            UpdatedCA = [UpdatedCA,Remain];
        else
            Fitness=CalFitness(UpdatedCA.objs,UpdatedCA.cons);
            Next = Fitness < 1;
            if sum(Next) < N
                [~,Rank] = sort(Fitness);
                Next(Rank(1:N)) = true;
            elseif sum(Next) > N
                Del  = Truncation(UpdatedCA(Next).objs,sum(Next)-N);
                Temp = find(Next);
                Next(Temp(Del)) = false;
            end
            % Archive for next generation
            UpdatedCA = UpdatedCA(Next);
            
%             S = [];
%             PopObj = UpdatedCA.objs;
%             [FrontNO,MaxNO] = NDSort(PopObj,inf);
%             for i=1:MaxNO
%                 S = cat(2,S,UpdatedCA(FrontNO == i));
%                 if length(S) >= N
%                     break;
%                 end
%             end
%             PopObj = S.objs;
%             Distance = pdist2(PopObj,PopObj);
%             Distance(logical(eye(length(Distance)))) = inf;
%             [~,index] = sort(Distance,'descend');
%             UpdatedCA = S(index(1:N));
        end
end

function Del = Truncation(PopObj,K)
% Select part of the solutions by truncation

    %% Truncation
    Distance = pdist2(PopObj,PopObj);
    Distance(logical(eye(length(Distance)))) = inf;
    Del = false(1,size(PopObj,1));
    while sum(Del) < K
        Remain   = find(~Del);
        Temp     = sort(Distance(Remain,Remain),2);
        [~,Rank] = sortrows(Temp);
        Del(Remain(Rank(1))) = true;
    end
end