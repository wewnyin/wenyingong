function MatingPool = MatingSelection(Population,N,type)
% Mating selection of C-TAEA2
  
        if type==1
            %MatingPool = randi(Problem.N,1,Problem.N);
            ranking = Ranking(Population.objs,Population.cons);
            MatingPool = TournamentSelection(2,N,ranking);
        else
            ranking = CalFitness(Population.objs,Population.cons);
            MatingPool = TournamentSelection(2,N,ranking);
        end

end