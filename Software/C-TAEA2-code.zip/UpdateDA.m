function UpdatedDA=UpdateDA(CA,DA,Population,N)
% Update DA

    Population = setdiff(Population,CA);
    Population = [DA,Population];
    PopObj = Population.objs;
    [FrontNO,MaxNO] = NDSort(PopObj,inf);
    S = [];
    for i=1:MaxNO
        S = cat(2,S,Population(FrontNO == i));
        if length(S) >= N
            break;
        end
    end
    SPopObj = S.objs;
    CAObjs = CA.objs;
    Distance = pdist2(SPopObj,CAObjs);
    [~,index] = sort(Distance,'descend');
    UpdatedDA = S(index(1:N));
end