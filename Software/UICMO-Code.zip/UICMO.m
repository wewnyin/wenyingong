classdef UICMO < ALGORITHM
% <multi> <real/integer/label/binary/permutation> <constrained>
% Coevolutionary constrained multi-objective optimization framework


%------------------------------- Reference --------------------------------
% Y. Tian, T. Zhang, J. Xiao, X. Zhang, and Y. Jin, A coevolutionary
% framework for constrained multi-objective optimization problems, IEEE
% Transactions on Evolutionary Computation, 2021, 25(1): 102-116.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2023 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    methods
        function main(Algorithm,Problem)

            %% Generate random population
            Population1 = Problem.Initialization();
            Distance = pdist2(Population1.objs,Population1.objs);
            epsilon  = max(max(Distance));
            Fitness1    = CalFitness(Population1.objs,Population1.cons,epsilon);
            delta = 0.9;
            nr = 2;
            [W,~] = UniformPoint(Problem.N,Problem.M);
            T = ceil(Problem.N/10);
            B = pdist2(W,W);
            [~,B] = sort(B,2);
            B = B(:,1:T);
%             cosine = 1 - pdist2(W,W,'cosine');
%             cosine(logical(eye(length(cosine)))) = 0;
%             Angle = acos(1-pdist2(W,Population1.objs,'cosine'));
%             [~,associate] = min(Angle,[],2);
%             Population2 = Population1(associate);
             Population2 = Problem.Initialization();
            Z          = min([Population2.objs;Population1.objs],[],1);
            archive = Archive([Population1,Population2],Problem.N,0);
             archive_FN = ArchiveFN(archive);

            %% Optimization
            while Algorithm.NotTerminated(Population1)
                gen        = ceil(Problem.FE/(2*Problem.N));
                G        = ceil(Problem.maxFE/(2*Problem.N));
                epsilon = epsilon*(exp(-25*(gen/G-0.5))/(1+exp(-25*(gen/G-0.5))));
                MatingPool1 = TournamentSelection(2,Problem.N,Fitness1);
              Offspring1  = OperatorGA(Problem,Population1(MatingPool1));
                Z          = min([Z;Offspring1.objs],[],1);
                Offspring2 = [];
                 Angle_W = acos(1-pdist2(W,Offspring1.objs,'cosine'));
                 [~,associate_New] = min(Angle_W,[],2);
                  Offspring_O1 = Offspring1(associate_New);
                for i = 1:Problem.N
                  if rand < delta
                        P = B(i,randperm(size(B,2)));
                    else
                        P = randperm(Problem.N);
                  end
                   Parent1 = EnvironmentalSelectionD(Population2(i),Offspring_O1(i),W,Z,archive_FN,i);
                     Parent2 = EnvironmentalSelectionD(Population2(P(1)),Offspring_O1(P(1)),W,Z,archive_FN,P(1));
                    Parent3 = EnvironmentalSelectionD(Population2(P(2)),Offspring_O1(P(2)),W,Z,archive_FN,P(2));
                     Offspring_DE = OperatorDE(Problem,Parent1,Parent2,Parent3);
%                      Offspring_DE = OperatorDE(Problem,Population2(i),Population2(P(1)),Population2(P(2)));

                    Offspring2 = [Offspring2,Offspring_DE];
                    Population2(P) = EnvironmentalSelectionD(Population2(P),Offspring_DE,W,Z,archive_FN,P);
                       
                end
                Z          = min([Z;Offspring2.objs],[],1);
                 archive = Archive([archive,Offspring1,Offspring2],Problem.N,0);
                 archive_FN = ArchiveFN(archive);
                [Population1,Fitness1] = EnvironmentalSelection([Population1,Offspring1,Offspring2],Problem.N,true,epsilon);
                if Problem.FE >= Problem.maxFE
                    Population1 = archive;
                end
            end
        end
    end
end