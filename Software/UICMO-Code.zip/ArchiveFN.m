function Population = ArchiveFN(Population)
% Select feasible and non-dominated solutions

    %% Select feasible solutions
    fIndex           = all(Population.cons <= 0,2);
    Population       = Population(fIndex);
    if isempty(Population)
        return
    else
        Fitness = CalFitness(Population.objs,Population.cons,0);
        Next = Fitness < 1;
        Population = Population(Next);
%         if size(Population,2) >=3
%             Popobj = Population.objs;
%             [~,I] = sort(Popobj,1);
%             I = I(:,1);
%             Population = [Population(I(1)),Population(I(ceil(end/2))),Population(I(end))];
%         end
    end
end

