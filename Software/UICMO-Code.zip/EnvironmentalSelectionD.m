function Population = EnvironmentalSelectionD(OldPop,NewPop,W,Z,Archive,current)
% The environmental selection of SPEA2

%------------------------------- Copyright --------------------------------
% Copyright (c) 2023 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    N = size(OldPop,2);
    Angle_New = acos(1-pdist2(NewPop.objs,W,'cosine'));
    [~,associate_New] = min(Angle_New,[],2);
    Angle_Old = acos(1-pdist2(OldPop.objs,W,'cosine'));
    [~,associate_Old] = min(Angle_Old,[],2);
    CV_Old = sum(max(0,OldPop.cons),2);
    CV_New = sum(max(0,NewPop.cons),2);
    W_new = W(current,:);
    for i = 1 :N
    Fit_Old(:,i) = max(abs(OldPop.objs-repmat(Z,N,1)).*W_new(i,:),[],2);
    end
    Fit_New = max(abs(NewPop.objs-repmat(Z,1,1)).*W_new,[],2);
    Population = OldPop;
    count = 0;
    if N ~= 1
        for i = 1:N
            if count == 2
                break
            end
           if  (associate_Old(i) == current(i)) && (associate_New == current(i))
               Flag_Old = Judge(OldPop(i),Archive);
               Flag_New = Judge(NewPop,Archive);
               if (Flag_New == 0) && (Flag_Old ~= 0)
                   Population(i) = NewPop;
                   count = count+1;
               elseif (Flag_New == 0) && (Flag_Old == 0) 
                   if CV_Old(i) > CV_New
                       Population(i) = NewPop;
                       count = count+1;
                   elseif CV_Old(i) ==  CV_New && (Fit_Old(i,i) > Fit_New(i))
                       Population(i) = NewPop;
                       count = count+1;
                   end
               elseif (Flag_New == -1) && (Flag_Old == -1) && (Fit_Old(i,i) > Fit_New(i))
                   Population(i) = NewPop;
                   count = count+1;
               elseif (Flag_New == 1) && (Flag_Old ~= 0) 
                   if CV_Old(i) > CV_New
                       Population(i) = NewPop;
                        count = count+1;
                   elseif CV_Old(i) ==  CV_New && (Fit_Old(i,i) > Fit_New(i))
                       Population(i) = NewPop;
                        count = count+1;
                   end
               elseif (Flag_New == -1) && (Flag_Old == 1) 
                   if CV_Old(i) > CV_New
                       Population(i) = NewPop;
                        count = count+1;
                   elseif CV_Old(i) ==  CV_New && (Fit_Old(i,i) > Fit_New(i))
                       Population(i) = NewPop;
                        count = count+1;
                   end
               end
           elseif Angle_Old(i,current(i)) > Angle_New(current(i)) && (Fit_Old(i,i) > Fit_New(i))
                   Population(i) = NewPop;
                        count = count+1;
           end   
        end
    else
        if  (associate_Old(i) == current(i)) && (associate_New == current(i))
               Flag_Old = Judge(OldPop,Archive);
               Flag_New = Judge(NewPop,Archive);
               if (Flag_New == 0) && (Flag_Old ~= 0)
                   Population = NewPop;
               elseif (Flag_New == 0) && (Flag_Old == 0) 
                   if CV_Old > CV_New
                       Population = NewPop;
                   elseif CV_Old ==  CV_New && (Fit_Old > Fit_New)
                       Population = NewPop;
                   end
               elseif (Flag_New == -1) && (Flag_Old == -1) && (Fit_Old > Fit_New)
                   Population = NewPop;
               elseif (Flag_New == 1) && (Flag_Old ~= 0) 
                   if CV_Old > CV_New
                       Population = NewPop;
                   elseif CV_Old ==  CV_New && (Fit_Old > Fit_New)
                       Population = NewPop;
                   end
               elseif (Flag_New == -1) && (Flag_Old == 1) 
                   if CV_Old > CV_New
                       Population = NewPop;
                   elseif CV_Old ==  CV_New && (Fit_Old > Fit_New)
                       Population = NewPop;
                   end
               end
        elseif Angle_Old(current) > Angle_New(current) && (Fit_Old > Fit_New)
                   Population = NewPop;
        end
    end
end

function K = Judge(Pop,Archive)
% Select part of the solutions by truncation
     N = size(Archive,2);
     K = 0;
     if ~isempty(Archive)
         for i = 1 : N
             k = any(Pop.objs<Archive(i).objs) - any(Pop.objs>Archive(i).objs);
             if k == 1
                 K = 1;
                 break
             elseif k == -1
                  K = -1;
                  break
             end
         end
     end
end

