 function Y = sample_dpp(L,k)

 n=size(L.D,1);
[~,i]=sort(L.D);
v=i(n-k+1:n);
k = length(v);
V = L.V(:,v);

Y = zeros(k,1);
for i = k:-1:1
  
   if size(V,2)==1 && i~=1
      V=abs(V);
      [~,b1]=sort(V);
      bb=b1(n-i+1:n);
      for ii=i:-1:1
          Y(ii)=bb(ii);
      end
      break;
      
   end
  P = sum(V.^2,2);
  P = P / sum(P);

  [~,Y(i)] = max(P);

  j = find(V(Y(i),:),1);
  Vj = V(:,j);
  V = V(:,[1:j-1 j+1:end]);

  V = V - bsxfun(@times,Vj,V(Y(i),:)/Vj(Y(i)));

  V=orth(V);
end

Y = sort(Y);
end