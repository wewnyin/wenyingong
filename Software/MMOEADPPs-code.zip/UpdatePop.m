function Pop = UpdatePop(Pop,New,MaxSize,z,znad,z_dec,znad_dec)

    Pop = [New,Pop];
    N = length(Pop); 
    
    CAObj=Pop.objs;
    CADec = Pop.decs;
    CAObj2 = (CAObj-repmat(z,N,1))./(repmat(znad,N,1)-repmat(z,N,1));
    CADec2 = (CADec-repmat(z_dec,N,1))./(repmat(znad_dec,N,1)-repmat(z_dec,N,1));
    D = pdist2(CAObj2,CAObj2);
    Dec = pdist2(CADec2,CADec2);

    D(1:size(D,1)+1:end) = 0;
    Dec(1:size(Dec,1)+1:end) = 0;

    H=exp(-D);
    HDec=exp(-Dec);
   
    FrontNo = NDSort(CAObj,N);
    FrontNo = FrontNo'*FrontNo;
    
    H=H.*HDec./(FrontNo.^(1/2));

    L = decompose_kernel(H);
    Choose = sample_dpp(L,MaxSize);
    Pop = Pop(Choose);
end