classdef MMOEADPPse2 < ALGORITHM
%  <multi> <real> <multimodal>
    
    methods
        function main(Algorithm,Problem)          
            %% Generate random population
            Population = Problem.Initialization();
            Pop = Population;
            Archive = ArchiveUpdate(Population,Problem.N,0.3);
            [z,znad]     = deal(min(Population.objs),max(Population.objs));
            [z_dec,znad_dec]     = deal(min(Population.decs),max(Population.decs));
            
            %% Optimization
            while Algorithm.NotTerminated(Archive)  
                MatingPool = randi(length(Pop),1,floor(Problem.N/2));
                Offspring1  = OperatorGA(Pop(MatingPool));
                MatingPool = randi(length(Archive),1,floor(Problem.N/2));
                Offspring2  = OperatorGA(Archive(MatingPool));
                Offspring = [Offspring1,Offspring2];

                z = min(z,min(Offspring.objs,[],1));
                z_dec = min(z_dec,min(Offspring.decs,[],1));
                
                Pop = UpdatePop(Pop,Offspring,Problem.N,z,znad,z_dec,znad_dec);
                Archive = ArchiveUpdate([Archive,Pop,Offspring],Problem.N,0.3);
                znad=max(Pop.objs,[],1);
                znad_dec=max(Pop.decs,[],1);
            end
        end
    end
end