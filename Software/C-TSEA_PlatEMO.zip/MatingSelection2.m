function MatingPool = MatingSelection2(Population,Archive,N)
% The mating selection of stage 2

    Fitness1 = CalFitness(Population.objs,Population.cons);
    MatingPool1 = TournamentSelection(2,N,Fitness1);
    MatingPool = Population(MatingPool1);
end