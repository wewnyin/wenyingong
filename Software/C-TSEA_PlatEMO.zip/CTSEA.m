function CTSEA(Global)
% <algorithm> <C>

    %% Generate the sampling points and random population
    Population = Global.Initialization();
    W = UniformPoint(Global.N,Global.M);
    [ARMOEA_Archive,RefPoint,Range] = UpdateRefPoint(Population.objs,W,[]);
    CV = sum(max(0,Population.cons),2);
    Archive = Population(CV==0);
    stage_conver = 0;
    
    %% Optimization
    while Global.NotTermination(Population)
        if Global.evaluated<0.5*Global.evaluation
            % evolve population to PF by ARMOEA
            MatingPool = MatingSelection1(Population,RefPoint,Range);
            Offspring = GA(Population(MatingPool));
            [ARMOEA_Archive,RefPoint,Range] = UpdateRefPoint([ARMOEA_Archive;Offspring.objs],W,Range);
            Archive = UpdateArchive(Archive,[Population,Offspring],Global.N);
            [Population,Range] = EnvironmentalSelection1([Population,Offspring],RefPoint,Range,Global.N);
        else
            if stage_conver==0
                % exchange archive and population
                temp = Population;
                Population = Archive;
                Archive = temp;
                stage_conver = 1;
            end
            % evolve population to CPF by modified SPEA2
            MatingPool = MatingSelection2(Population,Archive,Global.N);
            Offspring = GA(MatingPool);
            Population = EnvironmentalSelection2([Population,Offspring],Global.N);
        end
    end
end