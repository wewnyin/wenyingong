/* 
	Description: The C code of the DE algorithms with MS VC++ 6.0
	Optimizer:   Basic DE; jDE; jDE-BBO 
	References:  1. J. of Global Optimization 1997, Basic DE
				 2. IEEE TEVC 2006, jDE
				 3. ..., jDE-BBO
	Programmer:  Wenyin Gong
	E-mail:      cug11100304@yahoo.com.cn
	Date:	     27/5/2009
	Lisence:     Free
	Note:		 If you use this code, pls cite the following paper:
	             W. Gong, Z. Cai, and C.X. Ling, DE/BBO: A Hybrid Differential 
				 Evolution with Biogeography-Based Optimization for Global Numerical 
				 Optimization, Soft Computing, In Press.
*/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>
#include <time.h>
#include <iostream.h>

/* Random number generator defined by URAND should return
   double-precision floating-point values uniformly distributed
   over the interval [0.0, 1.0)	*/
#define URAND			((double)rand()/((double)RAND_MAX + 1.0))

#define INF				1e99

#define N_of_x			30		/* number of decision variables */
#define pop_size		100		/* population size */
#define max_iteration	1500	/* maximal number of iteration */
#define PRECISION		1E-8	/* expected precision of the problem */

typedef struct 
{
	double xreal[N_of_x];	/* decision variables */
	double fitness;			/* fitness of the solution */
	double CR;				/* for jDE and jDE-DE */
	double FF;				/* for jDE and jDE-DE */

	int	   SpeciesCount;	/* species count */
}individual;

individual parent_pop[pop_size];/* save the parent population */
individual child_pop[pop_size];	/* save the child population */
double	lowerBound[N_of_x];		/* lower bounds of the decision variables */
double	upperBound[N_of_x];		/* upper bounds of the decision variables */
int		bestIndex;				/* index of the best solution in the current population */
int		worstIndex;				/* index of the worst solution in the current population */

int		evaluations;
int		gen_no;		
FILE	*fp;

individual best_individual;

/* some functions */
int		rndint(int);
double	rndreal(double, double);

void	init_variables();
void	init_pop_uniform();
double	evaluate_ind(double *);
void	evaluate_pop(individual *pop, int size);
void	copyIndividuals(individual *source, individual *target);
void	find_best_and_worst();

void	welcome();

void	Run_DE();
void	Run_jDE();
void	Run_jDE_BBO();

/* for BBO */
double lambdaLower = 0.0;	/* lower bound for immigration probability per gene */
double lambdaUpper = 1.0;	/* upper bound for immigration probability per gene */
double II = 1.0;			/* max immigration rate for each island */
double EE = 1.0;			/* max emigration rate, for each island */
int	   sort_index[pop_size];/* only for sorting the population */

double lambda[pop_size];	/* the immigration rate */
double mu[pop_size];		/* the emigration rate */

void	shell_sort_pop(individual *pop, int *list, int size);
void	GetSpeciesCounts(individual *pop, int size);
void	GetLambdaMu(individual *pop, int size);

int main(int argc, char* argv[])
{
	welcome();
	
	int run_num = 10;
	
	int method;
	printf("Please select the optimizer.\nmethod = ");
	cin>>method;

	for (int i=0;i<run_num;i++)
	{
		srand((unsigned)time(NULL));

		evaluations = 0;

		switch(method) {
		case 1:
			Run_DE();
			break;
		case 2:
			Run_jDE();
			break;
		case 3:
			Run_jDE_BBO();
			break;
		default:
			printf("The selected optimizer does not exist.\n");
			exit(0);
		}
	}

	return 0;
}

void welcome()
{
	printf("\n");
	printf("***************************************************************\n");
	printf("*             Welcome to use the DE optimizers.               *\n");
	printf("*        You can select and use the following optimizer.      *\n");
	printf("*                method = 1   for Basic DE                    *\n");
	printf("*                method = 2   for jDE                         *\n");
	printf("*                method = 3   for jDE-BBO                     *\n");
	printf("***************************************************************\n");
	printf("\n");
}

/* random number generator */
double rndreal(double low,double high)
{
	double  val;
	val = URAND*(high-low)+low;
	return (val);
}

int rndint(int Nmem)
{
	int newval;
	newval = (int)(URAND*Nmem);
	return(newval);
}

/* initialize the variables */
void init_variables()
{
	int i;
	for (i=0;i<N_of_x;i++)
	{
		lowerBound[i] = -500.0;
		upperBound[i] = 500.0;
	}
}

/* initialize the population */
void init_pop_uniform()
{
	int i, j;
	double low, up;

	for(i=0;i<pop_size;i++)
	{
		for(j=0;j<N_of_x;j++)
		{
			low = lowerBound[j];
			up  = upperBound[j];
			
			parent_pop[i].xreal[j] = rndreal(low, up);
		}

		// only for jDE and jDE-DE
		parent_pop[i].CR = rndreal(0.0, 1.0);
		parent_pop[i].FF = rndreal(0.1, 1.0);
	}
}

/* evaluate the individual */
double evaluate_ind(double *x)
{
	/* add different functions here */
	double value = 0.0;
	
	double obj;
	for (int i=0;i<N_of_x;i++)
	{
		value += x[i]*sin(sqrt(fabs(x[i]))); 
	}
	obj = -value + 418.9828872724337998*(double)N_of_x;
	value = obj;

//	for (int i=0;i<N_of_x;i++)
//	{
//		value += (x[i])*(x[i]);
//	}

	evaluations++;
		 
	return(value);
}

/* evaluate the population */
void evaluate_pop(individual *pop, int size)
{
	int i;
	for (i=0;i<size;i++)
	{
		pop[i].fitness = evaluate_ind(pop[i].xreal);
	}
}

/* find the best individual and worst individual in the current population */
void find_best_and_worst()
{
	int i;
	bestIndex  = 0;
	worstIndex = 0;
	for (i=1;i<pop_size;i++)
	{
		if (parent_pop[i].fitness <parent_pop[bestIndex].fitness)
		{
			bestIndex = i;
		}
		if (parent_pop[i].fitness > parent_pop[worstIndex].fitness)
		{
			worstIndex = i;
		}
	}
}

/* copy individuals */
void copyIndividuals(individual *source, individual *target)
{
	int i;
	for (i=0;i<N_of_x;i++)
	{
		target->xreal[i] = source->xreal[i];
	}
	target->fitness      = source->fitness;
	target->CR           = source->CR;
	target->FF           = source->FF;
	
	target->SpeciesCount = source->SpeciesCount;
}

void Run_DE()
{
	int i, j;
	FILE *fp1, *fp2;
	clock_t start, finish;
	double time_consuming;

	srand(time(0));

	start = clock();

	init_variables();
	init_pop_uniform();
	evaluate_pop(parent_pop, pop_size);
	
	gen_no = 1;
	
	if((fp=fopen("process.txt","w"))==NULL)
	{
		printf("\nCannot open input file\n");
		exit(1);
	}

	if((fp1=fopen("results.txt","a"))==NULL)
	{
	    printf("\nCannot open input file\n");
        exit(1);
	}

	if((fp2=fopen("evaluations.txt","a"))==NULL)
	{
	    printf("\nCannot open input file\n");
        exit(1);
	}

	double CR = 0.9;
	double F  = 0.5;
	int    j_rnd;
	int    r1, r2, r3;
	int	   flag_eval = 0;
	while (gen_no < max_iteration)
	{
		find_best_and_worst();
		copyIndividuals(&parent_pop[bestIndex], &best_individual);

		if (flag_eval == 0 && best_individual.fitness < PRECISION)
		{
			flag_eval = 1;
			fprintf(fp2, "%d\n", evaluations);
		}
		
		finish = clock();
		time_consuming = (finish-start)/1000.0;

		if (gen_no%20 == 0)
		{
			//printf("gen=%6d eval=%8d fitness=%e\t%f s.\n", 
			//	gen_no, evaluations, best_individual.fitness, time_consuming);
			fprintf(fp, "%6d %8d %e\n", gen_no, evaluations, best_individual.fitness);
		}

		/* DE/rand/1/bin operator */
		for (i=0;i<pop_size;i++)
		{
			do {
				r1 = rndint(pop_size);
			} while(r1 == i);
			do {
				r2 = rndint(pop_size);
			} while(r2 == i || r2 == r1);
			do {
				r3 = rndint(pop_size);
			} while(r3 == i || r3 == r2 || r3 == r1);

			F = rndreal(0.1, 1.0);
			j_rnd = rndint(N_of_x);
			for (j=0;j<N_of_x;j++)
			{
				if (rndreal(0,1) < CR || j == j_rnd)
				{
					child_pop[i].xreal[j] = parent_pop[r1].xreal[j] +
						F*(parent_pop[r2].xreal[j]-parent_pop[r3].xreal[j]);
					if (child_pop[i].xreal[j] < lowerBound[j] ||
						child_pop[i].xreal[j] > upperBound[j])
					{
						child_pop[i].xreal[j] = 
							rndreal(lowerBound[j], upperBound[j]);
					}
				}
				else
				{
					child_pop[i].xreal[j] = parent_pop[i].xreal[j];
				}
			}
		}
		
		evaluate_pop(child_pop, pop_size);
		/* selection */
		for (i=0;i<pop_size;i++)
		{
			if (child_pop[i].fitness <= parent_pop[i].fitness)
			{
				copyIndividuals(&child_pop[i], &parent_pop[i]);
			}
		}

		gen_no++;
	}

	printf("gen=%d\teval=%d\tfitness=%e\t%f s.\n", 
		gen_no, evaluations, best_individual.fitness, time_consuming);
	/*printf("The best individual is: \n");
	for (i=0;i<N_of_x;i++)
	{
		printf("%.2f\t", best_individual.xreal[i]);
		if ((i+1)%5 == 0)
		{
			printf("\n");
		}
	}*/
	fprintf(fp1, "%d\t%d\t%e\t\n", gen_no, evaluations, 
		best_individual.fitness, time_consuming);

	fclose(fp);
	fclose(fp1);
	fclose(fp2);
}

void Run_jDE()
{
	int i, j;
	FILE *fp1, *fp2;
	clock_t start, finish;
	double time_consuming;

	srand(time(0));

	start = clock();

	init_variables();
	init_pop_uniform();
	evaluate_pop(parent_pop, pop_size);
	
	gen_no = 1;
	
	if((fp=fopen("process.txt","w"))==NULL)
	{
		printf("\nCannot open input file\n");
		exit(1);
	}

	if((fp1=fopen("results.txt","a"))==NULL)
	{
	    printf("\nCannot open input file\n");
        exit(1);
	}

	if((fp2=fopen("evaluations.txt","a"))==NULL)
	{
	    printf("\nCannot open input file\n");
        exit(1);
	}

	double CR = 0.9;
	double F  = 0.5;
	int    j_rnd;
	int    r1, r2, r3;
	int	   flag_eval = 0;
	while (gen_no < max_iteration)
	{
		find_best_and_worst();
		copyIndividuals(&parent_pop[bestIndex], &best_individual);

		if (flag_eval == 0 && best_individual.fitness < PRECISION)
		{
			flag_eval = 1;
			fprintf(fp2, "%d\n", evaluations);
		}
		
		finish = clock();
		time_consuming = (finish-start)/1000.0;

		if (gen_no%20 == 0)
		{
			fprintf(fp, "%6d %8d %e\n", gen_no, evaluations, best_individual.fitness);
		}

		/* DE/rand/1/bin operator */
		for (i=0;i<pop_size;i++)
		{
			do {
				r1 = rndint(pop_size);
			} while(r1 == i);
			do {
				r2 = rndint(pop_size);
			} while(r2 == i || r2 == r1);
			do {
				r3 = rndint(pop_size);
			} while(r3 == i || r3 == r2 || r3 == r1);

			/* self-adaptive control parameters */
			child_pop[i].CR = parent_pop[i].CR;
			child_pop[i].FF = parent_pop[i].FF;
			if (rndreal(0,1) < 0.1)
			{
				child_pop[i].CR = rndreal(0,1);
			}
			if (rndreal(0,1) < 0.1)
			{
				child_pop[i].FF = rndreal(0.1, 1.0);
			}
			CR = child_pop[i].CR;
			F  = child_pop[i].FF;

			j_rnd = rndint(N_of_x);
			for (j=0;j<N_of_x;j++)
			{
				if (rndreal(0,1) < CR || j == j_rnd)
				{
					child_pop[i].xreal[j] = parent_pop[r1].xreal[j] +
						F*(parent_pop[r2].xreal[j]-parent_pop[r3].xreal[j]);
					if (child_pop[i].xreal[j] < lowerBound[j] ||
						child_pop[i].xreal[j] > upperBound[j])
					{
						child_pop[i].xreal[j] = 
							rndreal(lowerBound[j], upperBound[j]);
					}
				}
				else
				{
					child_pop[i].xreal[j] = parent_pop[i].xreal[j];
				}
			}
		}
		
		evaluate_pop(child_pop, pop_size);
		/* selection */
		for (i=0;i<pop_size;i++)
		{
			if (child_pop[i].fitness <= parent_pop[i].fitness)
			{
				copyIndividuals(&child_pop[i], &parent_pop[i]);
			}
		}

		gen_no++;
	}

	printf("gen=%d\teval=%d\tfitness=%e\t%f s.\n", 
		gen_no, evaluations, best_individual.fitness, time_consuming);
	fprintf(fp1, "%d\t%d\t%e\t\n", gen_no, evaluations, 
		best_individual.fitness, time_consuming);

	fclose(fp);
	fclose(fp1);
	fclose(fp2);
}

/* ------------------ for jDE-BBO method ------------------ */
void shell_sort_pop(individual *pop, int *list, int size)
{
	int done;
	int step, bound, i, j;
	int temp;

	step = size;  // array length
	while (step > 1) 
	{
		step /= 2;	//halve the step size
		do 
		{
			done   = 1;
			bound  = size - step;
			for (j = 0; j < bound; j++) 
			{
				i = j + step + 1;
				if (pop[list[j]].fitness > pop[list[i-1]].fitness) 	
				{
					temp      = list[i-1];
					list[i-1] = list[j];
					list[j]   = temp;
					done = 0; // if a swap has been made we are not finished yet
				}  // if
			}  // for
		} while (done == 0);   // while
	} //while (step > 1)
}

void GetSpeciesCounts(individual *pop, int size)
{
	int i;
	/* Map cost values to species counts.
	   This loop assumes the population is already sorted 
	   from most fit to least fit (This is only depended on
	   different implementation.). */
	for (i=0;i<size;i++)
	{
		if (pop[sort_index[i]].fitness < INF)
		{
			pop[sort_index[i]].SpeciesCount = size-i-1;
		}
		else
		{
			pop[sort_index[i]].SpeciesCount = 0;
		}
	}
}

void GetLambdaMu(individual *pop, int size)
{
	/* Compute immigration rate and extinction rate for each species count.
	   lambda(i) is the immigration rate for individual i.
	   mu(i) is the extinction rate for individual i. */
	int i;
	for (i=0;i<size;i++)
	{
		lambda[i] = II*(1.0-(double)pop[sort_index[i]].SpeciesCount/size);
		mu[i] = EE*((double)pop[sort_index[i]].SpeciesCount/size);
	}
}

void Run_jDE_BBO()
{
	int i, j;
	FILE *fp1, *fp2;
	clock_t start, finish;
	double time_consuming;

	srand(time(0));

	start = clock();

	init_variables();
	init_pop_uniform();
	evaluate_pop(parent_pop, pop_size);
	
	gen_no = 1;
	
	if((fp=fopen("process.txt","w"))==NULL)
	{
		printf("\nCannot open input file\n");
		exit(1);
	}

	if((fp1=fopen("results.txt","a"))==NULL)
	{
	    printf("\nCannot open input file\n");
        exit(1);
	}

	if((fp2=fopen("evaluations.txt","a"))==NULL)
	{
	    printf("\nCannot open input file\n");
        exit(1);
	}

	double CR = 0.9;
	double FF = 0.5;
	int    j_rnd;
	int    r1, r2, r3;
	int	   flag_eval = 0;
	while (gen_no < max_iteration)
	{
		find_best_and_worst();
		copyIndividuals(&parent_pop[bestIndex], &best_individual);

		if (flag_eval == 0 && best_individual.fitness < PRECISION)
		{
			flag_eval = 1;
			fprintf(fp2, "%d\n", evaluations);
		}
		
		finish = clock();
		time_consuming = (finish-start)/1000.0;

		if (gen_no%20 == 0)
		{
			fprintf(fp, "%6d %8d %e\n", gen_no, evaluations, best_individual.fitness);
		}

		// only for jDE-BBO
		// sort the population
		for (i=0;i<pop_size;i++)
		{
			sort_index[i] = i;
		}
		shell_sort_pop(parent_pop, sort_index, pop_size);
		
		// calculate mu and lambda of each solution
		// Map cost values to species counts.
		GetSpeciesCounts(parent_pop, pop_size);

		// Compute immigration rate and emigration rate for each species count.
		GetLambdaMu(parent_pop, pop_size);

		// Now use lambda and mu to decide how much information to share between habitats.
		double lambdaMin = lambda[0];
		double lambdaMax = lambda[0];
		for (j=1;j<pop_size;j++)
		{
			if (lambda[j] < lambdaMin)
			{
				lambdaMin = lambda[j];
			}
			if (lambda[j] > lambdaMax)
			{
				lambdaMax = lambda[j];
			}
		}

		/* DE/rand/1/bin operator */
		for (i=0;i<pop_size;i++)
		{
			do {
				r1 = rndint(pop_size);
			} while(r1 == i);
			do {
				r2 = rndint(pop_size);
			} while(r2 == i || r2 == r1);
			do {
				r3 = rndint(pop_size);
			} while(r3 == i || r3 == r2 || r3 == r1);

			int mate1 = sort_index[r1];
			int mate2 = sort_index[r2];
			int mate3 = sort_index[r3]; 

			/* parameter self-adaptation technique proposed by J. Brest */
			child_pop[i].FF = parent_pop[sort_index[i]].FF;
			child_pop[i].CR = parent_pop[sort_index[i]].CR;
			if (rndreal(0.0, 1.0) < 0.1)
			{
				child_pop[i].FF = rndreal(0.1, 1.0);
			}
			if (rndreal(0.0, 1.0) < 0.1)
			{
				child_pop[i].CR = rndreal(0.0, 1.0);
			}
			CR = child_pop[i].CR;
			FF = child_pop[i].FF;

			// Normalize the immigration rate.
			double lambdaScale=lambda[i];
			lambdaScale = lambdaLower +
				(lambdaUpper-lambdaLower)*(lambda[i]-lambdaMin)/(lambdaMax-lambdaMin);

			j_rnd = rndint(N_of_x);

			for (j=0;j<N_of_x;j++)
			{
				//if (rndreal(0,1) < lambdaScale)
				if (1) // especially for the rotated functions
				{
					if ( (rndreal(0,1) < CR) || (j == j_rnd) )
					{// differential operator
						double low = lowerBound[j];
						double up  = upperBound[j];
						
						child_pop[i].xreal[j] = parent_pop[mate1].xreal[j]
							+ FF*(parent_pop[mate2].xreal[j]-parent_pop[mate3].xreal[j]);

						if (child_pop[i].xreal[j] < low || 
							child_pop[i].xreal[j] > up)
						{
							child_pop[i].xreal[j] = rndreal(low, up);
						}
					}
					else
					{// BBO migration	
						int SelectIndex;
						SelectIndex = rndint(pop_size);
						if (rndreal(0,1) < mu[SelectIndex])
						{
							child_pop[i].xreal[j] = 
								parent_pop[sort_index[SelectIndex]].xreal[j];
						}
						else
						{
							child_pop[i].xreal[j] = parent_pop[sort_index[i]].xreal[j];
						}
					}
				}
				else
				{
					child_pop[i].xreal[j] = parent_pop[sort_index[i]].xreal[j];
				}				
			}
		}
		
		/* evaluate the children population */
		evaluate_pop(child_pop, pop_size);
		
		/* selection */
		for (i=0;i<pop_size;i++)
		{
			if (child_pop[i].fitness <= parent_pop[sort_index[i]].fitness)
			{
				copyIndividuals(&child_pop[i], &parent_pop[sort_index[i]]);
			}
		}

		gen_no++;
	}

	printf("gen=%d\teval=%d\tfitness=%e\t%f s.\n", 
		gen_no, evaluations, best_individual.fitness, time_consuming);
	fprintf(fp1, "%d\t%d\t%e\t\n", gen_no, evaluations, 
		best_individual.fitness, time_consuming);

	fclose(fp);
	fclose(fp1);
	fclose(fp2);
}