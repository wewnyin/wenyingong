function [f_con,f_dis] = Estimation(PopObj,r)


    N = size(PopObj,1);
    
    %% Proximity estimation
    fmax   = repmat(max(PopObj,[],1),N,1);
    fmin   = repmat(min(PopObj,[],1),N,1);
	% 先进行归一化
    PopObj = (PopObj-fmin)./(fmax-fmin);
	% 然后将每个个体的目标函数值相加，其结果就位 收敛度
    f_con    = sum(PopObj,2);
    
    %% Crowding degree estimation
    d     = pdist2(PopObj,PopObj);
    d(logical(eye(length(d)))) = inf;
    fprm  = repmat(f_con,1,N);
    case1 = d<r & fprm<=fprm';
    case2 = d<r & fprm>fprm';
    sh        = zeros(N);
    sh(case1) = (0.5*(1-d(case1)/r)).^2;
    sh(case2) = (1.5*(1-d(case2)/r)).^2;
    f_dis   = sqrt(sum(sh,2));
end