classdef TSCSO < ALGORITHM
%<many> <real/binary/permutation> <constrained/none>


	methods
        function main(Algorithm,Problem)

			Population = Problem.Initialization();
			[f_con,f_dis] = Estimation(Population.objs,1/Problem.N^(1/Problem.M));
			f_fea = Calculate_fcv(Population); 
			PopObj_1 = [f_con,f_dis]; 
			[fm,~] = NDSort(PopObj_1,Problem.N);
			PopObj = [fm' + Epsilon * f_fea,f_fea];
			[frank,~] = NDSort(PopObj,Problem.N);
			fitness = frank' + f_fea./(f_fea+1);
			CV      = sum(max(0,Population.cons),2);
			CVmax = max(CV); 
			Pf      = sum(CV==0)/Problem.N;
			archive = Archive(Population,Problem.N);
			isFlag = true;
			isFlag2 = true;
			isFlag3 = true;
			
			[~,FrontNo,CrowdDis] = EnvironmentalSelectionnsga(Population,Problem.N);
			
			%% Optimization
			while Algorithm.NotTerminated(archive)
				if Problem.FE<=0.2*Problem.maxFE
					MatingPool = TournamentSelection(2,Problem.N,FrontNo,-CrowdDis);
					Offspring  = OperatorGA(Population(MatingPool));
					[Population,FrontNo,CrowdDis] = EnvironmentalSelectionnsga([Population,Offspring],Problem.N);
					archive = Archive([Population,archive],Problem.N);
				
				elseif Problem.FE<=0.6*Problem.maxFE
					if isFlag
						[f_con,f_dis] = Estimation(Population.objs,1/Problem.N^(1/Problem.M));
						f_fea = Calculate_fcv(Population); 
						Epsilon = Epsilon0;
						PopObj_1 = [f_fea,f_dis]; 
						[fm,~] = NDSort(PopObj_1,Problem.N);
						PopObj = [fm' + Epsilon * f_con,f_con];
						[frank,~] = NDSort(PopObj,Problem.N);
						fitness = frank' + f_fea./(f_fea+1);
						isFlag = false;
					
					end

					MatingPool = TournamentSelection(2,Problem.N,fitness);
					Offspring  = OperatorGA(Population(MatingPool));
					[f_con,f_dis] = Estimation(Offspring.objs,1/Problem.N^(1/Problem.M));
					f_fea = Calculate_fcv(Offspring); 
					OffObj_1 = [f_fea,f_dis]; 
					[fm,~] =NDSort(OffObj_1,Problem.N);
					OffObj = [fm' + Epsilon * f_con,f_con];
					[Population,fitness] = EnvironmentalSelection([Population,Offspring],PopObj,OffObj,Problem.N);
					[f_con,f_dis] = Estimation(Population.objs,1/Problem.N^(1/Problem.M));
					f_fea = Calculate_fcv(Population);
					PopObj_1 = [f_fea,f_dis]; 
					[fm,~] =NDSort(PopObj_1,Problem.N);
					PopObj = [fm' + Epsilon * f_con,f_con];
					archive = Archive([Population,archive],Problem.N);

				else
					
					if isFlag3
						Population = archive;
						isFlag3 = false;
					end
					
					gen = ceil(Problem.FE/Problem.N);
					CV = sum(max(0,Population.cons),2);
					CV_max = max(CV);
					CVmax = max([CV_max,CVmax]);

					Pop1_Fitness = CalFitness2(Population.objs,Population.cons);
					if length(Population) >= 2
						Rank = randperm(length(Population),floor(length(Population)/2)*2);
					else
						Rank = [1,1];
					end
					Loser  = Rank(1:end/2);
					Winner = Rank(end/2+1:end);
					Change = Pop1_Fitness(Loser) <= Pop1_Fitness(Winner);
					Temp   = Winner(Change);
					Winner(Change) = Loser(Change);
					Loser(Change)  = Temp;
					Offspring = Operator(Population(Loser),Population(Winner));
					
					Population = EnvironmentalSelectioncso([Population,Offspring],Problem.N);
					
					archive = Archive([Population,Offspring,archive],Problem.N);
					if Problem.FE >= Problem.maxFE
						Population = archive;
					end
				end
			end
			end
		end
	end
