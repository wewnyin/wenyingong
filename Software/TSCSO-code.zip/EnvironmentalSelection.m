function [Population,fitness] = EnvironmentalSelection(Population,PopObj,OffObj,N)
	[FrontNo,~] = NDSort([PopObj;OffObj],N);
    fcv = Calculate_fcv(Population); % CV of hybrid population
    fitness = FrontNo' + fcv./(fcv+1);
    [~,index] = sort(fitness);
    Population = Population(index(1:N));
    fitness = fitness(index(1:N));
end