function [Gm,NP,D,XRmin,XRmax,solution_num,Threshold,fun_name,kesi,radius] = Parameter(fun_num)
%EQUATIONS_ Summary of this function goes here
%   Detailed explanation goes here
   if fun_num==1
    Gm=1000;
    NP=10;  
    D = 2;
    XRmin = [-3, -3];
    XRmax = [3, 3];
    Threshold=0.01;
    solution_num=2;  
    fun_name='F01';
    kesi=10^-5;
    radius=0.01;
   end
   
   if fun_num==2
       
    Gm=5000;
    NP=10;  
    D = 2;
    XRmin = [-3, -3];
    XRmax = [3, 3];
    Threshold=0.01;
    solution_num=3;  
    fun_name='F02';    
    kesi=10^-5;
    radius=0.01;
   end
   
    if fun_num==3
   
    Gm=10000; 
    NP=10;  
    D = 3;
    XRmin = [0, 0,0];
    XRmax = [50, 50,50];
    Threshold=0.01;
    solution_num=2;  
%     error=20;
    fun_name='F03';
    kesi=10^-5;
    radius=0.01;  
   end

    
   
   if fun_num==4
       
    Gm=2000; 
    NP=10;  
    D = 2;
    XRmin = [-3, -3];
    XRmax = [3, 3];
    Threshold=0.01;
    solution_num=2;  
    fun_name='F04'; 
    kesi=10^-5; 
    radius=0.01;
   end
   
   if fun_num==5
       
   Gm=10000; 
    NP=10;  
    D = 2;
    XRmin = [-3, -3];
    XRmax = [3, 3];
    Threshold=0.01;
    solution_num=3;  
    fun_name='F05';   
    kesi=10^-5;
    radius=0.01;
    end
   
   if fun_num==6
    
    Gm=5000; 
    NP=10;  
    D = 3;
    XRmin = [0,0,0];
    XRmax = [1, 1,1];
    Threshold=0.01;
    solution_num=2;  
    fun_name='F06';  
    kesi=10^-5;
    radius=0.01;
   end
   
   if fun_num==7
    Gm=5000; 
    NP=10;  
    D = 2;
    XRmin = [-1, -1];
    XRmax = [2, 2];
    Threshold=0.01;
    solution_num=3;  
    fun_name='F07';
    kesi=10^-5;    
    radius=0.01;
   end
    
    if fun_num==8
         
    Gm = 5000;  
    NP=10;  
    D = 2;
    XRmin = [-1, -1];
    XRmax = [1, 1];
    Threshold=0.01;
    solution_num=2;
    fun_name='F08';
    kesi=10^-5;
    radius=0.01;
    end
    
    if fun_num==9
         
    Gm = 5000;  
    NP=10;  
    D = 20;
   XRmin = [-1, -1,-1, -1, -1,-1, -1, -1,-1, -1, -1,-1, -1, -1,-1, -1, -1,-1, -1, -1];
    XRmax = [1, 1,1, 1,1, 1,1, 1,1, 1,1, 1,1, 1,1, 1,1, 1,1,1];
    Threshold=0.01;
    solution_num=2;
    fun_name='F09';
    kesi=10^-5;
    radius=0.01;
    end
    
     if fun_num==10
         
    Gm = 5000;  
    NP=10;  
    D = 2;
    XRmin = [-1, -1];
    XRmax = [1, 1];
    Threshold=0.01;
    solution_num=11;
    fun_name='F10';
    kesi=10^-5;
    radius=0.01;
     end
    
    if fun_num==11  %the min value equal 1.0
         
    Gm = 5000;  
    NP=10;  
    D = 2;
    XRmin = [-1, -1];
    XRmax = [1, 1]; 
    Threshold=0.01;
    solution_num=15;
    fun_name='F11';
    kesi=10^-5;
    radius=0.01;
    end  
    
    if fun_num==12
        
    Gm = 5000;  
    NP=10;  
    D = 2;
   XRmin = [-10, -10];
    XRmax = [10, 10];
    Threshold=0.01;
    solution_num=13;
  %  error=12;
    fun_name='F12';
    kesi=10^-5;
    radius=0.01;
    end
    
     if fun_num==13 
        
    Gm = 5000;  
    NP=10;  
    D = 10;
    XRmin = [-2, -2 ,-2, -2 ,-2, -2 ,-2, -2 ,-2,-2];
    XRmax = [2, 2,2, 2,2, 2,2, 2,2, 2];
    Threshold=0.01;
    solution_num=1;
    fun_name='F13';
    kesi=10^-5;    
    radius=0.01;
     end
    
    if fun_num==14 
        
    Gm = 5000;  
    NP=10;  
    D = 2;
    XRmin = [-1, -1];
    XRmax = [1, 1]; 
    Threshold=0.01;
    solution_num=8;
    fun_name='F14';
    kesi=10^-5;
    radius=0.01;
    end
    
    if fun_num==15
   
    Gm =5000;  
    NP=10;  
    D = 4;
   XRmin = [0,0,0,0];
    XRmax = [5, 5,5,5]; 
    Threshold=0.01;
    solution_num=1;  
    fun_name='F15';
    kesi=10^-5;
    radius=0.01;
    end
   
    if fun_num==16
        
    Gm =5000;  
    NP=10;  
    D = 2;
    XRmin = [0, 0];
    XRmax = [1, 1]; 
    Threshold=0.01;
    solution_num=7;  
    fun_name='F16';
    kesi=10^-5;
    radius=0.01;
    end
    
     if fun_num==17
        
    Gm =10000;  
    NP=10;  
    D = 5;
    XRmin = [-10, -10,-10, -10, -10];
    XRmax = [10, 10, 10, 10, 10]; 
    Threshold=0.01;
    solution_num=3;  
    fun_name='F17';  
    kesi=10^-5;
    radius=0.01;
     end
    
    if fun_num==18
        
    Gm =5000;  
    NP=10;  
    D = 6;
   XRmin = [-1, -1, -1, -1, -1, -1];
    XRmax = [1, 1, 1, 1, 1, 1]; 
    Threshold=0.01;
    solution_num=1;  
    fun_name='F18';
    kesi=10^-5;
    radius=0.01;
    end
    
   if fun_num==19
        
    Gm =5000;  
    NP=10;  
    D = 2;
    XRmin = [-2, -2];
    XRmax = [2, 2]; 
    Threshold=0.01;
    solution_num=10;  
    fun_name='F19';
    kesi=10^-5;
    radius=0.01;
  end
    
   if fun_num==20
        
    Gm =5000;  
    NP=10;  
    D = 2;
    XRmin = [-5, -5];
    XRmax = [5, 5]; 
    Threshold=0.01;
    solution_num=9;  
    fun_name='F20';
    kesi=10^-5;
    radius=0.01;
   end
    
    if fun_num==21
    
    Gm =5000;  
    NP=10;  
    D = 2;
    XRmin = [0, 0];
    XRmax = [2*pi, 2*pi]; 
    Threshold=0.01;
    solution_num=13;  
    fun_name='F21';
    kesi=10^-5;
    radius=0.01;
    end
   
    if fun_num==22
    
    Gm =10000;  
    NP=10;  
    D = 8;
    XRmin = [-1, -1, -1, -1, -1, -1, -1, -1];
    XRmax = [1, 1, 1, 1, 1, 1, 1, 1]; 
    Threshold=0.01;
    solution_num=16;  
    fun_name='F22';
    kesi=10^-5;
    radius=0.01;
    end 
    
   if fun_num==23
        
    Gm =5000;  
    NP=10;  
    D = 2;
    XRmin = [-2, -2];
    XRmax = [2, 2]; 
    Threshold=0.01;
    solution_num=6;  
    fun_name='F23';
    kesi=10^-5;
    radius=0.01;
   end
   
   if fun_num==24
        
    Gm =20000;  
    NP=10;  
    D = 10;
    XRmin = [-2, -2, -2, -2, -2, -2, -2, -2, -2, -2];
    XRmax = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2]; 
    Threshold=0.01;
    solution_num=2;  
    fun_name='F24';
    kesi=10^-5;
    radius=0.01;
   end
   
   if fun_num==25
        
    Gm =5000;  
    NP=10;  
    D = 3;
    XRmin =[-1,-1,-1];
    XRmax = [1,1,1];
    Threshold=0.01;
    solution_num=7;  
    fun_name='F25';
    kesi=10^-5;
    radius=0.01;
   end
   
   if fun_num==26
        
    Gm =5000;  
    NP=10;  
    D = 2;
    XRmin =[-2,-2];
    XRmax = [2,2];
    Threshold=0.01;
    solution_num=4;  
    fun_name='F26';
    kesi=10^-5;
    radius=0.01;
   end
   
    if fun_num==27
        
    Gm =5000;  
    NP=10;  
    D = 2;
    XRmin =[-2,-2];
    XRmax = [2,2];
    Threshold=0.01;
    solution_num=6;  
    fun_name='F27';
    kesi=10^-5;
    radius=0.01;
    end
   
     if fun_num==28
        
    Gm =10000;  
    NP=10;  
    D = 3;
    XRmin =[0,0,0];
    XRmax = [1,1,1];
    Threshold=0.01;
    solution_num=8;  
    fun_name='F28';
    kesi=10^-5;
    radius=0.01;
     end
        
    if fun_num==29
        
    Gm =5000;  
    NP=10;  
    D = 3;
    XRmin = [-5, -1,-5];
    XRmax = [5, 3,5];
    Threshold=0.01;
    solution_num=2;  
    fun_name='F29'; 
    kesi=10^-5;
    radius=0.01;
    end
    
     if fun_num==30
        
    Gm =5000;  
    NP=10;  
    D = 3;
    XRmin = [-0.6, -0.6,-2];
    XRmax = [0.6, 0.6,5];
    Threshold=0.01;
    solution_num=12;  
    fun_name='F30';
    kesi=10^-5;
    radius=0.01;
     end
    
    if fun_num==31
        
    Gm =5000;  
    NP=10;  
    D = 2;
    XRmin = [0, -10];
    XRmax = [1, 0];
    Threshold=0.01;
    solution_num=2;  
    fun_name='F31';
    kesi=10^-5;
    radius=0.01;
    end
    
    if fun_num==32
        
    Gm =5000;  
    NP=10;  
    D = 2;
    XRmin = [0, -4];
    XRmax = [2.5, 6];
    Threshold=0.01;
    solution_num=4;  
    fun_name='F32'; 
    kesi=10^-5;
    radius=0.01;
    end
    
    if fun_num==33
        
    Gm =5000;  
    NP=10;  
    D = 2;
    XRmin = [-1, -10];
    XRmax = [1, 10];
    Threshold=0.01;
    solution_num=4;  
    fun_name='F33';
    kesi=10^-5;
    radius=0.01;
    end
    
     if fun_num==34
        
    Gm =5000;  
    NP=10;  
    D = 2;
    XRmin = [0.25, 0.5];
    XRmax = [1, 2*pi];
    Threshold=0.01;
    solution_num=2;  
    fun_name='F34';
    kesi=10^-5;
    radius=0.01;
     end
    
   if fun_num==35
        
    Gm =5000;  
    NP=10;  
    D = 3;
    XRmin = [3, 2, 0.5];
    XRmax = [5, 4, 2];
    Threshold=0.01;
    solution_num=1;  
    fun_name='F35';
    kesi=10^-5;
    radius=0.01;
   end
    
   if fun_num==36
        
    Gm =5000;  
    NP=10;  
    D = 2;
    XRmin = [-1, -2];
    XRmax = [-0.1,2];
    Threshold=0.01;
    solution_num=2;  
    fun_name='F36';
    kesi=10^-5;
    radius=0.01;
   end
    
   if fun_num==37
        
    Gm =5000;  
    NP=10;  
    D = 3;
    XRmin = [1, 0.2, 0.1];
    XRmax = [2.5, 2, 3];
    Threshold=0.01;
    solution_num=1;  
    fun_name='F37';
    kesi=10^-5;
    radius=0.01;
   end
    
    if fun_num==38
        
    Gm =5000;  
    NP=10;  
    D = 2;
    XRmin = [-5, 0];
    XRmax = [1.5, 5];
    Threshold=0.01;
    solution_num=3;  
    fun_name='F38';
    kesi=10^-5;
    radius=0.01;
    end
    
    if fun_num==39
        
    Gm =5000;  
    NP=10;  
    D = 2;
    XRmin = [0, 10];
    XRmax = [2, 30];
    Threshold=0.01;
    solution_num=2;  
    fun_name='F39';
    kesi=10^-5;
    radius=0.01;
    end
    
    if fun_num==40
        
    Gm =5000;  
    NP=10;  
    D = 3;
    %XRmin =-10;
    %XRmax = 10;
    XRmin = [0, -10, -1];
    XRmax = [2, 10 ,1];
    Threshold=0.01;
    solution_num=5;  
    fun_name='F40';
    kesi=10^-5;
    radius=0.01;
    end
    
     if fun_num==41
        
    Gm =5000;  
    NP=10;  
    D = 2;
    XRmin = [-2, 0];
    XRmax = [2, 1.1];
    Threshold=0.01;
    solution_num=4;  
    fun_name='F41';
    kesi=10^-5;
    radius=0.01;
     end
    
   if fun_num==42      
    Gm=5000;  
    NP=10;  
    D = 2;
    XRmin = [0.25, 1.5];
    XRmax = [1, 2*pi];
    Threshold=0.01;
    solution_num=2;  
    fun_name='F42';   
    kesi=10^-5;    
    radius=0.01;
   end
end

