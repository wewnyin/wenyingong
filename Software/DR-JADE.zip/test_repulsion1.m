%


    tic
    
   
    Iter_final_max=1;
    total_percentage=zeros(Iter_final_max,1);
    mean_root=zeros(Iter_final_max,1);
    mean_iter=zeros(Iter_final_max,1);
    store_NPF=zeros(Iter_final_max,1);
     store_FE=zeros(Iter_final_max,1);

               

%                  for p=[1:42]
         for p=2:2

        fun_num=p;
        
        Iter_final=1;
        total_mean_outcome=zeros(Iter_final_max,2);
         
         t=1;
       [Gm,NP,D,XRmin,XRmax,solution_num1,Threshold,fun_name,kesi,radius] = Parameter(fun_num);

       exact_solution=Exact_solution(fun_num);
     
    while Iter_final<=Iter_final_max
        
    
        Iter_final
       
        fun_name
         
    G1=1;
    solution = [];
    Iter_max=30;
    q=0;
    It=1;
    outCome=[];  
    total_iter=0;
    
   rmin=0.01*min(XRmax-XRmin);
   rmax=0.5*min(XRmax-XRmin);
    
    
   
    while It<=Iter_max
 
% ======================repulsion radius change from big to small==================================

                 error=rmin+(rmax-rmin)*(It/Iter_max-1).^2;

% =========================================================================

    
    [best_vector,best_value,solution_num,Threshold,fun_name,outcome,iter1] = JADE(solution,fun_num,error);
   
    
         total_iter=total_iter+iter1;
         bestValue=  Equations(best_vector,fun_num);
         
        if Equations(best_vector,fun_num)<kesi
            S=size(solution,1);
            w=[];          
             if S==0
                 q=q+1;
                 solution(q,:)=[bestValue,best_vector];
                 outCome(q)=bestValue;
 
             else
                
               all_vector=solution(:,2:end);
                w=sqrt(sum((repmat(best_vector,S,1)-all_vector).^2,2));
                              
              if all(w>Threshold)
                  q=q+1;
                  solution(q,:)=[bestValue,best_vector];
                  outCome(q)=bestValue;
              end
        end
      end  
     
    It=It+1;
    end
    
    

    

% =================  Compare with the exact solution===================
   total_solution=[];
   
%     solution=real(solution);
   
   inter_num=size(solution,1);
   iter_i=1;
   num_p=1;
   
   flag=zeros(solution_num,1);
   exactSolution=[exact_solution flag];
 
   while iter_i<=inter_num
       
       found=0;
         if solution(iter_i,1)<kesi
           [size_solution,np]=size(exactSolution);
              dist = sqrt(sum((repmat(solution(iter_i,2:end),size_solution,1)-exactSolution(:,2:np-1)).^2,2));
              [valu,dis]=min(dist);
              if valu<radius
                  index=dis;
%               index=find(dist<radius);
                 if exactSolution(index,np)==0
                    total_solution(num_p,:)=solution(iter_i,2:end);
                    found=1;
                    exactSolution(index,np)=1;
                    num_p=num_p+1;
                 end
              end
       end
       iter_i=iter_i+1;
   end
   

   
%  ======================================================================     
    S1=size(total_solution,1);
    
    store_FE(Iter_final,1)=total_iter;
    
    
    if S1<solution_num
        total_percentage(Iter_final)=0;
        mean_root(Iter_final)=S1;
        store_NPF(Iter_final,1)=S1;
    else
            total_percentage(Iter_final)=100;
            mean_root(Iter_final)=S1;
            store_NPF(Iter_final,1)=S1;
    end

    
     
     
    total_mean_outcome(Iter_final,:)=[mean(outCome),std(outCome)];
   
   Iter_final=Iter_final+1;
    end
 

     end

     toc




  
 


