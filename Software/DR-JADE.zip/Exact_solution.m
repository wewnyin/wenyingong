function y= Exact_solution( fun_num )
%EXACT_SOLUTION Summary of this function goes here
%   Detailed explanation goes here
    if fun_num==1
        load('exactResult/F01','A');
        y1=A;
    elseif  fun_num==2
        load('exactResult/F02','A');
        y1=A;
     elseif  fun_num==3
        load('exactResult/F03','A');
        y1=A;
     elseif  fun_num==42
        load('exactResult/F42','A');
        y1=A;
     elseif  fun_num==4
        load('exactResult/F04','A');
        y1=A;
     elseif  fun_num==5
        load('exactResult/F05','A');
        y1=A;
     elseif  fun_num==6
        load('exactResult/F06','A');
        y1=A;
     elseif  fun_num==7
        load('exactResult/F07','A');
        y1=A;
    
    elseif  fun_num==8
        load('exactResult/F08','A');
        y1=A;
    elseif  fun_num==9
        load('exactResult/F09','A');
        y1=A;
    elseif  fun_num==10
        load('exactResult/F10','A');
        y1=A;
    elseif  fun_num==11
        load('exactResult/F11','A');
        y1=A;
    elseif  fun_num==12
        load('exactResult/F12','A');
        y1=A;
     elseif  fun_num==13
        load('exactResult/F13','A');
        y1=A;
     elseif  fun_num==14
        load('exactResult/F14','A');
        y1=A;
    elseif fun_num==15
        load('exactResult/F15','A');
        y1=A;
    elseif fun_num==16
        load('exactResult/F16','A');
        y1=A;
    elseif fun_num==17
        load('exactResult/F17','A');
        y1=A;
    elseif fun_num==18
        load('exactResult/F18','A');
        y1=A;
    elseif fun_num==19
        load('exactResult/F19','A');
        y1=A;
    elseif fun_num==20
        load('exactResult/F20','A');
        y1=A;
    elseif fun_num==21
        load('exactResult/F21','A');
        y1=A;
    elseif fun_num==22
        load('exactResult/F22','A');
        y1=A;
     elseif fun_num==23
        load('exactResult/F23','A');
        y1=A;
    elseif fun_num==24
        load('exactResult/F24','A');
        y1=A;
     elseif fun_num==25
        load('exactResult/F25','A');
        y1=A;
     elseif fun_num==26
        load('exactResult/F26','A');
        y1=A;
     elseif fun_num==27
        load('exactResult/F27','A');
        y1=A;
      elseif fun_num==28
        load('exactResult/F28','A');
        y1=A;
      elseif fun_num==29
        load('exactResult/F29','A');
        y1=A;
      elseif fun_num==30
        load('exactResult/F30','A');
        y1=A;
      elseif fun_num==31
        load('exactResult/F31','A');
        y1=A;
      elseif fun_num==32
        load('exactResult/F32','A');
        y1=A;
      elseif fun_num==33
        load('exactResult/F33','A');
        y1=A;
      elseif fun_num==34
        load('exactResult/F34','A');
        y1=A;
        
      elseif fun_num==35
        load('exactResult/F35','A');
        y1=A;
      elseif fun_num==36
        load('exactResult/F36','A');
        y1=A;
      elseif fun_num==37
        load('exactResult/F37','A');
        y1=A;
      elseif fun_num==38
        load('exactResult/F38','A');
        y1=A;
      elseif fun_num==39
        load('exactResult/F39','A');
        y1=A;
      elseif fun_num==40
        load('exactResult/F40','A');
        y1=A;
      elseif fun_num==41
        load('exactResult/F41','A');
        y1=A;
    end
    
    
    
    y=y1;

end

