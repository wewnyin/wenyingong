function [best_vector,best_value,solution_num,Threshold,fun_name,outcome,iter1]=JADE(solution,fun_num,error)


outcome=[];
[Gm,NP,D,XRmin,XRmax,solution_num1,Threshold,fun_name,kesi,radius] = Parameter(fun_num);

 c = 1/10;
 p = 0.05;

 CRm = 0.9;
 Fm = 0.5;
 
  Afactor = 1;

  archive.NP = Afactor * NP; % the maximum size of the archive
  archive.pop = zeros(0, D); % the solutions stored in te archive
  archive.funvalues = zeros(0, 1); % the function value of the archived solutions
  
  


G=1;
%Lbound = XRmin*ones(1,D);

%lu = [-5 * ones(1, n); 5 * ones(1, n)];
   %lu= [XRmin*ones(1,D);XRmax*ones(1,D)];
   lu= [XRmin;XRmax];
%  lu=[0,-10,-1;2,10,1];
%DE_gbest = popold(ibest,:);
%DE_gbestval=val(i);

 rand('seed', sum(100 * clock));
 
        % Initialize the main population
        
         popold = repmat(XRmin, NP, 1) + rand(NP, D) .* repmat(XRmax-XRmin,NP,1);

        valParents = Equations12(popold,solution,fun_num,error,NP);


        
        %% the values and indices of the best solutions
        [valBest, indBest] = sort(valParents, 'ascend');
        
        iter=1;   
        It_uns=0;
        inter_value1=0;
 while iter < Gm/30             % & min(valBest)>10^-5         %   & Equations12(valBest,solution,fun_num,error)>10^-5
     
   
     pop = popold;
     
      if iter > 1 && ~isempty(goodCR) && sum(goodF) > 0 % If goodF and goodCR are empty, pause the update
          CRm = (1 - c) * CRm + c * mean(goodCR);
          Fm = (1 - c) * Fm + c * sum(goodF .^ 2) / sum(goodF); % Lehmer mean
      end
   
       [F, CR] = randFCR(NP, CRm, 0.1, Fm, 0.1);

       r0 = [1 : NP];
       popAll = [pop; archive.pop];
       [r1, r2] = gnR1R2(NP, size(popAll, 1), r0);
      
      
        % Find the p-best solutions
        pNP = max(round(p * NP), 2); % choose at least two best solutions
        randindex = ceil(rand(1, NP) * pNP); % select from [1, 2, 3, ..., pNP]
        randindex = max(1, randindex); % to avoid the problem that rand = 0 and thus ceil(rand) = 0
        pbest = pop(indBest(randindex), :); % randomly choose one of the top 100p% solutions
      
                   
     % == == == == == == == == == == == == == == == Mutation == == == == == == == == == == == == ==
              vi = pop + F(:, ones(1,D)) .* (pbest - pop + pop(r1, :) - popAll(r2, :));
%       DE/rand-to best/1
%              vi = pop(r1,:) + F(:, ones(1,D)) .* (pbest - pop(r1,:) + pop(r2, :) - pop(r3, :));
            
            vi = boundConstraint(vi, pop, lu,fun_num);
            

            % == == == == = Crossover == == == == =
         
            mask = rand(NP, D) > CR(:, ones(1, D)); % mask is used to indicate which elements of ui comes from the parent
            rows = (1 : NP)'; cols = floor(rand(NP, 1) * D)+1; % choose one position where the element of ui doesn't come from the parent
            jrand = sub2ind([NP D], rows, cols); mask(jrand) = false;
            ui = vi; ui(mask) = pop(mask);

            valOffspring = Equations12(ui,solution,fun_num,error,NP);
            
                        
             % == == == == == == == == == == == == == == == Selection == == == == == == == == == == == == ==
            % I == 1: the parent is better; I == 2: the offspring is better
            [valParents, I] = min([valParents, valOffspring], [], 2);
            popold = pop;

            archive = updateArchive(archive, popold(I == 2, :), valParents(I == 2));

            popold(I == 2, :) = ui(I == 2, :);

            goodCR = CR(I == 2);
            goodF = F(I == 2);

            [valBest indBest] = sort(valParents, 'ascend');
            
            

          iter=iter+1;
 end
        iter1=iter;
        outcome = [outcome min(valParents)];    
        best_vector = popold(indBest(1),:);
        best_value =  min(valBest);
        solution_num=solution_num1;   
         

         
         
 end

