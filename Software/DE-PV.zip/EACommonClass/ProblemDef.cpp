// ProblemDef.cpp: implementation of the CProblemDef class.
//
//////////////////////////////////////////////////////////////////////


#include "ProblemDef.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CProblemDef::CProblemDef()
{
	flag_once = 0;
}

CProblemDef::~CProblemDef()
{
}

void CProblemDef::evaluate_normal_fitness(double *xreal, tFitness &obj, double *constr, 
										  int func_flag, long int &evaluations)
{
	switch(func_flag) {
	// for PEMFC parameter identification
	case 1:
		PV_model_single(xreal, obj, constr);
		break;
	case 2:
		PV_model_double(xreal, obj, constr);
		break;
	case 3:
		PV_model_module(xreal, obj, constr);
		break;
	case 4:
		PV_model_module_double(xreal, obj, constr);
		break;
	default:
		printf("The function you selected does not exist.\n");
		exit(0);
		break;
	}
	evaluations++;
}

/************************************************************************/
/*  PV model with single-diode
    # of real variables = 5
    # of objectives     = 1
    # of constraints    = 0                                             */
/************************************************************************/
tFitness CProblemDef::calculate_objective_single(double *x, double V_L, double I_L)
{
	tFitness result = 0.0;
	
	double	I_ph;
	double	I_SD;
	double	R_s;
	double	R_sh;
	double	n;

	/* extracted parameters */
	I_ph	= x[0];
	I_SD	= x[1];
	R_s		= x[2];
	R_sh	= x[3];
	n		= x[4];

	double	q = 1.60217646e-19;
	double	k = 1.3806503e-23;
	double	T = 273.15 + 33.0;		// the temperature is set as 33 centi-degree
	double	V_t = k * T / q;

	result = I_ph - I_SD * ( exp( (V_L + I_L*R_s) / (V_t*n) ) - 1.0 ) - ( (V_L + I_L*R_s)/R_sh ) - I_L;

	return result;
}

void CProblemDef::PV_model_single(double *x, tFitness &obj, double *constr)
{
	int		i, j;

	double	o_data[100] = {0};
	
	if (flag_once == 0)
	{
		flag_once = 1;
		printf("The data is initialized only once.\n");

		/*********************************************************************/
		/* get data from the file                                            */ 
		FILE *fpt;
		fpt = fopen("data/cell_data.txt","r");
		
		fscanf(fpt,"%d",&data_len);
		
		for(i=0;i<data_len;i++)
		{
			fscanf(fpt,"%Lf%Lf",&actual_V_data[i], &actual_I_data[i]);
		}

		fclose(fpt);
		/*********************************************************************/
	}

	// calculate the fitness value
	tFitness fitness, error_value;
	double	ee=0.0;
	fitness = 0.0;
	for (j=0;j<data_len;j++)
	{	
		/*ee = 0.5;
		dmtcl(&ee, 1.0, 10, 1e-5, x, actual_V_data[j]);
		error_value = ee-actual_I_data[j];*/
		error_value = calculate_objective_single(x, actual_V_data[j], actual_I_data[j]);
// 		fitness     += fabs( error_value );					// individual absolute error
		fitness     += error_value * error_value;
	}
 	fitness = sqrt( (fitness)/(double)data_len );		// root mean square error (RMSE)

	obj = fitness;
}


/************************************************************************/
/*  PV model with double-diode
    # of real variables = 7
    # of objectives     = 1
    # of constraints    = 0                                             */
/************************************************************************/
tFitness CProblemDef::calculate_objective_double(double *x, double V_L, double I_L)
{
	tFitness result = 0.0;
	
	double	I_ph;
	double	I_SD1;
	double	R_s;
	double	R_sh;
	double	n1;
	double	I_SD2;
	double	n2;

	/* extracted parameters */
	I_ph	= x[0];
	I_SD1	= x[1];
	R_s		= x[2];
	R_sh	= x[3];
	n1		= x[4];
	I_SD2	= x[5];
	n2		= x[6];

	double	q = 1.60217646e-19;
	double	k = 1.3806503e-23;
	double	T = 273.15 + 33.0;		// the temperature is set as 33 centi-degree

	result = I_ph - I_SD1 * ( exp( (q*(V_L + I_L*R_s)) / (n1*k*T) ) -1.0 ) - I_SD2 * ( exp( (q*(V_L + I_L*R_s)) / (n2*k*T) ) -1.0 ) - ( (V_L + I_L*R_s)/R_sh ) - I_L;

	return result;
}

void CProblemDef::PV_model_double(double *x, tFitness &obj, double *constr)
{
	int		i, j;

	double	o_data[100] = {0};
	
	if (flag_once == 0)
	{
		flag_once = 1;
		printf("The data is initialized only once.\n");

		/*********************************************************************/
		/* get data from the file                                            */ 
		FILE *fpt;
		fpt = fopen("data/cell_data.txt","r");
		
		fscanf(fpt,"%d",&data_len);
		
		for(i=0;i<data_len;i++)
		{
			fscanf(fpt,"%Lf%Lf",&actual_V_data[i], &actual_I_data[i]);
		}

		fclose(fpt);
		/*********************************************************************/
	}

	// calculate the fitness value
	tFitness fitness, error_value;
	fitness = 0.0;
	for (j=0;j<data_len;j++)
	{
		error_value = calculate_objective_double(x, actual_V_data[j], actual_I_data[j]);
// 		fitness += fabs( error_value );					// individual absolute error
		fitness += error_value * error_value;
	}
	fitness = sqrt( (fitness)/(double)data_len );		// root mean square error (RMSE)

	obj = fitness;
}


/************************************************************************/
/*  PV model with module-diode
    # of real variables = 5
    # of objectives     = 1
    # of constraints    = 0                                             */
/************************************************************************/
tFitness CProblemDef::calculate_objective_module(double *x, double V_L, double I_L)
{
	tFitness result = 0.0;
	
	double	I_ph;
	double	I_SD;
	double	R_s;
	double	R_sh;
	double	n;

	/* extracted parameters */
	I_ph	= x[0];
	I_SD	= x[1];
	R_s		= x[2];
	R_sh	= x[3];
	n		= x[4];

	double	q  = 1.60217646e-19;
	double	k  = 1.3806503e-23;
	double	T  = 273.15 + 45.0;		// the temperature is set as 45 centi-degree
	int		Ns = 1;

	result = I_ph - I_SD * ( exp( (q*(V_L/Ns + I_L*R_s)) / (n*k*T) ) -1.0 ) - ( (V_L/Ns + I_L*R_s)/R_sh ) - I_L;
	//result = I_ph - I_SD * ( exp( (q*(V_L + I_L*R_s)) / (n*k*T*Ns) ) -1.0 ) - ( (V_L + I_L*R_s)/(R_sh) ) - I_L;

	return result;
}

void CProblemDef::PV_model_module(double *x, tFitness &obj, double *constr)
{
	int		i, j;

	double	o_data[100] = {0};
	
	if (flag_once == 0)
	{
		flag_once = 1;
		printf("The data is initialized only once.\n");

		/*********************************************************************/
		/* get data from the file                                            */ 
		FILE *fpt;
		fpt = fopen("data/module_data.txt","r");
		
		fscanf(fpt,"%d",&data_len);
		
		for(i=0;i<data_len;i++)
		{
			fscanf(fpt,"%Lf%Lf",&actual_V_data[i], &actual_I_data[i]);
		}

		fclose(fpt);
		/*********************************************************************/
	}

	// calculate the fitness value
	tFitness fitness, error_value;
	double ee = 0.0;
	fitness = 0.0;
	for (j=0;j<data_len;j++)
	{
		error_value = calculate_objective_module(x, actual_V_data[j], actual_I_data[j]);
		//fitness += fabs( error_value );					// individual absolute error
		fitness += error_value * error_value;
	}
	fitness = sqrt( (fitness)/(double)data_len );		// root mean square error (RMSE)

	obj = fitness;
}

/************************************************************************/
/*  PV model with module-diode
    # of real variables = 7
    # of objectives     = 1
    # of constraints    = 0                                             */
/************************************************************************/
tFitness CProblemDef::calculate_objective_module_double(double *x, double V_L, double I_L)
{
	tFitness result = 0.0;
	
	double	I_ph;
	double	I_SD1;
	double	R_s;
	double	R_sh;
	double	n1;
	double	I_SD2;
	double	n2;

	/* extracted parameters */
	I_ph	= x[0];
	I_SD1	= x[1];
	R_s		= x[2];
	R_sh	= x[3];
	n1		= x[4];
	I_SD2	= x[5];
	n2		= x[6];

	double	q = 1.60217646e-19;
	double	k = 1.3806503e-23;
	double	T = 273.15 + 45.0;		// the temperature is set as 45 centi-degree

	result = I_ph - I_SD1 * ( exp( (q*(V_L + I_L*R_s)) / (n1*k*T) ) -1.0 ) - I_SD2 * ( exp( (q*(V_L + I_L*R_s)) / (n2*k*T) ) -1.0 ) - ( (V_L + I_L*R_s)/R_sh ) - I_L;

	return result;
}

void CProblemDef::PV_model_module_double(double *x, tFitness &obj, double *constr)
{
	int		i, j;

	double	o_data[100] = {0};
	
	if (flag_once == 0)
	{
		flag_once = 1;
		printf("The data is initialized only once.\n");

		/*********************************************************************/
		/* get data from the file                                            */ 
		FILE *fpt;
		fpt = fopen("data/module_data.txt","r");
		
		fscanf(fpt,"%d",&data_len);
		
		for(i=0;i<data_len;i++)
		{
			fscanf(fpt,"%Lf%Lf",&actual_V_data[i], &actual_I_data[i]);
		}

		fclose(fpt);
		/*********************************************************************/
	}

	// calculate the fitness value
	tFitness fitness, error_value;
	double ee = 0.0;
	fitness = 0.0;
	for (j=0;j<data_len;j++)
	{
		error_value = calculate_objective_module_double(x, actual_V_data[j], actual_I_data[j]);
		//fitness += fabs( error_value );					// individual absolute error
		fitness += error_value * error_value;
	}
	fitness = sqrt( (fitness)/(double)data_len );		// root mean square error (RMSE)

	obj = fitness;
}





