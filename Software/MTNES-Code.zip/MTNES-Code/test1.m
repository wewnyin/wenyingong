clear all;%%%%14.2%crand/1+best/1   %%%%%��һ����12.44%%%  ---14.4%��һ���ԣ�rmp=0
clc
M_PR1=[];
M_PR2=[];
M_SR1=[];
M_SR2=[];

timeA = [];
NP = 100;
Iter_final_max = 25;

for index=1:9
    tic
    Pop = {};
%     Tasks = benchmark_NES(index); %%% get the task
    Tasks = New_benchmark_NES(index); %%% get the task
%     Tasks = Real_NES(index); %%% get the task
    no_of_tasks=length(Tasks);
    D=zeros(1,no_of_tasks);
    for i=1:no_of_tasks
        D(i)=Tasks(i).dims; %ÿ�������ά��
    end
    D_multitask=max(D); % �����������ά��
    solution1 =[];
    solution2=[];
    for Iter_final=1:Iter_final_max
        %%% ��ʼ�������������Ⱥ
        for i=1:no_of_tasks
            for j=1:NP  %%%% unified search space
                Pop{i}(j,:)=rand(1,D_multitask);
            end
        end
        [solution1,solution2,NFE]=MTNES(Pop,Tasks,NP,no_of_tasks,D_multitask);
        
        S1=size(solution1,1);
        if S1<Tasks(1).Nr
            SR1(Iter_final)=0;
            PR1(Iter_final) = S1/Tasks(1).Nr;
        else
            SR1(Iter_final)=1;
            PR1(Iter_final) = 1;
        end
        
        S2=size(solution2,1);
        if S2<Tasks(2).Nr
            SR2(Iter_final)=0;
            PR2(Iter_final) = S2/Tasks(2).Nr;
        else
            SR2(Iter_final)=1;
            PR2(Iter_final) = 1;
        end
        fprintf('The %d time of %d function has been completed\n',Iter_final,index);
    end
    M_PR1 = [M_PR1;Tasks(1).NESNo,mean(PR1)];
    M_SR1 = [M_SR1;Tasks(1).NESNo,mean(SR1)];
    
    M_PR2 = [M_PR2;Tasks(2).NESNo,mean(PR2)];
    M_SR2 = [M_SR2;Tasks(2).NESNo,mean(SR2)];
    tt = toc;
    timeA(index) = tt/Iter_final_max;
    
end
FinalPR = [M_PR1;M_PR2];
FinalSR = [M_SR1;M_SR2];
fprintf('PR = %4f\n',mean(FinalPR(:,2)));
fprintf('SR = %4f\n',mean(FinalSR(:,2)));







