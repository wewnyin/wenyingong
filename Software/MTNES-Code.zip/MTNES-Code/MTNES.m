function [solution_T1,solution_T2,NFE] = MTNES(Pop,Tasks,NP,no_of_tasks,D_multitask)

    archive = cell(1,no_of_tasks);
    archive_val = cell(1,no_of_tasks);
    
    historypop = cell(1,no_of_tasks);

    func_value = [];
    NFE= zeros(1,no_of_tasks);
    rmp = 0.5;
    
    muF = 0.5*ones(1,no_of_tasks);
    muCR = 0.9*ones(1,no_of_tasks);
    
    %%%% Evaluate the populations
    for task=1:no_of_tasks
        historypop{task}=Pop{task};
        for i=1:NP
            func_value(task,i) = fnceval(Tasks(task),Pop{task}(i,:));
            NFE(task) = NFE(task)+1;
        end
    end
    
    while NFE(1)<Tasks(1).Max_EFs || NFE(2)<Tasks(2).Max_EFs
        for task=1:no_of_tasks
            source_pop = [];
            if NFE(task)<Tasks(task).Max_EFs
                % select the source task to perform knowledge transfer
                task_idx = 1:no_of_tasks;
                task_idx(task) = [];
                c_idx = task_idx(randi(length(task_idx))); %%% ѡ���Դ����������
                % ��Դ�����Ŀ��ֵ��������ѡ���S�����Ž�
%                 [~,s_index] = sort(func_value(c_idx,:));
                source_pop = historypop{c_idx};
                
                 %%%%%Ԫ֪ʶǨ��
%                 [~, newindex] = sort(func_value(task,:));
%                 popsort = Pop{task}(newindex,:);
%                 PopTr = source_pop-mean(source_pop,1)+mean(popsort,1);
                
                %%%%��ȡĿ������ǰS����õĽ�
%                 target_pop = [];
%                 target_pop = popsort(1:S,:);
                
                %%%%%%%%%  �Ƿ�֪ʶǨ��
                [Pop{task},func_value(task,:), NFE(task),muF(task),muCR(task)] = NCADE1(Tasks(task),Pop{task},func_value(task,:),NFE(task),NP,D_multitask,rmp,source_pop,muF(task),muCR(task));
                historypop{task} = Pop{task};
                if Tasks(task).dims<=5
                    kesi=1e-6;
                    thresold = 0.001;
                else
                    kesi=1e-4;
                    thresold = 0.01;
                end
  
                for j=1:size(Pop{task},1)
                    real_x = [];
                    if func_value(task,j)<kesi
                        real_x = decode(Tasks(task),Pop{task}(j,:)); %%%��ʵ��ֵ���Ա���浵��Ϊ��0��1��ͬһ֪ʶ�ռ���ɵľ�������
                        [archive{task},archive_val{task}] = Repulsion_archive(real_x,func_value(task,j),archive{task},archive_val{task},NP,thresold);
%                         archive{task} = [archive{task};real_x];
%                         archive_val{task} = [archive_val{task},func_value(task,j)];
%                         if rand<rmp
%                             Pop{task}(j,:) = 1-Pop{task}(j,:);
%                         else
%                             Pop{task}(j,:) = rand(1,D_multitask);
%                         end
%                         func_value(task,j) = fnceval(Tasks(task),Pop{task}(j,:));
%                         NFE(task) = NFE(task)+1;
                    end
                end
            end
        end 
    end
    %%%% ����жϸ�
    for task=1:no_of_tasks
        root = [];
        final_pop = [];
        final_val = [];
        if Tasks(task).dims<=5
            kesi=1e-6;
            t_dis=0.01;
        else
            kesi=1e-4;
            t_dis=0.1;
        end
        root = Tasks(task).roots/mread(Tasks(task).NESNo);
%         root = Tasks(task).roots;
        final_pop = archive{task};
        final_val=archive_val{task};
        solution=[];
        root_index=1;
        for s=1:Tasks(task).Nr
            if size(final_pop,1)>0
                [minval,minindex]=min(sqrt(sum((ones(size(final_pop,1),1)*root(s,:)-final_pop).^2,2)));
                if final_val(minindex)<kesi && minval<=t_dis
                    solution(root_index,:)=[s,final_pop(minindex,:)];
                    root_index=root_index+1;
                end
            end
        end
        Fsolution{task} = solution;  
    end
    solution_T1 = Fsolution{1};
    solution_T2 = Fsolution{2};
    
end

