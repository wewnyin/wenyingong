function [Tasks] = New_benchmark_NES(index)
%BENCHMARK function
%   Input
%   - index: the index number of problem set
%
%   Output:
%   - Tasks: benchmark problem set
    addpath('./NewNESs');
    switch(index)
        case 1  % (F01,F02)
            dim = 20;
            Tasks(1).NESNo = 1;
            Tasks(1).dims = dim; % dimensionality of Task 1
            Tasks(1).Max_EFs = 100000;
            Tasks(1).fnc = @(x)F01(x);
            Tasks(1).Lb = -5*ones(1,dim); % Lower bound of Task 1
            Tasks(1).Ub = 5*ones(1,dim); %  Upper bound of Task 1
            Tasks(1).Nr = 4; % number of roots
            Tasks(1).roots = [1.5*ones(1,dim-1),3;1.5*ones(1,dim-1),4;-1.5*ones(1,dim-1),-3;-1.5*ones(1,dim-1),-4];

            dim = 35;
            Tasks(2).NESNo = 2;
            Tasks(2).dims = dim; % dimensionality of Task 2
            Tasks(2).Max_EFs = 100000; % Maximum function evalutions
            Tasks(2).fnc = @(x)F02(x); 
            Tasks(2).Lb = [-5*ones(1,dim-1),-30]; % Lower bound of Task 2
            Tasks(2).Ub = [5*ones(1,dim-1),30]; %  Upper bound of Task 2
            Tasks(2).Nr = 4; % number of roots
            Tasks(2).roots = [1.5*ones(1,dim-1),30;1.5*ones(1,dim-1),4;-1.5*ones(1,dim-1),-30;-1.5*ones(1,dim-1),-4];
        case 2 % (F04,F5)
            dim = 20;
            Tasks(1).NESNo = 4;
            Tasks(1).dims = dim; % dimensionality of Task 1
            Tasks(1).Max_EFs = 100000; % Maximum function evalutions
            Tasks(1).fnc = @(x)F04(x);
            Tasks(1).Lb = -1*ones(1,dim); % Lower bound of Task 1
            Tasks(1).Ub = (dim+1)*ones(1,dim); %  Upper bound of Task 1
            Tasks(1).Nr = 2; % number of roots
            Tasks(1).roots = [0*ones(1,dim);1:dim-1,-0.5];

            dim = 35;
            Tasks(2).NESNo = 5;
            Tasks(2).dims = dim; % dimensionality of Task 2
            Tasks(2).Max_EFs = 100000; % Maximum function evalutions
            Tasks(2).fnc = @(x)F05(x);
            Tasks(2).Lb = -1*ones(1,dim); % Lower bound of Task 2
            Tasks(2).Ub = [2:35,1]; %  Upper bound of Task 2
            Tasks(2).Nr = 2; % number of roots
            Tasks(2).roots = [0*ones(1,dim);1:dim-1,-0.5];
        case 3 % (F06,F08)
            dim = 2;
            Tasks(1).NESNo = 6;
            Tasks(1).dims = dim; % dimensionality of Task 1
            Tasks(1).Max_EFs = 50000; % Maximum function evalutions
            Tasks(1).fnc = @(x)F06(x);
            Tasks(1).Lb = [-1, -1]; % Lower bound of Task 1
            Tasks(1).Ub = [1, 1]; %  Upper bound of Task 1
            Tasks(1).Nr = 5; % number of roots
            Tasks(1).roots = [0,1;-1/3,-1;-1/3,0.5;1/3,-1;1/3,0.5];

            dim = 3;
            Tasks(2).NESNo = 8;
            Tasks(2).dims = dim; % dimensionality of Task 2
            Tasks(2).Max_EFs = 50000; % Maximum function evalutions
            Tasks(2).fnc = @(x)F08(x);
            Tasks(2).Lb = [-16,0,0]; % Lower bound of Task 2
            Tasks(2).Ub = [3,25,30]; %  Upper bound of Task 2
            Tasks(2).Nr = 5; % number of roots
            Tasks(2).roots = [1,22,2;1,3,1;-15,22,30;3,22,30;2,3,30];
        case 4 % (F11,F12)
            dim = 20;
            Tasks(1).NESNo = 11;
            Tasks(1).dims = dim; % dimensionality of Task 1
            Tasks(1).Max_EFs = 100000; % Maximum function evalutions
            Tasks(1).fnc = @(x)F11(x);
            Tasks(1).Lb = [-3*ones(1,dim-2),-20,-30]; % Lower bound of Task 1
            Tasks(1).Ub = [3*ones(1,dim-2),20,30]; %  Upper bound of Task 1
            Tasks(1).Nr = 6; % number of roots
            Tasks(1).roots = [0.5*ones(1,dim-2),-20,-20;0.5*ones(1,dim-2),20,30;0*ones(1,dim-2),10,-20;0*ones(1,dim-2),20,-10;-1*ones(1,dim-2),-20,-10;-1*ones(1,dim-2),10,30];

            dim = 30;
            Tasks(2).NESNo = 12;
            Tasks(2).dims = dim; % dimensionality of Task 2
            Tasks(2).Max_EFs = 100000; % Maximum function evalutions
            Tasks(2).fnc = @(x)F12(x);
            Tasks(2).Lb = -3*ones(1,dim); % Lower bound of Task 2
            Tasks(2).Ub = 3*ones(1,dim); %  Upper bound of Task 2
            Tasks(2).Nr = 6; % number of roots
            Tasks(2).roots = [0.5*ones(1,dim-2),-2,-2;0.5*ones(1,dim-2),2,3;0*ones(1,dim-2),1,-2;0*ones(1,dim-2),2,-1;-1*ones(1,dim-2),-2,-1;-1*ones(1,dim-2),1,3];
        case 5 % (F13,F14)
            dim = 15;
            Tasks(1).NESNo = 13;
            Tasks(1).dims = dim; % dimensionality of Task 1
            Tasks(1).Max_EFs = 50000; % Maximum function evalutions
            Tasks(1).fnc = @(x)F13(x);
            Tasks(1).Lb = -2*ones(1,dim); % Lower bound of Task 1
            Tasks(1).Ub = [2:dim-1,3,3]; %  Upper bound of Task 1
            Tasks(1).Nr = 6; % number of roots
            Tasks(1).roots = [0*ones(1,dim-2),1,-0.5;0.1*ones(1,dim-2),0.5,-0.5;0.1*ones(1,dim-2),-0.5,-0.5;1:dim-2,0.5,0.5;1:dim-2,-0.5,0.5;1:dim-2,1,0];

            dim = 4;
            Tasks(2).NESNo = 14;
            Tasks(2).dims = dim; % dimensionality of Task 2
            Tasks(2).Max_EFs = 50000; % Maximum function evalutions
            Tasks(2).fnc = @(x)F14(x);
            Tasks(2).Lb = [-2*ones(1,dim-2),-25,-10]; % Lower bound of Task 2
            Tasks(2).Ub = [2*ones(1,dim-2),35,35]; %  Upper bound of Task 2
            Tasks(2).Nr = 6; % number of roots
            Tasks(2).roots = [0.5*ones(1,dim-2),-25,-6;0.5*ones(1,dim-2),0.5,4;1.5*ones(1,dim-2),32,-6;1.5*ones(1,dim-2),0.5,30;-1*ones(1,dim-2),-25,30;-1*ones(1,dim-2),32,4];
        case 6 % (F03,F07)
            dim = 2;
            Tasks(1).NESNo = 3;
            Tasks(1).dims = dim; % dimensionality of Task 1
            Tasks(1).Max_EFs = 50000; % Maximum function evalutions
            Tasks(1).fnc = @(x)F03(x);
            Tasks(1).Lb = [-1,-45]; % Lower bound of Task 1
            Tasks(1).Ub = [2,45]; %  Upper bound of Task 1
            Tasks(1).Nr = 4; % number of roots
            Tasks(1).roots = [0,3;0,40;1,-3;1,-40];

            dim = 2;
            Tasks(2).NESNo = 7;
            Tasks(2).dims = dim; % dimensionality of Task 2
            Tasks(2).Max_EFs = 50000; % Maximum function evalutions
            Tasks(2).fnc = @(x)F07(x);
            Tasks(2).Lb = [-2,-15]; % Lower bound of Task 2
            Tasks(2).Ub = [2,15]; %  Upper bound of Task 2
            Tasks(2).Nr = 19; % number of roots
            Tasks(2).roots = [-1/3,-13;-2,10;-3/2,10;-1,10;-1/2,10;0,10;1/2,10;1,10;3/2,10;2,10;-2,-1;-3/2,-1;-1,-1;-1/2,-1;0,-1;1/2,-1;1,-1;3/2,-1;2,-1];
        case 7 % (F09,F18)
            dim = 3;
            Tasks(1).NESNo = 9;
            Tasks(1).dims = dim; % dimensionality of Task 1
            Tasks(1).Max_EFs = 50000; % Maximum function evalutions
            Tasks(1).fnc = @(x)F09(x);
            Tasks(1).Lb = [-3,0,0]; % Lower bound of Task 1
            Tasks(1).Ub = [3.2, 3.2,3.2]; %  Upper bound of Task 1
            Tasks(1).Nr = 20; % number of roots
            Tasks(1).roots = [2,3,3;1,3,1;1,1/4,2;1,3/4,2;1,5/4,2;1,7/4,2;1,9/4,2;1,11/4,2;3,1/4,3;3,3/4,3;3,5/4,3;3,7/4,3;3,9/4,3;3,11/4,3;-3,1/4,3;-3,3/4,3;-3,5/4,3;-3,7/4,3;-3,9/4,3;-3,11/4,3];

            dim = 3;
            Tasks(2).NESNo = 18;
            Tasks(2).dims = dim; % dimensionality of Task 2
            Tasks(2).Max_EFs = 50000; % Maximum function evalutions
            Tasks(2).fnc = @(x)F18(x);
            Tasks(2).Lb = [-2,-2,-5]; % Lower bound of Task 2
            Tasks(2).Ub = [4,2,5]; %  Upper bound of Task 2
            Tasks(2).Nr = 2; % number of roots
            Tasks(2).roots = [1.5,1.5,3;1.5,1.5,4];
        %%%%%%%%%%%%%%%%%% Same Nr, different dim
        case 8 % (F15,F16)
            dim = 3;
            Tasks(1).NESNo = 15;
            Tasks(1).dims = dim; % dimensionality of Task 1
            Tasks(1).Max_EFs = 50000; % Maximum function evalutions
            Tasks(1).fnc = @(x)F15(x);
            Tasks(1).Lb = [-2,-1,-2]; % Lower bound of Task 1
            Tasks(1).Ub = [2,1,2]; %  Upper bound of Task 1
            Tasks(1).Nr = 13; % number of roots
            Tasks(1).roots = [1/3,-1,-2;-1/3,-1,-2;5/3,-1,-2;-5/3,-1,-2;1/3,0.5,1;1/3,0.5,-1;-1/3,0.5,1;-1/3,0.5,-1;5/3,0.5,1;5/3,0.5,-1;-5/3,0.5,1;-5/3,0.5,-1;-1/4,-1,2];

            dim = 3;
            Tasks(2).NESNo = 16;
            Tasks(2).dims = dim; % dimensionality of Task 2
            Tasks(2).Max_EFs = 50000; % Maximum function evalutions
            Tasks(2).fnc = @(x)F16(x);
            Tasks(2).Lb = [-5,-5,-5]; % Lower bound of Task 2
            Tasks(2).Ub = [5,5,5]; %  Upper bound of Task 2
            Tasks(2).Nr = 11; % number of roots
            Tasks(2).roots = [1.5,1.5,3;1.5,1.5,4;1.5,-1.5,3;1.5,-1.5,4;1.5,0,5;0,2,3;0,2,4;0,0,-3;3,1.5,-3;3,-1.5,-3;3,2,5];
        case 9 % (F10,F17)
            dim = 3;
            Tasks(1).NESNo = 10;
            Tasks(1).dims = dim; % dimensionality of Task 1
            Tasks(1).Max_EFs = 50000; % Maximum function evalutions
            Tasks(1).fnc = @(x)F10(x);
            Tasks(1).Lb = [-1,-15,-1]; % Lower bound of Task 1
            Tasks(1).Ub = [2,15,1]; %  Upper bound of Task 1
            Tasks(1).Nr = 8; % number of roots
            Tasks(1).roots = [1,14,-0.5;1,-14,-0.5;1,1,1;2,1,0;2,-1,-0.5;-1,-14,0;-1,14,0;-1,-1,1];

            dim = 4;
            Tasks(2).NESNo = 17;
            Tasks(2).dims = dim; % dimensionality of Task 2
            Tasks(2).Max_EFs = 50000; % Maximum function evalutions
            Tasks(2).fnc = @(x)F17(x);
            Tasks(2).Lb = [-4,-4,-4,-4]; % Lower bound of Task 2
            Tasks(2).Ub = [4,4,4,4]; %  Upper bound of Task 2
            Tasks(2).Nr = 24; % number of roots
            Tasks(2).roots = [-1,1,-1,1;-1,1,-2,-2;-1,2,2,1;-1,-1,2,-2;-1,2,-2,-1;-1,-1,-1,-1;
                -2,2,-2,2;-2,2,1,1;-2,-1,-1,2;-2,-2,-1,1;-2,-1,1,-2;-2,-2,-2,-2;
                1,-1,1,-1;1,-1,2,2;1,-2,-2,-1;1,1,-2,2;1,-2,2,1;1,1,1,1;
                2,-2,2,-2;2,-2,-1,-1;2,1,1,-2;2,2,1,-1;2,1,-1,2;2,2,2,2];
    end
end

