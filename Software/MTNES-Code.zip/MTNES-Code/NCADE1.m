function [ pop1,val1, FES,muF,muCR] = NCADE1(Task,pop1,val1,FES,NP,D_multitask,rmp,source_pop,muF,muCR)
    D = D_multitask;
    real_D = Task.dims;
    XRmin = zeros(1,D_multitask);
    XRmax = ones(1,D_multitask);
    [F, CR] = randFCR(NP, muCR, 0.1, muF, 0.1); 
    SF = [];
    SCR = [];
    
    [~,sortindex] = sort(val1);

    nich_k=5;
    
    for j=1:NP
        jindex = find(sortindex==j);
        
        PP(j) = (NP-jindex)/NP;
        
        
        newpop = [];
        newval = [];
        distance= sqrt(sum((ones(NP,1)*pop1(j,1:real_D)-pop1(:,1:real_D)).^2,2));
        [~,dindex]=sort(distance);

        newpop = pop1(dindex(1:nich_k),:);
        newval=val1(dindex(1:nich_k));

        [~,bestid] = min(newval);
        bestx = newpop(bestid,:);
%         if rand<FES/Task.Max_EFs
            ui1(j,1:D) = DEbest1(bestx,pop1(j,:),newpop,F(j),CR(j),D,size(newpop,1),XRmin,XRmax,rmp,source_pop,real_D,nich_k);
%         else
%             ui1(j,1:D) = DErand1(pop1(j,:),newpop,F(j),CR(j),D,size(newpop,1),XRmin,XRmax,rmp,source_pop,real_D);
%         end
        
%         if rand<PP(j)
%             ui1(j,1:D) = DER2best1(bestx,pop1(j,:),newpop,F(j),CR(j),D,size(newpop,1),XRmin,XRmax,rmp,source_pop,real_D);
%         else
%             ui1(j,1:D) = DEbest1(bestx,pop1(j,:),newpop,F(j),CR(j),D,size(newpop,1),XRmin,XRmax,rmp,source_pop,real_D);
% %             ui1(j,1:D) = DErand1(pop1(j,:),newpop,F(j),CR(j),D,size(newpop,1),XRmin,XRmax,rmp,source_pop,real_D);
%         end
        
        ui_val1(j)=fnceval(Task,ui1(j,:));
        FES=FES+1;
         
         [~, index]=min(sqrt(sum((ones(NP,1)*ui1(j,1:real_D)-pop1(:,1:real_D)).^2,2)));
         if ui_val1(j)<val1(index)
            pop1(index,:)=ui1(j,:);
            val1(index)=ui_val1(j);
            SF = [SF,F(j)];
            SCR = [SCR,CR(j)];
         end   
    end
    if ~isempty(SF)
        muF = mean(SF);
        muCR = mean(SCR);
    end
end

