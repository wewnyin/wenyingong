function [archive,archive_val]=Repulsion_archive(pop,val,archive,archive_val,NP,thresold)
size_archive=size(archive,1);
max_archive=4*NP;
if size_archive==0
    archive=[archive;pop];
    archive_val=[archive_val,val];
    size_archive=size_archive+1;
else
    [temp k]=sort(sqrt(sum((ones(size(archive,1),1)*pop-archive).^2,2)));
    subpop=archive(k(1),:);
    subpop_val=archive_val(k(1));
    distance=sqrt(sum((subpop-pop).^2,2));
    if abs(distance)<thresold %%% 如果该个体与存档中距离最近的个体都小于预定的阈值，那么则用该个体替换掉存档中的最相似的个体
        if val<subpop_val
            archive(k(1),:)=pop;
            archive_val(k(1))=val;
        end
    elseif size_archive<max_archive  %%% 如果该个体与存档中的个体差别大于给定阈值，且存档大小没有超出，则将该个体放入存档
        archive=[archive;pop];
        archive_val=[archive_val,val];
        size_archive=size_archive+1;
    else  %%%% 如果存档大小超出了，且该个体的适应值小于存档中最相似的个体的值，则用该个体替换掉存档中最相似的个体
        [temp k]=sort(sqrt(sum((ones(size(archive,1),1)*pop-archive).^2,2)));
        subpop=archive(k(1),:);
        subpop_val=archive_val(k(1));
        if val<subpop_val
            archive(k(1),:)=pop;
            archive_val(k(1))=val;
        end
    end
end