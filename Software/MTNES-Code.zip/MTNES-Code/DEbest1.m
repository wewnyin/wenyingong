function ui=DEbest1(bestx,popold,pop,F,CR,n,NP,XRmin,XRmax,rmp,source_pop,real_D,nich_k)

    %%% ����֪ʶǨ�Ƶ�DE
    if rand<rmp %֪ʶǨ��
        temmpop = [pop;source_pop];
%         temmpop = source_pop;
        [~, k]=sort(sqrt(sum((ones(size(temmpop,1),1)*popold(1:real_D)-temmpop(:,1:real_D)).^2,2)));
        
        transpop = temmpop(k(1:nich_k),:);
        
        source_pop_NP = size(transpop,1);
        popindex = randperm(source_pop_NP);
        r1 = popindex(1);
        r2 = popindex(2);
        pm1=transpop(r1,1:n);
        pm2=transpop(r2,1:n);
    else
        index = randperm(NP);
        r1 = index(1);
        r2 = index(2);
        pm1=pop(r1,1:n);
        pm2=pop(r2,1:n);
    end
    mui = rand(1,n) < CR;          % all random numbers < CR are 1, 0 otherwise
    if mui==zeros(1,n),nn=randperm(n);mui(nn(1))=1;end

    mpo = mui < 0.5;                % inverse mask to mui
    ui = bestx + F*(pm1 - pm2);       % differential variation
    ui = popold.*mpo + ui.*mui;     % crossover

    if rand>0.5
        ui=(ui<XRmin).*XRmin+(ui>=XRmin).*ui;
        ui=(ui>XRmax).*XRmax+(ui<=XRmax).*ui;
    else
        ui=(ui<XRmin).*(XRmin+rand(1,n).*(XRmax-XRmin))+(ui>=XRmin).*ui;
        ui=(ui>XRmax).*(XRmin+rand(1,n).*(XRmax-XRmin))+(ui<=XRmax).*ui;
    end
end