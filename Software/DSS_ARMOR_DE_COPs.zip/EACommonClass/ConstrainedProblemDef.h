// ConstrainedProblemDef.h: interface for the CConstrainedProblemDef class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CONSTRAINEDPROBLEMDEF_H__7E5BBA9D_B8CA_4DD1_B4BD_DBED7B755F3B__INCLUDED_)
#define AFX_CONSTRAINEDPROBLEMDEF_H__7E5BBA9D_B8CA_4DD1_B4BD_DBED7B755F3B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "../global.h"
#include "Individual.h"

class CConstrainedProblemDef
{
public:
	CConstrainedProblemDef();
	virtual ~CConstrainedProblemDef();

	double epsilon;		// tolerance of the equality constraint

	void	evaluate_constraint_fitness(double *xreal,tFitness &obj, double *constr,
		 int &no_of_violation, int &feasible, double &cv,
		 int func_flag, long int &evaluations);

public:
	// constrained functions
	void test_01_g01 (double *x,tFitness &obj, double *constr, int &no_of_violation, int &feasible, double &cv);


};

#endif // !defined(AFX_CONSTRAINEDPROBLEMDEF_H__7E5BBA9D_B8CA_4DD1_B4BD_DBED7B755F3B__INCLUDED_)
