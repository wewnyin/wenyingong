// ConstrainedProblemDef.cpp: implementation of the CConstrainedProblemDef class.
//
//////////////////////////////////////////////////////////////////////

#include "ConstrainedProblemDef.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CConstrainedProblemDef::CConstrainedProblemDef()
{
	epsilon = 1e-4;		// tolerance of the equality conversion
}

CConstrainedProblemDef::~CConstrainedProblemDef()
{
}

void CConstrainedProblemDef::evaluate_constraint_fitness(double *x, tFitness &obj, double *constr,
													int &no_of_violation, int &feasible, double &cv,
													int func_flag, long int &evaluations)
{
	switch(func_flag) {
	case 1:
		test_01_g01(x,obj,constr,no_of_violation,feasible,cv);
		break;
	default:
		printf("The function you selected does not exist.\n");
		exit(0);
		break;
	}
	evaluations++;		// increase the number of fitness function evaluations
}

/*
   !!!!!!!!!!!!!!!!! NOTE !!!!!!!!!!!!!!!!!!!!
   1. Convert all of the constrained function into g(x) <= 0.0
   2. The objective problem does not convert into the minimal objective problem
*/

/*  Test problem g01
    # of real variables = 13
    # of bin variables = 0
    # of objectives = 1
    # of constraints = 9
    */
void CConstrainedProblemDef::test_01_g01(double *x,tFitness &obj, double *constr, int &no_of_violation, int &feasible, double &cv)
{
	double aux1,aux2,aux3;
	double fitaux,c[9];
	int i;

	fitaux=0.0;
	aux1=0.0;
	aux2=0.0;
	aux3=0.0;
	for(i=0;i<4;i++)
	{
		aux1+=x[i];
	}
	aux1*=5.0;
	for(i=0;i<4;i++)
	{
		aux2+=pow(x[i],2.0);
	}
	aux2*=5.0;
	for(i=4;i<13;i++)
	{
		aux3+=x[i];
	}
	fitaux=aux1-aux2-aux3;
	obj = fitaux;

	// all constraints are converted into g(x)<=0
	c[0]=0.0;
	fitaux=0.0;
	fitaux=(2.0*x[0])+(2.0*x[1])+x[9]+x[10]-10.0;
	c[0]=fitaux;

	c[1]=0.0;
	fitaux=0.0;
	fitaux=(2.0*x[0])+(2.0*x[2])+x[9]+x[11]-10.0;
	c[1]=fitaux;

	c[2]=0.0;
	fitaux=0.0;
	fitaux=(2.0*x[1])+(2.0*x[2])+x[10]+x[11]-10.0;
	c[2]=fitaux;

	c[3]=0.0;
	fitaux=0.0;
	fitaux=(-8.0*x[0])+x[9];
	c[3]=fitaux;

	c[4]=0.0;
	fitaux=0.0;
	fitaux=(-8.0*x[1])+x[10];
	c[4]=fitaux;

	c[5]=0.0;
	fitaux=0.0;
	fitaux=(-8.0*x[2])+x[11];
	c[5]=fitaux;

	c[6]=0.0;
	fitaux=0.0;
	fitaux=(-2.0*x[3])-x[4]+x[9];
	c[6]=fitaux;

	c[7]=0.0;
	fitaux=0.0;
	fitaux=(-2.0*x[5])-x[6]+x[10];
	c[7]=fitaux;

	c[8]=0.0;
	fitaux=0.0;
	fitaux=(-2.0*x[7])-x[8]+x[11];
	c[8]=fitaux;

	cv = 0.0;
	feasible = TRUE;
	no_of_violation = 0;
	for(i=0;i<CIndividual::N_of_constr;i++)
	{
		if(c[i]>0)
		{
			cv += c[i];
			feasible=FALSE;
			no_of_violation++;
		}
	}

	for (i=0;i<CIndividual::N_of_constr;i++)
	{
		if (c[i] <= 0.0)
		{
			c[i] = 0.0;
		}
		constr[i] = c[i];
	}

	return;
}




