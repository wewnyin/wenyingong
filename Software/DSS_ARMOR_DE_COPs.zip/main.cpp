#include "global.h"
#include "DE_method.h"

void welcome();

int main(int argc, char* argv[])
{
	welcome();

	double seed = 0.0;

	int func_index     = 1;
	int method;
	int RUN_NUMBER;
	int strategy_index = 1;		// 1: adaptive; 2: 0.2; 3: 0.5; 4: 1.0; 5: 2.0
	int output_counter = 0;

	/**/
	printf("function   = ");
	func_index = 1;
	cin>>func_index;

	printf("method     = ");
	method = 1;
	cin>>method;

	printf("RUN_NUMBER = ");
	RUN_NUMBER = 5;
	cin>>RUN_NUMBER;

	/*if (argc != 5 && argc != 6)
	{
		printf("Usage: DE_*.exe func_index method run_number out_counter\n");
		printf("OR--->\n");
		printf("Usage: DE_*.exe func_index method run_number out_counter strategy_index\n");
		exit(0);
	}
	if (argc == 5)
	{
		func_index     = atoi(argv[1]);
		method         = atoi(argv[2]);
		RUN_NUMBER     = atoi(argv[3]);
		output_counter = atoi(argv[4]);
	}
	else if (argc == 6)
	{
		func_index     = atoi(argv[1]);
		method         = atoi(argv[2]);
		RUN_NUMBER     = atoi(argv[3]);
		output_counter = atoi(argv[4]);
		strategy_index = atoi(argv[5]);
 	}*/

	srand((unsigned)time(NULL));


	CDE_method *DE_method;
	for (int i=0;i<RUN_NUMBER;i++)
	{
		int t = output_counter;
		int k = t*RUN_NUMBER;
		printf("--------- Run no. is %d ---------\n", k+i+1);
		//seed = ((double)(k+i+1))/((double)RUN_NUMBER);
		seed = ((double)(k+i+1))/((double)RUN_NUMBER);				// ........................................................ Total running times
		if (RUN_NUMBER == 1)
		{
			//seed = 0.86564;
			seed = 0.2;
		}
		//seed = ((double)(60+1))/100.0;				// test seed
		if (seed <= 0.0)
		{
			seed = 0.001;
		}
		if (seed >= 1.0)
		{
			seed = 0.99;
		}

		DE_method = new CDE_method;
		DE_method->Run_Optimizer(func_index, k+i, seed, method, strategy_index);
		delete DE_method;

		if ((i+1)%100 == 0 && (i+1) != RUN_NUMBER)	// pause
		{
			printf("\nPlease press ENTER key to continue.\n");
			getchar();
		}
	}

	return 0;
}

void welcome()
{
	printf("\n");
	printf("***************************************************************\n");
	printf("*             Welcome to use the DE optimizers.               *\n");
	printf("*        You can select and use the following optimizer.      *\n");
	printf("*                method = 1   for DSS_MDE_COPs                *\n");
	printf("*                method = 2   for rank_DSS_MDE_COPs           *\n");
	printf("***************************************************************\n");
	printf("\n");
}
