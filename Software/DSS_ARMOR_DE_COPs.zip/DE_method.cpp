// DE_method.cpp: implementation of the CDE_method class.
//
//////////////////////////////////////////////////////////////////////

#include "DE_method.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CDE_method::CDE_method()
{
	max_iterations = (Max_of_NFEs)/(population_size);
	max_NFFEs      = Max_of_NFEs;
	pop_size       = population_size;

	parent_pop   = new CIndividual[2*pop_size];
	child_pop    = new CIndividual[2*pop_size];
	child_pop1   = new CIndividual[2*pop_size];
	upper_bounds = new double[CIndividual::N_of_x];
	lower_bounds = new double[CIndividual::N_of_x];
	sort_index   = new int[2*pop_size];

	/************************************************************************/
	/* default parameter settings for DE method                             */
	/************************************************************************/
	m_F              = 0.5;
	m_CR             = 0.9;
	m_strategy       = 1;
}

CDE_method::~CDE_method()
{
	delete []parent_pop;
	delete []child_pop;
	delete []child_pop1;
	delete []upper_bounds;
	delete []lower_bounds;
	delete []sort_index;
}

void CDE_method::init_variables()
{
	if ( CIndividual::index_of_constrain==0 && CIndividual::index_of_cec2010==0 )
	{
		printf("Are you kinding me?\nThere is no function to be optimized.\n");
		exit(0);
	}
	if ( CIndividual::index_of_constrain!=0 && CIndividual::index_of_cec2010!=0 )
	{
		printf("There are too many functions to be optimized.\n");
		exit(0);
	}

	if (CIndividual::index_of_constrain != 0)
	{
		init_constrained_variables();
	}

	max_interval = 0;
	double temp;
	for (int i=0;i<CIndividual::N_of_x;i++)
	{
		temp = upper_bounds[i]-lower_bounds[i];
		max_interval += temp*temp;
	}
	max_interval = sqrt(max_interval);
}


void CDE_method::init_constrained_variables()
{
	int i;
	int n;
	func_flag = CIndividual::index_of_constrain;
	switch(func_flag) {
	case 1:
		CIndividual::N_of_x      = 13;
		CIndividual::N_of_constr = 9;

		n = CIndividual::N_of_x;
		for(i=0;i<9;i++)
		{
			lower_bounds[i] = 0;
			upper_bounds[i] = 1;
		}
		for(i=9;i<12;i++)
		{
			lower_bounds[i] = 0;
			upper_bounds[i] = 100;
		}
		lower_bounds[12] = 0;
		upper_bounds[12] = 1;
		known_optimal = -15.0;
		MINIMIZE = 1;
		break;
	default:
		printf("The function you selected does not exist.\n");
		exit(0);
	}
}

void CDE_method::init_pop()
{
	printf("Random based parent_pop initialization method is used.\n");
	init_pop_random();

	// initialize the F and CR of DE
	for (int i=0;i<pop_size;i++)
	{
		parent_pop[i].F  = m_rnd.rndreal(0.3, 0.9);
		parent_pop[i].CR = m_rnd.rndreal(0.9, 1.0);

		parent_pop[i].n_of_offspring = m_rnd.rndint(3, 7);
	}
}

void CDE_method::init_pop_random()
{
	int i, j;
	for (i=0;i<pop_size;i++)
	{
		for (j=0;j<CIndividual::N_of_x;j++)
		{
			parent_pop[i].xreal[j] = m_rnd.rndreal(lower_bounds[j],upper_bounds[j]);
		}
	}
}

void CDE_method::evaluate_ind(CIndividual &indv)
{
	if ( CIndividual::index_of_constrain==0)
	{
		printf("Are you kinding me?\nThere is no function to be optimized.\n");
		exit(0);
	}

	if (CIndividual::index_of_constrain != 0)
	{
		evaluate_constrained_ind(indv);
	}

	// convert objective function value into fitness
	indv.fitness = MINIMIZE*indv.obj;

	// sum violation of the constrained functions
	if (CIndividual::N_of_constr == 0)
	{
		indv.constr_violation = 0.0;
		indv.feasible         = 1;
	}
}

void CDE_method::evaluate_constrained_ind(CIndividual &indv)
{
	func_flag = CIndividual::index_of_constrain;

	constrained_func.evaluate_constraint_fitness(indv.xreal,indv.obj,indv.constr,
		indv.no_of_violation,indv.feasible,indv.constr_violation,
		func_flag, evaluations);
}

void CDE_method::evaluate_pop(CIndividual *pop, int size)
{
	for (int i=0;i<size;i++)
	{
		evaluate_ind(pop[i]);
	}
}

int CDE_method::compare_ind (CIndividual *indv1, CIndividual *indv2)
{
	if((indv1->feasible==TRUE && indv2->feasible==TRUE))
	{
		if(indv1->fitness < indv2->fitness)
		{
			return 1;
		}
		else if (indv1->fitness > indv2->fitness)
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
	else if(indv1->feasible==TRUE && indv2->feasible==FALSE)
	{
		return 1;
	}
	else if (indv1->feasible==FALSE && indv2->feasible==TRUE)
	{
		return -1;
	}
	else
	{
		if(indv1->constr_violation < indv2->constr_violation)
		{
			return 1;
		}
		else if (indv1->constr_violation > indv2->constr_violation)
		{
			return -1;
		}
		else
		{
			return 0;
			if (indv1->fitness < indv2->fitness)
			{
				return 1;
			}
			else if (indv1->fitness > indv2->fitness)
			{
				return -1;
			}
			else
			{
				return 0;
			}
		}
	}
}

void CDE_method::find_best_index(CIndividual *pop, int size)
{
	int i, flag;

	best_index = 0;
	for (i=1;i<size;i++)
	{
		flag = compare_ind(&pop[i], &pop[best_index]);
		if (flag == 1)
		{
			best_index = i;
		}
	}

	worst_index = 0;
	for (i=1;i<size;i++)
	{
		flag = compare_ind(&pop[i], &pop[worst_index]);
		if (flag == -1)
		{
			worst_index = i;
		}
	}
}

void CDE_method::random_index(int *array_index, int all_size, int size)
{
	int i,j,krand;
	int *a;
	a = new int[all_size];

	for(i = 0;i<all_size;i++)
	{
		a[i] = i;
	}
	for(i=0;i<size;i++)
	{
		j     = m_rnd.rndint(i,(all_size-1));
		krand = a[i];
		a[i]  = a[j];
		a[j]  = krand;
	}
	for(i=0;i<size;i++)
	{
		array_index[i] = a[i];
	}

	//a = NULL;
	delete []a;
}

void CDE_method::shell_sort_pop(CIndividual *pop, int *list, int size)
{
	int done;
	int step, bound, i, j;
	int temp;

	for (i=0;i<size;i++)
	{
		list[i] = i;
	}

	step = size;  // array length
	while (step > 1)
	{
		step /= 2;	//halve the step size
		do
		{
			done   = 1;
			bound  = size - step;
			for (j = 0; j < bound; j++)
			{
				i = j + step + 1;
				if (compare_ind(&pop[list[j]], &pop[list[i-1]]) == -1)
				{
					temp      = list[i-1];
					list[i-1] = list[j];
					list[j]   = temp;
					done      = 0; // if a swap has been made we are not finished yet
				}  // if
			}  // for
		} while (done == 0);   // while
	} //while (step > 1)
}

void CDE_method::shell_sort_array(double *array, int *list, int size)
{
	int done;
	int step, bound, i, j;
	int temp;

	for (i=0;i<size;i++)
	{
		list[i] = i;
	}

	step = size;  // array length
	while (step > 1)
	{
		step /= 2;	//halve the step size
		do
		{
			done   = 1;
			bound  = size - step;
			for (j = 0; j < bound; j++)
			{
				i = j + step + 1;
				if (array[list[j]] > array[list[i-1]])
				{
					temp      = list[i-1];
					list[i-1] = list[j];
					list[j]   = temp;
					done      = 0; // if a swap has been made we are not finished yet
				}  // if
			}  // for
		} while (done == 0);   // while
	} //while (step > 1)
}

void CDE_method::shell_sort_array_t(tFitness *array, int *list, int size)
{
	int done;
	int step, bound, i, j;
	int temp;

	for (i=0;i<size;i++)
	{
		list[i] = i;
	}

	step = size;  // array length
	while (step > 1)
	{
		step /= 2;	//halve the step size
		do
		{
			done   = 1;
			bound  = size - step;
			for (j = 0; j < bound; j++)
			{
				i = j + step + 1;
				if (array[list[j]] > array[list[i-1]])
				{
					temp      = list[i-1];
					list[i-1] = list[j];
					list[j]   = temp;
					done      = 0; // if a swap has been made we are not finished yet
				}  // if
			}  // for
		} while (done == 0);   // while
	} //while (step > 1)
}

double CDE_method::modulo(double a, double b)
{
	double value = 0.0;

	assert(b != 0.0);
	value = (a) - b * (floor((a)/b));

	return value;
}

double CDE_method::median(double *array, int size)
{
	double value = 0.0;

	int i, list[2000];
	for (i=0;i<2000;i++)
	{
		list[i] = i;
	}
	shell_sort_array(array, list, size);

	if (size%2 == 1)
	{// the size of the array is odd.
		int media_index;
		media_index = size/2;
		value = array[list[media_index]];
	}
	else
	{// the size of the array is even.
		int a = (size-1)/2;
		int b = size/2;
		value = (array[list[a]]+array[list[b]])/2.0;
	}

	return value;
}

double CDE_method::mean_std(double *array, int size, double &stdv)
{
	double value = 0.0;
	int i;

	assert(size > 0);

	for (i=0;i<size;i++)
	{
		value += array[i];
	}
	value = value/((double)size);

	stdv = 0.0;
	for (i=0;i<size;i++)
	{
		stdv += (array[i]-value)*(array[i]-value);
	}
	stdv = sqrt(stdv/((double)size-1));

	return value;
}

tFitness CDE_method::mean_std_t(tFitness *array, int size, tFitness &stdv)
{
	tFitness value = 0.0;
	int i;

	assert(size > 0);

	for (i=0;i<size;i++)
	{
		value += array[i];
	}
	value = value/((double)size);

	stdv = 0.0;
	for (i=0;i<size;i++)
	{
		stdv += (array[i]-value)*(array[i]-value);
	}
	stdv = sqrt(stdv/((double)size-1));

	return value;
}

void CDE_method::display_result(long int gen)
{
	if(gen%10==0 || gen == 1)
	{
		//��ǰ��ø����������Ļ
		cout<<setw(5)<<gen;
		cout<<setw(8)<<evaluations;
		//��ʾԼ��������ֵ
		if (CIndividual::N_of_constr != 0)
		{
			cout<<setw(15)<<best_individual.constr_violation;
		}
		cout.precision(10);					//�����������
		cout<<setw(20)<<MINIMIZE * parent_pop[best_index].fitness;
		cout<<setw(20)<<MINIMIZE * parent_pop[m_rnd.rndint(0, pop_size-1)].fitness;
		cout<<setw(20)<<MINIMIZE * parent_pop[worst_index].fitness<<endl;
	}
}

void CDE_method::report_result(long int gen, ofstream &file)
{
	if (gen < 10 )
	{
		//��ǰ��ø���������ļ�
		file<<setw(5)<<gen;
		file<<setw(10)<<evaluations;
		file.precision(20);			//�����������
		file<<setw(30)<<fabs(MINIMIZE * best_individual.fitness-known_optimal);
		file<<setw(30)<<best_individual.constr_violation;
		//file<<setw(30)<<best_individual.CR;
		file<<endl;
	}
	else
	{
		if ((gen % (max_iterations/out_internal) == 0 ||
			gen >= max_iterations ||
			evaluations >= max_NFFEs) )
		{
			//��ǰ��ø���������ļ�
			file<<setw(5)<<gen;
			file<<setw(10)<<evaluations;
			file.precision(20);			//�����������
			file<<setw(30)<<fabs(MINIMIZE * best_individual.fitness-known_optimal);
			file<<setw(30)<<best_individual.constr_violation;
			//file<<setw(30)<<best_individual.CR;
			file<<endl;
		}
	}
}

void CDE_method::report_diversity(long int gen, ofstream &file)
{
	// calculate the diversity of the population
	double x_average[2000];
	int i;
	for (i=0;i<2000;i++)
	{
		x_average[i] = 0.0;
	}

	for (i=0;i<CIndividual::N_of_x;i++)
	{
		for (int j=0;j<pop_size;j++)
		{
			x_average[i] += parent_pop[j].xreal[i];
		}
		x_average[i] = x_average[i]/((double)pop_size);
	}

	double diversity = 0.0;
	for (i=0;i<pop_size;i++)
	{
		double temp = 0.0;
		double x;
		for (int j=0;j<CIndividual::N_of_x;j++)
		{
			x = parent_pop[i].xreal[j];
			temp += (x-x_average[j])*(x-x_average[j]);
		}
		diversity += sqrt(temp);
	}
	diversity = diversity/(((double)pop_size)*max_interval);

	pop_diversity = diversity;

	if (gen < 100 )
	{
		//��ǰ��ø���������ļ�
		file<<setw(5)<<gen;
		file<<setw(10)<<evaluations;
		file.precision(20);			//�����������
		file<<setw(30)<<diversity<<endl;
	}
	else
	{
		if ((gen % out_internal == 0 ||
			gen >= max_iterations ||
			evaluations >= max_NFFEs) )
		{
			//��ǰ��ø���������ļ�
			file<<setw(5)<<gen;
			file<<setw(10)<<evaluations;
			file.precision(20);			//�����������
			file<<setw(30)<<diversity<<endl;
		}
	}
}

void CDE_method::report_parameter(long int gen, ofstream &file)
{
	int counter = max_iterations/20;
	if (method_flag==7 || method_flag==8 )
	{
		if (gen <=10 || gen%counter == 0)
		{
			//��ǰ��ø���������ļ�
			file<<setw(5)<<gen;
			file<<setw(10)<<evaluations;
			file.precision(20);			//�����������
			file<<setw(30)<<"0";
			file<<setw(30)<<"0";
			file<<setw(30)<<"0";
			file<<endl;
		}
	}
	else
	{
		if (gen <=10 || gen%counter == 0)
		{
			//��ǰ��ø���������ļ�
			file<<setw(5)<<gen;
			file<<setw(10)<<evaluations;
			file.precision(20);			//�����������
			file<<setw(30)<<best_individual.CR;
			file<<setw(30)<<best_individual.F;
			file<<setw(30)<<"0";
			file<<endl;
		}
	}
}

void CDE_method::sort_pop(CIndividual *pop, int size)
{
	for (int i=0;i<size;i++)
	{
		sort_index[i] = i;
	}
	shell_sort_pop(pop, sort_index, size);
}

// copy files from the source directory to the target directory
void CDE_method::copy_files(char *source, char *target)
{
	FILE *fs,*ft;
	char ma[204];
	unsigned int rd=0;

	fs=fopen(source, "rb");
	ft=fopen(target, "wb");
	if (fs&&ft)
	{
		while (!feof(fs))
		{
			rd=fread(ma,sizeof(char),204,fs);
			fwrite(ma,sizeof(char),rd,ft);
		}
		fclose(fs);
		fclose(ft);
	}
}

long CDE_method::filesize(FILE *stream)
{
	long curpos, length;
	curpos = ftell(stream);
	fseek(stream, 0L, SEEK_END);
	length = ftell(stream);
	fseek(stream, curpos, SEEK_SET);
	return length;
}

int CDE_method::copyfile(const char* src,const char* dest)
{
	FILE *fp1,*fp2;
	int fsize,factread;
	static unsigned char buffer[SIZEOFBUFFER];

	fp1=fopen(src,  "rb");
	fp2=fopen(dest, "wb+");
	if (!fp1 || !fp2)
	{
		return 0;
	}

    for (fsize=filesize(fp1);fsize>0;fsize-=SIZEOFBUFFER)
    {
		factread=fread(buffer,1,SIZEOFBUFFER,fp1);
		fwrite(buffer,factread,1,fp2);
    }
	fclose(fp1);
	fclose(fp2);
	return 1;
}

// create folders, only for batch execution
void CDE_method::create_folders(int method_ii, int strategy_ii)
{
	int status;
	int func_index;
	if (CIndividual::index_of_constrain)	func_index = CIndividual::index_of_constrain;
	if (CIndividual::index_of_cec2010)	    func_index = CIndividual::index_of_cec2010;

	/************************************************************************/
	/* Create the zero-order folders: function level                         */
	/************************************************************************/
	char f_name_0[150];
	// set the folder name
	sprintf(f_name_0,"%s%s%d", ".\\results", (func_index<10 ? "\\f0" : "\\f"), func_index);

	// create the folders
	status = mkdir(f_name_0);
	//if (!status==0)	printf("Unable to create directory 1\n");
	/************************************************************************/

	/************************************************************************/
	/* Create the first-order folders: method level                         */
	/************************************************************************/
	char f_name0[150];
	// set the folder name
	sprintf(f_name0,"%s%s%d%s%d", ".\\results", (func_index<10 ? "\\f0" : "\\f"), func_index, "\\algorithm_", method_ii);

	// create the folders
	status = mkdir(f_name0);
	//if (!status==0)	printf("Unable to create directory 1\n");
	/************************************************************************/

	/************************************************************************/
	/* Create the second-order folders: strategy level                      */
	/************************************************************************/
	char f_name00[150];
	// set the folder name
	sprintf(f_name00,"%s%s%d%s%d%s%d", ".\\results", (func_index<10 ? "\\f0" : "\\f"), func_index, "\\algorithm_", method_ii, "\\strategy_", strategy_ii);

	// create the folders
	status = mkdir(f_name00);
	//if (!status==0)	printf("Unable to create directory 1\n");
	/************************************************************************/

	/************************************************************************/
	/* Copy the statistic file to the strategy_level folder                 */
	/************************************************************************/
	char source_file_name[150] = ".\\Results\\1-DA-50.exe";
	char target_file_name[150];
	sprintf(target_file_name, "%s%s%d%s%d%s%d%s", ".\\results", (func_index<10 ? "\\f0" : "\\f"), func_index, "\\algorithm_", method_ii, "\\strategy_", strategy_ii, "\\1-DA-50.exe");
	//copy_files(source_file_name, target_file_name);
	copyfile(source_file_name, target_file_name);

	/************************************************************************/
	/* Create the third-order folders: results level                        */
	/************************************************************************/
	char f_name1[150];
	char f_name2[150];
	char f_name3[150];
	// set the folder name
	sprintf(f_name1, "%s%s%d%s%d%s%d%s", ".\\results", (func_index<10 ? "\\f0" : "\\f"), func_index, "\\algorithm_", method_ii, "\\strategy_", strategy_ii, "\\process");
	sprintf(f_name2, "%s%s%d%s%d%s%d%s", ".\\results", (func_index<10 ? "\\f0" : "\\f"), func_index, "\\algorithm_", method_ii, "\\strategy_", strategy_ii, "\\diversity");
	sprintf(f_name3, "%s%s%d%s%d%s%d%s", ".\\results", (func_index<10 ? "\\f0" : "\\f"), func_index, "\\algorithm_", method_ii, "\\strategy_", strategy_ii, "\\migration");

	// create the folders
	status = mkdir(f_name1);
	//if (!status==0)	printf("Unable to create directory 2\n");
	status = mkdir(f_name2);
	//if (!status==0)	printf("Unable to create directory 3\n");
	status = mkdir(f_name3);
	//if (!status==0)	printf("Unable to create directory 4\n");
	/************************************************************************/
}

void CDE_method::Run_Optimizer(int functions, int run_no, double seed, int method, int strategy_ii)
{
	m_strategy = strategy_ii;

    CIndividual::index_of_constrain = functions;
    CIndividual::index_of_cec2010   = 0;


	if (batch_execution==1)
	{
		create_folders(method, strategy_ii);
	}

	switch(method) {
    case 1:
        printf("Algorithm: DSS_MDE_COPs.\n");
		break;
    case 2:
        printf("Algorithm: rank_DSS_MDE_COPs.\n");
		break;
	default:
		printf("The method does not exist!!\n");
		exit(0);
	}

	switch(m_strategy) {
    case 1:// adaptive ranking
            printf("Feasibility-adaptive-based ranking!\n");
            break;
    case 2:// static ranking
            printf("Adaptive-penalty-based ranking!\n");
            break;
    case 3:// static ranking
            printf("other ranking!\n");
       	 	break;
    default:
            printf("The ranking technique does not exist.\n");
            exit(0);
    }

	int i = 0;

	method_flag = method;
	rnd_seed    = seed;

	int func_index;
	if (CIndividual::index_of_constrain)	func_index = CIndividual::index_of_constrain;

	ofstream SummaryFile;
	char     f_name0[150];
	if (batch_execution==0)
	{
		SummaryFile.open(".\\results\\summary.txt",ios::app);
	}
	if (batch_execution==1)
	{
		sprintf(f_name0, "%s%s%d%s%d%s%d%s", ".\\results", (func_index<10 ? ".\\f0" : ".\\f"), func_index, ".\\algorithm_", method, ".\\strategy_", strategy_ii, ".\\summary.txt");
		SummaryFile.open(f_name0, ios::app);
	}

	char f_name1[150];
	if (batch_execution==0)
	{
		sprintf(f_name1,"%s%d%s",".\\results\\process\\process_",run_no+1,".txt");
	}
	if (batch_execution==1)
	{
		sprintf(f_name1, "%s%s%d%s%d%s%d%s%d%s", ".\\results", (func_index<10 ? ".\\f0" : ".\\f"), func_index, ".\\algorithm_", method, ".\\strategy_", strategy_ii, ".\\process/process_" ,run_no+1,".txt");
	}
	ofstream file_process(f_name1);

	char f_name2[150];
	if (batch_execution==0)
	{
		sprintf(f_name2,"%s%d%s",".\\results\\diversity\\diversity_",run_no+1,".txt");
	}
	if (batch_execution==1)
	{
		sprintf(f_name2, "%s%s%d%s%d%s%d%s%d%s", ".\\results", (func_index<10 ? ".\\f0" : ".\\f"), func_index, ".\\algorithm_", method, ".\\strategy_", strategy_ii, ".\\diversity/diversity_",run_no+1,".txt");
	}
	ofstream file_diversity(f_name2);

	char f_name3[150];
	if (batch_execution==0)
	{
		sprintf(f_name3,"%s%d%s",".\\results\\migration\\migration_",run_no+1,".txt");
	}
	if (batch_execution==1)
	{
		sprintf(f_name3, "%s%s%d%s%d%s%d%s%d%s", ".\\results", (func_index<10 ? ".\\f0" : ".\\f"), func_index, ".\\algorithm_", method, ".\\strategy_", strategy_ii, ".\\migration/migration_",run_no+1,".txt");
	}
	ofstream file_migration(f_name3);

	clock_t start, finish;
	double time_consume;

	time_consume = 0.0;
	start = clock();						// starts the clock

	srand((unsigned)time(0));
	m_rnd.randomize(seed);

	evaluations = 0;						// reset the NFFEs

	init_variables();
	init_pop();
	evaluate_pop(parent_pop, pop_size);
	find_best_index(parent_pop, pop_size);
	best_individual = parent_pop[best_index];

	gen = 1;								// current generation number
	int counter=0;							// only for restarting the population

	report_result(gen, file_process);
	report_diversity(gen, file_diversity);
	report_parameter(gen, file_migration);

	int feasible_flag = 0;					// check to get the feasible individual first
	flag_precision = 0;						// check to arrive the required value
	/* -------- add different optimizer here -------- */
	while ( (evaluations < max_NFFEs) && (gen < max_iterations) )
	{
		finish = clock();					// time consuming of this generation
		time_consume = (double)(finish-start)/CLOCKS_PER_SEC;

		if (flag_precision == 0 &&
			fabs(MINIMIZE*best_individual.fitness - known_optimal) < PRECISION
			&& best_individual.feasible == 1)
		{
			flag_precision = 1;
			ofstream SummaryFile1;
			char     f_name00[150];
			if (batch_execution==0)
			{
				SummaryFile1.open(".\\results\\evaluations.txt",ios::app);
			}
			if (batch_execution==1)
			{
				sprintf(f_name00, "%s%s%d%s%d%s%d%s", ".\\results", (func_index<10 ? ".\\f0" : ".\\f"), func_index, ".\\algorithm_", method, ".\\strategy_", strategy_ii, ".\\evaluations.txt");
				SummaryFile1.open(f_name00, ios::app);
			}
			SummaryFile1<<setw(9)<<evaluations<<endl;
			SummaryFile1.close();
			//break;		// ������һ���ľ���ͳ����Ӧֵ���۴���ʱʹ��
		}
		if (CIndividual::N_of_constr != 0 && feasible_flag == 0 && best_individual.feasible == 1)
		{
			feasible_flag = 1;
			ofstream SummaryFile1;
			char     f_name000[150];
			if (batch_execution==0)
			{
				SummaryFile1.open(".\\results\\feasible_NFFEs.txt",ios::app);
			}
			if (batch_execution==1)
			{
				sprintf(f_name000, "%s%s%d%s%d%s%d%s", ".\\results", (func_index<10 ? ".\\f0" : ".\\f"), func_index, ".\\algorithm_", method, ".\\strategy_", strategy_ii, ".\\feasible_NFFEs.txt");
				SummaryFile1.open(f_name000, ios::app);
			}
			SummaryFile1<<setw(9)<<evaluations<<endl;
			SummaryFile1.close();
		}

		// report the results in the screen
		/* comment the following routines to save the time_consuming */
		//display_result(gen);

		// ADD YOUR OPTIMIZER HERE
		switch(method) {
        case 1:
            run_DSS_MDE_constraints();
            break;
        case 2:
            run_rank_DSS_MDE_constraints();
            break;
		default:
			printf("The selected method does not exist.\n");
			exit(0);
		}

		gen++;

		find_best_index(parent_pop, pop_size);

		if (compare_ind(&parent_pop[best_index], &best_individual) != -1)
		{
			best_individual = parent_pop[best_index];
		}

		report_result(gen, file_process);
		report_diversity(gen, file_diversity);
		report_parameter(gen, file_migration);
	}
	/* -------- add different optimizer here -------- */

	printf("The total running time is %f s.\n", time_consume);
	if (CIndividual::index_of_constrain != 0)
	{
		printf("The routine in optimizing c(%d) exits successfully.\n\n", CIndividual::index_of_constrain);
	}
	if (CIndividual::index_of_cec2010 != 0)
	{
		printf("The routine in optimizing c(%d) exits successfully.\n\n", CIndividual::index_of_cec2010);
	}

	SummaryFile.precision(20);
	SummaryFile<<setw(5)<<gen<<setw(9)<<evaluations
		<<setw(30)<<(MINIMIZE * best_individual.fitness)
		<<setw(30)<<fabs(MINIMIZE * best_individual.fitness-known_optimal)
		<<setw(25)<<best_individual.constr_violation
		//<<setw(8)<<time_consume
		<<endl;

	// ������Ÿ����Ա���
	if (func_index >= 31)
	{
        /**/ofstream file_variable;
        char f_name0000[150];
        if (batch_execution==0)
        {
            file_variable.open(".\\results\\x_variables.txt", ios::app);
        }
        else if (batch_execution==1)
        {
            sprintf(f_name0000, "%s%s%d%s%d%s%d%s", ".\\results", (func_index<10 ? ".\\f0" : ".\\f"), func_index, ".\\algorithm_", method, ".\\strategy_", strategy_ii, ".\\x_variables.txt");
            file_variable.open(f_name0000, ios::app);
        }
        for (i=0;i<CIndividual::N_of_x;i++)
        {
            file_variable.precision(12);
            file_variable<<setw(18)<<best_individual.xreal[i];
        }
        file_variable<<endl;
        file_variable.close();
	}

	// ������Ⱥ��
	/*ofstream final_pop(".\\results\\pop.txt");
	final_pop.precision(8);
	for (int i=0;i<pop_size;i++)
	{
		for (int j=0;j<CIndividual::N_of_x;j++)
		{
			final_pop<<setw(15)<<parent_pop[i].xreal[j];
		}
		final_pop<<setw(15)<<parent_pop[i].fitness<<endl;
	}
	final_pop.close();*/

	file_process.close();
	file_diversity.close();
	file_migration.close();
	SummaryFile.close();

	return;
}

/************************************************************************/
/* For constrained DE methods                                           */
/************************************************************************/
void CDE_method::shell_sort_pop_constraints(CIndividual *pop, int *list, int size)
{
	int done;
	int step, bound, i, j;
	int temp;

	for (i=0;i<size;i++)
	{
		list[i] = i;
	}

	step = size;  // array length
	while (step > 1)
	{
		step /= 2;	//halve the step size
		do
		{
			done   = 1;
			bound  = size - step;
			for (j = 0; j < bound; j++)
			{
				i = j + step + 1;
				if (compare_ind(&pop[list[j]], &pop[list[i-1]]) == -1)
				{
					temp      = list[i-1];
					list[i-1] = list[j];
					list[j]   = temp;
					done      = 0; // if a swap has been made we are not finished yet
				}  // if
			}  // for
		} while (done == 0);   // while
	} //while (step > 1)
}


/* Ranking-based on the feasible status */
	/* Ref:
	   Y. Wang, Z. Cai,
	   Constrained evolutionary optimization by means of mu+lambda-differential evolution and improved adaptive trade-off model,
	   Evolutionary Computation, 2011 19(2): 249-285
	*/
void CDE_method::semifeasible_fitness_transformation(CIndividual *pop, int size, double *transformed_fitness, double current_feasible_ratio)
{
	assert(size <= 500);
	assert(current_feasible_ratio>=0.0 && current_feasible_ratio<=1.0);

	int		i;
	double	f1[500];						// to save the converted objective function value
	double	f_best, f_worst;				// fitness of the best and worst feasible solutions

	/************************************************************************/
	/* convert the objective function value                                 */
	/************************************************************************/
	// find the fitness of the best and worst feasible solutions in the combined population
	f_best  = DBL_MAX;
	f_worst = -DBL_MAX;
	for (i=0;i<size;i++)
	{
		if (pop[i].constr_violation==0.0)////////////////////////////////////////////// 2013-04-29		constr_violation==0.0 or feasible==TRUE
		{
			if (pop[i].fitness < f_best)
			{
				f_best = pop[i].fitness;
			}
			if (pop[i].fitness > f_worst)
			{
				f_worst = pop[i].fitness;
			}
		}
	}

	//  convert the objective function values for the infeasible solutions
	for (i=0;i<size;i++)
	{
		if (pop[i].constr_violation==0.0)////////////////////////////////////////////// 2013-04-29		constr_violation==0.0 or feasible==TRUE
		{
			f1[i] = pop[i].fitness;
		}
		else
		{
			f1[i] = max(current_feasible_ratio*f_best + (1.0-current_feasible_ratio)*f_worst, pop[i].fitness);
		}
	}
	/************************************************************************/

	/************************************************************************/
	/* normalize the converted objective function values                    */
	/************************************************************************/
	double	f_nor[500];
	double	min_f1, max_f1;
	min_f1 = f1[0];
	max_f1 = f1[0];
	for (i=1;i<size;i++)
	{
		if (f1[i] < min_f1)
		{
			min_f1 = f1[i];
		}
		if (f1[i] > max_f1)
		{
			max_f1 = f1[i];
		}
	}

	for (i=0;i<size;i++)
	{
		f_nor[i] = (f1[i]-min_f1)/(max_f1-min_f1 + 1e-30);
	}
	/************************************************************************/

	/************************************************************************/
	/* normalize the constraint violation for the second criterion          */
	/************************************************************************/
	double	g_nor[500];
	double	max_g, min_g;
	{
		max_g = -DBL_MAX;
		min_g = DBL_MAX;
		for (i=0;i<size;i++)
		{
			if (pop[i].feasible==FALSE)////////////////////////////////////////////// 2013-04-29		constr_violation!=0.0 or feasible==FALSE
			{
				if (pop[i].constr_violation < min_g)
				{
					min_g = pop[i].constr_violation;
				}
				if (pop[i].constr_violation > max_g)
				{
					max_g = pop[i].constr_violation;
				}
			}
		}

		for (i=0;i<size;i++)
		{
			if (pop[i].feasible==TRUE)////////////////////////////////////////////// 2013-04-29				constr_violation==0.0 or feasible==TRUE
			{
				g_nor[i] = 0.0;
			}
			else
			{
				g_nor[i] = (pop[i].constr_violation-min_g)/(max_g-min_g + 1e-30);
			}
		}
	}
	/************************************************************************/

	/************************************************************************/
	/* get the final transformed fitness function                           */
	/* add the normalized objective function value and constraint violation */
	/************************************************************************/
	for (i=0;i<size;i++)
	{
		transformed_fitness[i] = f_nor[i] + g_nor[i];
	}
	/************************************************************************/
}

void CDE_method::feasibility_adaptive_ranking_probability(CIndividual *pop, int size, double *probability)
{
	int i;

	/************************************************************************/
	/* Calculate the ratio of feasible individuals in the population        */
	/************************************************************************/
	int		n_f = 0;
	double	ratio_feasible = 0.0;
	for (i=0;i<size;i++)
	{
		if (pop[i].feasible==TRUE)// constr_violation==0.0 or feasible==TRUE
		{
			n_f++;
		}
	}
	ratio_feasible = (double)(n_f)/((double)size);

	/************************************************************************/
	/* In the infeasible situation                                          */
	/************************************************************************/
	// we let the first half best solutions have the selected probability with 1.0
	// and the next half solutions have the selected probability with linearly decreased.
	if (ratio_feasible-0.0 < EPS)
	{
		shell_sort_pop_constraints(pop, sort_index, size);			// the population is sorted only by the constraint violation of each solution
		/*int tt = size/3;
		for (i=0;i<tt;i++)
		{
			probability[sort_index[i]] = 1.0;
		}
		for (i=tt;i<size;i++)
		{
			probability[sort_index[i]] = (double)(size-i-1)/(double)(size-tt);
		}*/

		/**/for (i=0;i<size;i++)
		{
			//probability[sort_index[i]] = pow( (double)(size-i-1)/size, 2.0 );					// quadratic model
			probability[sort_index[i]] = 0.5* ( 1.0 - cos(PI*(double)(size-i-1)/size) ) ;		// sin model
			//probability[sort_index[i]] = acos( 1.0 - 2.0*(double)(size-i-1)/size )/PI ;			// asin model

			assert(probability[sort_index[i]]>=0.0 && probability[sort_index[i]]<=1.0);
		}
	}

	/************************************************************************/
	/* In the semi-feasible situation                                       */
	/************************************************************************/
	// firstly, we transformed the fitness like the method proposed by Wang, et al in EC 2011,
	// then, the population is sorted according to the transformed fitness,
	// finally, the probabilities is calculated with the linear ranking method
	if (ratio_feasible>0.0 && ratio_feasible<1.0)
	{
		double transformed_fitness[population_size];
		semifeasible_fitness_transformation(pop, size, transformed_fitness, ratio_feasible);
		shell_sort_array(transformed_fitness, sort_index, size);
		for (i=0;i<size;i++)
		{
			//probability[sort_index[i]] = pow( (double)(size-i-1)/size, 2.0 );					// quadratic model
			probability[sort_index[i]] = 0.5* ( 1.0 - cos(PI*(double)(size-i-1)/size) ) ;		// sin model
			//probability[sort_index[i]] = acos( 1.0 - 2.0*(double)(size-i-1)/size )/PI ;			// asin model

			assert(probability[sort_index[i]]>=0.0 && probability[sort_index[i]]<=1.0);
		}
	}

	/************************************************************************/
	/* In the feasible situation                                            */
	/************************************************************************/
	// we use the quadratic model to calculate the probability of each solution
	if (ratio_feasible==1.0)
	{
		shell_sort_pop_constraints(pop, sort_index, size);
		for (i=0;i<size;i++)
		{
			//probability[sort_index[i]] = pow( (double)(size-i-1)/size, 0.5 );
			//probability[sort_index[i]] = 0.5* ( 1.0 - cos(PI*(double)(size-i-1)/size) ) ;		// sin model
			probability[sort_index[i]] = acos( 1.0 - 2.0*(double)(size-i-1)/size )/PI ;			// asin model

			assert(probability[sort_index[i]]>=0.0 && probability[sort_index[i]]<=1.0);
		}
	}
}

/************************************************************************/
/* Methods and attributes for DSS-MDE algorithm                         */
/************************************************************************/
/*
** Deb's three comparison criteria
** Inputs:  current population pop and the population size lambda
*/
void CDE_method::cmp_ranking(CIndividual *pop, int lambda)
{
	int i,a;
	a = 0;
	for (i=1; i<lambda-1; i++)
	{
		if (pop[a].constr_violation>pop[i].constr_violation || pop[a].constr_violation==pop[i].constr_violation && pop[a].fitness>pop[i].fitness)
		{
			a = i;
		}
	}
	sindex[0] = a;
}

/*
** Runarsson and Yao's Stochastic Ranking
** Inputs: current population pop, compare probability pf and the population size lambda
*/
void CDE_method::stochastic_ranking(CIndividual *pop, double pf, int lambda)
{
	int i,j,swap_count,a,b;
	double u;
	for (i=0; i<lambda; i++)
		sindex[i] = i;
	for (i=0; i<lambda; i++)
	{
		swap_count = 0;
		for (j=0; j<lambda-1; j++)
		{
			a = sindex[j];
			b = sindex[j+1];
			u = m_rnd.randomperc();
			if (pop[a].constr_violation==0 && pop[b].constr_violation==0 || u<pf)
			{
				if (pop[a].fitness>pop[b].fitness)
				{
					sindex[j]   = b;
					sindex[j+1] = a;
					swap_count ++;
				}
			}
			else if (pop[a].constr_violation>pop[b].constr_violation)
			{
				sindex[j]   = b;
				sindex[j+1] = a;
				swap_count ++;
			}
		}
		if (swap_count == 0)
			break;
	}
}

void CDE_method::run_DSS_MDE_constraints()
{
	int		i, j, k, j_rand;
	int		n = CIndividual::N_of_x;
	int		r1, r2, r3;
	double	tmp;
	double	low, up;

	if (1==gen)
	{
		no_of_children = 5;
		SR             = 0.45;
		m_CR		   = 0.9;
		m_F			   = 0.5;

		max_iterations = Max_of_NFEs/(no_of_children*population_size);
	}

	SR = 0.45 * ( 1.0-sqrt((double)(gen-1)/max_iterations) );

	for (i=0;i<pop_size;i++)
	{
		child_pop[0] = parent_pop[i];
		m_F          = m_rnd.rndreal(0.3, 0.9);
		for (j=0;j<no_of_children;j++)
		{
			do {
				r1 = m_rnd.rndint(0, pop_size-1);
			} while(0);
			do {
				r2 = m_rnd.rndint(0, pop_size-1);
			} while(r2==r1);
			do {
				r3 = m_rnd.rndint(0, pop_size-1);
			} while(r3==r2 || r3==r1);

			j_rand = m_rnd.rndint(0, n-1);
			for (k=0;k<n;k++)
			{
				low = lower_bounds[k];
				up  = upper_bounds[k];
				if (m_rnd.rndreal(0,1)<m_CR || k==j_rand)
				{
					tmp = parent_pop[r1].xreal[k] + m_F * (parent_pop[r2].xreal[k]-parent_pop[r3].xreal[k]);
				}
				else
				{
					tmp = parent_pop[i].xreal[k];
				}
				if (tmp<low || tmp>up)
				{
					tmp = m_rnd.rndreal(low, up);
				}
				child_pop[j+1].xreal[k] = tmp;
			}

			evaluate_ind(child_pop[j+1]);
		}

		if (SR > 0.0)
		{
			stochastic_ranking(child_pop, SR, no_of_children+1);
		}
		else
		{
			cmp_ranking(child_pop, no_of_children+1);
		}

		child_pop1[i] = child_pop[sindex[0]];
	}

	for (i=0;i<pop_size;i++)
	{
		parent_pop[i] = child_pop1[i];
	}
}

void CDE_method::run_rank_DSS_MDE_constraints()
{
	int		i, j, k, j_rand;
	int		n = CIndividual::N_of_x;
	int		r1, r2, r3;
	double	tmp;
	double	low, up;

	if (1==gen)
	{
		no_of_children = 5;
		SR             = 0.45;
		m_CR		   = 0.9;
		m_F			   = 0.5;

		max_iterations = Max_of_NFEs/(no_of_children*population_size);
	}

    /************************************************************************/
	/* update the SR in stochastic ranking                                  */
	/************************************************************************/
	SR = 0.45 * ( 1.0-sqrt((double)(gen-1)/max_iterations) );
	/************************************************************************/

	/************************************************************************/
	/* Calculate the probabilities of each individual based on its fitness  */
	/************************************************************************/
	double   probability[1000];
	feasibility_adaptive_ranking_probability(parent_pop, pop_size, probability);

	for (i=0;i<pop_size;i++)
	{
		child_pop[0] = parent_pop[i];
		m_F          = m_rnd.rndreal(0.3, 0.9);
		for (j=0;j<no_of_children;j++)
		{
			do {
				r1 = m_rnd.rndint(0, pop_size-1);
			} while(!m_rnd.flip(probability[r1]));
			do {
				r2 = m_rnd.rndint(0, pop_size-1);
			} while(r2==r1 || !m_rnd.flip(probability[r2]));
			do {
				r3 = m_rnd.rndint(0, pop_size-1);
			} while(r3==r2 || r3==r1);

			j_rand = m_rnd.rndint(0, n-1);
			for (k=0;k<n;k++)
			{
				low = lower_bounds[k];
				up  = upper_bounds[k];
				if (m_rnd.rndreal(0,1)<m_CR || k==j_rand)
				{
					tmp = parent_pop[r1].xreal[k] + m_F * (parent_pop[r2].xreal[k]-parent_pop[r3].xreal[k]);
				}
				else
				{
					tmp = parent_pop[i].xreal[k];
				}
				if (tmp<low || tmp>up)
				{
					tmp = m_rnd.rndreal(low, up);
				}
				child_pop[j+1].xreal[k] = tmp;
			}

			evaluate_ind(child_pop[j+1]);
		}

		if (SR > 0.0)
		{
			stochastic_ranking(child_pop, SR, no_of_children+1);
		}
		else
		{
			cmp_ranking(child_pop, no_of_children+1);
		}

		child_pop1[i] = child_pop[sindex[0]];
	}

	for (i=0;i<pop_size;i++)
	{
		parent_pop[i] = child_pop1[i];
	}
}




