classdef CMORWMDP< ALGORITHM
% <multi> <real/integer/label/binary/permutation> <constrained>
% Constrained multi-objective optimization for real-world mechanical design
% problems

    methods
        function main(Algorithm,Problem)
            %% Generate random population
            Population = Problem.Initialization();
            Fitness    = CalFitness(Population.objs,Population.cons);
            
            %% Optimization
            while Algorithm.NotTerminated(Population)
                MatingPool1 = TournamentSelection(2,Problem.N,Fitness);
                Offspring1  = OperatorDE(Problem,Population(1:end/2),Population(MatingPool1(1:end/2)),Population(MatingPool1(end/2+1:end)));
                MatingPool2 = TournamentSelection(2,Problem.N,Fitness);
                Offspring2  = OperatorGAhalf(Problem,Population(MatingPool2));
                [Population,Fitness] = EnvironmentalSelection_final([Population,Offspring1,Offspring2],Problem.N);
                
                if Problem.FE >= Problem.maxFE
                    CV = sum(max(0,Population.cons),2);
                    Population = Population(CV==0);
                end
            end
        end
    end
end