/* 
	Description: The C code of the DE algorithms with MS VC++ 6.0
	Optimizer:   Basic DE; jDE; jDE-DE 
	References:  1. J. of Global Optimization 1997, Basic DE
				 2. IEEE TEVC 2006, jDE
				 3. ..., jDE-DE
	Programmer:  Wenyin Gong
	E-mail:      cug11100304@yahoo.com.cn
	Date:	     27/5/2009
	Lisence:     Free
*/

#include "stdafx.h"

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>
#include <time.h>
#include <iostream.h>

/* Random number generator defined by URAND should return
   double-precision floating-point values uniformly distributed
   over the interval [0.0, 1.0)	*/
#define URAND			((double)rand()/((double)RAND_MAX + 1.0))

#define INF				1e99

#define N_of_x			30		/* number of decision variables */
#define pop_size		100		/* population size */
#define max_iteration	3000	/* maximal number of iteration */
#define PRECISION		1E-8	/* expected precision of the problem */

typedef struct 
{
	double xreal[N_of_x];	/* decision variables */
	double fitness;			/* fitness of the solution */
	double CR;				/* for jDE and jDE-DE */
	double FF;				/* for jDE and jDE-DE */
	double exploitation;	/* for jDE-DE */
	double KK;				/* for jDE-DE, not used in our paper */
}individual;

individual parent_pop[pop_size];/* save the parent population */
individual child_pop[pop_size];	/* save the child population */
double	lowerBound[N_of_x];		/* lower bounds of the decision variables */
double	upperBound[N_of_x];		/* upper bounds of the decision variables */
int		sort_index[pop_size];	/* only for sorting the population */
int		bestIndex;				/* index of the best solution in the current population */
int		worstIndex;				/* index of the worst solution in the current population */

int		evaluations;
int		gen_no;		
FILE	*fp;

individual best_individual;

/* some functions */
int		rndint(int);
double	rndreal(double, double);

void	init_variables();
void	init_pop_uniform();
double	evaluate_ind(double *);
void	evaluate_pop(individual *pop, int size);
void	copyIndividuals(individual *source, individual *target);
void	find_best_and_worst();

void	welcome();

void	Run_DE();
void	Run_jDE();
void	Run_jDE_DE();

int main(int argc, char* argv[])
{
	welcome();
	
	int run_num = 10;
	
	int method;
	printf("Please select the optimizer.\nmethod = ");
	cin>>method;

	for (int i=0;i<run_num;i++)
	{
		srand((unsigned)time(NULL));

		evaluations = 0;

		switch(method) {
		case 1:
			Run_DE();
			break;
		case 2:
			Run_jDE();
			break;
		case 3:
			Run_jDE_DE();
			break;
		default:
			printf("The selected optimizer does not exist.\n");
			exit(0);
		}
	}

	return 0;
}

void welcome()
{
	printf("\n");
	printf("***************************************************************\n");
	printf("*             Welcome to use the DE optimizers.               *\n");
	printf("*        You can select and use the following optimizer.      *\n");
	printf("*                method = 1   for Basic DE                    *\n");
	printf("*                method = 2   for jDE                         *\n");
	printf("*                method = 3   for jDE-DE                      *\n");
	printf("***************************************************************\n");
	printf("\n");
}

/* random number generator */
double rndreal(double low,double high)
{
	double  val;
	val = URAND*(high-low)+low;
	return (val);
}

int rndint(int Nmem)
{
	int newval;
	newval = (int)(URAND*Nmem);
	return(newval);
}

/* initialize the variables */
void init_variables()
{
	int i;
	for (i=0;i<N_of_x;i++)
	{
		lowerBound[i] = -500.0;
		upperBound[i] = 500.0;
	}
}

/* initialize the population */
void init_pop_uniform()
{
	int i, j;
	double low, up;

	for(i=0;i<pop_size;i++)
	{
		for(j=0;j<N_of_x;j++)
		{
			low = lowerBound[j];
			up  = upperBound[j];
			
			parent_pop[i].xreal[j] = rndreal(low, up);
		}

		// only for jDE and jDE-DE
		parent_pop[i].CR = rndreal(0.0, 1.0);
		parent_pop[i].FF = rndreal(0.1, 1.0);
		parent_pop[i].exploitation = rndreal(0.0, 1.0);
		parent_pop[i].KK = rndreal(0.0, 1.0);
	}
}

/* evaluate the individual */
double evaluate_ind(double *x)
{
	/* add different functions here */
	double value = 0.0;
	
	double obj;
	for (int i=0;i<N_of_x;i++)
	{
		value += x[i]*sin(sqrt(fabs(x[i]))); 
	}
	obj = -value + 418.9828872724337998*(double)N_of_x;
	value = obj;

//	for (int i=0;i<N_of_x;i++)
//	{
//		value += (x[i])*(x[i]);
//	}

	evaluations++;
		 
	return(value);
}

/* evaluate the population */
void evaluate_pop(individual *pop, int size)
{
	int i;
	for (i=0;i<size;i++)
	{
		pop[i].fitness = evaluate_ind(pop[i].xreal);
	}
}

/* find the best individual and worst individual in the current population */
void find_best_and_worst()
{
	int i;
	bestIndex  = 0;
	worstIndex = 0;
	for (i=1;i<pop_size;i++)
	{
		if (parent_pop[i].fitness <parent_pop[bestIndex].fitness)
		{
			bestIndex = i;
		}
		if (parent_pop[i].fitness > parent_pop[worstIndex].fitness)
		{
			worstIndex = i;
		}
	}
}

/* copy individuals */
void copyIndividuals(individual *source, individual *target)
{
	int i;
	for (i=0;i<N_of_x;i++)
	{
		target->xreal[i] = source->xreal[i];
	}
	target->fitness = source->fitness;
	target->CR = source->CR;
	target->FF = source->FF;
	target->exploitation = source->exploitation;
	target->KK = source->KK;
}

void Run_DE()
{
	int i, j;
	FILE *fp1, *fp2;
	clock_t start, finish;
	double time_consuming;

	srand(time(0));

	start = clock();

	init_variables();
	init_pop_uniform();
	evaluate_pop(parent_pop, pop_size);
	
	gen_no = 1;
	
	if((fp=fopen("process.txt","w"))==NULL)
	{
		printf("\nCannot open input file\n");
		exit(1);
	}

	if((fp1=fopen("results.txt","a"))==NULL)
	{
	    printf("\nCannot open input file\n");
        exit(1);
	}

	if((fp2=fopen("evaluations.txt","a"))==NULL)
	{
	    printf("\nCannot open input file\n");
        exit(1);
	}

	double CR = 0.9;
	double F  = 0.5;
	int    j_rnd;
	int    r1, r2, r3;
	int	   flag_eval = 0;
	while (gen_no < max_iteration)
	{
		find_best_and_worst();
		copyIndividuals(&parent_pop[bestIndex], &best_individual);

		if (flag_eval == 0 && best_individual.fitness < PRECISION)
		{
			flag_eval = 1;
			fprintf(fp2, "%d\n", evaluations);
		}
		
		finish = clock();
		time_consuming = (finish-start)/1000.0;

		if (gen_no%20 == 0)
		{
			//printf("gen=%6d eval=%8d fitness=%e\t%f s.\n", 
			//	gen_no, evaluations, best_individual.fitness, time_consuming);
			fprintf(fp, "%6d %8d %e\n", gen_no, evaluations, best_individual.fitness);
		}

		/* DE/rand/1/bin operator */
		for (i=0;i<pop_size;i++)
		{
			do {
				r1 = rndint(pop_size);
			} while(r1 == i);
			do {
				r2 = rndint(pop_size);
			} while(r2 == i || r2 == r1);
			do {
				r3 = rndint(pop_size);
			} while(r3 == i || r3 == r2 || r3 == r1);

			F = rndreal(0.1, 1.0);
			j_rnd = rndint(N_of_x);
			for (j=0;j<N_of_x;j++)
			{
				if (rndreal(0,1) < CR || j == j_rnd)
				{
					child_pop[i].xreal[j] = parent_pop[r1].xreal[j] +
						F*(parent_pop[r2].xreal[j]-parent_pop[r3].xreal[j]);
					if (child_pop[i].xreal[j] < lowerBound[j] ||
						child_pop[i].xreal[j] > upperBound[j])
					{
						child_pop[i].xreal[j] = 
							rndreal(lowerBound[j], upperBound[j]);
					}
				}
				else
				{
					child_pop[i].xreal[j] = parent_pop[i].xreal[j];
				}
			}
		}
		
		evaluate_pop(child_pop, pop_size);
		/* selection */
		for (i=0;i<pop_size;i++)
		{
			if (child_pop[i].fitness <= parent_pop[i].fitness)
			{
				copyIndividuals(&child_pop[i], &parent_pop[i]);
			}
		}

		gen_no++;
	}

	printf("gen=%d\teval=%d\tfitness=%e\t%f s.\n", 
		gen_no, evaluations, best_individual.fitness, time_consuming);
	/*printf("The best individual is: \n");
	for (i=0;i<N_of_x;i++)
	{
		printf("%.2f\t", best_individual.xreal[i]);
		if ((i+1)%5 == 0)
		{
			printf("\n");
		}
	}*/
	fprintf(fp1, "%d\t%d\t%e\t\n", gen_no, evaluations, 
		best_individual.fitness, time_consuming);

	fclose(fp);
	fclose(fp1);
	fclose(fp2);
}

void Run_jDE()
{
	int i, j;
	FILE *fp1, *fp2;
	clock_t start, finish;
	double time_consuming;

	srand(time(0));

	start = clock();

	init_variables();
	init_pop_uniform();
	evaluate_pop(parent_pop, pop_size);
	
	gen_no = 1;
	
	if((fp=fopen("process.txt","w"))==NULL)
	{
		printf("\nCannot open input file\n");
		exit(1);
	}

	if((fp1=fopen("results.txt","a"))==NULL)
	{
	    printf("\nCannot open input file\n");
        exit(1);
	}

	if((fp2=fopen("evaluations.txt","a"))==NULL)
	{
	    printf("\nCannot open input file\n");
        exit(1);
	}

	double CR = 0.9;
	double F  = 0.5;
	int    j_rnd;
	int    r1, r2, r3;
	int	   flag_eval = 0;
	while (gen_no < max_iteration)
	{
		find_best_and_worst();
		copyIndividuals(&parent_pop[bestIndex], &best_individual);

		if (flag_eval == 0 && best_individual.fitness < PRECISION)
		{
			flag_eval = 1;
			fprintf(fp2, "%d\n", evaluations);
		}
		
		finish = clock();
		time_consuming = (finish-start)/1000.0;

		if (gen_no%20 == 0)
		{
			fprintf(fp, "%6d %8d %e\n", gen_no, evaluations, best_individual.fitness);
		}

		/* DE/rand/1/bin operator */
		for (i=0;i<pop_size;i++)
		{
			do {
				r1 = rndint(pop_size);
			} while(r1 == i);
			do {
				r2 = rndint(pop_size);
			} while(r2 == i || r2 == r1);
			do {
				r3 = rndint(pop_size);
			} while(r3 == i || r3 == r2 || r3 == r1);

			/* self-adaptive control parameters */
			child_pop[i].CR = parent_pop[i].CR;
			child_pop[i].FF = parent_pop[i].FF;
			if (rndreal(0,1) < 0.1)
			{
				child_pop[i].CR = rndreal(0,1);
			}
			if (rndreal(0,1) < 0.1)
			{
				child_pop[i].FF = rndreal(0.1, 1.0);
			}
			CR = child_pop[i].CR;
			F  = child_pop[i].FF;

			j_rnd = rndint(N_of_x);
			for (j=0;j<N_of_x;j++)
			{
				if (rndreal(0,1) < CR || j == j_rnd)
				{
					child_pop[i].xreal[j] = parent_pop[r1].xreal[j] +
						F*(parent_pop[r2].xreal[j]-parent_pop[r3].xreal[j]);
					if (child_pop[i].xreal[j] < lowerBound[j] ||
						child_pop[i].xreal[j] > upperBound[j])
					{
						child_pop[i].xreal[j] = 
							rndreal(lowerBound[j], upperBound[j]);
					}
				}
				else
				{
					child_pop[i].xreal[j] = parent_pop[i].xreal[j];
				}
			}
		}
		
		evaluate_pop(child_pop, pop_size);
		/* selection */
		for (i=0;i<pop_size;i++)
		{
			if (child_pop[i].fitness <= parent_pop[i].fitness)
			{
				copyIndividuals(&child_pop[i], &parent_pop[i]);
			}
		}

		gen_no++;
	}

	printf("gen=%d\teval=%d\tfitness=%e\t%f s.\n", 
		gen_no, evaluations, best_individual.fitness, time_consuming);
	fprintf(fp1, "%d\t%d\t%e\t\n", gen_no, evaluations, 
		best_individual.fitness, time_consuming);

	fclose(fp);
	fclose(fp1);
	fclose(fp2);
}

void Run_jDE_DE()
{
	int i, j;
	FILE *fp1, *fp2;
	clock_t start, finish;
	double time_consuming;

	srand(time(0));

	start = clock();

	init_variables();
	init_pop_uniform();
	evaluate_pop(parent_pop, pop_size);
	
	gen_no = 1;
	
	if((fp=fopen("process.txt","w"))==NULL)
	{
		printf("\nCannot open input file\n");
		exit(1);
	}

	if((fp1=fopen("results.txt","a"))==NULL)
	{
	    printf("\nCannot open input file\n");
        exit(1);
	}

	if((fp2=fopen("evaluations.txt","a"))==NULL)
	{
	    printf("\nCannot open input file\n");
        exit(1);
	}

	double CR = 0.9;
	double F  = 0.5;
	int    j_rnd;
	int    r1, r2, r3;
	int	   flag_eval = 0;
	while (gen_no < max_iteration)
	{
		find_best_and_worst();
		copyIndividuals(&parent_pop[bestIndex], &best_individual);

		if (flag_eval == 0 && best_individual.fitness < PRECISION)
		{
			flag_eval = 1;
			fprintf(fp2, "%d\n", evaluations);
		}
		
		finish = clock();
		time_consuming = (finish-start)/1000.0;

		if (gen_no%20 == 0)
		{
			fprintf(fp, "%6d %8d %e\n", gen_no, evaluations, best_individual.fitness);
		}

		// only for jDE-DE
		double dynamic_gen = (double)gen_no/max_iteration;
		double factor;
		double KK;

		/* DE/rand/1/bin operator */
		for (i=0;i<pop_size;i++)
		{
			do {
				r1 = rndint(pop_size);
			} while(r1 == i);
			do {
				r2 = rndint(pop_size);
			} while(r2 == i || r2 == r1);
			do {
				r3 = rndint(pop_size);
			} while(r3 == i || r3 == r2 || r3 == r1);

			/* self-adaptive control parameters */
			child_pop[i].CR = parent_pop[i].CR;
			child_pop[i].FF = parent_pop[i].FF;
			if (rndreal(0,1) < 0.1)
			{
				child_pop[i].CR = rndreal(0,1);
			}
			if (rndreal(0,1) < 0.1)
			{
				child_pop[i].FF = rndreal(0.1, 1.0);
			}
			CR = child_pop[i].CR;
			F  = child_pop[i].FF;

			j_rnd = rndint(N_of_x);

			//KK = rndreal(0.1, 1.0);	// only for jDE-DE

			int elag = 0;
			int flag_once = 0;
			for (j=0;j<N_of_x;j++)
			{
				// only for jDE-DE
				if ( (rndreal(0,1) < CR || j == j_rnd) )
				{
					elag = 1;
				}
				else
				{
					elag = 0;
					// For each individual, exploitation and KK are only generated once.
					if (flag_once == 0)
					{
						flag_once = 1;
						child_pop[i].exploitation = parent_pop[i].exploitation;
						if (rndreal(0, 1) < 0.1)
						{
							child_pop[i].exploitation = rndreal(0, dynamic_gen);
						}
						factor = child_pop[i].exploitation;

						child_pop[i].KK = parent_pop[i].KK;
						if (rndreal(0,1) < 0.1)
						{
							child_pop[i].KK = rndreal(0.0, 1.0);
						}
						KK = child_pop[i].KK;
					}
				}

				if (elag == 1)
				{// DE/rand/1
					child_pop[i].xreal[j] = parent_pop[r1].xreal[j] +
						F*(parent_pop[r2].xreal[j]-parent_pop[r3].xreal[j]);
					
					if (child_pop[i].xreal[j] < lowerBound[j] ||
						child_pop[i].xreal[j] > upperBound[j])
					{
						child_pop[i].xreal[j] = 
							rndreal(lowerBound[j], upperBound[j]);
					}
				}
				else // elag == 0
				{
					if (rndreal(0,1) < factor)
					{
						// DE/best/1
						child_pop[i].xreal[j] = parent_pop[bestIndex].xreal[j] +
							KK*(parent_pop[r2].xreal[j]-parent_pop[r3].xreal[j]);

						if (child_pop[i].xreal[j] < lowerBound[j] ||
							child_pop[i].xreal[j] > upperBound[j])
						{
							child_pop[i].xreal[j] = 
								rndreal(lowerBound[j], upperBound[j]);
						}
					}
					else
					{// the original parent
						child_pop[i].xreal[j] = parent_pop[i].xreal[j];
					}
				}
			}
		}
		
		evaluate_pop(child_pop, pop_size);
		/* selection */
		for (i=0;i<pop_size;i++)
		{
			if (child_pop[i].fitness <= parent_pop[i].fitness)
			{
				copyIndividuals(&child_pop[i], &parent_pop[i]);
			}
		}

		gen_no++;
	}

	printf("gen=%d\teval=%d\tfitness=%e\t%f s.\n", 
		gen_no, evaluations, best_individual.fitness, time_consuming);
	fprintf(fp1, "%d\t%d\t%e\t\n", gen_no, evaluations, 
		best_individual.fitness, time_consuming);

	fclose(fp);
	fclose(fp1);
	fclose(fp2);
}