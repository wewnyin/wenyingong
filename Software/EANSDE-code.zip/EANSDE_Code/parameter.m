function  [MaxFEs,D,XRmin,XRmax,solution_num,solution,foptima] = parameter(funnum)
 load data/optima.mat; 
if funnum==1
    MaxFEs=50000;
    D=1;
    XRmin=0;
    XRmax=30;
    solution_num=2;
    solution=[0;30];
    foptima=200;
elseif funnum==2
    MaxFEs=50000;
    D=1;
    XRmin=0;
    XRmax=1;
    solution_num=5;
    solution=[0.1;0.3;0.5;0.7;0.9];
    foptima=1;
elseif funnum==3
    MaxFEs=50000;
    D=1;
    XRmin=0;
    XRmax=1;
    solution_num=1;
    solution=[0.079699779582100];
      foptima=1;
elseif funnum==4
    MaxFEs=50000;
    D=2;
    XRmin=[-6,-6];
    XRmax=[6,6];
    solution_num=4;
    solution=[3.584,-1.848; 3.0, 2.0;-2.805,3.131; -3.779,-3.283];
      foptima=200;
elseif funnum==5
    MaxFEs=50000;
    D=2;
    XRmin=[-1.9,-1.9];
    XRmax=[1.1,1.1];
    solution_num=2;
    solution=[0.0898, -0.7126; -0.0898, 0.7126];
    foptima=1.03163;
elseif funnum==6
    MaxFEs=200000;
    D=2;
    XRmin=[-10,-10];
    XRmax=[10,10];
    solution_num=18;
    solution=load('data/F6_2D_opt.dat');
    foptima=186.7309088310240;
elseif funnum==7
    MaxFEs=200000;
    D=2;
    XRmin=[0.25,0.25];
    XRmax=[10,10];
    solution_num=36;
    solution=load('data/F7_2D_opt.dat');
    foptima=1;
elseif funnum==8%��������
     MaxFEs=400000;
     D=3;
     XRmin=[-10,-10,-10];
     XRmax=[10,10,10];
     solution_num=81;
     solution=load('data/F6_3D_opt.dat');
foptima=2709.093505572820;
elseif funnum==9
     MaxFEs=400000;
     D=3;
     XRmin=[0.25,0.25,0.25];
     XRmax=[10,10,10];
     solution_num=216;
     solution=load('data/F7_3D_opt.dat');
     foptima=1;
elseif funnum==10
     MaxFEs=200000;
     D=2;
     XRmin=[0,0];
     XRmax=[1,1];
     solution_num=12;
     solution= load('data/F8_2D_opt.dat');
     foptima=-2.0;  
elseif funnum==11
     MaxFEs=200000;
     D=2;
     XRmin= -5*ones(1,D);
     XRmax=5*ones(1,D);
      solution_num=6;
	  o = o(:,1:D);
      solution=o(1:solution_num,1:D);
      foptima=0;
elseif funnum==12  
     MaxFEs=200000;
     D=2;
     XRmin= -5*ones(1,D);
     XRmax=5*ones(1,D);
      solution_num=8;
      solution=o(1:solution_num,1:D); 
      foptima=0;
elseif funnum==13
     MaxFEs=200000;
     D=2;
    XRmin= -5*ones(1,D);
     XRmax=5*ones(1,D);
      solution_num=6;
      solution=o(1:solution_num,1:D); 
      foptima=0;
elseif funnum==14
     MaxFEs=400000;
     D=3;
      XRmin=-5*ones(1,D);
      XRmax=5*ones(1,D);
      solution_num=6;
      solution=o(1:solution_num,1:D);  
      foptima=0;
elseif funnum==15
     MaxFEs=400000;
     D=3;
      solution_num=8;
      XRmin=-5*ones(1,D);
      XRmax=5*ones(1,D);
      solution=o(1:solution_num,1:D);
      foptima=0;
elseif funnum==16
    MaxFEs=400000;
    D=5;
       XRmin=-5*ones(1,D);
      XRmax=5*ones(1,D);
     solution_num=6;
     solution=o(1:solution_num,1:D);
     foptima=0;
elseif funnum==17
    MaxFEs=400000;
    D=5;
      XRmin=-5*ones(1,D);
      XRmax=5*ones(1,D);
     solution_num=8;
     solution=o(1:solution_num,1:D); 
     foptima=0;
elseif funnum==18
    MaxFEs=400000;
    D=10;
      XRmin=-5*ones(1,D);
      XRmax=5*ones(1,D);
     foptima=0;
     solution_num=6;
     solution=o(1:solution_num,1:D);
elseif funnum==19
    MaxFEs=400000;
    D=10;
      XRmin=-5*ones(1,D);
      XRmax=5*ones(1,D);
     foptima=0;
     solution_num=8;
     solution=o(1:solution_num,1:D);
elseif funnum==20
    MaxFEs=400000;
    D=20;
      XRmin=-5*ones(1,D);
      XRmax=5*ones(1,D);
    solution_num=8;
    solution=o(1:solution_num,1:D);
     foptima=0;
elseif funnum==51
   MaxFEs=200000;
    D = 8;
    %������
   % XRmin = [-3,-1,-2,-1,-1,-0.5,-1.5,-1.5];
  %  XRmax = [1,1,2,1,1,0.5,1.5,1.5];   
    %�β�RCADE
     XRmin = [-3,-1,-2,-1,-1,-1,-1.4,-1.1];
     XRmax = [3,1,2,1,1,1,1.4,1.1];
    solution_num=4;
   solution=[
    0.378136	0.583102	1.863559	0.829251	0.749801	0.335176	1.306394	1.086646;
0.378136	-0.583102	1.863559	0.829251	0.749801	0.335176	1.306394	-1.086646;
-2.64455	0.583102	1.863559	-0.829251	-0.749801	-0.335176	-1.306394	1.086646;
-2.64455	-0.583102	1.863559	-0.829251	-0.749801	-0.335176	-1.306394	-1.086646;];
foptima=0;
  elseif funnum==52
   MaxFEs=200000;
    NP=100;
    D = 9;
    %������
  % XRmin = [-0.5,-1,-1,-1,1,-1,-1,0,-1];
  % XRmax = [0.5,1,1,1,2,1,1,1,1];
 %�β�
  XRmin = [-1,-1,-1,-1,1,-1,-1,0,-1];
     XRmax = [1,1,1,1,2,1,1,1,1];
 %   XRmax = 2*ones(1,9);
    solution_num=4;
    solution=[0 0 0.49592916610169 0.328 1.475 0 0.93889242520687 0.00075458025211 0;
        0.13822998056871 0.52895199925097 0.00349088935328 0.31848234085023 1.48451765914977 0.00951765914977 0.94495076966886 0.00076434975528 0.15242273285488;
        0.12876431282348 0.49592916610169 0 0.328 1.475 0 0.93889242520687 0.00075458025211 0.14108031990518;
        -0.10002985383902 -0.42781123484657 0.09764987505113 0.51484610962593 1.28815389037407 -0.18684610962593 0.81995791876134 0.00057551532619 -0.09282189473363];
    foptima=0;
end
    






















end