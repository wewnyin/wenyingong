function [solution1,solution2,solution3]=EANSDE(Iter_final,NP,pop,fun_num,MaxFEs,D,XRmin,XRmax,solution_num,solution,foptima)
warning off
tic
M_CR=0.5;
M_F=0.5;
c=0.1;
SCR=[];
SF=[];
solution1=[];
solution2=[];
solution3=[];
FES = 0;
UI = [];
UI_VAL = [];
archive=[];
archiveval=[];
bestval=-Inf;
thresold=[0.01*ones(1,4) 0.5  0.5 0.2 0.5 0.2 0.01*ones(1,100)];
UI_archive_size=2*NP;
%root_archive_size=5*NP;
%root_val=1e-4;
dis=0.1;
min_val=1e-5;
val=niching_func(pop,fun_num);
val=val';
FES=FES+NP;

while FES<MaxFEs
   ui=[];
   ui_val = [];
   % Parametric Adaptive
   for j = 1:size(pop,1)
        A_CR(j)=normrnd(M_CR,0.1);%正态分布
        while (A_CR(j)>1||A_CR(j)<0)
            A_CR(j)=normrnd(0,0.1);  
        end
        
        A_F(j)=M_F + 0.1* tan(pi * (rand() - 0.5)); %柯西分布
        A_F(j)=min(1, A_F(j));
        while(A_F(j)<0)
            A_F(j)=M_F + 0.1* tan(pi * (rand() - 0.5));
            A_F(j)=min(1, A_F(j));
        end  
   end
   [sortval,sortindex]=sort(val,'descend');
   popsort=pop(sortindex,:);%根据适应值大小降序排列
   valsort=val(sortindex);
   bestval=max(bestval,valsort(1));
   clear spop;
   number=5;
   for i=1:(size(popsort,1)/number)
       [temp k]=sort(sqrt(sum((ones(size(popsort,1),1)*popsort(1,:)-popsort).^2,2)));
       spop(i).species = popsort(1,:);
       spop(i).speciesval=valsort(1);
       
       spop(i).min = valsort(number);
       spop(i).minval=valsort(number);
       
       checker = ones(size(popsort,1),1);
       checker(k(1:number),:) = 0;
       spop(i).pop = popsort(checker==0,:);
       spop(i).val = valsort(checker==0);
       popsort = popsort(checker==1,:);
       valsort = valsort(checker==1);
   end
   pop = popsort;
   val = valsort;
   x = 0;
   for i = 1:size(spop,2)
      for j = 1:size(spop(i).pop,1)
        popold = spop(i).pop(j,:);
        bm = spop(i).species;
        x = x + 1;
        st = 6;
        ui(x,:) = DE(popold,spop(i).pop,bm,st,A_F(x),A_CR(x),D,size(spop(i).pop,1),XRmin,XRmax);
      end
   end
   
   ui_val=niching_func(ui,fun_num);
   FES=FES + size(ui,1);
   x=0;
   n=1;
    for i=1:size(spop,2)
        for j=1:size(spop(i).pop,1)
            x=x+1;
           if ui_val(x)>spop(i).val(j)
%                 if abs(bestval-spop(i).val(j))<root_val
%                     [archive,archiveval]=Repulsion_archive(spop(i).pop(j,:),spop(i).val(j),archive,archiveval,D,root_archive_size,dis);
%                 end
                spop(i).val(j)=ui_val(x);
                spop(i).pop(j,:)=ui(x,:);
                
                SCR(n)=A_CR(x);
                SF(n)=A_F(x);
                n=n+1;
           else
               [UI,UI_VAL]=Repulsion_archive(ui(x,:),ui_val(x),UI,UI_VAL,D,UI_archive_size,dis);% Archive
           end
       end
    end
    M_CR=(1-c)*M_CR+c*mean(SCR);
    M_F=(1-c)*M_F+c*sum(SF .^ 2) / sum(SF);
    SCR=[];
    SF=[];
    for i = 1:size(spop,2)
        pop=[pop;spop(i).pop];
        val=[val,spop(i).val];
    end
    
    %---Crowding Relieving---
    i = 1;
    d2 = 0.1;
    while i<=size(pop,1)
       [temp k] = sort(sqrt(sum((ones(size(pop,1),1)*pop(i,:)-pop).^2,2)));
       e = 2; 
       Q = ones(size(pop,1),1);
       while e <= size(pop,1)
            if temp(e)<d2&&val(i)-val(k(e))>0&&val(i)-val(k(e))<min_val
                Q(k(e),:)=0;
            else
                break;
            end
            e=e+1;
       end
        pop=pop(Q==1,:);
        val=val(Q==1);
        i=i+1;
    end
    if size(pop,1)<NP%合并种群
        pop=[pop;UI];
        val=[val,UI_VAL];
        UI=[];
        UI_VAL=[];
    end

end
%--------------------------------------------
final_pop=[pop;UI;archive];
final_val=[val,UI_VAL,archiveval];
archive1=[];
archive2=[];
archive3=[];
archiveval1=[];
archiveval2=[];
archiveval3=[];
for i=1:size(final_pop,1)
    if abs(final_val(i)-foptima)<=1e-3
        archive1=[archive1;final_pop(i,:)];
        archiveval1=[archiveval1,final_val(i)];
    end
    if abs(final_val(i)-foptima)<=1e-4
        archive2=[archive2;final_pop(i,:)];
        archiveval2=[archiveval2,final_val(i)];
    end
    if abs(final_val(i)-foptima)<=1e-5
        archive3=[archive3;final_pop(i,:)];
        archiveval3=[archiveval3,final_val(i)];
    end
end
solution_index1=1;
solution_index2=1;
solution_index3=1;
for s=1:solution_num
    if size(archive1,1)>0
        [minval,minindex]=min(sqrt(sum((ones(size(archive1,1),1)*solution(s,:)-archive1).^2,2)));
        if minval<thresold(fun_num)
            solution1(solution_index1,:)=[s,archive1(minindex,:)];
            solution_index1=solution_index1+1;
        end
    end
    if size(archive2,1)>0
        [minval,minindex]=min(sqrt(sum((ones(size(archive2,1),1)*solution(s,:)-archive2).^2,2)));
        if minval<thresold(fun_num)
            solution2(solution_index2,:)=[s,archive2(minindex,:)];
            solution_index2=solution_index2+1;
        end
    end
    if size(archive3,1)>0
        [minval,minindex]=min(sqrt(sum((ones(size(archive3,1),1)*solution(s,:)-archive3).^2,2)));
        if minval<thresold(fun_num)
            solution3(solution_index3,:)=[s,archive3(minindex,:)];
            solution_index3=solution_index3+1;
        end
    end
end
toc  
end




