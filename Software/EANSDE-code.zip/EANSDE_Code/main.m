clc;
clear all;
tic
Iter_final_max=1;
total_percentage1=zeros(Iter_final_max,1);
store_NPF1=zeros(Iter_final_max,1);
total_percentage2=zeros(Iter_final_max,1);
store_NPF2=zeros(Iter_final_max,1);
MPR1=[];
MPR2=[];
MSR1=[];
MSR2=[];
MPR3=[];
MSR3=[];
global initial_flag
for fun_num =1:20
    initial_flag=0;
    store_NPF1=[];
    fun_num
    pop=[];
    final_solution1=[];
    final_solution2=[];
    Iter_final=1;
    [MaxFEs,D,XRmin,XRmax,solution_num,solution,foptima]=parameter(fun_num);
    solution1 = [];
    solution2=[];
    if fun_num<6
        NP=80;
    elseif fun_num==6||fun_num==10
        NP=100;
    elseif fun_num>6&&fun_num<10
        NP=300;
    elseif fun_num>10&&fun_num<21
        NP=200;
    else
        NP=100;
    end
    while Iter_final<=Iter_final_max
        Iter_final
        for i=1:NP
            pop(i,:)=XRmin+(XRmax-XRmin).*rand(1,D);
        end
        [solution1,solution2,solution3]=EANSDE( Iter_final,NP,pop,fun_num,MaxFEs,D,XRmin,XRmax,solution_num,solution,foptima);
        S1=size(solution1,1);
        S2=size(solution2,1);
        S3=size(solution3,1);
        if S1<solution_num
            total_percentage1(Iter_final)=0;
            store_NPF1(Iter_final,1)=S1;
        else
            total_percentage1(Iter_final)=100;
            store_NPF1(Iter_final,1)=S1;
        end
        S2=size(solution2,1);
        if S2<solution_num
            total_percentage2(Iter_final)=0;
            store_NPF2(Iter_final,1)=S2;
        else
            total_percentage2(Iter_final)=100;
            store_NPF2(Iter_final,1)=S2;
        end
        S3=size(solution2,1);
        if S3<solution_num
            total_percentage3(Iter_final)=0;
            store_NPF3(Iter_final,1)=S3;
        else
            total_percentage3(Iter_final)=100;
            store_NPF3(Iter_final,1)=S3;
        end
        Iter_final=Iter_final+1;
    end
    PR1=sum(store_NPF1)/(solution_num*Iter_final_max);%calculate the peak ratio
    SR1=mean(total_percentage1)/100;
    PR2=sum(store_NPF2)/(solution_num*Iter_final_max);            %calculate the peak ratio
    SR2=mean(total_percentage2)/100;
    PR3=sum(store_NPF3)/(solution_num*Iter_final_max);            %calculate the peak ratio
    SR3=mean(total_percentage3)/100
    MPR1=[MPR1;PR1];
    MSR1=[MSR1;SR1];
    MPR2=[MPR2;PR2];
    MSR2=[MSR2;SR2];
    MPR3=[MPR3;PR3];
    MSR3=[MSR3;SR3];
end
%     xlswrite('C:\Users\xxxL\Desktop\RESULT.xlsx',MPR1,'sheet2','B3');
%     xlswrite('C:\Users\xxxL\Desktop\RESULT.xlsx',MSR1,'sheet2','C3');
%     xlswrite('C:\Users\xxxL\Desktop\RESULT.xlsx',MPR2,'sheet2','D3');
%     xlswrite('C:\Users\xxxL\Desktop\RESULT.xlsx',MSR2,'sheet2','E3');
%     xlswrite('C:\Users\xxxL\Desktop\RESULT.xlsx',MPR3,'sheet2','F3');
%     xlswrite('C:\Users\xxxL\Desktop\RESULT.xlsx',MSR3,'sheet2','G3');
toc








