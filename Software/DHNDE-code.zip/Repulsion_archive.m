function [archive,archive_val]=Repulsion_archive(pop,val,archive,archive_val,D,max_archive,thresold)
size_archive=size(archive,1);
if size_archive==0
    archive=[archive;pop];
    archive_val=[archive_val,val];
else
    [temp k]=sort(sqrt(sum((ones(size(archive,1),1)*pop-archive).^2,2)));
    subpop=archive(k(1),:);
    subpop_val=archive_val(k(1));
    distance=sqrt(sum((subpop-pop).^2,2));
    if abs(distance)<thresold
        if val>subpop_val
            archive(k(1),:)=pop;
            archive_val(k(1))=val;
        end
    elseif   size_archive<max_archive
        archive=[archive;pop];
        archive_val=[archive_val,val];
    else
        [temp k]=sort(sqrt(sum((ones(size(archive,1),1)*pop-archive).^2,2)));
        subpop_val=archive_val(k(1));
        if val>subpop_val
            archive(k(1),:)=pop;
            archive_val(k(1))=val;
        end
    end
end