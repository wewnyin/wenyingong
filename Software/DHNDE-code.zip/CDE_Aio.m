function [FES,pop,val,UI,UI_VAL,archive,archiveval,root_archive_size]=CDE_Aio(FES,NP,pop,val,fun_num,MaxFEs,D,XRmin,XRmax,bestval,root_val,F,CR,UI,UI_VAL,UI_archive_size,dis,archive,archiveval,root_archive_size)
    ui=[];
    ui_val=[];
    subpop=[];
    [sortval,sortindex]=sort(val,'descend');
    bestval=max(bestval,sortval(1));
    num=5;
    for j=1:size(pop,1)
            A=pop;
            r1=round(rand*size(A,1)); r2=round(rand*size(A,1)); r3=round(rand*size(A,1));r4=round(rand*size(A,1));r5=round(rand*size(A,1));
            while (r1==0),r1=ceil(rand*size(A,1));end
            while (r2==r1|r2==0),r2=ceil(rand*size(A,1));end
            while (r3==r1|r3==r2|r3==0),r3=ceil(rand*size(A,1));end
            while (r4==r1|r4==r2|r4==r3|r4==0),r4=ceil(rand*size(A,1));end
            while (r5==r1|r5==r2|r5==r3|r5==r4|r5==0),r5=ceil(rand*size(A,1)); end
            subpop(j).pop=[A(r1,:);A(r2,:);A(r3,:);A(r4,:);A(r5,:)];
             st=2;
             ui(j,1:D)=DE( pop(j,:),subpop(j).pop, pop(j,:),st,F,CR,D,size(subpop(j).pop,1),XRmin,XRmax);
    end
    ui_val=niching_func(ui,fun_num);
    FES=FES+size(ui,1);
    [sortval,sortindex]=sort(val,'descend');
    bestval=max(bestval,sortval(1));
    for j=1:size(ui,1)
        [temp index]=min(sqrt(sum((ones(size(pop,1),1)*ui(j,:)-pop).^2,2)));
        if val(index)<ui_val(j)
            if abs(bestval-val(index))<root_val
                [archive,archiveval]=Repulsion_archive(pop(index,:),val(index),archive,archiveval,D,root_archive_size,dis);
            end
            pop(index,:)=ui(j,:);
            val(index)=ui_val(j);
        else
              UI=[UI;ui(j,:)];
             UI_VAL=[UI_VAL,ui_val(j)];
        end
    end
end
