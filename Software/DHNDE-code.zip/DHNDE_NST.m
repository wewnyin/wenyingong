function [solution1,solution2,solution3]=DHNDE_NST(Iter_final,NP,pop,fun_num,MaxFEs,D,XRmin,XRmax,solution_num,solution,foptima)
warning off
tic
solution1=[];
solution2=[];
solution3=[];
F=0.9;%ԭʼ����F=0.9,CR=0.1�ñ�Ĳ������ܲ�
CR=0.3;
FES=0;
UI=[];
UI_VAL=[];
archive=[];
archiveval=[];
bestval=-Inf;
thresold=[0.01*ones(1,4) 0.5  0.5 0.2 0.5 0.2 0.01*ones(1,100)];
UI_archive_size=2*NP;%���
root_archive_size=5*NP;
dis=0.01;
min_val=1e-5;
root_val=1e-4;
val=niching_func(pop,fun_num);
val=val';
FES=FES+NP;
num=0;
iw=1;
W=0;
maxT=20;
while FES<MaxFEs
        ui=[];
        ui_val=[];
        if iw==1%
            pop=[pop;UI];
            val=[val,UI_VAL];
            T=zeros(size(pop,1),1);
            [sortval,sortindex]=sort(val,'descend');
            popsort=pop(sortindex,:);%������Ӧֵ��С��������
            valsort=val(sortindex);
            bestval=max(bestval,valsort(1));
            iw=iw+1;
        else
            [sortval,sortindex]=sort(val,'descend');
            popsort=pop(sortindex,:);%������Ӧֵ��С��������
            valsort=val(sortindex);
            bestval=max(bestval,valsort(1));
        end
        clear spop;
        number=5;
        for i=1:(size(popsort,1)/number)
            [temp k]=sort(sqrt(sum((ones(size(popsort,1),1)*popsort(1,:)-popsort).^2,2)));
            spop(i).species=popsort(1,:);%��ǰ��Ⱥ����õ�
            spop(i).speciesval=valsort(1); %��ǰ��õ���Ӧֵ
            checker=ones(size(popsort,1),1);
            checker(k(1:number),:)=0;
            spop(i).pop=popsort(checker==0,:);%�ҳ�����õ�m=5����������µ���ȺͶ��DE��
            spop(i).val=valsort(checker==0);%��¼������������Ӧֵ
            spop(i).T=T(checker==0);
            T=T(checker==1);
            popsort=popsort(checker==1,:);%�����ʣ��ģ�Ȼ����ʣ���������
            valsort=valsort(checker==1);
        end
        pop=popsort;
        val=valsort;
         x=0;
        for i=1:size(spop,2)
            for j=1:size(spop(i).pop,1)
                popold=spop(i).pop(j,:);
                bm=spop(i).species;
                st=3;
                x=x+1;
                ui(x,:)=DE(popold,spop(i).pop,bm,st,F,CR,D,size(spop(i).pop,1),XRmin,XRmax);
            end
        end
        ui_val=niching_func(ui,fun_num);
        FES=FES + size(ui,1);
        x=0;
        for i=1:size(spop,2)
            for j=1:size(spop(i).pop,1)
                x=x+1;
                if ui_val(x)>spop(i).val(j)
                    spop(i).T(j)=0;   
                    if abs(bestval-spop(i).val(j))<root_val
                        [archive,archiveval]=Repulsion_archive(spop(i).pop(j,:),spop(i).val(j),archive,archiveval,D,root_archive_size,dis);
                    end
                    spop(i).val(j)=ui_val(x);
                    spop(i).pop(j,:)=ui(x,:);
                else
                    spop(i).T(j)=spop(i).T(j)+1;
                end
            end
        end
        for i=1:size(spop,2)
            pop=[pop;spop(i).pop];
            val=[val,spop(i).val];
            T=[T;spop(i).T];
        end
        % ��֤��Ⱥ������
        [sortval,sortindex]=sort(val,'descend');
        bestval=max(bestval,sortval(1));
        i=1;%��֤��Ⱥ������
        d2=0.1;
        while i<=size(pop,1)
            [temp k]=sort(sqrt(sum((ones(size(pop,1),1)*pop(i,:)-pop).^2,2)));
            e=2;
            Q=ones(size(pop,1),1);
            while e<=size(pop,1)
                if temp(e)<d2&&val(i)-val(k(e))<min_val&&val(i)-val(k(e))>0
                    Q(k(e),:)=0;
                else
                    break;
                end
                e=e+1;
            end
            pop=pop(Q==1,:);
            val=val(Q==1);
            T=T(Q==1,:);
            i=i+1;
        end
           i=1;
        while i<=size(pop,1)
            if T(i)>maxT
                [archive,archiveval]=Repulsion_archive(pop(i,:),val(i),archive,archiveval,D,root_archive_size,dis);
                pop(i,:)=[];
                val(i)=[];
                T(i)=[];
            end
            i=i+1;
        end
        if size(pop,1)<=NP
            while size(pop,1)<NP
                pop(size(pop,1)+1,:)=XRmin+(XRmax-XRmin).*rand(1,D);
                val(size(pop,1))=niching_func(pop(size(pop,1),:),fun_num);
                T(size(pop,1))=0;
                FES=FES+1;
            end
            UI=[];
            UI_VAL=[];
        end
        TEMP=[pop;archive];
    TEMPVAL=[val,archiveval];
    TEMP2=[];
    TEMPVAL2=[];
    TT=[T;maxT*ones(size(archive,1),1)];
    for i=1:size(TEMP,1)
       if abs(TEMPVAL(i)-foptima)<1e-4
           TEMP2=[TEMP2;TEMP(i,:)];
           TEMPVAL2=[TEMPVAL2,TEMPVAL(i)];
       end
    end
    solution1=[];
    solution_index=1;
    for s=1:solution_num
        if size(TEMP2,1)~=0
            [minval,minindex]=min(sqrt(sum((ones(size(TEMP2,1),1)*solution(s,:)-TEMP2).^2,2)));
            if minval<thresold(fun_num)
                solution1(solution_index,:)=[s,TEMP2(minindex,:)];
                solution_index=solution_index+1;
            else
                [mind,minindex]=min(sqrt(sum((ones(size(TEMP,1),1)*solution(s,:)-TEMP).^2,2)));
                fprintf('F%d: not found solution %d the minium distance %d the val difference%f,T=%d', fun_num, s, mind, abs(foptima-TEMPVAL(minindex)),TT(minindex));
                fprintf('\n');
            end
        else
               [mind,minindex]=min(sqrt(sum((ones(size(TEMP,1),1)*solution(s,:)-TEMP).^2,2)));
                fprintf('F%d: not found solution %d the minium distance %d the val difference%f,T=%d', fun_num, s, mind, abs(foptima-TEMPVAL(minindex)),TT(minindex));
                fprintf('\n');  
        end
    end
    fprintf('FES=%d,MaxFEs=%d,NP=%d,size of population=%d,the number of solution%d',FES,MaxFEs,NP,size(pop,1),size(solution1,1));
    fprintf('\n');
end
final_pop=[pop;UI;archive];
final_val=[val,UI_VAL,archiveval];
archive1=[];
archive2=[];
archive3=[];
archiveval1=[];
archiveval2=[];
archiveval3=[];
for i=1:size(final_pop,1)
    if abs(final_val(i)-foptima)<=1e-3
        archive1=[archive1;final_pop(i,:)];
        archiveval1=[archiveval1,final_val(i)];
    end
    if abs(final_val(i)-foptima)<=1e-4
        archive2=[archive2;final_pop(i,:)];
        archiveval2=[archiveval2,final_val(i)];
    end
    if abs(final_val(i)-foptima)<=1e-5
        archive3=[archive3;final_pop(i,:)];
        archiveval3=[archiveval3,final_val(i)];
    end
end
solution1=[];
solution2=[];
solution3=[];
for s=1:solution_num
    if size(archive1,1)>0
        [minval,minindex]=min(sqrt(sum((ones(size(archive1,1),1)*solution(s,:)-archive1).^2,2)));
        if minval<thresold(fun_num)
            solution1(solution_index1,:)=[s,archive1(minindex,:)];
            solution_index1=solution_index1+1;
        end
    end
    if size(archive2,1)>0
        [minval,minindex]=min(sqrt(sum((ones(size(archive2,1),1)*solution(s,:)-archive2).^2,2)));
        if minval<thresold(fun_num)
            solution2(solution_index2,:)=[s,archive2(minindex,:)];
            solution_index2=solution_index2+1;
        end
    end
    if size(archive3,1)>0
        [minval,minindex]=min(sqrt(sum((ones(size(archive3,1),1)*solution(s,:)-archive3).^2,2)));
        if minval<thresold(fun_num)
            solution3(solution_index3,:)=[s,archive3(minindex,:)];
            solution_index3=solution_index3+1;
        end
    end
end
% figure( Iter_final);
% plot(solution(:,1),solution(:,2),'*');
% hold on
% plot(solution1(:,2),solution1(:,3),'p');
% plot(pop(:,1),pop(:,2),'>');
% legend('�м���Ⱥ','��','�ҵ��ĸ�','�����Ⱥ�ֲ�');
fprintf('F%d: In the precision %f there are %d global optima! ', fun_num, 1E-04, size(solution2,1));
fprintf('The PR is %f, ',size(solution2,1)/solution_num);
toc
size(solution2,1)
end