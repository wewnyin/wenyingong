
/*********************************************************************************************************************************************/
/* 
	Description:  The C code of the Rcr_JADE algorithms in MS VC++ 6.0
	Optimizer:    JADE, Rcr_JADE 
	References:   1. J. Zhang, and A. C. Sanderson, "JADE: Adaptive Differential Evolution with Optional External Archive,"
	                IEEE Trans. on Evol. Comput., 2009, 13, 945-958.
				  2. W. Gong, Z. Cai, and Y. Wang, "Repairing the Crossover Rate with Its Binary String in Adaptive Differential Evolution,"
				    IEEE Trans. on Evol. Comput., 2012, in press.
	Developed by: Dr. Wenyin Gong
	E-mail:       cug11100304@yahoo.com.cn
	Lisence:      Free for academic purpose
	Notes:		  The source code of Rcr-JADE is the clean C version of our approach presented in the journal paper. The results may have 
	              some slight differences between the C code and the C++ code used in our experiments. If you find any errors or problems 
				  when using the code, pls feel free to contact me via E-mail.
*/
/*********************************************************************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>
#include <time.h>

/* Random number generator defined by URAND should return
   double-precision floating-point values uniformly distributed
   over the interval [0.0, 1.0)	*/
#define URAND			((double)rand()/((double)RAND_MAX + 1.0))

#define INF				1e99
#define PI				acos(-1)

#define N_of_x			30			/* number of decision variables */
#define max_evaluations	150000		/* maximal number of function evaluations */
#define pop_size		100			/* population size */
#define PRECISION		1E-8		/* expected precision of the problem */

int		index_of_func     = 12;		/* function to be optimized */
int		mutation_strategy = 2;		/* 1: DE/current-to-pbest/1; 2: DE/rand-to-pbest/1 */

typedef struct 
{
	double xreal[N_of_x];			/* decision variables */
	double fitness;					/* fitness of the solution */
}individual;

individual	parent_pop[pop_size];	/* save the parent population */
individual	child_pop[2*pop_size];	/* save the child population */
double		lowerBound[N_of_x];		/* lower bounds of the decision variables */
double		upperBound[N_of_x];		/* upper bounds of the decision variables */
int			bestIndex;				/* index of the best solution in the current population */
int			worstIndex;				/* index of the worst solution in the current population */	

int			evaluations;
int			gen_no;		
FILE		*fp;

individual	best_individual;

/************************************************************************/
/* random number generator                                              */
/************************************************************************/
int		rndint(int low, int high);
double	rndreal(double, double);
double	gaussian(double median, double stdev);
double	cauchy(double median, double formFactor);

/************************************************************************/
/* test functions                                                       */
/************************************************************************/
void test_01(double *xreal, double *obj);
void test_02(double *xreal, double *obj);
void test_03(double *xreal, double *obj);
void test_04(double *xreal, double *obj);
void test_05(double *xreal, double *obj);
void test_06(double *xreal, double *obj);
void test_07(double *xreal, double *obj);
void test_08(double *xreal, double *obj);
void test_09(double *xreal, double *obj);
void test_10(double *xreal, double *obj);
void test_11(double *xreal, double *obj);
void test_12(double *xreal, double *obj);
void test_13(double *xreal, double *obj);
/************************************************************************/

void	init_variables();
void	init_pop_uniform();
double	evaluate_ind(double *);
void	evaluate_pop(individual *pop, int size);
void	copyIndividuals(individual *source, individual *target);
void	find_best_and_worst();

int		sort_index[pop_size];
void	shell_sort_pop(individual * pop, int *index, int size);

void	Run_optimizer(int method);
void	welcome();

/************************************************************************/
/* global parameters and functions for JADE                             */
/************************************************************************/
double	JADE_c     = 0.1;
double	JADE_p     = 0.05;
double	JADE_mu_cr = 0.5;
double	JADE_mu_ff = 0.5;

void	run_JADE();
void	run_Rcr_JADE();
/************************************************************************/

int main(int argc, char* argv[])
{
	welcome();
	
	int total_run_num = 10;
	
	int method;
	printf("Please select the optimizer.\nmethod = ");
	scanf("%d", &method);

	for (int i=0;i<total_run_num;i++)
	{
		Run_optimizer(method);
	}

	return 0;
}

void welcome()
{
	printf("\n");
	printf("***************************************************************\n");
	printf("*             Welcome to use the DE optimizers.               *\n");
	printf("*        You can select and use the following optimizer.      *\n");
	printf("*                method = 1   for JADE                        *\n");
	printf("*                method = 2   for Rcr_JADE                    *\n");
	printf("***************************************************************\n");
	printf("\n");
}

/************************************************************************/
/* random number generator                                              */
/************************************************************************/
double rndreal(double low,double high)
{
	double  val;
	val = URAND*(high-low)+low;
	return (val);
}

int rndint(int low, int high)
{
	int res;
    if (low >= high)
    {
        res = low;
    }
    else
    {
        res = low + (int)(URAND*(high-low+1));
        if (res > high)
        {
            res = high;
        }
    }
    return (res);
}

double gaussian(double median, double stdev)
{
	assert( stdev > 0. ); 
	double u,v,x; 
	do { 
			double U1 = (double) URAND;
			double U2 = (double) URAND;
			u = 2.0 * U1 - 1.0; 
			v = 2.0 * U2 - 1.0; 
			x = u * u + v * v; 
		}while ( x >= 1.0 || x == 0 ); 
	return median + stdev * u * sqrt( -2. * log( x ) / x );
}

double cauchy(double median, double formFactor)
{
	assert( formFactor > 0. ); 
	double u, v; 
	do { 
			double U1 = (double) URAND;
			double U2 = (double) URAND;
			u = 2.0 * U1 - 1.0; 
			v = 2.0 * U2 - 1.0; 
		}while ((u*u+v*v>1.0) || (u==0.0&&v==0.0)); 

	if (u!=0) 
		return (median + formFactor * (v/u)); 
	else 
		return (median);
}

/************************************************************************/
/* For the DE algorithm                                                 */
/************************************************************************/
/* initialize the variables */
void init_variables()
{
	int i;
	
	switch(index_of_func) {
	case 1:
		for (i=0;i<N_of_x;i++)
		{
			lowerBound[i] = -100.0;
			upperBound[i] = 100.0;
		}
		break;
	case 2:
		for (i=0;i<N_of_x;i++)
		{
			lowerBound[i] = -10.0;
			upperBound[i] = 10.0;
		}
		break;
	case 3:
		for (i=0;i<N_of_x;i++)
		{
			lowerBound[i] = -100.0;
			upperBound[i] = 100.0;
		}
		break;
	case 4:
		for (i=0;i<N_of_x;i++)
		{
			lowerBound[i] = -100.0;
			upperBound[i] = 100.0;
		}
		break;
	case 5:
		for (i=0;i<N_of_x;i++)
		{
			lowerBound[i] = -30.0;
			upperBound[i] = 30.0;
		}
		break;
	case 6:
		for (i=0;i<N_of_x;i++)
		{
			lowerBound[i] = -100.0;
			upperBound[i] = 100.0;
		}
		break;
	case 7:
		for (i=0;i<N_of_x;i++)
		{
			lowerBound[i] = -1.28;
			upperBound[i] = 1.28;
		}
		break;
	case 8:// -418.982887272434*D
		for (i=0;i<N_of_x;i++)
		{
			lowerBound[i] = -500.0;
			upperBound[i] = 500.0;
		}
		break;
	case 9:
		for (i=0;i<N_of_x;i++)
		{
			lowerBound[i] = -5.12;
			upperBound[i] = 5.12;
		}
		break;
	case 10:
		for (i=0;i<N_of_x;i++)
		{
			lowerBound[i] = -32.0;
			upperBound[i] = 32.0;
		}
		break;
	case 11:
		for (i=0;i<N_of_x;i++)
		{
			lowerBound[i] = -600.0;
			upperBound[i] = 600.0;
		}
		break;
	case 12:
		for (i=0;i<N_of_x;i++)
		{
			lowerBound[i] = -50.0;
			upperBound[i] = 50.0;
		}
		break;
	case 13:
		for (i=0;i<N_of_x;i++)
		{
			lowerBound[i] = -50.0;
			upperBound[i] = 50.0;
		}
		break;
	default:
		printf("The function does not exist!\n");
		exit(0);
	}
}

/* initialize the population */
void init_pop_uniform()
{
	int i, j;
	double low, up;

	for(i=0;i<pop_size;i++)
	{
		for(j=0;j<N_of_x;j++)
		{
			low = lowerBound[j];
			up  = upperBound[j];
			
			parent_pop[i].xreal[j] = rndreal(low, up);
		}
	}
}

/* evaluate the individual */
double evaluate_ind(double *x)
{
	double	value = 0.0;	

	switch(index_of_func) {
	case 1:
		test_01(x, &value);
		break;
	case 2:
		test_02(x, &value);
		break;
	case 3:
		test_03(x, &value);
		break;
	case 4:
		test_04(x, &value);
		break;
	case 5:
		test_05(x, &value);
		break;
	case 6:
		test_06(x, &value);
		break;
	case 7:
		test_07(x, &value);
		break;
	case 8:
		test_08(x, &value);
		break;
	case 9:
		test_09(x, &value);
		break;
	case 10:
		test_10(x, &value);
		break;
	case 11:
		test_11(x, &value);
		break;
	case 12:
		test_12(x, &value);
		break;
	case 13:
		test_13(x, &value);
		break;
	default:
		printf("The function does not exist!\n");
		exit(0);
	}

	evaluations++;
		 
	return(value);
}

/* evaluate the population */
void evaluate_pop(individual *pop, int size)
{
	int i;
	for (i=0;i<size;i++)
	{
		pop[i].fitness = evaluate_ind(pop[i].xreal);
	}
}

/* find the best individual and worst individual in the current population */
void find_best_and_worst()
{
	int i;
	bestIndex  = 0;
	worstIndex = 0;
	for (i=1;i<pop_size;i++)
	{
		if (parent_pop[i].fitness <parent_pop[bestIndex].fitness)
		{
			bestIndex = i;
		}
		if (parent_pop[i].fitness > parent_pop[worstIndex].fitness)
		{
			worstIndex = i;
		}
	}
}

/* copy individuals */
void copyIndividuals(individual *source, individual *target)
{
	int i;
	for (i=0;i<N_of_x;i++)
	{
		target->xreal[i] = source->xreal[i];
	}
	target->fitness = source->fitness;
}

/* sort the population */
void shell_sort_pop(individual *pop, int *index, int size)
{
	int done;
	int step, bound, i, j;
	int temp;

	for (i=0;i<size;i++)
	{
		index[i] = i;
	}

	step = size;  // array length
	while (step > 1) 
	{
		step /= 2;	//halve the step size
		do 
		{
			done   = 1;
			bound  = size - step;
			for (j = 0; j < bound; j++) 
			{
				i = j + step + 1;
				if (pop[index[j]].fitness > pop[index[i-1]].fitness) 	
				{
					temp       = index[i-1];
					index[i-1] = index[j];
					index[j]   = temp;
					done       = 0;			// if a swap has been made we are not finished yet
				}  // if
			}  // for
		} while (done == 0);   // while
	} //while (step > 1)
}

/************************************************************************/
/* Execute the optimizer                                                */
/************************************************************************/
void Run_optimizer(int method)
{
	FILE	*fp1, *fp2;
	clock_t start, finish;
	double	time_consuming;
	int		flag_eval = 0;

	srand((unsigned)time(NULL));

	start       = clock();
	evaluations = 0;	// reset the evaluations in each run
	gen_no      = 1;

	init_variables();
	init_pop_uniform();
	evaluate_pop(parent_pop, pop_size);
	
	if((fp=fopen(".\\results\\process.txt","w"))==NULL)
	{
		printf("\nCannot open input file\n");
		exit(1);
	}

	if((fp1=fopen(".\\results\\results.txt","a"))==NULL)
	{
	    printf("\nCannot open input file\n");
        exit(1);
	}

	if((fp2=fopen(".\\results\\evaluations.txt","a"))==NULL)
	{
	    printf("\nCannot open input file\n");
        exit(1);
	}

	while (evaluations < max_evaluations)
	{
		find_best_and_worst();
		copyIndividuals(&parent_pop[bestIndex], &best_individual);

		if (flag_eval==0 && best_individual.fitness<PRECISION)
		{
			flag_eval = 1;
			fprintf(fp2, "%d\n", evaluations);
		}
		
		finish = clock();
		time_consuming = (finish-start)/1000.0;

		if (gen_no%20 == 0)
		{
			//printf("gen=%6d eval=%8d fitness=%e\t%f s.\n", 
			//	gen_no, evaluations, best_individual.fitness, time_consuming);
			fprintf(fp, "%6d %10d %15e %10f %10f\n", gen_no, evaluations, best_individual.fitness, JADE_mu_cr, JADE_mu_ff);
		}

		/************************************************************************/
		/* Add different optimizers herein                                      */
		/************************************************************************/
		switch(method) {
		case 1:
			run_JADE();
			break;
		case 2:
			run_Rcr_JADE();
			break;
		default:
			printf("The selected optimizer does not exist.\n");
			exit(0);
		}

		gen_no++;
	}

	printf("\nFunction %d is optimized.\n", index_of_func);
	printf("gen=%d\teval=%d\tfitness=%e\t%f s.\n", gen_no, evaluations, best_individual.fitness, time_consuming);

	fprintf(fp1, "%d\t%d\t%e\t\n", gen_no, evaluations, best_individual.fitness, time_consuming);

	fclose(fp);
	fclose(fp1);
	fclose(fp2);
}

/* main routine of JADE */
void run_JADE()
{
	int	   i, j;
	int    j_rnd;
	int    r1, r2, r3;
	int    p_index = -1;
	int	   binary_vector[N_of_x];

	double low, up;
	double FF[pop_size];
	double CR[pop_size];
	
	/* to save the successful CR and F values */
	double SS_FF[pop_size], SS_CR[pop_size];
	int	   SS_size = 0;

	/* initialize JADE parameters in each independent run */
	if (1==gen_no)
	{
		JADE_c     = 0.1;
		JADE_p     = 0.05;
		JADE_mu_cr = 0.5;
		JADE_mu_ff = 0.5;
	}

	/* Step 1: sort the population from best to worst */
	shell_sort_pop(parent_pop, sort_index, pop_size);

	/* Step 2: generate the CR and F values based on gaussian and cauchy distribution, respectively */
	for (i=0;i<pop_size;i++)
	{
		do {
			FF[i] = cauchy(JADE_mu_ff, 0.1);
		} while (FF[i] <= 0.0);
		if (FF[i] > 1.0)	FF[i] = 1.0;

		CR[i] = gaussian(JADE_mu_cr, 0.1);
		if (CR[i] < 0.0)	CR[i] = 0.0;
		if (CR[i] > 1.0)	CR[i] = 1.0;
	}

	for (i=0;i<pop_size;i++)
	{
		/* Step 3: generate the mutant vector (the archive is not used here) */
		// randomly choose the p_best individual
		p_index = rndint(0, int(JADE_p*pop_size)-1);
		p_index = sort_index[p_index];

		// select three parents randomly
		do {
			r1 = rndint(0, pop_size-1);
		} while (r1==i);
		do {
			r2 = rndint(0, pop_size-1);
		} while(r2== i || r2==r1);
		do {
			r3 = rndint(0, pop_size-1);
		} while(r3==i || r3==r2 || r3==r1);
	
		for (j=0;j<N_of_x;j++)
		{
			low = lowerBound[j];
			up  = upperBound[j];

			if (1==mutation_strategy)
			{			
				child_pop[i].xreal[j] = parent_pop[i].xreal[j] +
					FF[i] * (parent_pop[p_index].xreal[j]-parent_pop[i].xreal[j]) +
					FF[i] * (parent_pop[r1].xreal[j]-parent_pop[r2].xreal[j]);
			}
			else if (2==mutation_strategy)
			{
				child_pop[i].xreal[j] = parent_pop[r1].xreal[j] +
					FF[i] * (parent_pop[p_index].xreal[j]-parent_pop[r1].xreal[j]) +
					FF[i] * (parent_pop[r2].xreal[j]-parent_pop[r3].xreal[j]);
			}

			if (child_pop[i].xreal[j]<low || child_pop[i].xreal[j]>up)
			{
				child_pop[i].xreal[j] = rndreal(low, up);
			}
		}

		/* Step 4: generate the binary vector based on the binomial crossover */
		j_rnd = rndint(0, N_of_x-1);
		for (j=0;j<N_of_x;j++)
		{
			if (rndreal(0,1)<CR[i] || j==j_rnd)
			{
				binary_vector[j] = 1;
			}
			else
			{
				binary_vector[j] = 0;
			}
		}

		/* Step 5: generate the trial vector based on the binary vector and the mutant vector */
		for (j=0;j<N_of_x;j++)
		{
			if (1 == binary_vector[j])
			{
				child_pop[i].xreal[j] = child_pop[i].xreal[j];
			}
			else
			{
				child_pop[i].xreal[j] = parent_pop[i].xreal[j];
			}
		}
	}
		
	/* Step 6: evaluate the child population */
	evaluate_pop(child_pop, pop_size);

	/* Step 7: selection and save the successful parameters */
	SS_size = 0;
	for (i=0;i<pop_size;i++)
	{
		if (child_pop[i].fitness <= parent_pop[i].fitness)
		{
			copyIndividuals(&child_pop[i], &parent_pop[i]);

			/************************************************************************/
			/* save the successful CR and F values                                  */
			/************************************************************************/
			SS_FF[SS_size] = FF[i];
			SS_CR[SS_size] = CR[i];
			SS_size++;
		}
	}

	/* Step 8: update mu_CR and mu_F based on the successful CRs and Fs */
	if (SS_size) 
	{
		// update the mu_CR values
		double mean_cr  = 0.0;
		for (i=0;i<SS_size;i++)
		{
			mean_cr += SS_CR[i];
		}
		mean_cr    = mean_cr/((double)SS_size);
		JADE_mu_cr = (1-JADE_c) * JADE_mu_cr + JADE_c * mean_cr;

		// update the mu_F value
		double mean_ff = 0.0;
		double t1      = 0.0;
		double t2      = 0.0;
		for (i=0;i<SS_size;i++)
		{
			t1 += SS_FF[i]*SS_FF[i];
			t2 += SS_FF[i];
		}					
		mean_ff    = t1/t2;					// Lehmer mean
		JADE_mu_ff = (1-JADE_c)*JADE_mu_ff + JADE_c*mean_ff;
	}
}

/* main routine of JADE */
void run_Rcr_JADE()
{
	int	   i, j;
	int    j_rnd;
	int    r1, r2, r3;
	int    p_index = -1;
	int	   binary_vector[N_of_x];

	double low, up;
	double FF[pop_size];
	double CR[pop_size];
	
	/* to save the successful CR and F values */
	double SS_FF[pop_size], SS_CR[pop_size];
	int	   SS_size = 0;

	/* initialize JADE parameters in each independent run */
	if (1==gen_no)
	{
		JADE_c     = 0.1;
		JADE_p     = 0.05;
		JADE_mu_cr = 0.5;
		JADE_mu_ff = 0.5;
	}

	/* Step 1: sort the population from best to worst */
	shell_sort_pop(parent_pop, sort_index, pop_size);

	/* Step 2: generate the CR and F values based on gaussian and cauchy distribution, respectively */
	for (i=0;i<pop_size;i++)
	{
		do {
			FF[i] = cauchy(JADE_mu_ff, 0.1);
		} while (FF[i] <= 0.0);
		if (FF[i] > 1.0)	FF[i] = 1.0;

		CR[i] = gaussian(JADE_mu_cr, 0.1);
		if (CR[i] < 0.0)	CR[i] = 0.0;
		if (CR[i] > 1.0)	CR[i] = 1.0;
	}

	for (i=0;i<pop_size;i++)
	{
		/* Step 3: generate the mutant vector (the archive is not used here) */
		// randomly choose the p_best individual
		p_index = rndint(0, int(JADE_p*pop_size)-1);
		p_index = sort_index[p_index];

		// select three parents randomly
		do {
			r1 = rndint(0, pop_size-1);
		} while (r1==i);
		do {
			r2 = rndint(0, pop_size-1);
		} while(r2== i || r2==r1);
		do {
			r3 = rndint(0, pop_size-1);
		} while(r3==i || r3==r2 || r3==r1);
	
		for (j=0;j<N_of_x;j++)
		{
			low = lowerBound[j];
			up  = upperBound[j];

			if (1==mutation_strategy)
			{			
				child_pop[i].xreal[j] = parent_pop[i].xreal[j] +
					FF[i] * (parent_pop[p_index].xreal[j]-parent_pop[i].xreal[j]) +
					FF[i] * (parent_pop[r1].xreal[j]-parent_pop[r2].xreal[j]);
			}
			else if (2==mutation_strategy)
			{
				child_pop[i].xreal[j] = parent_pop[r1].xreal[j] +
					FF[i] * (parent_pop[p_index].xreal[j]-parent_pop[r1].xreal[j]) +
					FF[i] * (parent_pop[r2].xreal[j]-parent_pop[r3].xreal[j]);
			}

			if (child_pop[i].xreal[j]<low || child_pop[i].xreal[j]>up)
			{
				child_pop[i].xreal[j] = rndreal(low, up);
			}
		}

		/* Step 4: generate the binary vector based on the binomial crossover */
		j_rnd = rndint(0, N_of_x-1);
		for (j=0;j<N_of_x;j++)
		{
			if (rndreal(0,1)<CR[i] || j==j_rnd)
			{
				binary_vector[j] = 1;
			}
			else
			{
				binary_vector[j] = 0;
			}
		}

		/************************************************************************/
		/* repair the crossover rate with its binary vector generated above     */
		/************************************************************************/
		int tt = 0;
		for (j=0;j<N_of_x;j++)
		{
			tt += binary_vector[j];
		}
		CR[i] = (double)tt/((double)N_of_x);
		/************************************************************************/

		/* Step 5: generate the trial vector based on the binary vector and the mutant vector */
		for (j=0;j<N_of_x;j++)
		{
			if (1 == binary_vector[j])
			{
				child_pop[i].xreal[j] = child_pop[i].xreal[j];
			}
			else
			{
				child_pop[i].xreal[j] = parent_pop[i].xreal[j];
			}
		}
	}
		
	/* Step 6: evaluate the child population */
	evaluate_pop(child_pop, pop_size);

	/* Step 7: selection and save the successful parameters */
	SS_size = 0;
	for (i=0;i<pop_size;i++)
	{
		if (child_pop[i].fitness <= parent_pop[i].fitness)
		{
			copyIndividuals(&child_pop[i], &parent_pop[i]);

			/************************************************************************/
			/* save the successful CR and F values                                  */
			/************************************************************************/
			SS_FF[SS_size] = FF[i];
			SS_CR[SS_size] = CR[i];
			SS_size++;
		}
	}

	/* Step 8: update mu_CR and mu_F based on the successful CRs and Fs */
	if (SS_size) 
	{
		// update the mu_CR values
		double mean_cr  = 0.0;
		for (i=0;i<SS_size;i++)
		{
			mean_cr += SS_CR[i];
		}
		mean_cr    = mean_cr/((double)SS_size);
		JADE_mu_cr = (1-JADE_c) * JADE_mu_cr + JADE_c * mean_cr;

		// update the mu_F value
		double mean_ff = 0.0;
		double t1      = 0.0;
		double t2      = 0.0;
		for (i=0;i<SS_size;i++)
		{
			t1 += SS_FF[i]*SS_FF[i];
			t2 += SS_FF[i];
		}					
		mean_ff    = t1/t2;					// Lehmer mean
		JADE_mu_ff = (1-JADE_c)*JADE_mu_ff + JADE_c*mean_ff;
	}
}

/************************************************************************/
/* test functions                                                       */
/************************************************************************/
// Ellipsoidal function
void test_01(double *x, double *obj)
{
	double fit = 0.0;
	for(int i=0;i<N_of_x;i++)
		fit += ((x[i])*(x[i]));
	*obj = fit;
}

// Schwefel's function 2.22
void test_02(double *x, double *obj)
{
	double value = 0.0;
	double temp1 = 0.0;
	double temp2 = 1.0;
	for (int i=0;i<N_of_x;i++)
	{
		 temp1 += fabs(x[i]);
		 temp2 *= fabs(x[i]);
	}
	value = temp1+temp2;
	*obj = value;
}

// Schwefel's function 1.2
void test_03(double *x, double *obj)
{
	double fit = 0.0;
	double sumSCH;
	int i,j;
	
	for (i=0;i<N_of_x;i++)
	{
		sumSCH = 0.0;
		for (j=0;j<i+1;j++)
		{
			sumSCH += x[j];
		}
		fit += sumSCH*sumSCH;
	}
	*obj = fit;
}

// Schwefel's function 2.21
void test_04(double *x, double *obj)
{
	double temp1 = fabs(x[0]);
	for (int i=1;i<N_of_x;i++)
	{
		if (fabs(x[i]) > temp1)
		{
			temp1 = fabs(x[i]);
		}
	}
	*obj = temp1;
}

// Rosenbrock's function
void test_05(double *x, double *obj)
{
	double fit;
	double t0, tt, t1, d=0;
	t0=x[0];
	for (int i=1; i<N_of_x; i++) 
	{
		t1 = x[i];
		tt = (1.0-t0);
		d += tt*tt;
		tt = t1-t0*t0;
		d += 100*tt*tt;				
		t0 = t1;
	}
	fit = d;

	*obj = fit;
}

// step function
void test_06(double *x, double *obj)
{
	double temp;
	double value = 0.0;
	for (int i=0;i<N_of_x;i++)
	{
		temp = floor(x[i]+0.5);
		value += temp*temp; 
	}
	*obj = value;
}

// Quartic function
void test_07(double *xreal, double *obj)
{
	double value = 0.0;
	for (int i=0;i<N_of_x;i++)
	{
		value += (i+1)*pow(xreal[i],4.0); 
	}
	*obj = value+URAND;
}

// Generalized Schwefel's function
void test_08(double *x, double *obj)
{
	double value = 0.0;
	for (int i=0;i<N_of_x;i++)
	{
		value += x[i]*sin(sqrt(fabs(x[i]))); 
	}
	*obj = -value + 418.9828872724337998*(double)N_of_x; // modified here
}

// Generalized Rastrigin's function
void test_09(double *x, double *obj)
{
	double value = 0.0;
	for (int i=0;i<N_of_x;i++)
	{
		value += x[i]*x[i]-10.0*cos(2.0*PI*x[i])+10.0; 
	}
	*obj = value;
}

// Ackley' function
void test_10(double *x, double *obj)
{
	double value = 0.0;
	double temp1 = 0.0;
	double temp2 = 0.0;
	for (int i=0;i<N_of_x;i++)
	{
		 temp1 += x[i]*x[i];
		 temp2 += cos(2.0*PI*x[i]);
	}
	*obj = -20.0*exp(-0.2*sqrt(temp1/N_of_x))-exp(temp2/N_of_x)+20.0+exp(1.0);
}

// Generalized Griewank function
void test_11(double *x, double *obj)
{
	double temp1 = 0.0;
	double temp2 = 1.0;
	for (int i=0;i<N_of_x;i++)
	{
		 temp1 += x[i]*x[i];
		 temp2 *= cos(x[i]/sqrt(i+1));
	}
	*obj = temp1/4000.0-temp2+1;
}

double TempValue(double x,int a,int k,int m)
{
	double temp = 0.0;
	if( x > a)
	{
		temp = k*pow(x-a,m);
	}
	else if( x <= a && x >= -a)
	{
		temp = 0.0;
	}
	else
	{
		temp = k*pow(-x-a,m);
	}
	return temp;
}

// Generalized Penalized function
void test_12(double *x, double *obj)
{
	double *y;	//��ʱ�洢�����еı���

	y=new double[N_of_x];

	for (int i=0;i<N_of_x;i++)
	{
		y[i]=0.0;
	}

	for (i=0;i<N_of_x;i++)
	{
		y[i]=1+(x[i]+1)/4.0;
	}

	double temp1 = 0.0;
	double temp2 = 0.0;
	for (i=0;i<N_of_x-1;i++)
	{
		temp1 += pow(y[i]-1,2.0)*(1.0+10.0*pow(sin(PI*y[i+1]),2.0)); 
	}
	for (i=0;i<N_of_x;i++)
	{
		temp2 += TempValue(x[i],10,100,4);
	}
	*obj = (10.0*pow(sin(PI*y[0]),2.0)+temp1+pow(y[N_of_x-1]-1,2))*PI/N_of_x+temp2;
	delete []y;
}

// Generalized Penalized function
void test_13(double *x, double *obj)
{
	double temp1 = 0.0;
	double temp2 = 0.0;
	for (int i=0;i<N_of_x-1;i++)
	{
		temp1 += pow(x[i]-1,2.0)*(1.0+10.0*pow(sin(3*PI*x[i+1]),2.0)); 
	}
	for (i=0;i<N_of_x;i++)
	{
		temp2 += TempValue(x[i],5,100,4);
	}
	*obj = (pow(sin(3.0*PI*x[0]),2.0)+temp1+pow(x[N_of_x-1]-1,2.0)*(1.0+pow(sin(2.0*PI*x[N_of_x-1]),2.0)))/10.0+temp2;
}




