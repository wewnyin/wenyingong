# Notes

Before running optimal power flow cases, *Matpower* needs to be installed first.

*Matpower* is an open-source tool for electric power system simulation and optimization.

The source code of *Matpower* can be download from <https://matpower.org/>
