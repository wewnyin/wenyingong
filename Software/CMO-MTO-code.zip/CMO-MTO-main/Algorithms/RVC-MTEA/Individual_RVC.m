classdef Individual_RVC < Individual

properties
    SD % Search direction
    TR % Transfer rate
end
end
