
function [solution]=ABC(func_no,optima,tolerance,popSize,Max_gen,t_dis)




[Gm,NP,D,XRmin,XRmax,solution_num1,Threshold,fun_name,kesi,radius] = Parameter(func_no);


%/* Control Parameters of ABC algorithm*/

FoodNumber=NP; 
maxCycle=Gm/2; %/*The number of cycles for foraging {a stopping criteria}*/
maxFes=NP*Gm;
F=0.5;
CR=0.9;

%/* Problem specific variables*/
% D=2; %/*The number of parameters of the problem to be optimized*/
ub=XRmax; %/*lower bounds of the parameters. */
lb=XRmin;%/*upper bound of the parameters.*/

runtime=1;%/*Algorithm can be run many times in order to see its robustness*/
solution_archive=[];


%Foods [FoodNumber][D]; /*Foods is the population of food sources. Each row of Foods matrix is a vector holding D parameters to be optimized. The number of rows of Foods matrix equals to the FoodNumber*/
%ObjVal[FoodNumber];  /*f is a vector holding objective function values associated with food sources */
%Fitness[FoodNumber]; /*fitness is a vector holding fitness (quality) values associated with food sources*/
%trial[FoodNumber]; /*trial is a vector holding trial numbers through which solutions can not be improved*/
%prob[FoodNumber]; /*prob is a vector holding probabilities of food sources (solutions) to be chosen*/
%solution [D]; /*New solution (neighbour) produced by v_{ij}=x_{ij}+\phi_{ij}*(x_{kj}-x_{ij}) j is a randomly chosen parameter and k is a randomlu chosen solution different from i*/
%ObjValSol; /*Objective function value of new solution*/
%FitnessSol; /*Fitness value of new solution*/
%neighbour, param2change; /*param2change corrresponds to j, neighbour corresponds to k in equation v_{ij}=x_{ij}+\phi_{ij}*(x_{kj}-x_{ij})*/
%GlobalMin; /*Optimum solution obtained by ABC algorithm*/
%GlobalParams[D]; /*Parameters of the optimum solution*/
%GlobalMins[runtime]; /*GlobalMins holds the GlobalMin of each run in multiple runs*/



% for r=1:runtime
  
% /*All food sources are initialized */
%/*Variables are initialized in the range [lb,ub]. If each parameter has different range, use arrays lb[j], ub[j] instead of lb and ub */

nfeval=0;

for i=1:FoodNumber
    Foods(i,:)=XRmin+(XRmax-XRmin).*rand(1,D);
end


ObjVal=eobj(Foods,func_no);

nfeval=nfeval+NP;
%reset trial counters
trial=zeros(1,FoodNumber);

% if rand<0.5
    st=2;
% else
%     st=1;
% end

numb=5;

iter=1;
while (nfeval<maxFes)

 %������Ӧֵ���򣬽�����������   
        %��С��������
    [sort_val,sort_index]=sort(ObjVal,'ascend');
    popsort=Foods(sort_index,:);
    pop_temp=popsort;
    val_temp=ObjVal(sort_index);
    
 %����С������������ӽṹ
 
     x=[];
    x_val=[];
    
    x(1,:)= popsort(1,:);
    x_val(1)=val_temp(1);
    pop_temp(1,:)=[];%ȥ�����Ѿ�����x�ĸ���
    val_temp(1)=[];%ȥ������Ӧ����Ӧֵ
    
        for i=1:FoodNumber-2
    
    if i==1    
        %���������㣬���бջ�
    [temp, k]=sort(sqrt(sum((ones(size(pop_temp,1),1)* popsort(1,:)-pop_temp).^2,2)));
  
    x(2,:)=pop_temp(k(2),:);
    x_val(2)=val_temp(k(2));
    x(FoodNumber,:)=pop_temp(k(3),:);
    x_val(FoodNumber)=val_temp(k(3));
    
    delete_row=[k(2);k(3)];
    pop_temp(delete_row,:)=[];
    val_temp(delete_row)=[];
    
    else
      [temp, k]=sort(sqrt(sum((ones(size(pop_temp,1),1)* x(i,:)-pop_temp).^2,2)));  
%       node_in_network=[node_in_network,pop(k(1),1)];
      x(i+1,:)=pop_temp(k(1),:);
      x_val(i+1)=val_temp(k(1));

      pop_temp(k(1),:)=[];
      val_temp(k(1))=[];
    end

        end
    
    Foods=x;
    ObjVal=x_val;  
    
    LocalBest=ObjVal;
    LocalBestX=Foods;
    
    nBestX=Foods;
    nBest=ObjVal;
    
    
    
        
       for j=1:FoodNumber
        if j==1
            if LocalBest(FoodNumber)<nBest(j)
                nBestX(j,:)=LocalBestX(FoodNumber,:);
                nBest(j)=LocalBest(FoodNumber);
            end
            if LocalBest(j+1)<nBest(j)
                nBestX(j,:)=LocalBestX(j+1,:);
                nBest(j)=LocalBest(j+1);
            end       
        elseif j~=FoodNumber 
            if LocalBest(j-1)<nBest(j)
                nBestX(j,:)=LocalBestX(j-1,:);
                nBest(j)=LocalBest(j-1);
            end        
            if LocalBest(j+1)<nBest(j)
                nBestX(j,:)=LocalBestX(j+1,:);
                nBest(j)=LocalBest(j+1);
            end
        else
            if LocalBest(1)<nBest(j)
                nBestX(j,:)=LocalBestX(1,:);
                nBest(j)=LocalBest(1);
            end
            if LocalBest(j-1)<nBest(j)
                nBestX(j,:)=LocalBestX(j-1,:);
                nBest(j)=LocalBest(j-1);
            end             
        end
    end 
    
    
    
    
    
    
    
    
%%%%%%%%% EMPLOYED BEE PHASE %%%%%%%%%%%%%%%%%%%%%%%%
    for i=1:(FoodNumber)
              
        
%        sol=Foods(i,:);
       %  /*v_{ij}=x_{ij}+\phi_{ij}*(x_{kj}-x_{ij}) */
%        sol(Param2Change)=Foods(i,Param2Change)+(Foods(i,Param2Change)-Foods(neighbour,Param2Change))*(rand-0.5)*2;
          sol(i,:)=Foods(i,:)+(LocalBestX(i,:)-Foods(i,:))*2.05*rand+(nBestX(i,:)-Foods(i,:))*2.05*rand;
 

        
       %  /*if generated parameter value is out of boundaries, it is shifted onto the boundaries*/
        ind=find(sol(i,:)<lb);
        sol(i,ind)=lb(ind);
        ind=find(sol(i,:)>ub);
        sol(i,ind)=ub(ind);
        
        %evaluate new solution
        ObjValSol(i)=eobj(sol(i,:),func_no);
        
        checkdis=sum((ones(size(Foods,1),1)*sol(i,:)-Foods).^2,2);
        [minval,minindex]=sort(checkdis,'ascend');
        
   
       if ObjValSol(i)<ObjVal(minindex(1))
            Foods(minindex(1),:)=sol(i,:);
            ObjVal(minindex(1))=ObjValSol(i);
            trial(minindex(1))=0;
        else
            trial(minindex(1))=trial(minindex(1))+1; %/*if the solution i can not be improved, increase its trial counter*/
       end;

   
       
       
       %���¾ֲ�������Դ
        
        checkdis1=sum((ones(size(LocalBestX,1),1)*sol(i,:)-LocalBestX).^2,2);
        [minval1,minindex1]=sort(checkdis1,'ascend');
        
        if ObjValSol(i)<LocalBest(minindex(1))
            LocalBestX(minindex(1),:)=sol(i,:);
            LocalBest(minindex(1))=ObjValSol(i);
       end;
        

         
         nfeval=nfeval+1;
    end
    
   

%%%%%%%%%%%%%%%%%%%%%%%% CalculateProbabilities %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%/* A food source is chosen with the probability which is proportioal to its quality*/
%/*Different schemes can be used to calculate the probability values*/
%/*For example prob(i)=fitness(i)/sum(fitness)*/
%/*or in a way used in the metot below prob(i)=a*fitness(i)/max(fitness)+b*/
%/*probability values are calculated by using fitness values and normalized by dividing maximum fitness value*/
  
%%%%%%%%%%%%%%%%%%%%%%%% ONLOOKER BEE PHASE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

i=1;

while(i<=FoodNumber)

          ui=[];
   
% ��DE�Ĳ���,crowding����������Դλ��
        
        bm=Foods(i,:);
        
        [temp k]=sort(sqrt(sum((ones(NP,1)*bm-Foods).^2,2)));
        
        popold=Foods(i,:);
        newpop1=Foods(k(1:numb),:);
        ui(i,:)=DE(popold,newpop1,bm,st,F,CR,D,size(newpop1,1),XRmin,XRmax);
        
        nfeval=nfeval+1;
        
        %evaluate new solution
        ObjValSol(i)=eobj(ui(i,:),func_no);
       
        
        checkdis=sum((ones(size(Foods,1),1)*ui(i,:)-Foods).^2,2);
        [minval,minindex]=sort(checkdis,'ascend');
        
        if ObjValSol(i)<ObjVal(minindex(1))
            Foods(minindex(1),:)=ui(i,:);
            ObjVal(minindex(1))=ObjValSol(i);
            trial(minindex(1))=0;
        else
            trial(minindex(1))=trial(minindex(1))+1; %/*if the solution i can not be improved, increase its trial counter*/
        end
        
    
    i=i+1;

end; 

         
         
%%%%%%%%%%%% SCOUT BEE PHASE %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%/*determine the food sources whose trial counter exceeds the "limit" value. 
%In Basic ABC, only one scout is allowed to occur in each cycle*/

ind1=find(trial>50);

if size(ind1,2)~=0
    for i=1:size(ind1,1)
    temp_sol=(ub-lb).*rand(1,D)+lb;
    temp_val=eobj(temp_sol,func_no);
    Foods(ind1(i),:)=temp_sol;
    ObjVal(ind1(i))=temp_val;
    nfeval=nfeval+1;
    end
end



ind=find(ObjVal<kesi);


if size(ind,2)~=0
    
  solution_archive=[solution_archive;ObjVal(ind)',Foods(ind,:)];
  trial(ind)=0;
  
for i=1:size(ind,1)
    temp_sol=(ub-lb).*rand(1,D)+lb;
    temp_val=eobj(temp_sol,func_no);
    Foods(ind(i),:)=temp_sol;
    ObjVal(ind(i))=temp_val;
    nfeval=nfeval+1;
end

end

%fprintf('�ter=%d ObjVal=%g\n',iter,GlobalMin);
iter=iter+1;

end % End of ABC

   
       peakslocation=10000*ones(size(optima,1),D);


       for u=1:size(optima,1)
           checkdis=sum((ones(size(solution_archive,1),1)*optima(u,:)-solution_archive(:,2:end)).^2,2);
           [minval,minindex]=min(checkdis);
           if  minval<=0.01 &  solution_archive(minindex,1)<kesi 
               peakslocation(u,:)=solution_archive(minindex,2:end);
           end
       end



% fprintf('�ter=%d ObjVal=%g\n',iter,Foods);
% GlobalMins(r)=GlobalMin;
% end; %end of runs
solution= peakslocation;
end

