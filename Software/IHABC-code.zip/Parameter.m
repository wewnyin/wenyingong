function [Gm,NP,D,XRmin,XRmax,solution_num,Threshold,fun_name,kesi,radius] = Parameter(fun_num)
%EQUATIONS_ Summary of this function goes here
%   Detailed explanation goes here
        if fun_num==1
        
     Gm = 500;  
    NP=100;  
    D = 20;
    XRmin = [-1, -1,-1, -1, -1,-1, -1, -1,-1, -1, -1,-1, -1, -1,-1, -1, -1,-1, -1, -1];
    XRmax = [1, 1,1, 1,1, 1,1, 1,1, 1,1, 1,1, 1,1, 1,1, 1,1,1];
    Threshold=0.01;
    solution_num=2;
    fun_name='F1';
    kesi=10^-4;
    radius=0.01;
        end
    
      
     if fun_num==2
         
    Gm = 500;  
    NP=100;  
    D = 2;
    XRmin = [-1, -1];
    XRmax = [1, 1];
    Threshold=0.01;
    solution_num=11;
    fun_name='F2';
    kesi=10^-6;
    radius=0.01;
     end
       if fun_num==3  %the min value equal 1.0
         
    Gm = 500;  
    NP=100;  
    D = 2;
    XRmin = [-1, -1];
    XRmax = [1, 1]; 
    Threshold=0.01;
    solution_num=15;
    fun_name='F3';
    kesi=10^-6;
    radius=0.01;
       end  
    
           if fun_num==4
        
    Gm = 500;  
    NP=100;  
    D = 2;
   XRmin = [-10, -10];
    XRmax = [10, 10];
    Threshold=0.01;
    solution_num=13;
    fun_name='F4';
    kesi=10^-6;
    radius=0.01;
    end
         
     if fun_num==5 
        
    Gm = 500;  
    NP=100;  
    D = 10;
    XRmin = [-2, -2 ,-2, -2 ,-2, -2 ,-2, -2 ,-2,-2];
    XRmax = [2, 2,2, 2,2, 2,2, 2,2, 2];
    Threshold=0.01;
    solution_num=1;
    fun_name='F5';
    kesi=10^-4;    
    radius=0.01;
     end
     
         if fun_num==6 
        
    Gm = 500;  
    NP=100;  
    D = 2;
    XRmin = [-1, -1];
    XRmax = [1, 1]; 
    Threshold=0.01;
    solution_num=8;
    fun_name='F6';
    kesi=10^-6;
    radius=0.01;
    end
       
    if fun_num==7
        
    Gm =500;  
    NP=100;  
    D = 2;
    XRmin = [0, -10];
    XRmax = [1, 0];
    Threshold=0.01;
    solution_num=2;  
    fun_name='F7';
    kesi=10^-6;
    radius=0.01;
    end
    
        if fun_num==8
        
    Gm =500;  
    NP=100;  
    D = 2;
    XRmin = [0, 0];
    XRmax = [1, 1]; 
    Threshold=0.01;
    solution_num=7;  
    fun_name='F8';
    kesi=10^-6;
    radius=0.01;
    end
    
       if fun_num==9
        
        
    Gm =1000;  
    NP=100;  
    D = 5;
    XRmin = [-10, -10,-10, -10,-10];
    XRmax = [10, 10, 10, 10, 10]; 
    Threshold=0.01;
    solution_num=3;  
    fun_name='F9';  
    kesi=10^-6;
    radius=0.01;
       end
   
          if fun_num==10
        
    Gm =500;  
    NP=100;  
    D = 3;
    XRmin = [-5, -1,-5];
    XRmax = [5, 3,5];
    Threshold=0.01;
    solution_num=2;  
    fun_name='F10'; 
    kesi=10^-6;
    radius=0.01;
    end
        if fun_num==11
        
    Gm =500;  
    NP=100;  
    D = 2;
    XRmin = [-1, -10];
    XRmax = [1, 10];
    Threshold=0.01;
    solution_num=4;  
    fun_name='F11';
    kesi=10^-6;
    radius=0.01;
        end
       if  fun_num==12
     Gm =500;  
    NP=100;  
    D = 2;
    XRmin = [-2, -2];
    XRmax = [2, 2]; 
    Threshold=0.01;
    solution_num=10;  
    fun_name='F12';
    kesi=10^-6;
    radius=0.01;
       end
       
           if fun_num==13
        
    Gm =500;  
    NP=100;  
    D = 3;
    XRmin = [-0.6, -0.6,-5];
    XRmax = [6, 0.6,5];
    Threshold=0.01;
    solution_num=12;  
    fun_name='F13';
    kesi=10^-6;
    radius=0.01;
           end
     
     if fun_num==14
        
    Gm =500;  
    NP=100;  
    D = 2;
    XRmin = [-5, -5];
    XRmax = [5, 5]; 
    Threshold=0.01;
    solution_num=9;  
    fun_name='F14';
    kesi=10^-6;
    radius=0.01;
     end
     
          if fun_num==15
        
    Gm =500;  
    NP=100;  
    D = 2;
    XRmin = [0.25, 0.5];
    XRmax = [1, 2*pi];
    Threshold=0.01;
    solution_num=2;  
    fun_name='F15';
    kesi=10^-6;
    radius=0.01;
     end
   
      if fun_num==16
    
    Gm =500;  
    NP=100;  
    D = 2;
    XRmin = [0, 0];
    XRmax = [2*pi, 2*pi]; 
    Threshold=0.01;
    solution_num=13;  
    fun_name='F16';
    kesi=10^-6;
    radius=0.01;
    end
   
    if fun_num==17
    
    Gm =1000;  
    NP=100;  
    D = 8;
    XRmin = [-1, -1, -1, -1, -1, -1, -1, -1];
    XRmax = [1, 1, 1, 1, 1, 1, 1, 1];   
    Threshold=0.01;
    solution_num=16;  
    fun_name='F17';
    kesi=10^-4;
    radius=0.01;
    end 
    
      if  fun_num==18
           Gm =500;  
    NP=100;  
    D = 2;
    XRmin = [-2, -2];
    XRmax = [2, 2]; 
    Threshold=0.01;
    solution_num=6;  
    fun_name='F18';
    kesi=10^-6;
    radius=0.01;
      end
    
            if fun_num==19    
        
    Gm =2000;  
    NP=100;  
    D = 20;
    XRmin = [-2, -2, -2, -2, -2, -2, -2, -2, -2, -2,-2,-2,-2,-2,-2,-2,-2,-2,-2,-2];
    XRmax = [2, 2, 2, 2, 2, 2, 2, 2, 2, 2,2,2,2,2,2,2,2,2,2,2]; 
    Threshold=0.01;
    solution_num=2;  
    fun_name='F19';
    kesi=10^-4;
    radius=0.01;
            end
   
    if fun_num==20
        
    Gm =500;  
    NP=100;  
    D = 3;
    XRmin =[-1,-1,-1];
    XRmax = [1,1,1];
    Threshold=0.01;
    solution_num=7;  
    fun_name='F20';
    kesi=10^-6;
    radius=0.01;
    end
        
    if fun_num==21
        
    Gm =500;  
    NP=100;  
    D = 2;
    XRmin =[-2,-2];
    XRmax = [2,2];
    Threshold=0.01;
    solution_num=4;  
    fun_name='F21';
    kesi=10^-6;
    radius=0.01;
    end
             
    
   if fun_num==22
        
    Gm =500;  
    NP=100;  
    D = 2;
    XRmin =[-2,-2];
    XRmax = [2,2];
    Threshold=0.01;
    solution_num=6;  
    fun_name='F22';
    kesi=10^-6;
    radius=0.01;
   end
    
  
   if fun_num==23
        
    Gm =5000;  
    NP=100;  
    D = 3;
    XRmin =[-20,-20,-20];
    XRmax = [20,20,20];
    Threshold=0.01;
    solution_num=16;  
    fun_name='F23';
    kesi=10^-6;
    radius=0.01;
    end
    
   
   if  fun_num==24
    Gm =1000;  
    NP=100;  
    D = 3;
    XRmin =[0,0,0];
    XRmax = [1,1,1];
    Threshold=0.01;
    solution_num=8;  
    fun_name='F24';
    kesi=10^-6;
    radius=0.01;
                 end
                 
   if  fun_num==25       
    Gm =1000;  
    NP=100;  
    D = 3;
    XRmin =[-3,-3,-3];
    XRmax = [3,3,3];
    Threshold=0.01;
    solution_num=2;  
    fun_name='F25';
    kesi=10^-6;
    radius=0.01;
   end  
    
    if  fun_num==26 
        
    Gm =500;  
    NP=100;  
    D = 2;
    XRmin =[-1,-2];
    XRmax = [-0.1,2];
    Threshold=0.01;
    solution_num=2;  
    fun_name='F26';
    kesi=10^-6;
    radius=0.01;
    end  
    
    if  fun_num==27
        
    Gm =500;  
    NP=100;  
    D = 2;
    XRmin =[-5,0];
    XRmax = [1.5,5];
    Threshold=0.01;
    solution_num=3;  
    fun_name='F27';
    kesi=10^-6;
    radius=0.01;
    end  
    
    
   if  fun_num==28
        
    Gm =500;  
    NP=100;  
    D = 2;
    XRmin =[0,2];
    XRmax = [10,30];
    Threshold=0.01;
    solution_num=2;  
    fun_name='F28';
    kesi=10^-6;
    radius=0.01;
    end  
    
    if fun_num==29
        
    Gm =500;  
    NP=100;  
    D = 3;
    %XRmin =-10;
    %XRmax = 10;
    XRmin = [0, -10, -1];
    XRmax = [2, 10 ,1];
    Threshold=0.01;
    solution_num=5;  
    fun_name='F29';
    kesi=10^-6;
    radius=0.01;
              end
    
  if fun_num==30
        
    Gm =500;  
    NP=100;  
    D = 2;
    XRmin = [-2, 0];
    XRmax = [2, 1.1];
    Threshold=0.01;
    solution_num=4;  
    fun_name='F30';
    kesi=10^-6;
    radius=0.01;
  end
  
  
end

