


    tic
    
   
    Iter_final_max=30;
    total_percentage=zeros(Iter_final_max,1);
    mean_root=zeros(Iter_final_max,1);
    mean_iter=zeros(Iter_final_max,1);
    store_NPF=zeros(Iter_final_max,1);
    store_FE=zeros(Iter_final_max,1);
%    title_row={'Prob','SR','Nroot_avg','PR','AveFEs'};
%    title_column={'F1';'F2';'F3';'F4';'F5';'F6';'F7';'F8';'F9';'F10';'F11';'F12';'F13';'F14';'F15';'F16';'F17';'F18';'F19';'F20';'F21';'F22';'F23';'F24';'F25';'F26';'F27';'F28';'F28';'F30'};
%    xlswrite('C:\Users\d\Desktop\JADE_repulsion\decomposition2_iter100.xlsx',title_row);
%    xlswrite('C:\Users\d\Desktop\JADE_repulsion\decomposition2_iter100.xlsx',title_column,'sheet1','A2');
%         
% 
   title_row={'Prob','SR','Nroot_avg','PR','AveFEs'};
   title_column={'F01';'F02';'F03';'F04';'F05';'F06';'F07';'F08'};
   xlswrite('C:\Users\d\Desktop\JADE_repulsion\ABC-555.xlsx',title_row);
   xlswrite('C:\Users\d\Desktop\JADE_repulsion\ABC-555.xlsx',title_column,'sheet1','A2');


                   for p=[4:4,6:6,8:8,12:12,14:14,16:16,23:23,25:25]
%                 for p=43:44
        fun_num=p;
        

        
        Iter_final=1;
        total_mean_outcome=zeros(Iter_final_max,2);
         
         t=1;
       [Gm,NP,D,XRmin,XRmax,solution_num1,Threshold,fun_name,kesi,radius] = Parameter(fun_num);

       exact_solution=Exact_solution(fun_num);
       optima=exact_solution(:,2:end);
       tolerance=kesi;
       popSize=NP;
       Max_gen=Gm;
       t_dis=radius;
       solution_num=solution_num1;
     
    while Iter_final<=Iter_final_max
        
    
        Iter_final
        fun_name
         
    G1=1;
    solution = [];
    q=0;
    It=1;
    outCome=[];  
    total_iter=0;
    
    
    solution=ABC(fun_num,optima,tolerance,popSize,Max_gen,t_dis);
    
    
    id=find(solution(:,1)==10000);
    solution(id,:)=[];
    
%     S3=size(solution,1);
%     fid=fopen('C:\Users\d\Desktop\test\ABC.txt','a+');
%     for i=1:S3    
%         fprintf(fid,'%d  ',i); 
%         fprintf(fid,'%g  ',solution(i,:));
%         fprintf(fid,'\r\n');  
%     end
%      fprintf(fid,'=================================');
%      fprintf(fid,'\r\n');
%      fclose(fid);   
% %  ====================================================================== 


    S1=size(solution,1);
    
    store_FE(Iter_final,1)=total_iter;
    
    
    if S1<solution_num
        total_percentage(Iter_final)=0;
        mean_root(Iter_final)=S1;
        store_NPF(Iter_final,1)=S1;
    else
            total_percentage(Iter_final)=100;
            mean_root(Iter_final)=S1;
            store_NPF(Iter_final,1)=S1;
    end

 
     
    total_mean_outcome(Iter_final,:)=[mean(outCome),std(outCome)];
   
   Iter_final=Iter_final+1; 
    end
 
     total_mean_outcome(any(isnan(total_mean_outcome)'),:)=[];   %Remove the rows that have 'NAN' in the matrix
     PR=sum(store_NPF)/(solution_num*Iter_final_max);            %calculate the peak ratio
     AveFEs=sum(store_FE)/Iter_final_max;                        %calculate the convergence speed
%      StoreMean(fun_num,total_mean_outcome');                     %store and printf the result of mean and std
     
     store_data(p,:)=[mean(total_percentage),mean(mean_root),PR,AveFEs];  
%       meanResult(p,:)=mean(total_mean_outcome);
     Result(p,:)=mean(total_mean_outcome);
     end
    
                 xlswrite('C:\Users\d\Desktop\JADE_repulsion\ABC-555.xlsx',store_data,'sheet1','B2');
%      xlswrite('C:\Users\d\Desktop\JADE_repulsion\solution.xlsx',meanResult,'sheet1','F2');
     toc




  
 


