
#include "global.h"
#include "DE_method.h"

void welcome();

int main(int argc, char* argv[])
{
	welcome();

	double seed = 0.0;

	int method;
	int RUN_NUMBER;
	int strategy_index	= 1;		// strategy used in DE (1: rand/1; )
	int output_counter	= 0;
	int func_flag		= 1;
	
	/**/
	printf("func_index = ");
	func_flag = 1;
	cin>>func_flag;
	
	printf("method     = ");
	method = 2;
	cin>>method;

	printf("RUN_NUMBER = ");
	RUN_NUMBER = 25;
	cin>>RUN_NUMBER;
	
	/*if (argc != 5 && argc != 6)
	{
		printf("Usage: DE_*.exe function method run_number out_counter\n");
		printf("OR--->\n");
		printf("Usage: DE_*.exe function method run_number out_counter strategy_index\n");
		exit(0);
	}
	if (argc == 5)
	{
		func_flag      = atoi(argv[1]);
		method         = atoi(argv[2]);
		RUN_NUMBER     = atoi(argv[3]);
		output_counter = atoi(argv[4]);
	}
	else if (argc == 6)
	{
		func_flag      = atoi(argv[1]);
		method         = atoi(argv[2]);
		RUN_NUMBER     = atoi(argv[3]);
		output_counter = atoi(argv[4]);
		strategy_index = atoi(argv[5]);
 	}*/

	srand((unsigned)time(NULL));


	CDE_method *DE_method;
	for (int i=0;i<RUN_NUMBER;i++)
	{
		int t = output_counter;				
		int k = t*RUN_NUMBER;
		printf("--------- Run no. is %d ---------\n", k+i+1);
		seed = ((double)(k+i+1))/((double)RUN_NUMBER);
		//seed = ((double)(k+i+1))/50.0;		// ............
		if (RUN_NUMBER == 1)
		{
			//seed = 0.86564;
			seed = 0.2;
		}
		//seed = ((double)(46+1))/50.0;			// test seed
		//seed = (double)(rand()%1000)/1000.0;	// test seed
		if (seed == 0.0)
		{
			seed = 0.001;
		}
		if (seed == 1.0)
		{
			seed = 0.99;
		}

		DE_method = new CDE_method;
		DE_method->Run_Optimizer(func_flag, k+i, seed, method, strategy_index);
		delete DE_method;

		if ((i+1)%100 == 0 && (i+1) != RUN_NUMBER)	// pause
		{
			printf("\nPlease press ENTER key to continue.\n");
			getchar();
		}
	}
	
	return 0;
}


void welcome()
{
	printf("\n");
	printf("***************************************************************\n");
	printf("*             Welcome to use the DE optimizers.               *\n");
	printf("*        You can select and use the following optimizer.      *\n");
	printf("*                method = 1   for CoDE                        *\n");
	printf("*                method = 2   for CSM-CoDE                    *\n");
	printf("*                method = 3   for JADE                        *\n");
	printf("*                method = 4   for CSM-JADE                    *\n");
	printf("***************************************************************\n");
	printf("\n");
}
