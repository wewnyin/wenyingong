function [ solution , value ,NFE] = tlboDE( ObjectFunction, type, Max_NFE)
%TLBO �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
    
    NP=50;
    Max_NFE = 30000;
    NFE = 0;
    F = 0.5;
    [LB,UB,Nvars] = Parameter(type);
     %% ��ʼ��
     X=zeros(NP,Nvars);
     for i=1:NP
         for j=1:Nvars
             X(i,j) = LB(j)+rand*(UB(j)-LB(j));
         end
     end
     
     CurrentOFV = zeros(1,NP);
     
     for i=1:NP
         CurrentOFV(i) = ObjectFunction(type,X(i,:));
         NFE = NFE+1;
     end
     
     [sorted,indices] = sort(CurrentOFV);
     Xteacher = X(indices(1),:);%�õ���õ�Xteacher
     Xmean = mean(X); % �õ���ֵXmean
     
     finalX = Xteacher;
     finalY = sorted(1);
     
     %% loop
      while NFE<Max_NFE 
          
          for i=1:NP
             R(indices(i)) = NP-i;
             CR(indices(i)) = (R(indices(i))/NP)^2;
          end
                   
          %% teacher phase 
          for i=1:NP
              
              if rand<CR(i)
                  New_X(i,:) = X(i,:)+rand.*(Xteacher-round(rand+1).*Xmean);
              else
                  r1 = randi(NP);
                  while r1==i
                     r1 = randi(NP); 
                  end
                  
                  r2 = randi(NP);
                  while r2==i || r2==r1
                     r2 = randi(NP); 
                  end
                  
                  r3 = randi(NP);
                  while r3==i || r3==r1 || r3==r2
                     r3 = randi(NP); 
                  end
                  
                  New_X(i,:) =  X(r1,:)+F.*(X(r2,:)-X(r3,:));
              end
              
              for j=1:Nvars
                  if New_X(i,j)<LB(j)
                      New_X(i,j) = LB(j)+rand*(UB(j)-LB(j));
                  end
                  
                  if New_X(i,j)>UB(j)
                      New_X(i,j) = LB(j)+rand*(UB(j)-LB(j));
                  end
              end
              
              New_CurrentOFV(i) = ObjectFunction(type,New_X(i,:));
              NFE = NFE+1;
              if New_CurrentOFV(i)<CurrentOFV(i)
                  X(i,:) = New_X(i,:);
                  CurrentOFV(i) = New_CurrentOFV(i);
              end
              
          end

          [sorted,indices] = sort(CurrentOFV);
          Xteacher = X(indices(1),:);%�õ���õ�Xteacher
          Xmean = mean(X); % �õ���ֵXmean
          
          finalX = Xteacher;
          finalY = sorted(1);
          
      end
      solution = finalX;
      value = finalY;
      


end

