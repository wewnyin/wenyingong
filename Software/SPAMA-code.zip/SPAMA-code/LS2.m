function [p_chrom,m_chrom,f_chrom]=LS2(p_chrom,m_chrom,f_chrom,fitness) %critical-block based neighborhood--N5

global N H SH time TM NM M;

    s1=p_chrom;
    s2=zeros(1,SH);
    p=zeros(1,N);
    
    for i=1:SH
        p(s1(i))=p(s1(i))+1;%��¼�����Ƿ�ӹ���� ���һ�μ�һ
        s2(i)=p(s1(i));%��¼�ӹ������У������Ĵ���
    end
    
P1=[];P2=[];IP1=[];IP2=[];
for i=1:SH
    t1=s1(i);%��¼����ǰ���Ǹ�����
    t2=s2(i);%��¼��ǰ�����Ǽӹ����ڼ���
    if f_chrom(t1)==0
        P1=[P1 p_chrom(i)]; 
        IP1=[IP1,i];
    else
        P2=[P2 p_chrom(i)];
        IP2=[IP2,i];
    end
end
FJ1=[];FJ2=[];
for i=1:N
    if f_chrom(i)==0
        FJ1=[FJ1 i];
    else
        FJ2=[FJ2 i];
    end
end

if fitness(1,3)==0
    [CriticalPath,CriticalBlock,block]=FindCriticalPathDFJSP(P1,m_chrom,FJ1); %�ؼ�·�����ص�������Ⱦɫ���йؼ�������±�
else
    [CriticalPath,CriticalBlock,block]=FindCriticalPathDFJSP(P2,m_chrom,FJ2);
end

for i=1:block
    BL=length(CriticalBlock(i).B);
    if BL>1
        Index3=0;Index4=0;Index1=0;Index2=0;
        if i==1
            Index1=BL-1;
            Index2=BL;
            Index1=CriticalBlock(i).B(Index1);
            Index2=CriticalBlock(i).B(Index2);
        end
        
        if i==block
            Index1=1;
            Index2=2;
            Index1=CriticalBlock(i).B(Index1);
            Index2=CriticalBlock(i).B(Index2);
        end
        
        if i>1&&i<block&&BL>2
            Index1=2;
            Index2=1;
            Index3=BL-1;
            Index4=BL;
            Index1=CriticalBlock(i).B(Index1);
            Index2=CriticalBlock(i).B(Index2);
            Index3=CriticalBlock(i).B(Index3);
            Index4=CriticalBlock(i).B(Index4);
        end
        
        if fitness(1,3)==0 %update P1
            if Index1~=0&&Index2~=0
            tmp=P1(Index1);
            P1(Index1)=P1(Index2);
            P1(Index2)=tmp;
            end
            if Index3~=0&&Index4~=0
                tmp=P1(Index3);
                P1(Index3)=P1(Index4);
                P1(Index4)=tmp;
            end
        else %update P2
            if Index1~=0&&Index2~=0
            tmp=P2(Index1);
            P2(Index1)=P2(Index2);
            P2(Index2)=tmp;
            end
            if Index3~=0&&Index4~=0
                tmp=P2(Index3);
                P2(Index3)=P2(Index4);
                P2(Index4)=tmp;
            end

        end
    end
end


newm=m_chrom;
newp=zeros(1,SH);
L=length(IP1);
for i=1:L
  newp(1,IP1(i))=P1(i);  
end

L=length(IP2);
for i=1:L
  newp(1,IP2(i))=P2(i);  
end


end