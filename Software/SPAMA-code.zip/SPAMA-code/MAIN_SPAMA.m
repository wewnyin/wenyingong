clc;
clear all;

DataPath='..\..\DATASET\';

name='DP';name2='Mk';fjsp='.fjs';zer='0'; txt='.txt';

k=1;
for i=1:10
    if i<10
        RealPath{k}=[DataPath,name2,zer,num2str(i),fjsp];
        ResultPath{k}=[name2,zer,num2str(i)];
    else
        RealPath{k}=[DataPath,name2,num2str(i),fjsp];
        ResultPath{k}=[name2,num2str(i)];
    end   
    k=k+1;    
end
for i=1:18
    if i<10
        RealPath{k}=[DataPath,name,zer,num2str(i),fjsp];
        ResultPath{k}=[name,zer,num2str(i)];
    else
        RealPath{k}=[DataPath,name,num2str(i),fjsp];
        ResultPath{k}=[name,num2str(i)];
    end   
    k=k+1;     
end

global  N H SH NM ps M TM time AP AM AF AN;

fout=fopen('parameter.txt','r');
A=fscanf(fout,'%d %d %d %f %f %f');
fclose(fout);
MaxNFEs=A(1);%������۴���
ps=A(2);%��Ⱥ��С
HL=A(3);%��ʷ��¼�ĳ���
S=A(4);%SPA��������
Pc=A(5);%crossover��������
Pm=A(6);%mutation��������

RP=[[0,0],[5,0],[10,0],[0,5],[0,10]];%GDָ����Ҫ�Ĳο���

for File=1:20
    [N,TM,H,NM,M,SH,time]=DataRead(RealPath{File});
     
    respath='timeresult\';
    tmp6='\';
    respath=[respath,ResultPath{File},tmp6];
    %����޹ر���
    clear tmp6
    a=['mkdir ' respath];%����д������ļ���
    system(a);%����Windows����������ִ��dos����
    fprintf('%s %s\r\n','Calculating ',RealPath{File});
    for round=1:10   
    CV=[];
    starttime=cputime;
    [p_chrom,m_chrom,f_chrom]=initial();
    
    NFEs=0;
    
    fitness=zeros(ps,3);
    for i=1:ps
        [fitness(i,1),fitness(i,2),fitness(i,3)]=fitDFJSP(p_chrom(i,:),m_chrom(i,:),f_chrom(i,:));
        NFEs=NFEs+1;
    end  
    
    AP=[];AM=[];AF=[];AN=[];
     % Suprisely popular Algorithm VNS
   numst=4;
   pfit = ones(1, numst)./4;
   normfit=zeros(1, numst); 
   NS=[];NF=[];NP=[];
   ER=zeros(1,numst);% Elimate success rate
   SR=zeros(1,numst);% Success rate
   SPD=zeros(1,numst);% Suprisely popular degree
   for i=1:numst
        ER(i)=0.5;
   end  
   i=1;
    while NFEs<MaxNFEs %����������
    
     fprintf('%s %s %d %s %d\r\n',RealPath{File},'round',round,'iter',i);
        i=i+1;
   
     [Par_p,Par_m,Par_f,Par_Fit]=TSelection(p_chrom,m_chrom,f_chrom,fitness);
     CP=[];CM=[];CN=[];CF=[];
     %MOIG
      for j=1:ps
        [new_p1,new_m1,new_f1,new_p2,new_m2,new_f2]= evolution(Par_p,Par_m,Par_f,j,Pc,Pm);
        [f1(1,1),f1(1,2),f1(1,3)]=fitDFJSP(new_p1,new_m1,new_f1);
        [f2(1,1),f2(1,2),f2(1,3)]=fitDFJSP(new_p2,new_m2,new_f2);
        NFEs=NFEs+2;
            
           CP=[CP;new_p1;new_p2];CM=[CM;new_m1;new_m2];CN=[CN;new_f1;new_f2];CF=[CF;f1;f2]; %��������Ⱥ
      end%J END
     
      %����ѡ��
      QP=[];QM=[];QN=[];QF=[];
      QP=[p_chrom;CP];QM=[m_chrom;CM];QN=[f_chrom;CN];QF=[fitness;CF];
      [QP,QM,QN,QF]=DeleteRpeatQF(QP,QM,QN,QF);
      [TopPSRank]=FastNDS(QF);

      %��������Ⱥ
      p_chrom=QP(TopPSRank,:);m_chrom=QM(TopPSRank,:);f_chrom=QN(TopPSRank,:);fitness=QF(TopPSRank,:);
      %Energy-saving 
      for j=1:ps
          [p_chrom(j,:),m_chrom(j,:),f_chrom(j,:),fitness(j,:)]=EnergySaveDFJSP(p_chrom(j,:),m_chrom(j,:),f_chrom(j,:),fitness(j,:));
        NFEs=NFEs+1;
      end
      
    %Update Elite Archive
    [PF,~]=pareto1(fitness);
    AP=[AP;p_chrom(PF,:)];AM=[AM;m_chrom(PF,:)];AN=[AN;f_chrom(PF,:)];AF=[AF;fitness(PF,:)];   
    [PF,~]=pareto1(AF);
    AP=AP(PF,:);AM=AM(PF,:);AN=AN(PF,:);AF=AF(PF,:);
    DeleteRpeat();

    [L,~]=size(AP);
    poolsize=L*numst;
    %SPA
      rr = rand;
        spacing = 1/poolsize;
         randnums = sort(mod(rr : spacing : 1 + rr - 0.5 * spacing, 1));

        sumfit=0;
        for j=1:numst%���Ӹ��ʹ�һ��
          sumfit=pfit(j)+sumfit;
        end
        for j=1:numst        
          normfit(j)=pfit(j)/sumfit;
          if normfit(j)<0.1
             normfit(j)=0.1; 
          end      
        end
        if sum(normfit)>1
            d=sum(normfit)-1;
           [~,index]= max(normfit);
           normfit(index)=normfit(index)-d;
        end
        %SPA
        for j=1:numst
            if i==1
                ER(j)=normfit(j);
            end
            SR(j)=normfit(j);
            SPD(j)=SR(j)/ER(j);
            ER(j)=SR(j);
            if SPD(j)>1
                normfit(j)=normfit(j)+S;
            end
        end
        
        d=sum(normfit);
        for j=1:numst
            normfit(j)=normfit(j)/d;
        end
        partsum = 0;
        count(1) = 0;
        stpool = [];
           
        for j = 1 : length(pfit)
            partsum = partsum + normfit(j);
            count(j + 1) = length(find(randnums < partsum));
            select(j, 1) = count(j + 1) - count(j);
            stpool = [stpool; ones(select(j, 1), 1) * j];
        end
        stpool = stpool(randperm(poolsize));
        scount=zeros(1,numst);%��¼��һ�����ӵ�ѡ���и������ӳɹ��Ĵ���
        lcount=zeros(1,numst);%��¼��һ�����ӵ�ѡ���и�������ʧ�ܵĴ���
    
      
      
      for j=1:L
          for k=1:numst
              t=numst*(j-1)+k;
%           chooseA=stpool(t);
            chooseA=2;
            switch chooseA
                case{1}
                    [P1,M1,N1]=LS3(AP(j,:),AM(j,:),AN(j,:),AF(j,:));%���������
                case{2}
                    [P1,M1,N1]=LS5(AP(j,:),AM(j,:),AN(j,:),AF(j,:));%���������
                case{3}
                    [P1,M1,N1]=LSRFA(AP(j,:),AM(j,:),AN(j,:),AF(j,:));%���������
                case{4}
                    [P1,M1,N1]=LSRMS(AP(j,:),AM(j,:),AN(j,:),AF(j,:));%���������
            end
            [F1(1,1),F1(1,2),F1(1,3)]=fitDFJSP(P1,M1,N1);
            NFEs=NFEs+1;
            if NDS(F1,AF(j,:))==1 %�½�֧��ɽ�
                AP(j,:)=P1;
                AM(j,:)=M1;
                AN(j,:)=N1;
                AF(j,:)=F1;
                AP=[AP;P1];
                AM=[AM;M1];
                AF=[AF;F1];
                AN=[AN;N1];
                scount(chooseA)=scount(chooseA)+1;%��Ӧ���ӳɹ�����+1                    
            elseif NDS(F1,AF(j,:))==0 %�½⻥��֧��ɽ�
                if F1(1,1)~=AF(j,1)&&F1(1,2)~=AF(j,2)
                AP=[AP;P1];
                AM=[AM;M1];
                AF=[AF;F1];
                AN=[AN;N1];
                scount(chooseA)=scount(chooseA)+1;%��Ӧ���ӳɹ�����+1     
                else
                    lcount(chooseA)=lcount(chooseA)+1;%��Ӧ����ʧ�ܴ���+1
                end   
            elseif NDS(F1,AF(j,:))==2 %�½ⱻ�ɽ�֧��
                lcount(chooseA)=lcount(chooseA)+1;%��Ӧ����ʧ�ܴ���+1
            end
          end%KEND
      end %JEND
      
      NS=[NS;scount];NF=[NF;lcount];NP=[NP;normfit];
        
        [k,~]=size(NS);
        
        if k >= HL
          [ns_row,~]=size(NS);
          [nf_row,~]=size(NF);
            for j = 1 : numst            
              sum_ns=0;sum_nf=0;
              for k=1:ns_row
                  sum_ns=sum_ns+NS(k,j);
              end
              for k=1:nf_row
                  sum_nf=sum_nf+NF(k,j);
              end
              if (sum_ns + sum_nf) == 0
                 pfit(j) = 0.01;
               else
                  pfit(j) = sum_ns / (sum_ns + sum_nf) + 0.01;
              end

            end
           if ~isempty(NS), NS(1, :) = [];  end%ɾ����һ��
           if ~isempty(NF), NF(1, :) = [];  end
        end

    end%IEND


    [PF,~]=pareto1(AF);
    AP=AP(PF,:);AM=AM(PF,:);AN=AN(PF,:);AF=AF(PF,:);

    totaltime=cputime-starttime;
    [PF,~]=pareto1(AF);
    L=length(PF);
    obj=AF(:,1:2);
    newobj=[];
    for i=1:L
        newobj(i,:)=obj(PF(i),:);   
    end
    newobj=unique(newobj,'rows');%ɾ���ظ���
    tmp5=newobj';%����õ�ǰ�ؽ⼯ת��
    %scatter(newobj(:,1),newobj(:,2));
    tmp1='res';%�����ַ�����д������洢��·��
    resPATH=[respath tmp1 num2str(round) txt];
    fout=fopen(resPATH,'w');
    fprintf(fout,'%6.3f\r\n',totaltime);%����matlab�ǰ����д洢�Ͷ�ȡ������д���ļ���ʱ��Ҳ�ǰ�������д�����Ҫת�ô���
    fclose(fout);
    end
end