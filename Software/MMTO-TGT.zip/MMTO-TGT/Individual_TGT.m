classdef Individual_TGT < Individual

properties
    F
    CR
end
end
