classdef Individual_DCK < Individual

properties
    V
    F
    CR
    TRD
end
end
